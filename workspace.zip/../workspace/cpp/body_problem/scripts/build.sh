#!/bin/bash
set -euo pipefail

if [ $1 == "-c" ]; then
  clear
  echo "Compiling..."
  g++ \
  $(find cpp/body_problem/source -name "*.cpp") \
  -I$PREFIX/include/lua5.5 \
  -L$PREFIX/lib \
  -llua5.5 -lm -ldl \
  -o cpp/body_problem/body_problem.exe \
  -std=c++23 \
  -O3 \
  -mcpu=native \
  -ffast-math \
  -flto \
  -Wno-unused-result \
  -Wno-multichar \
  -Wno-overflow \
  -Wno-constant-conversion
elif [ $1 != "-nc" ]; then
  echo "Error: bad flag"
  exit 1
fi

if [ $# -eq 2 ]; then
  ./cpp/body_problem/body_problem.exe $2
else
  ./cpp/body_problem/body_problem.exe
fi

exit 0
