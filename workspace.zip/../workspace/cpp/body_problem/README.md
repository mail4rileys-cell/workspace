# Body Problem
  - A sandboxed runtime model of astrophysics

# Physics
  - Pairwise Newtonian gravity
  - Pairwise inelastic collisions (optional)
  - Pairwise radiation pressure
  - Elementwise radiative mass loss

# Units
  - All units match what is listed below, unless otherwise stated
  - Mass: kilograms (kg)
  - Distance: meters (m)
  - Time: seconds (s)
  - Everthing else: derived from the above

# User Interface
  - Simple textual graphics via seven views with configurable reference frames (SFML graphics update soon)
  - Simulation is concurrent, every real second is one day for the simulation
  - While the simulation runs, users can push commands which range from manipulating bodies to time skipping to saving and loading simulations

# Run and Build
  - Ensure that the current working directory is workspace
  - Run the following command: python3 cpp/body_problem/launch.py

# Supported Operating Systems
  - Linux (tested)
  - Windows (untested)

# System Requirements
  - 2 processors

# Compiler Requirements
  - C++23 or later

# Interpreter Requirements
  - Python 3 or later

# Dependencies
  - cpp/utils 4.0.0 or later