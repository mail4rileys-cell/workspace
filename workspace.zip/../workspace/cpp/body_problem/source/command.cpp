#include <memory>
// std::unique_ptr

#include <mutex>
// std::lock_guard
// std::mutex

#include <optional>
// std::optional

#include <string>
// std::string
// std::to_string

#include <utility>
// std::move

#include "command.hpp"
// Command
// CommandQueue

#include "result.hpp"
// Result

#include "types.hpp"
// scalar_t
// vector_t

#include "simulation.hpp"
// Simulation

#include "../../utils/physics.hpp"
// physics::


SimulateCommand::SimulateCommand(const scalar_t total_time, const scalar_t timestep) noexcept {
  this->total_time = total_time;
  this->timestep = timestep;
}

Result SimulateCommand::execute(Simulation& simulation) noexcept {
  if (this->total_time <= 0) {
    return {Flag::InvalidInput, "Batch time must be positive"};
  }
  if (this->timestep <= 0) {
    return {Flag::InvalidInput, "Timestep must be positive"};
  }
  if (this->total_time < this->timestep) {
    return {Flag::InvalidInput, "Batch cannot be less than timestep"};
  }
  simulation.system.simulate(this->total_time, this->timestep);
  return {Flag::Success, std::to_string(this->total_time / physics::EARTH_PERIOD<scalar_t>) + " yr simulated with " + std::to_string(this->timestep / 60.0L) + " min timestep"};
}


CreateBodyCommand::CreateBodyCommand(
  const std::string& anchor,
  const std::string& name,
  const scalar_t mass,
  const scalar_t radius,
  const scalar_t luminosity,
  const vector_t<scalar_t>& position,
  const vector_t<scalar_t>& velocity
) noexcept {
  this->anchor = anchor;
  this->name = name;
  this->mass = mass;
  this->radius = radius;
  this->position = position;
  this->velocity = velocity;
}

Result CreateBodyCommand::execute(Simulation& simulation) noexcept {
  if (this->anchor != "none") {
    const Body* anchor_ptr = simulation.system.get_body(this->anchor);
    if (anchor_ptr == nullptr) {
      return {Flag::NotFound, anchor + " not found"};
    }
    this->position += anchor_ptr->position;
    this->velocity += anchor_ptr->velocity;
  }
  if (this->name == "none") {
    return {Flag::InvalidInput, "Name cannot be none"};
  }
  if (this->mass == 0.0L) {
    return {Flag::InvalidInput, "Mass cannot be zero"};
  }
  if (this->radius == 0.0L) {
    return {Flag::InvalidInput, "Radius cannot be zero"};
  }
  if (this->luminosity < 0.0L) {
    return {Flag::InvalidInput, "Luminosity cannot be negative"};
  }
  return simulation.system.create_body(this->name, this->mass, this->radius, this->luminosity, this->position, this->velocity);
}


ModifyBodyCommand::ModifyBodyCommand(
  const std::string& name,
  const std::optional<scalar_t> mass,
  const std::optional<scalar_t> radius,
  const std::optional<scalar_t> luminosity,
  const std::optional<scalar_t> pos_x,
  const std::optional<scalar_t> pos_y,
  const std::optional<scalar_t> pos_z,
  const std::optional<scalar_t> vel_x,
  const std::optional<scalar_t> vel_y,
  const std::optional<scalar_t> vel_z
) noexcept {
  this->name = name;
  this->mass = mass;
  this->radius = radius;
  this->luminosity = luminosity;
  this->pos_x = pos_x;
  this->pos_y = pos_y;
  this->pos_z = pos_z;
  this->vel_x = vel_x;
  this->vel_y = vel_y;
  this->vel_z = vel_z;
}

Result ModifyBodyCommand::execute(Simulation& simulation) noexcept {
  Body* body = simulation.system.get_body(this->name);
  if (body == nullptr) {
    return {Flag::NotFound, this->name + " not found"};
  }
  if (this->mass) {
    body->mass = this->mass.value();
  }
  if (this->radius) {
    body->radius = this->radius.value();
  }
  if (this->luminosity) {
    body->luminosity = this->luminosity.value();
  }
  if (this->pos_x) {
    body->position.x = this->pos_x.value();
  }
  if (this->pos_y) {
    body->position.y = this->pos_y.value();
  }
  if (this->pos_z) {
    body->position.z = this->pos_z.value();
  }
  if (this->vel_x) {
    body->velocity.x = this->vel_x.value();
  }
  if (this->vel_y) {
    body->velocity.y = this->vel_y.value();
  }
  if (this->vel_z) {
    body->velocity.z = this->vel_z.value();
  }
  return {Flag::Success, this->name + " modified"};
}


DestroyBodyCommand::DestroyBodyCommand(const std::string& name) noexcept {
  this->name = name;
}

Result DestroyBodyCommand::execute(Simulation& simulation) noexcept {
  if (this->name == "none") {
    return {Flag::InvalidInput, "Name cannot be none"};
  }
  return simulation.system.destroy_body(this->name);
}


FocusViewCommand::FocusViewCommand(const std::size_t index, const std::string& name_one, const std::string& name_two) noexcept {
  this->index = index;
  this->name_one = name_one;
  this->name_two = name_two;
}

Result FocusViewCommand::execute(Simulation& simulation) noexcept {
  if ((this->index < 0) || (this->index > 6)) {
    return {Flag::InvalidInput, "Index must be 0, 1, 2, 3, 4, 5, or 6"};
  }
  if (this->name_one == "none") {
    return {Flag::InvalidInput, "Name one cannot be none"};
  }
  return simulation.display.views[this->index].focus(this->name_one, this->name_two);
}


ScaleViewCommand::ScaleViewCommand(const std::size_t index, const scalar_t radius) noexcept {
  this->index = index;
  this->radius = radius;
}

Result ScaleViewCommand::execute(Simulation& simulation) noexcept {
  if ((this->index < 0) || (this->index > 6)) {
    return {Flag::InvalidInput, "Index must be 0, 1, 2, 3, 4, 5, or 6"};
  }
  if (this-> radius <= 0.0) {
    return {Flag::InvalidInput, "Radius must be positive"};
  }
  return simulation.display.views[this->index].scale(this->radius);
}


Result PurgeBodiesCommand::execute(Simulation& simulation) noexcept {
  return simulation.system.purge_bodies();
}


Result ToggleCollisionsCommand::execute(Simulation& simulation) noexcept {
  simulation.system.collisions = !simulation.system.collisions;
  return {Flag::Success, "Collisions " + std::string(simulation.system.collisions ? "enabled" : "disabled")};
}


SaveCommand::SaveCommand(const std::string& filename) noexcept {
  this->filename = filename;
}

Result SaveCommand::execute(Simulation& simulation) noexcept {
  return simulation.save(this->filename);
}


LoadCommand::LoadCommand(const std::string& filename) noexcept {
  this->filename = filename;
}

Result LoadCommand::execute(Simulation& simulation) noexcept {
  return simulation.load(this->filename);
}


Result PauseResumeCommand::execute(Simulation& simulation) noexcept {
  simulation.pause = !simulation.pause;
  return {Flag::Success, "Simulation " + std::string(simulation.pause ? "paused" : "resumed")};
}


Result StopCommand::execute(Simulation& simulation) noexcept {
  simulation.stop = true;
  simulation.save("autosave");
  return {Flag::Success, "Simulation stopped"};
}


void CommandQueue::push(std::unique_ptr<Command> command) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->queue.push(std::move(command));
}

std::unique_ptr<Command> CommandQueue::pop() noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  if (this->queue.empty()) {
    return nullptr;
  }
  std::unique_ptr<Command> command = std::move(this->queue.front());
  this->queue.pop();
  return command;
}

bool CommandQueue::empty() const noexcept {
  std::lock_guard<std::mutex> lock (this->mtx);
  return this->queue.empty();
}