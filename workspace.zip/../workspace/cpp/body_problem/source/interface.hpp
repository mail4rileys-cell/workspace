#pragma once

#include <atomic>
// std::atomic

#include <cstddef>
// std::size_t

#include <memory>
// std::unique_ptr

#include <mutex>
// std::mutex

#include <queue>
// std::queue

#include <string>
// std::string

#include <thread>
// std::thread

#include "command.hpp"
// Command
// CommandQueue

#include "types.hpp"
// scalar_t

#include "../../utils/terminal.hpp"
// terminal::

#include "../../utils/windowlib.hpp"
// windowlib::


class Interface final {
  std::string buffer = "";
  mutable std::mutex mtx;
  std::thread input_thread;
  std::atomic<bool> running = {false};
  std::queue<std::unique_ptr<Command>> command_batch;
  CommandQueue& command_queue;

  void clear() noexcept;

  void write(const std::string& text) noexcept;

  void writeln(const std::string& text) noexcept;

  std::string get_text(const std::string& prompt) noexcept;

  scalar_t get_number(const std::string& prompt) noexcept;

  void confirm_command_menu(std::unique_ptr<Command> command) noexcept;

  void command_batch_menu() noexcept;

  void simulate_menu() noexcept;

  void create_body_menu() noexcept;

  void modify_body_menu() noexcept;

  void destroy_body_menu() noexcept;

  void purge_bodies_menu() noexcept;

  void toggle_collisions_menu() noexcept;

  void focus_view_menu() noexcept;

  void scale_view_menu() noexcept;

  void save_menu() noexcept;

  void load_menu() noexcept;

  void pause_resume_menu() noexcept;

  void stop_menu() noexcept;

  void main_menu() noexcept;

  public:

  terminal::Keyboard keyboard;

  __attribute__((cold, noinline))
  Interface(CommandQueue& command_queue) noexcept;

  [[nodiscard]] __attribute__((hot))
  std::string read() const noexcept;

  __attribute__((cold, noinline))
  void start() noexcept;

  __attribute__((cold, noinline))
  void stop() noexcept;
};


class InterfaceView final {
  Interface& interface;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept;

  [[nodiscard]] __attribute__((hot))
  windowlib::Window get_window() const noexcept;
};