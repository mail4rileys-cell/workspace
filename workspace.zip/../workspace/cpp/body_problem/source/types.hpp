#pragma once

#include "../../utils/physics.hpp"
// physics::

typedef long double scalar_t;

template<typename S>
using vector_t = physics::Vector3D<S>;