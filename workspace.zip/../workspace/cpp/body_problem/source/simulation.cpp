#include <cmath>
// cbrt

#include <cstddef>
// std::size_t

#include <cstdint>
// std::uintmax_t

#include <filesystem>
// std::filesystem::

#include <fstream>
// std::ifstream
// std::ofstream

#include <iomanip>
// std::scientific
// std::setprecision

#include <iostream>
// std::endl

#include <limits>
// std::numerical_limit

#include <string>
// std::string
// std::to_string
// std::stoull

#include "result.hpp"
// Flag
// Result

#include "types.hpp"
// scalar_t
// vector_t

#include "simulation.hpp"
// Body
// System
// SystemView
// Display
// Simulation

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

__attribute__((cold, noinline))
System::System() noexcept {
  for (std::size_t i = 0; i < this->bodies.size(); i++) {
    Body& a = this->bodies[i];
    for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
      Body& b = this->bodies[j];
      this->original_energy -= (physics::GRAVITATIONAL_CONSTANT<scalar_t> * a.mass * b.mass) / ((b.position - a.position)).get_magnitude();
    }
    const scalar_t speed = a.velocity.get_magnitude();
    this->original_energy += (a.mass * speed * speed) / 2;
  }
}

__attribute__((hot))
void System::simulate(const scalar_t total_time, const scalar_t timestep) noexcept {
  [[assume(total_time > 0)]];
  [[assume(timestep > 0)]];
  [[assume(total_time >= timestep)]];
  const std::uintmax_t steps = static_cast<std::uintmax_t>(total_time / timestep);
  this->energy = 0.0L;
  for (std::uintmax_t step = 0; step < steps; step++) {
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      Body& a = this->bodies[i];
      for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
        Body& b = this->bodies[j];
        const vector_t<scalar_t> displacement = b.position - a.position;
        const scalar_t distance = displacement.get_magnitude();
        const vector_t<scalar_t> unit_displacement = displacement / distance;
        const scalar_t potential_energy = (physics::GRAVITATIONAL_CONSTANT<scalar_t> * a.mass * b.mass) / distance;
        // gravity
        const vector_t<scalar_t> gravity = (unit_displacement * potential_energy) / distance;
        a.net_force += gravity;
        b.net_force -= gravity;
        // radiation pressure
        const scalar_t denominator = 4.0L * physics::LIGHTSPEED<scalar_t> * distance * distance;
        a.net_force -= (unit_displacement * b.luminosity * a.radius * a.radius) / denominator;
        b.net_force += (unit_displacement * a.luminosity * b.radius * b.radius) / denominator;
        if (step == (steps - 1)) {
          this->energy -= potential_energy;
        }
      }
      // integration
      a.velocity += (a.net_force / a.mass) * timestep;
      a.position += a.velocity * timestep;
      a.net_force = {0.0L, 0.0L, 0.0L};
      // radiative mass loss
      a.mass -= (a.luminosity / (physics::LIGHTSPEED<scalar_t> * physics::LIGHTSPEED<scalar_t>)) * timestep;
      if (step == (steps - 1)) {
        // kinetic energy
        const scalar_t speed = a.velocity.get_magnitude();
        this->energy += (a.mass * speed * speed) / 2;
      }
    }
    if (this->collisions) {
      for (std::size_t i = 0; i < this->bodies.size(); i++) {
        Body& a = this->bodies[i];
        for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
          Body& b = this->bodies[j];
          if ((b.position - a.position).get_magnitude() < (a.radius + b.radius)) {
            const Body merged = {
              a.mass + b.mass,
              std::cbrt((a.radius * a.radius * a.radius) + (b.radius * b.radius * b.radius)),
              a.luminosity + b.luminosity,
              ((a.position * a.mass) + (b.position * b.mass)) / (a.mass + b.mass),
              ((a.velocity * a.mass) + (b.velocity * b.mass)) / (a.mass + b.mass),
              {0.0L, 0.0L, 0.0L}
            };
            if (a.mass > b.mass) {
              this->bodies[i] = merged;
              this->destroy_body(this->names[j]);
            } else {
              this->bodies[j] = merged;
              this->destroy_body(this->names[i]);
            }
          }
        }
      }
    }
  }
  this->time += total_time;
}

[[nodiscard]] __attribute__((hot, pure))
Body* System::get_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      return &this->bodies[i];
    }
  }
  return nullptr;
}

__attribute__((cold, noinline))
Result System::create_body(
  const std::string& name,
  const scalar_t mass,
  const scalar_t radius,
  const scalar_t luminosity,
  const vector_t<scalar_t>& position,
  const vector_t<scalar_t>& velocity
) noexcept {
  if (this->get_body(name) != nullptr) {
    return {Flag::AlreadyExists, name + " already exists"};
  }
  this->names.push_back(name);
  this->bodies.push_back(Body(mass, radius, luminosity, position, velocity, {0, 0, 0}));
  return {Flag::Success, name + " created"};
}

__attribute__((cold, noinline))
Result System::destroy_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      this->names.erase(this->names.begin() + i);
      this->bodies.erase(this->bodies.begin() + i);
      return {Flag::Success, name + " destroyed"};
    }
  }
  return {Flag::NotFound, name + " not found"};
}

__attribute__((cold, noinline))
Result System::purge_bodies() noexcept {
  this->names.clear();
  this->bodies.clear();
  return {Flag::Success, "Bodies purged"};
}


__attribute__((cold, noinline))
SystemView::SystemView(
  System& system,
  const std::string& name_one,
  const std::string& name_two,
  const scalar_t radius,
  const std::size_t width,
  const std::size_t height
) noexcept : system(system) {
  this->name_one = name_one;
  this->name_two = name_two;
  this->radius = radius;
  this->width = width;
  this->height = height;
}

[[nodiscard]] __attribute__((hot, pure))
windowlib::Window SystemView::get_window() const noexcept {
  windowlib::Window window(this->height);
  vector_t<scalar_t> focus;
  if (this->name_two == "none") {
    const Body* body = this->system.get_body(this->name_one);
    if (body == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
    }
    focus = body->position;
  } else {
    const Body* body_one = this->system.get_body(this->name_one);
    if (body_one == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
    }
    const Body* body_two = this->system.get_body(this->name_two);
    if (body_two == nullptr) {
      window[0] = this->name_two + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return window;
    }
    focus = ((body_one->position * body_one->mass) + (body_two->position * body_two->mass)) / (body_one->mass + body_two->mass);
  }
  std::vector<std::vector<std::string>> grid(this->height, std::vector<std::string>(this->width, "  "));
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      grid[y][x] = "  ";
    }
  }
  for (std::size_t i = 0; i < this->system.bodies.size(); i++) {
    const vector_t<scalar_t> normal = physics::get_delta<vector_t, scalar_t>(focus, this->system.bodies[i].position) / this->radius;
    if ((normal.x < -1.0L) || (normal.x > 1.0L) || (normal.y < -1.0L) || (normal.y > 1.0L) || (normal.z < -1.0L) || (normal.z > 1.0L)) {
      continue;
    }
    const std::size_t x = static_cast<std::size_t>(((normal.x + 1.0L) * 0.5L * this->width));
    const std::size_t y = (this->height - 1) - static_cast<std::size_t>((normal.y + 1.0L) * 0.5L * this->height);
    if (grid[y][x] != "  ") {
      continue;
    }
    grid[y][x] = format::grayscale(format::pad_right(system.names[i], 2), (normal.z + 1.0L) * 0.5L);
  }
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      window[y] += grid[y][x];
    }
  }
  return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SystemView::get_name_one() const noexcept {
  return this->name_one;
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SystemView::get_name_two() const noexcept {
  return this->name_two;
}

[[nodiscard]] __attribute__((cold, noinline))
scalar_t SystemView::get_radius() const noexcept {
  return this->radius;
}

__attribute__((cold, noinline))
Result SystemView::focus(const std::string& name_one, const std::string& name_two) noexcept {
  this->name_one = name_one;
  this->name_two = name_two;
  return {Flag::Success, "View focused on " + this->name_one + " and " + this->name_two};
}

__attribute__((cold, noinline))
Result SystemView::scale(const scalar_t radius) noexcept {
  this->radius = radius;
  return {Flag::Success, "View scaled to " + std::to_string(this->radius) + " m"};
}


[[nodiscard]] __attribute__((hot, pure))
windowlib::Window Display::get_window(const std::size_t index) const noexcept {
  return this->views[index].get_window();
}


__attribute__((cold, noinline))
Simulation::Simulation(System& system, Display& display, const bool pause) noexcept
: system(system), display(display) {
  this->pause = pause;
}

__attribute__((cold, noinline))
Result Simulation::save(const std::string& filename) const noexcept {
  std::ifstream version_file("cpp/body_problem/version.txt");
  std::string version;
  version_file >> version;
  version_file.close();
  std::ofstream file("cpp/body_problem/saves/" + filename + ".sim");
  file << std::scientific << std::setprecision(std::numeric_limits<scalar_t>::max_digits10);
  file << "version = " << version << std::endl;
  file << std::endl;
  file << "system = {" << std::endl;
  for (std::size_t i = 0; i < this->system.bodies.size(); i++) {
    file << std::endl;
    file << "  " << this->system.names[i] << " = {" << std::endl;
    file << "    mass = " << this->system.bodies[i].mass << std::endl;
    file << "    radius = " << this->system.bodies[i].radius << std::endl;
    file << "    luminosity = " << this->system.bodies[i].luminosity << std::endl;
    file << "    position = {" << std::endl;
    file << "      x = " << this->system.bodies[i].position.x << std::endl;
    file << "      y = " << this->system.bodies[i].position.y << std::endl;
    file << "      z = " << this->system.bodies[i].position.z << std::endl;
    file << "    }" << std::endl;
    file << "    velocity = {" << std::endl;
    file << "      x = " << this->system.bodies[i].velocity.x << std::endl;
    file << "      y = " << this->system.bodies[i].velocity.y << std::endl;
    file << "      z = " << this->system.bodies[i].velocity.z << std::endl;
    file << "    }" << std::endl;
    file << "  }" << std::endl;
  }
  file << std::endl;
  file << "  time = " << this->system.time << std::endl;
  file << std::endl;
  file << "  collisions = " << this->system.collisions << std::endl;
  file << "}" << std::endl;
  file << std::endl;
  file << std::endl;
  file << "display = {" << std::endl;
  for (std::size_t i = 0; i < 7; i++) {
    file << std::endl;
    file << "  " << i << " = {" << std::endl;
    file << "    name_one = " << this->display.views[i].get_name_one() << std::endl;
    file << "    name_two = " << this->display.views[i].get_name_two() << std::endl;
    file << "    radius = " << this->display.views[i].get_radius() << std::endl;
    file << "  }" << std::endl;
  }
  file << "}" << std::endl;
  file.close();
  return {Flag::Success, "Simulation saved to " + filename};
}

__attribute__((cold, noinline))
Result Simulation::load(const std::string& filename) noexcept {
  if (!std::filesystem::exists("cpp/body_problem/saves/" + filename + ".sim")) {
    return {Flag::NotFound, filename + " not found"};
  }
  std::ifstream file("cpp/body_problem/saves/" + filename + ".sim");
  std::string token;
  while (file >> token) {
    if (token == "version") {
      file >> token; // "="
      std::ifstream version_file("cpp/body_problem/version.txt");
      std::string program_version;
      version_file >> program_version;
      version_file.close();
      std::string save_version;
      file >> save_version;
      if (save_version != program_version) {
        return {Flag::UnsupportedVersion, "Save file and program versions do not match"};
      }
    } else if (token == "system") {
      this->system.purge_bodies();
      this->system.time = 0.0L;
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        } else if (token == "time") {
          file >> token; // "="
          file >> this->system.time;
          continue;
        } else if (token == "collisions") {
          file >> token; // "="
          file >> this->system.collisions;
          continue;
        }
        std::string name = token;
        file >> token; // "="
        file >> token; // "{"
        scalar_t mass = 0.0L;
        scalar_t radius = 0.0L;
        scalar_t luminosity = 0.0L;
        vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
        vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "mass") {
            file >> token; // "="
            file >> mass;
          } else if (token == "radius") {
            file >> token; // "="
            file >> radius;
          } else if (token == "luminosity") {
            file >> token; // "="
            file >> luminosity;
          } else if (token == "position") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> position.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> position.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> position.z;
              }
            }
          } else if (token == "velocity") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> velocity.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> velocity.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> velocity.z;
              }
            }
          }
        }
        this->system.create_body(name, mass, radius, luminosity, position, velocity);
      }
    }
    else if (token == "display") {
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        }
        std::size_t index = std::stoull(token);
        file >> token; // "="
        file >> token; // "{"
        std::string name_one;
        std::string name_two;
        scalar_t radius;
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "name_one") {
            file >> token; // "="
            file >> name_one; // name_one
          } else if (token == "name_two") {
            file >> token; // "="
            file >> name_two; // name_two
          } else if (token == "radius") {
            file >> token; // "="
            file >> radius;
          }
        }
        this->display.views[index].focus(name_one, name_two);
        this->display.views[index].scale(radius);
      }
    }
  }
  file.close();
  return {Flag::Success, "Simulation loaded from " + filename};
}