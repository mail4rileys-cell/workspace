#pragma once

#include <cmath>
// std::sin
// std::cos

#include <cstddef>
// std::size_t

#include <string>
// std::string

#include "result.hpp"
// Result

#include "types.hpp"
// scalar_t
// vector_t

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::


struct Body final {
  scalar_t mass = 0.0L;
  scalar_t radius = 0.0L;
  scalar_t luminosity = 0.0L;
  vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> net_force = {0.0L, 0.0L, 0.0L};
};


struct System final {
  std::vector<std::string> names = {
    "Sun",
    "Mercury",
    "Venus",
    "Earth", "Moon",
    "Mars", "Phobos", "Deimos",
    "Jupiter", "Io", "Europa", "Ganymede", "Callisto",
    "Saturn", "Titan", "Rhea", "Iapetus", "Dione", "Tethys", "Enceladus", "Mimas", "Hyperion",
    "Uranus", "Titania", "Oberon", "Umbriel", "Ariel", "Miranda",
    "Neptune", "Triton", "Proteus", "Larissa", "Galatea", "Despina", "Thalassa", "Naiad",
    "Pluto", "Charon", //"Styx", "Nix", "Kerberos", "Hydra",
    "1Ceres", "2Vesta", "3Juno", "4Pallas",
    "Encke", "Halley"
  };
  #define PLANET(NAME) \
    { \
      physics:: NAME##_MASS<scalar_t>, \
      physics:: NAME##_RADIUS<scalar_t>, \
      0.0L, \
      {physics:: NAME##_DISTANCE<scalar_t>, 0.0L, 0.0L}, \
      vector_t<scalar_t>(0.0L, physics:: NAME##_SPEED<scalar_t>, 0.0L).rotated(physics:: NAME##_INCLINE<scalar_t>, physics::Axis::X), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #define MOON(NAME, PLANET) \
    { \
      physics:: NAME##_MASS<scalar_t>, \
      physics:: NAME##_RADIUS<scalar_t>, \
      0.0L, \
      {physics:: NAME##_DISTANCE<scalar_t> + physics:: PLANET##_DISTANCE<scalar_t>, 0.0L, 0.0L}, \
      vector_t<scalar_t>(0.0L, physics:: NAME##_SPEED<scalar_t>, 0.0L).rotated(physics:: NAME##_INCLINE<scalar_t>, physics::Axis::X).rotated(physics:: PLANET##_AXIAL<scalar_t>, physics::Axis::X) + vector_t<scalar_t>(0.0L, physics:: PLANET##_SPEED<scalar_t>, 0.0L).rotated(physics:: PLANET##_INCLINE<scalar_t>, physics::Axis::X), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  std::vector<Body> bodies = {
    {
      physics::SUN_MASS<scalar_t>,
      physics::SUN_RADIUS<scalar_t>,
      physics::SUN_LUMINOSITY<scalar_t>,
      {0.0L, 0.0L, 0.0L},
      {0.0L, 0.0L, 0.0L},
      {0.0L, 0.0L, 0.0L}
    },
      PLANET(MERCURY)
      PLANET(VENUS)
      PLANET(EARTH)
        MOON(MOON, EARTH)
      PLANET(MARS)
        MOON(PHOBOS, MARS)
        MOON(DEIMOS, MARS)
      PLANET(JUPITER)
        MOON(IO, JUPITER)
        MOON(EUROPA, JUPITER)
        MOON(GANYMEDE, JUPITER)
        MOON(CALLISTO, JUPITER)
      PLANET(SATURN)
        MOON(TITAN, SATURN)
        MOON(RHEA, SATURN)
        MOON(IAPETUS, SATURN)
        MOON(DIONE, SATURN)
        MOON(TETHYS, SATURN)
        MOON(ENCELADUS, SATURN)
        MOON(MIMAS, SATURN)
        MOON(HYPERION, SATURN)
      PLANET(URANUS)
        MOON(TITANIA, URANUS)
        MOON(OBERON, URANUS)
        MOON(UMBRIEL, URANUS)
        MOON(ARIEL, URANUS)
        MOON(MIRANDA, URANUS)
      PLANET(NEPTUNE)
        MOON(TRITON, NEPTUNE)
        MOON(PROTEUS, NEPTUNE)
        MOON(LARISSA, NEPTUNE)
        MOON(GALATEA, NEPTUNE)
        MOON(DESPINA, NEPTUNE)
        MOON(THALASSA, NEPTUNE)
        MOON(NAIAD, NEPTUNE)
      PLANET(PLUTO)
        MOON(CHARON, PLUTO)
        //MOON(STYX, PLUTO)
        //MOON(NIX, PLUTO)
        //MOON(KERBEROS, PLUTO)
        //MOON(HYDRA, PLUTO)

      PLANET(CERES)
      PLANET(VESTA)
      PLANET(JUNO)
      PLANET(PALLAS)

      PLANET(ENCKE)
      PLANET(HALLEY)
  };
  #undef PLANET
  #undef MOON
  scalar_t time = 0.0L;
  scalar_t original_energy = 0.0L;
  scalar_t energy = 0.0L;
  bool collisions = false;

  __attribute__((cold, noinline))
  System() noexcept;

  __attribute__((hot))
  void simulate(const scalar_t batch_time, const scalar_t timestep) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  Body* get_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result create_body(
    const std::string& name,
    const scalar_t mass,
    const scalar_t radius,
    const scalar_t luminosity,
    const vector_t<scalar_t>& position,
    const vector_t<scalar_t>& velocity
  ) noexcept;

  __attribute__((cold, noinline))
  Result destroy_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result purge_bodies() noexcept;
};


class SystemView final {
  System& system;
  std::string name_one;
  std::string name_two;
  scalar_t radius;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  SystemView(
    System& system,
    const std::string& name_one,
    const std::string& name_two,
    const scalar_t radius,
    const std::size_t width,
    const std::size_t height
  ) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_one() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_two() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  scalar_t get_radius() const noexcept;

  __attribute__((cold, noinline))
  Result focus(const std::string& name_one, const std::string& name_two) noexcept;

  __attribute__((cold, noinline))
  Result scale(const scalar_t radius) noexcept;
};


struct Display final {
  SystemView views[7];
  
  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window(const std::size_t index) const noexcept;
};


struct Simulation final {
  System& system;
  Display& display;
  bool pause = false;

  bool stop = false;

  __attribute__((cold, noinline))
  Simulation(System& system, Display& display, const bool pause) noexcept;

  __attribute__((cold, noinline))
  Result save(const std::string& filename) const noexcept;

  __attribute__((cold, noinline))
  Result load(const std::string& filename) noexcept;
};