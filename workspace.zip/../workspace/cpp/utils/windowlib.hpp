#pragma once

#include <cstddef>
// std::size_t

#include <iostream>
// std::cout
// std::endl

#include <string>
// std::string

#include <vector>
// std::vector

#include "format.hpp"
// format::

namespace windowlib {

  typedef std::vector<std::string> Window;

  __attribute__((hot))
  inline void render(const Window& window) noexcept {
    std::cout << "\033[H";
    std::cout.flush();
    for (std::size_t i = 0; i < window.size(); i++) {
      std::cout << window[i] << std::endl;
    }
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window horizontal(const Window& left, const Window& right) noexcept {
    const Window* shorter = nullptr;
    const Window* taller = nullptr;
    if (left.size() < right.size()) {
      shorter = &left;
      taller = &right;
    } else {
      shorter = &right;
      taller = &left;
    }
    Window result(taller->size());
    for (std::size_t i = 0; i < shorter->size(); i++) {
      result[i] = left[i] + right[i];
    }
    for (std::size_t i = shorter->size(); i < taller->size(); i++) {
      result[i] = (*taller)[i];
    }
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window vertical(const Window& top, const Window& bottom) noexcept {
    Window result(top.size() + bottom.size());
    for (std::size_t i = 0; i < top.size(); i++) {
      result[i] = top[i];
    }
    for (std::size_t i = 0; i < bottom.size(); i++) {
      result[i + top.size()] = bottom[i];
    }
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window border(const Window& window) noexcept {
    Window result(window.size() + 2);
    result[0] = "--";
    for (std::size_t i = 0; i < window[0].size(); i++) {
      result[0] += "-";
    }
    for (std::size_t i = 0; i < window.size(); i++) {
      result[i + 1] = "|" + window[i] + "|";
    }
    result[result.size() - 1] = "--";
    for (std::size_t i = 0; i < window[0].size(); i++) {
      result[result.size() - 1] += "-";
    }
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window title(const Window& window, const std::string& text) noexcept {
    Window result = border(window);
    result[0] = format::pad_center(text, result[0].size(), '-');
    return result;
  }
}