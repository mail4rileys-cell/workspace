// since 2.0.0

#pragma once

#include <cmath>
// std::sin
// std::cos
// std::atan2
// std::sqrt
// std::cbrt

#include <concepts>
// std::floating_point
// std::same_as

#include <cstdint>
// std::uint8_t

#include <stdexcept>
// std::runtime_error

#include <string>
// std::string
// std::to_string

#include <vector>
// std::vector

namespace physics { // SI units

  namespace units {

    #define UNIT(NAME, FACTOR) \
      inline constexpr long double operator"" _##NAME(const long double value) noexcept { \
        return value * (FACTOR); \
      }
    // end

    UNIT(mg, 1e-6L)
    UNIT(g, 1e-3L)
    UNIT(kg, 1.0L)

    UNIT(mm, 1e-3L)
    UNIT(m, 1.0L)
    UNIT(km, 1e3L)

    UNIT(ms, 1e-3L)
    UNIT(s, 1.0L)
    UNIT(min, 60.0L)
    UNIT(h, 3600.0L)

    UNIT(mps, 1.0L)
    UNIT(kmph, 5.0L / 18.0L)

    UNIT(mps2, 1.0L)

    UNIT(N, 1.0L)
    UNIT(J, 1.0L)
    UNIT(W, 1.0L)

    #undef UNIT
  }

  using namespace units;


  #define CONSTANT(NAME, VALUE) \
    template<typename scalar_t> \
    requires std::floating_point<scalar_t> \
    inline constexpr scalar_t NAME = static_cast<scalar_t>(VALUE);
  // end

  CONSTANT(PI, 3.14159265358979323846L)
  CONSTANT(GRAVITATIONAL_CONSTANT, 6.67430e-11L)
  CONSTANT(LIGHTSPEED, 299792458.0_mps)

  template<typename scalar_t>
  requires std::floating_point<scalar_t>
  inline consteval scalar_t degrees_to_radians(const scalar_t degrees) noexcept {
    return (degrees * PI<scalar_t>) / static_cast<scalar_t>(180.0L);
  }

  template<typename scalar_t>
  requires std::floating_point<scalar_t>
  inline consteval scalar_t radians_to_degrees(const scalar_t radians) noexcept {
    return (radians * static_cast<scalar_t>(180.0L)) / PI<scalar_t>;
  }

  inline consteval long double operator"" _deg(const long double degrees) noexcept {
    return degrees_to_radians<long double>(degrees);
  }

   CONSTANT(SUN_MASS, 1.98847e30_kg)
   CONSTANT(SUN_RADIUS, 6.957e8_m)
   CONSTANT(SUN_LUMINOSITY, 3.828e26_W)
   CONSTANT(SUN_DISTANCE, 0.0_m)
   CONSTANT(SUN_SPEED, 0.0_mps)
   CONSTANT(SUN_INCLINE, 0.0_deg)
   CONSTANT(SUN_AXIAL, 0.0_deg)
   CONSTANT(SUN_PERIOD, 0.0_s)

    CONSTANT(MERCURY_MASS, 3.3011e23_kg)
    CONSTANT(MERCURY_RADIUS, 2.4397e6_m)
    CONSTANT(MERCURY_DISTANCE, 5.7909227e10_m)
    CONSTANT(MERCURY_SPEED, 47360.0_mps)
    CONSTANT(MERCURY_INCLINE, 7.005_deg)
    CONSTANT(MERCURY_AXIAL, 0.034_deg)
    CONSTANT(MERCURY_PERIOD, 7.6005e6_s)

    CONSTANT(VENUS_MASS, 4.8675e24_kg)
    CONSTANT(VENUS_RADIUS, 6.0518e6_m)
    CONSTANT(VENUS_DISTANCE, 1.0820949e11_m)
    CONSTANT(VENUS_SPEED, 35020.0_mps)
    CONSTANT(VENUS_INCLINE, 3.394_deg)
    CONSTANT(VENUS_AXIAL, 177.36_deg)
    CONSTANT(VENUS_PERIOD, 1.9414e7_s)

    CONSTANT(EARTH_MASS, 5.97237e24_kg)
    CONSTANT(EARTH_RADIUS, 6.3710e6_m)
    CONSTANT(EARTH_DISTANCE, 1.495978707e11_m)
    CONSTANT(EARTH_SPEED, 29782.7_mps)
    CONSTANT(EARTH_INCLINE, 0.0_deg)
    CONSTANT(EARTH_AXIAL, 23.43928_deg)
    CONSTANT(EARTH_PERIOD, 3.15581e7_s)

      CONSTANT(MOON_MASS, 7.342e22_kg)
      CONSTANT(MOON_RADIUS, 1.7374e6_m)
      CONSTANT(MOON_DISTANCE, 3.84400e8_m)
      CONSTANT(MOON_SPEED, 1022.0_mps)
      CONSTANT(MOON_INCLINE, 10.0_deg)
      CONSTANT(MOON_PERIOD, 2.3606e6_s)

    CONSTANT(MARS_MASS, 6.4171e23_kg)
    CONSTANT(MARS_RADIUS, 3.3895e6_m)
    CONSTANT(MARS_DISTANCE, 2.2793925e11_m)
    CONSTANT(MARS_SPEED, 24077.0_mps)
    CONSTANT(MARS_INCLINE, 1.850_deg)
    CONSTANT(MARS_AXIAL, 25.19_deg)
    CONSTANT(MARS_PERIOD, 5.93544e7_s)

      CONSTANT(PHOBOS_MASS, 1.0659e16_kg)
      CONSTANT(PHOBOS_RADIUS, 1.1266e4_m)
      CONSTANT(PHOBOS_DISTANCE, 9.376e6_m)
      CONSTANT(PHOBOS_SPEED, 2138.0_mps)
      CONSTANT(PHOBOS_INCLINE, 1.093_deg)
      CONSTANT(PHOBOS_PERIOD, 2.758e4_s)

      CONSTANT(DEIMOS_MASS, 1.4762e15_kg)
      CONSTANT(DEIMOS_RADIUS, 6.2e3_m)
      CONSTANT(DEIMOS_DISTANCE, 2.345e7_m)
      CONSTANT(DEIMOS_SPEED, 1351.0_mps)
      CONSTANT(DEIMOS_INCLINE, 0.93_deg)
      CONSTANT(DEIMOS_PERIOD, 1.096e5_s)
    
    CONSTANT(JUPITER_MASS, 1.8982e27_kg)
    CONSTANT(JUPITER_RADIUS, 6.9911e7_m)
    CONSTANT(JUPITER_DISTANCE, 7.78412027e11_m)
    CONSTANT(JUPITER_SPEED, 1.3056e4_mps)
    CONSTANT(JUPITER_INCLINE, 1.304_deg)
    CONSTANT(JUPITER_AXIAL, 3.13_deg)
    CONSTANT(JUPITER_PERIOD, 3.743556e8_s)

      CONSTANT(IO_MASS, 8.9319e22_kg)
      CONSTANT(IO_RADIUS, 1.8216e6_m)
      CONSTANT(IO_DISTANCE, 4.217e8_m)
      CONSTANT(IO_SPEED, 1.731e4_mps)
      CONSTANT(IO_INCLINE, 0.036_deg)
      CONSTANT(IO_PERIOD, 1.52853e5_s)

      CONSTANT(EUROPA_MASS, 4.7998e22_kg)
      CONSTANT(EUROPA_RADIUS, 1.5608e6_m)
      CONSTANT(EUROPA_DISTANCE, 6.711e8_m)
      CONSTANT(EUROPA_SPEED, 1.374e4_mps)
      CONSTANT(EUROPA_INCLINE, 0.466_deg)
      CONSTANT(EUROPA_PERIOD, 3.06785e5_s)

      CONSTANT(GANYMEDE_MASS, 1.4819e23_kg)
      CONSTANT(GANYMEDE_RADIUS, 2.6341e6_m)
      CONSTANT(GANYMEDE_DISTANCE, 1.0704e9_m)
      CONSTANT(GANYMEDE_SPEED, 1.088e4_mps)
      CONSTANT(GANYMEDE_INCLINE, 0.20_deg)
      CONSTANT(GANYMEDE_PERIOD, 6.18153e5_s)

      CONSTANT(CALLISTO_MASS, 1.0759e23_kg)
      CONSTANT(CALLISTO_RADIUS, 2.4103e6_m)
      CONSTANT(CALLISTO_DISTANCE, 1.8827e9_m)
      CONSTANT(CALLISTO_SPEED, 8.204e3_mps)
      CONSTANT(CALLISTO_INCLINE, 0.28_deg)
      CONSTANT(CALLISTO_PERIOD, 1.44193e6_s)

    CONSTANT(SATURN_MASS, 5.6834e26_kg)
    CONSTANT(SATURN_RADIUS, 5.8232e7_m)
    CONSTANT(SATURN_DISTANCE, 1.43353e12_m)
    CONSTANT(SATURN_SPEED, 9.68e3_mps)
    CONSTANT(SATURN_INCLINE, 2.485_deg)
    CONSTANT(SATURN_AXIAL, 26.73_deg)
    CONSTANT(SATURN_PERIOD, 2.928e9_s)

      CONSTANT(TITAN_MASS, 1.3452e23_kg)
      CONSTANT(TITAN_RADIUS, 2.57473e6_m)
      CONSTANT(TITAN_DISTANCE, 1.22187e9_m)
      CONSTANT(TITAN_SPEED, 5.574e3_mps)
      CONSTANT(TITAN_INCLINE, 0.348_deg)
      CONSTANT(TITAN_PERIOD, 1.377e6_s)

      CONSTANT(RHEA_MASS, 2.3065e21_kg)
      CONSTANT(RHEA_RADIUS, 7.638e5_m)
      CONSTANT(RHEA_DISTANCE, 5.27108e8_m)
      CONSTANT(RHEA_SPEED, 8.48e3_mps)
      CONSTANT(RHEA_INCLINE, 0.345_deg)
      CONSTANT(RHEA_PERIOD, 3.908e5_s)

      CONSTANT(IAPETUS_MASS, 1.805e21_kg)
      CONSTANT(IAPETUS_RADIUS, 7.349e5_m)
      CONSTANT(IAPETUS_DISTANCE, 3.56082e9_m)
      CONSTANT(IAPETUS_SPEED, 3.26e3_mps)
      CONSTANT(IAPETUS_INCLINE, 8.298_deg)
      CONSTANT(IAPETUS_PERIOD, 6.852e6_s)

      CONSTANT(DIONE_MASS, 1.095e21_kg)
      CONSTANT(DIONE_RADIUS, 5.614e5_m)
      CONSTANT(DIONE_DISTANCE, 3.774e8_m)
      CONSTANT(DIONE_SPEED, 1.003e4_mps)
      CONSTANT(DIONE_INCLINE, 0.028_deg)
      CONSTANT(DIONE_PERIOD, 2.737e5_s)

      CONSTANT(TETHYS_MASS, 6.174e20_kg)
      CONSTANT(TETHYS_RADIUS, 5.311e5_m)
      CONSTANT(TETHYS_DISTANCE, 2.946e8_m)
      CONSTANT(TETHYS_SPEED, 1.135e4_mps)
      CONSTANT(TETHYS_INCLINE, 1.091_deg)
      CONSTANT(TETHYS_PERIOD, 1.888e5_s)

      CONSTANT(ENCELADUS_MASS, 1.080e20_kg)
      CONSTANT(ENCELADUS_RADIUS, 2.521e5_m)
      CONSTANT(ENCELADUS_DISTANCE, 2.379e8_m)
      CONSTANT(ENCELADUS_SPEED, 1.263e4_mps)
      CONSTANT(ENCELADUS_INCLINE, 0.009_deg)
      CONSTANT(ENCELADUS_PERIOD, 1.184e5_s)

      CONSTANT(MIMAS_MASS, 3.749e19_kg)
      CONSTANT(MIMAS_RADIUS, 1.982e5_m)
      CONSTANT(MIMAS_DISTANCE, 1.855e8_m)
      CONSTANT(MIMAS_SPEED, 1.432e4_mps)
      CONSTANT(MIMAS_INCLINE, 1.574_deg)
      CONSTANT(MIMAS_PERIOD, 8.19e4_s)

      CONSTANT(HYPERION_MASS, 5.62e18_kg)
      CONSTANT(HYPERION_RADIUS, 1.35e5_m)
      CONSTANT(HYPERION_DISTANCE, 1.4811e9_m)
      CONSTANT(HYPERION_SPEED, 4.92e3_mps)
      CONSTANT(HYPERION_INCLINE, 0.43_deg)
      CONSTANT(HYPERION_PERIOD, 2.138e6_s)
    
    CONSTANT(URANUS_MASS, 8.6810e25_kg)
    CONSTANT(URANUS_RADIUS, 2.5362e7_m)
    CONSTANT(URANUS_DISTANCE, 2.87246e12_m)
    CONSTANT(URANUS_SPEED, 6.81e3_mps)
    CONSTANT(URANUS_INCLINE, 0.76989_deg)
    CONSTANT(URANUS_AXIAL, 97.769_deg)
    CONSTANT(URANUS_PERIOD, 2.651e9_s)

      CONSTANT(TITANIA_MASS, 3.527e21_kg)
      CONSTANT(TITANIA_RADIUS, 7.889e5_m)
      CONSTANT(TITANIA_DISTANCE, 4.362e8_m)
      CONSTANT(TITANIA_SPEED, 3.64e3_mps)
      CONSTANT(TITANIA_INCLINE, 0.079_deg)
      CONSTANT(TITANIA_PERIOD, 7.391e5_s)

      CONSTANT(OBERON_MASS, 3.014e21_kg)
      CONSTANT(OBERON_RADIUS, 7.614e5_m)
      CONSTANT(OBERON_DISTANCE, 5.835e8_m)
      CONSTANT(OBERON_SPEED, 3.15e3_mps)
      CONSTANT(OBERON_INCLINE, 0.068_deg)
      CONSTANT(OBERON_PERIOD, 1.146e6_s)

      CONSTANT(UMBRIEL_MASS, 1.172e21_kg)
      CONSTANT(UMBRIEL_RADIUS, 5.847e5_m)
      CONSTANT(UMBRIEL_DISTANCE, 2.661e8_m)
      CONSTANT(UMBRIEL_SPEED, 4.67e3_mps)
      CONSTANT(UMBRIEL_INCLINE, 0.128_deg)
      CONSTANT(UMBRIEL_PERIOD, 4.118e5_s)

      CONSTANT(ARIEL_MASS, 1.353e21_kg)
      CONSTANT(ARIEL_RADIUS, 5.788e5_m)
      CONSTANT(ARIEL_DISTANCE, 1.909e8_m)
      CONSTANT(ARIEL_SPEED, 5.51e3_mps)
      CONSTANT(ARIEL_INCLINE, 0.260_deg)
      CONSTANT(ARIEL_PERIOD, 2.363e5_s)

      CONSTANT(MIRANDA_MASS, 6.59e19_kg)
      CONSTANT(MIRANDA_RADIUS, 2.358e5_m)
      CONSTANT(MIRANDA_DISTANCE, 1.299e8_m)
      CONSTANT(MIRANDA_SPEED, 6.66e3_mps)
      CONSTANT(MIRANDA_INCLINE, 4.338_deg)
      CONSTANT(MIRANDA_PERIOD, 1.236e5_s)

    CONSTANT(NEPTUNE_MASS, 1.024e26_kg)
    CONSTANT(NEPTUNE_RADIUS, 2.4622e7_m)
    CONSTANT(NEPTUNE_DISTANCE, 4.495e12_m)
    CONSTANT(NEPTUNE_SPEED, 5.43e3_mps)
    CONSTANT(NEPTUNE_INCLINE, 1.77_deg)
    CONSTANT(NEPTUNE_AXIAL, 28.32_deg)
    CONSTANT(NEPTUNE_PERIOD, 5.50e9_s)

      CONSTANT(TRITON_MASS, 2.14e22_kg)
      CONSTANT(TRITON_RADIUS, 1.3534e6_m)
      CONSTANT(TRITON_DISTANCE, 3.547e8_m)
      CONSTANT(TRITON_SPEED, 4.39e3_mps)
      CONSTANT(TRITON_INCLINE, 156.8_deg)
      CONSTANT(TRITON_PERIOD, 5.88e5_s)

      CONSTANT(PROTEUS_MASS, 5.0e19_kg)
      CONSTANT(PROTEUS_RADIUS, 2.10e5_m)
      CONSTANT(PROTEUS_DISTANCE, 1.176e8_m)
      CONSTANT(PROTEUS_SPEED, 7.60e3_mps)
      CONSTANT(PROTEUS_INCLINE, 0.1_deg)
      CONSTANT(PROTEUS_PERIOD, 1.17e5_s)

      CONSTANT(LARISSA_MASS, 4.9e18_kg)
      CONSTANT(LARISSA_RADIUS, 9.7e4_m)
      CONSTANT(LARISSA_DISTANCE, 7.35e7_m)
      CONSTANT(LARISSA_SPEED, 9.60e3_mps)
      CONSTANT(LARISSA_INCLINE, 0.2_deg)
      CONSTANT(LARISSA_PERIOD, 3.29e4_s)

      CONSTANT(GALATEA_MASS, 2.12e18_kg)
      CONSTANT(GALATEA_RADIUS, 8.8e4_m)
      CONSTANT(GALATEA_DISTANCE, 6.20e7_m)
      CONSTANT(GALATEA_SPEED, 1.05e4_mps)
      CONSTANT(GALATEA_INCLINE, 0.05_deg)
      CONSTANT(GALATEA_PERIOD, 2.73e4_s)

      CONSTANT(DESPINA_MASS, 2.1e18_kg)
      CONSTANT(DESPINA_RADIUS, 7.4e4_m)
      CONSTANT(DESPINA_DISTANCE, 5.24e7_m)
      CONSTANT(DESPINA_SPEED, 1.13e4_mps)
      CONSTANT(DESPINA_INCLINE, 0.07_deg)
      CONSTANT(DESPINA_PERIOD, 2.40e4_s)

      CONSTANT(THALASSA_MASS, 3.5e17_kg)
      CONSTANT(THALASSA_RADIUS, 4.05e4_m)
      CONSTANT(THALASSA_DISTANCE, 5.00e7_m)
      CONSTANT(THALASSA_SPEED, 1.16e4_mps)
      CONSTANT(THALASSA_INCLINE, 0.2_deg)
      CONSTANT(THALASSA_PERIOD, 2.30e4_s)

      CONSTANT(NAIAD_MASS, 1.9e17_kg)
      CONSTANT(NAIAD_RADIUS, 3.3e4_m)
      CONSTANT(NAIAD_DISTANCE, 4.82e7_m)
      CONSTANT(NAIAD_SPEED, 1.19e4_mps)
      CONSTANT(NAIAD_INCLINE, 4.7_deg)
      CONSTANT(NAIAD_PERIOD, 2.18e4_s)

    CONSTANT(PLUTO_MASS, 1.303e22_kg)
    CONSTANT(PLUTO_RADIUS, 1.1883e6_m)
    CONSTANT(PLUTO_DISTANCE, 5.90638e12_m)
    CONSTANT(PLUTO_SPEED, 4.67e3_mps)
    CONSTANT(PLUTO_INCLINE, 17.16_deg)
    CONSTANT(PLUTO_AXIAL, 122.53_deg)

      CONSTANT(CHARON_MASS, 1.586e21_kg)
      CONSTANT(CHARON_RADIUS, 6.06e5_m)
      CONSTANT(CHARON_DISTANCE, 1.9571e7_m)
      CONSTANT(CHARON_SPEED, 2.21e2_mps)
      CONSTANT(CHARON_INCLINE, 0.0_deg)

      CONSTANT(STYX_MASS, 3.0e14_kg)
      CONSTANT(STYX_RADIUS, 9.0e3_m)
      CONSTANT(STYX_DISTANCE, 4.22e7_m)
      CONSTANT(STYX_SPEED, 1.54e2_mps)
      CONSTANT(STYX_INCLINE, 0.81_deg)

      CONSTANT(NIX_MASS, 4.5e16_kg)
      CONSTANT(NIX_RADIUS, 2.0e4_m)
      CONSTANT(NIX_DISTANCE, 4.87e7_m)
      CONSTANT(NIX_SPEED, 1.42e2_mps)
      CONSTANT(NIX_INCLINE, 0.24_deg)

      CONSTANT(KERBEROS_MASS, 1.0e15_kg)
      CONSTANT(KERBEROS_RADIUS, 6.0e3_m)
      CONSTANT(KERBEROS_DISTANCE, 5.77e7_m)
      CONSTANT(KERBEROS_SPEED, 1.30e2_mps)
      CONSTANT(KERBEROS_INCLINE, 0.39_deg)

      CONSTANT(HYDRA_MASS, 4.8e16_kg)
      CONSTANT(HYDRA_RADIUS, 2.2e4_m)
      CONSTANT(HYDRA_DISTANCE, 6.47e7_m)
      CONSTANT(HYDRA_SPEED, 1.23e2_mps)
      CONSTANT(HYDRA_INCLINE, 0.81_deg)

    // The Asteriod Belt
    
    CONSTANT(CERES_MASS, 9.3839e20_kg)
    CONSTANT(CERES_RADIUS, 4.696e5_m)
    CONSTANT(CERES_DISTANCE, 4.14111e11_m)
    CONSTANT(CERES_SPEED, 1.79e4_mps)
    CONSTANT(CERES_INCLINE, 10.6_deg)

    CONSTANT(VESTA_MASS, 2.59076e20_kg)
    CONSTANT(VESTA_RADIUS, 2.626e5_m)
    CONSTANT(VESTA_DISTANCE, 3.536e11_m)
    CONSTANT(VESTA_SPEED, 1.93e4_mps)
    CONSTANT(VESTA_INCLINE, 7.14_deg)

    CONSTANT(JUNO_MASS, 2.82e19_kg)
    CONSTANT(JUNO_RADIUS, 1.17e5_m)
    CONSTANT(JUNO_DISTANCE, 3.99e11_m)
    CONSTANT(JUNO_SPEED, 1.79e4_mps)
    CONSTANT(JUNO_INCLINE, 12.99_deg)

    CONSTANT(PALLAS_MASS, 2.14e20_kg)
    CONSTANT(PALLAS_RADIUS, 2.56e5_m)
    CONSTANT(PALLAS_DISTANCE, 4.144e11_m)
    CONSTANT(PALLAS_SPEED, 1.79e4_mps)
    CONSTANT(PALLAS_INCLINE, 34.8_deg)

    // Comets

    CONSTANT(HALLEY_MASS, 2.2e14_kg)
    CONSTANT(HALLEY_RADIUS, 5.5e3_m)
    CONSTANT(HALLEY_DISTANCE, 8.766e10_m)
    CONSTANT(HALLEY_SPEED, 5.46e4_mps)
    CONSTANT(HALLEY_INCLINE, 162.26_deg)
    CONSTANT(HALLEY_PERIOD, 2.3769e9_s)

    CONSTANT(ENCKE_MASS, 5.79e13_kg)
    CONSTANT(ENCKE_RADIUS, 2.4e3_m)
    CONSTANT(ENCKE_DISTANCE, 4.98e10_m)
    CONSTANT(ENCKE_SPEED, 5.50e4_mps)
    CONSTANT(ENCKE_INCLINE, 11.8_deg)
    CONSTANT(ENCKE_PERIOD, 1.041e8_s)

  #undef CONSTANT

  #define OBJECT_T template<template<typename> class, typename> class object_t
  #define VECTOR_T template<typename> class vector_t
  #define SCALAR_T typename scalar_t

  enum class Axis : std::uint8_t {
    X = 0,
    Y = 1,
    Z = 2,
  };

  template<SCALAR_T>
  requires std::floating_point<scalar_t>
  struct Vector2D {
    scalar_t x = 0.0L;
    scalar_t y = 0.0L;


    inline Vector2D(const scalar_t a, const scalar_t b, const bool cartesian = true) noexcept {
      if (cartesian) {
        this->x = a;
        this->y = b;
      } else {
        this->x = a * std::cos(b);
        this->y = a * std::sin(b);
      }
    }

    inline Vector2D<scalar_t> operator+(const Vector2D<scalar_t>& vector) const noexcept {
      return {this->x + vector.x, this->y + vector.y};
    }

    inline Vector2D<scalar_t> operator+() const noexcept {
      return {+this->x, +this->y};
    }

    inline Vector2D<scalar_t>& operator+=(const Vector2D<scalar_t>& vector) noexcept {
      this->x += vector.x;
      this->y += vector.y;
      return *this;
    }

    inline Vector2D<scalar_t> operator-(const Vector2D<scalar_t>& vector) const noexcept {
      return {this->x - vector.x, this->y - vector.y};
    }

    inline Vector2D<scalar_t> operator-() const noexcept {
      return {-this->x, -this->y};
    }

    inline Vector2D<scalar_t>& operator-=(const Vector2D<scalar_t>& vector) noexcept {
      this->x -= vector.x;
      this->y -= vector.y;
      return *this;
    }

    inline Vector2D<scalar_t> operator*(const scalar_t scalar) const noexcept {
      return {this->x * scalar, this->y * scalar};
    }

    inline Vector2D<scalar_t>& operator*=(const scalar_t scalar) noexcept {
      this->x *= scalar;
      this->y *= scalar;
      return *this;
    }

    inline Vector2D<scalar_t> operator/(const scalar_t scalar) const noexcept {
      return {this->x / scalar, this->y / scalar};
    }

    inline Vector2D<scalar_t>& operator/=(const scalar_t scalar) noexcept {
      this->x /= scalar;
      this->y /= scalar;
      return *this;
    }

    inline Vector2D<scalar_t> rotated(const scalar_t theta) const noexcept {
      const scalar_t sin_theta = std::sin(theta);
      const scalar_t cos_theta = std::cos(theta);
      return {(this->x * cos_theta) - (this->y * sin_theta), (this->x * sin_theta) + (this->y *cos_theta)};
    }

    inline Vector2D<scalar_t>& rotate(const scalar_t theta) noexcept {
      *this = this->rotated(theta);
      return *this;
    }

    inline scalar_t get_magnitude() const noexcept {
      return std::sqrt((this->x * this->x) + (this->y * this->y));
    }
  };

  template<SCALAR_T>
  requires std::floating_point<scalar_t>
  struct Vector3D {
    scalar_t x = 0.0L;
    scalar_t y = 0.0L;
    scalar_t z = 0.0L;

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator+(const Vector3D<scalar_t>& vector) const noexcept {
      return {this->x + vector.x, this->y + vector.y, this->z + vector.z};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator+() const noexcept {
      return {+this->x, +this->y, +this->z};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator+=(const Vector3D<scalar_t>& vector) noexcept {
      this->x += vector.x;
      this->y += vector.y;
      this->z += vector.z;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator-(const Vector3D<scalar_t>& vector) const noexcept {
      return {this->x - vector.x, this->y - vector.y, this->z - vector.z};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator-() const noexcept {
      return {-this->x, -this->y, -this->z};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator-=(const Vector3D<scalar_t>& vector) noexcept {
      this->x -= vector.x;
      this->y -= vector.y;
      this->z -= vector.z;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator*(const scalar_t scalar) const noexcept {
      return {this->x * scalar, this->y * scalar, this->z * scalar};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator*=(const scalar_t scalar) noexcept {
      this->x *= scalar;
      this->y *= scalar;
      this->z *= scalar;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator/(const scalar_t scalar) const noexcept {
      return {this->x / scalar, this->y / scalar, this->z / scalar};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator/=(const scalar_t scalar) noexcept {
      this->x /= scalar;
      this->y /= scalar;
      this->z /= scalar;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure))
    inline Vector3D<scalar_t> rotated(const scalar_t theta, const Axis axis = Axis::Z) const {
      const scalar_t sin_theta = std::sin(theta);
      const scalar_t cos_theta = std::cos(theta);
      switch (axis) {
        case Axis::X: return {this->x, (this->y * cos_theta) - (this->z * sin_theta), (this->y * sin_theta) + (this->z * cos_theta)};
        case Axis::Y: return {(this->x * cos_theta) + (this->z * sin_theta), this->y, (-this->x * sin_theta) + (this->z * cos_theta)};
        case Axis::Z: return {(this->x * cos_theta) - (this->y * sin_theta), (this->x * sin_theta) + (this->y * cos_theta), this->z};
        default: throw std::runtime_error("Unrecognized axis");
      }
    }

    __attribute__((hot))
    inline Vector3D<scalar_t>& rotate(const scalar_t theta, const Axis axis = Axis::Z) noexcept {
      *this = this->rotated(theta, axis);
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure))
    inline scalar_t get_magnitude() const noexcept {
      return std::sqrt((this->x * this->x) + (this->y * this->y) + (this->z * this->z));
    }
  };


  template<VECTOR_T, SCALAR_T>
  concept Vector = requires (vector_t<scalar_t> a, vector_t<scalar_t> b, scalar_t c) {
    requires std::floating_point<scalar_t>;
    {a + b} -> std::same_as<vector_t<scalar_t>>;
    {+a} -> std::same_as<vector_t<scalar_t>>;
    {a += b} -> std::same_as<vector_t<scalar_t>&>;
    {a - b} -> std::same_as<vector_t<scalar_t>>;
    {-a} -> std::same_as<vector_t<scalar_t>>;
    {a -= b} -> std::same_as<vector_t<scalar_t>&>;
    {a * c} -> std::same_as<vector_t<scalar_t>>;
    {a *= c} -> std::same_as<vector_t<scalar_t>&>;
    {a / c} -> std::same_as<vector_t<scalar_t>>;
    {a /= c} -> std::same_as<vector_t<scalar_t>&>;
    {a.rotated(c)} -> std::same_as<vector_t<scalar_t>>;
    {a.rotate(c)} -> std::same_as<vector_t<scalar_t>&>;
    {a.get_magnitude()} -> std::same_as<scalar_t>;
  };

  template<VECTOR_T, SCALAR_T>
  requires Vector<vector_t, scalar_t>
  [[nodiscard]] __attribute__((hot, const))
  inline vector_t<scalar_t> get_delta(const vector_t<scalar_t>& a, const vector_t<scalar_t>& b) noexcept {
    return b - a;
  }

  #undef OBJECT_T
  #undef VECTOR_T
  #undef SCALAR_T
}