#pragma once

#include <mutex>
// std::mutex
// std::lock_guard

#include <string>
// std::string

#include <termios.h>

#include <unistd.h>

namespace terminal {

  inline termios& saved_state() noexcept {
    static termios state;
    return state;
  }

  inline bool& is_saved() noexcept {
    static bool saved = false;
    return saved;
  }

  inline void disable_echo() noexcept {
    termios current;
    tcgetattr(STDIN_FILENO, &current);
    if (!is_saved()) {
      saved_state() = current;
      is_saved() = true;
    }
    termios modified = current;
    modified.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &modified);
  }

  inline void enable_echo() noexcept {
    if (!is_saved()) {
      return;
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &saved_state());
  }

  static termios oldt;

  inline void enable_raw() noexcept {
    termios newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  }

  inline void disable_raw() noexcept {
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  }

  inline char get_key() noexcept {
    char ch;
    ssize_t n = read(STDIN_FILENO, &ch, 1);
    if (n == 1) {
      return ch;
    }
    return 0;
  }

  class Keyboard final {
    std::string buffer;
    bool commited = false;
    mutable std::mutex mtx;

    inline void clear() noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      this->buffer = "";
    }

    inline void push(const char ch) noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      this->buffer += ch;
    }

    inline void backspace() noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      if (!this->buffer.empty()) {
        this->buffer.pop_back();
      }
    }

    public:

    Keyboard() = default;

    inline std::string read() const noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      return this->buffer;
    }

    inline std::string get_line() noexcept {
      this->clear();
      while (true) {
        const char ch = get_key();
        if (ch == '\n') {
          return this->read();
        }
        if ((ch == 127) || (ch == 8)) {
          this->backspace();
        } else {
          this->push(ch);
        }
      }
    }
  };
}