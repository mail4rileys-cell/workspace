(1..10).each do |i|
  i.times do
    print i.to_s + " "
  end
  puts
end