# since 1.1.0

import collections.abc as abc
import typing

from .typecheck import typecheck

def make_formatter(code: str) -> typing.Callable:
  def formatter(text: str) -> str:
    return f"\033[{code}m{text}\033[0m"
  return formatter

for prefix, code in (("", 30), ("bg_", 40), ("bright_", 90), ("bg_bright_", 100)):
  for colour in ("black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"):
    globals()[prefix + colour] = make_formatter(code)
    code += 1

code = 1
for effect in ("bold", "dim", "italic", "underline", "blink", "rapid_blink", "reverse", "hidden", "strikethrough"):
  globals()[effect] = make_formatter(code)
  code += 1

del make_formatter
del prefix
del colour
del effect
del code

@typecheck
def chain(text: str, *funcs: abc.Iterable[abc.Iterable[typing.Callable] | typing.Callable]) -> str:
  if len(funcs) == 1 and isinstance(funcs[0], abc.Iterable):
    funcs = funcs[0]
  for func in funcs:
    text = func(text)
  return text