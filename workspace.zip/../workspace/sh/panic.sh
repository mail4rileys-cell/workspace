#!/bin/bash
set -euo pipefail

echo "Panicking..."
zip -9 -r -q ../workspace.zip ../workspace
echo "Panic complete"
exit 0