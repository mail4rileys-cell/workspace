# 1.0.0
  - Original

# 1.1.0
  - Added format.hpp

# 2.0.0
  - Added physics.hpp
  - Added windowlib.hpp
  - Added bitwise.hpp
  - Added pad_left and pad_right in format.hpp
  - Moved bitwise functions out of math.hpp and into bitwise.hpp

# 2.1.0
  - Added terminal.hpp

# 2.1.1
  - Improved performance for windowlib.hpp

# 2.1.2
  - Improved performance for physics.hpp
  - Improved performance for windowlib.hpp

# 2.2.0
  - Added grayscale to format.hpp

# 2.3.0
  - Added pad_center to format.hpp
  - Added title to windowlib.hpp

# 3.0.0
  - Added potential energy to the return values for physics.hpp's get_gravity
  - Removed displacement from the return values for physics.hpp's get_gravity

# 3.1.0
  - Added enable raw to terminal.hpp
  - Added disable raw to terminal.hpp
  - Added get_key to terminal.hpp
  - Added Keyboard to terminal.hpp

# 4.0.0
  - Removed everything past Vectors from physics.hpp
  - Updated README.md