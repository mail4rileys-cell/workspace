local Vector = {}
Vector.__index = Vector

function Vector.new(x, y, z)
	return setmetatable({
		x = x,
		y = y,
		z = z
	}, Vector)
end

function Vector.__add(left, right)
	if right.x == nil or right.y == nil or right.z == nil then
		error("Vector.__add: right operand must be a Vector")
	end
	return Vector.new(
		left.x + right.x,
		left.y + right.y,
		left.z + right.z
	)
end

function Vector.__radd(left, right)
	if left.x == nil or left.y == nil or left.z == nil then
		error("Vector.__radd: left operand must be a Vector")
	end
	return Vector.new(
		left.x + right.x,
		left.y + right.y,
		left.z + right.z
	)
end

function Vector.__sub(left, right)
	if right.x == nil or right.y == nil or right.z == nil then
		error("Vector.__sub: right operand must be a Vector")
	end
	return Vector.new(
		left.x - right.x,
		left.y - right.y,
		left.z - right.z
	)
end

function Vector.__rsub(left, right)
	if left.x == nil or left.y == nil or left.z == nil then
		error("Vector.__rsub: left operand must be a Vector")
	end
	return Vector.new(
		left.x - right.x,
		left.y - right.y,
		left.z - right.z
	)
end
	

function Vector.__mul(vector, scalar)
	if type(scalar) ~= "number" then
		error("Vector.__mul: right operand must be a number")
	end
	return Vector.new(
		vector.x * scalar,
		vector.y * scalar,
		vector.z * scalar
	)
end

function Vector.__rmul(scalar, vector)
	if type(scalar) ~= "number" then
		error("Vector.__rmul: left operand must be a number")
	end
	return Vector.new(
		scalar * vector.x,
		scalar * vector.y,
		scalar * vector.z
	)
end

function Vector.__div(vector, scalar)
	if type(scalar) ~= "number" then
		error("Vector.__div: right operand must be a number")
	end
	return Vector.new(
		vector.x / scalar,
		vector.y / scalar,
		vector.z / scalar
	)
end

function Vector.__rdiv(any, vector)
	error("Vector.__rdiv: right operand cannot be a Vector")
end

function Vector:get_magnitude()
	return math.sqrt(
		(self.x * self.x)
		+ (self.y * self.y)
		+ (self.z * self.z)
	)
end

return Vector