# Magic 8 Ball
def Magic_8_Ball():
  print("\nMagic 8 Ball\n============\nHello. Type your yes or no question into the console, and await your fate...")
  m8b_program_outputs=("Yes - definitely","It is decidedly so","Without a doubt","Reply hazy, try again","Ask again later","Better not tell you now","My sources say no","Outlook not so good","Very doubtful")
  while(True):
    m8b_user_input=input("\n>: ")
    if(m8b_user_input=="Exit"):
      print("\nMagic 8 Ball terminated, returning to program selection...")
      break
    else:
      print("\n",random.choice(m8b_program_outputs))

# Number Guesser
def Number_Guesser():
  print("\nPick a number from 1-10, and this program will compare your input against its generation. Are you lucky enough to win? Play and find out.")
  ng_statistics=[]
  ng_terminator=False
  while(True):
    ng_user_input=input("\nNumber Guesser\n==============\nPick a number from 1-10, and this program will compare your input against its generation. Are you lucky enough to win? Play and find out.\n\nSelect an action\n1. Play\n2. Statistics\n3. Exit\n\n>: ")
    if(ng_user_input=="1"):
      while(True):
        while(True):
          ng_user_input_1=input("\nInput your number\n\n>: ")
          if(ng_user_input_1=="Exit"):
            ng_terminator=True
            break
          elif(not(ng_user_input_1.isdigit())):
            print("\nError: Invalid input.")
          elif(int(ng_user_input_1)<1)or(int(ng_user_input_1)>10):
            print("\nError: Invalid input.")
          else:
            break
            ng_terminator=False
        if(ng_terminator==True):
          break
        ng_user_input_1=int(ng_user_input_1)
        ng_program_output=random.randint(1,10)
        ng_statistics.append(ng_program_output)
        if(ng_user_input_1==ng_program_output):
          print("\nPerfect!\nYou chose:",ng_user_input_1,"\nThe program chose:",ng_program_output)
        elif(ng_user_input_1<ng_program_output):
          print("\nToo low!\nYou chose:",ng_user_input_1,"\nThe program chose:",ng_program_output)
        elif(ng_user_input_1>ng_program_output):
          print("\nToo high!\nYou chose:",ng_user_input_1,"\nThe program chose:",ng_program_output)
    elif(ng_user_input=="2"):
      while(True):
        ng_user_input=input("\nPick a number from 1-10 that you would like statistics on based off of recent plays of number guesser.\n\n>: ")
        if(ng_user_input=="Exit"):
          break
        else:
          ng_statistics_number=(ng_statistics.count(int(ng_user_input))/len(ng_statistics))*100
          print("\n",ng_statistics_number,"%")
    elif(ng_user_input=="3"):
      print("\nNumber Guesser terminated, returnin to main menu...")
      break
    else:
      print("\nError: Invalid input.")

# Helpline
def Helpline():
  print("\nHelpline\n========\nWhatever problem ails you, Helpline is here to help! Type a description of what troubles you into the console, and Helpine will make you feel better.")
  h_program_outputs=("Have you tried not being sad?","You just need to be more grateful for what you have.","Don't worry, things will get better.","You just haven't met the right person yet.","It's okay, we all get a little down sometimes.","You should meditate more often.","Have you tried going to the gym?","You should try practicing a more balanced diet.","Why don't you try being more mindful?","Might I suggest therapy?","It could be worse.","Just get over it.","That sucks.","It is what it is.","It's probably not as bad as you're making it seem.","I reccommend going out more.","Things don't look that bad to me.","It's all in your head, just chill out.","Life's too short to be worrying like this.","Kill yourself.")
  while(True):
    h_user_input=input("\n>: ")
    if(h_user_input=="Exit"):
      print("\nHelpline terminated, returning to main menu...")
      break
    else:
      print("\n",random.choice(h_program_outputs))

# Simple Calculator
def Simple_Calculator():
  def sc_confirmation():
    while(True):
      sc_user_input=input("\nSelect an action\n1. Continue\n2. Exit\n\n>: ")
      print()
      if(sc_user_input=="1"):
        return True
      elif(sc_user_input=="2"):
        return False
      else:
        print("\nError: Invalid Input")
  def sc_addition():
    while(True):
      sc_user_input_1=float(input("\nInput the first term\n\n>: "))
      sc_user_input_2=float(input("\nInput the second term\n\n>: "))
      sc_program_output=sc_user_input_1+sc_user_input_2
      print("\n",sc_user_input_1,"+",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  def sc_subtraction():
    while(True):
      sc_user_input_1=float(input("\nInput the first term\n\n>: "))
      sc_user_input_2=float(input("\nInput the second term\n\n>: "))
      sc_program_output=sc_user_input_1-sc_user_input_2
      print("\n",sc_user_input_1,"-",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  def sc_multiplication():
    while(True):
      sc_user_input_1=float(input("\nInput the first factor\n\n>: "))
      sc_user_input_2=float(input("\nInput the second factor\n\n>: "))
      sc_program_output=sc_user_input_1*sc_user_input_2
      print("\n",sc_user_input_1,"x",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  def sc_division():
    while(True):
      sc_user_input_1=float(input("\nInput the numerator\n\n>: "))
      sc_user_input_2=float(input("\nInput the denominator\n\n>: "))
      sc_user_input_2=float(sc_user_input_2)
      sc_program_output=sc_user_input_1/sc_user_input_2
      print("\n",sc_user_input_1,"/",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  def sc_exponentation():
    while(True):
      sc_user_input_1=float(input("\nInput the number\n\n>: "))
      sc_user_input_2=float(input("\nInput the exponent\n\n>: "))
      sc_program_output=sc_user_input_1**sc_user_input_2
      print("\n",sc_user_input_1,"^",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  def sc_modulation():
    while(True):
      sc_user_input_1=float(input("\nInput the first number\n\n>: "))
      sc_user_input_2=float(input("\nInput the second number\n\n>: "))
      sc_program_output=sc_user_input_1%sc_user_input_2
      print("\n",sc_user_input_1,"%",sc_user_input_2,"=",sc_program_output)
      if(sc_confirmation()==False):
        break
  while(True):
    sc_user_input=input("\nSimple Calculator\n=================\nSelect an operator\n1. Addition\n2. Subtraction\n3. Multiplication\n4. Division\n5. Exponentation\n6. Modulation\n7. Exit\n\n>: ")
    if(sc_user_input=="1"):
      print("\nAddition\n========")
      sc_addition()
    elif(sc_user_input=="2"):
      print("\nSubtraction\n===========")
      sc_subtraction()
    elif(sc_user_input=="3"):
      print("\nMultiplication\n==============")
      sc_multiplication()
    elif(sc_user_input=="4"):
      print("\nDivision\n========")
      sc_division()
    elif(sc_user_input=="5"):
      print("\nExponentation\n=============")
      sc_exponentation()
    elif(sc_user_input=="6"):
      print("\nModulation\n==========")
      sc_modulation()
    elif(sc_user_input=="7"):
      print("\nSimple Calculator terminated, returning to main menu...")
      break
    else:
      print("\nError: Invalid input")

# Dice Roller
def Dice_Roller():
  while(True):
    while(True):
      dr_user_input=input("\nDice Roller\n===========\nSelect a die\n1. D4\n2. D6\n3. D8\n4. D10\n5. D12\n6. D20\n7. D100\n8. Custom\n9. Exit\n\n>: ")
      if(dr_user_input=="1"):
        dr_die=4
      elif(dr_user_input=="2"):
        dr_die=6
      elif(dr_user_input=="3"):
        dr_die=8
      elif(dr_user_input=="4"):
        dr_die=10
      elif(dr_user_input=="5"):
        dr_die=12
      elif(dr_user_input=="6"):
        dr_die=20
      elif(dr_user_input=="7"):
        dr_die=100
      elif(dr_user_input=="8"):
        dr_die=int(input("\nInput the amount of sides\n\n>: "))
        dr_die=abs(dr_die)
      elif(dr_user_input=="9"):
        print("\nDice Roller terminated, returning to main menu...")
        dr_terminator=True
      if(dr_user_input in("1","2","3","4","5","6","7","8","9")):
        break
      else:
        print("\nError: Invalid input")
    if(dr_terminator==True):
      dr_terminator=False
      break
    dr_user_input_1=int(input("\nInput the amount of dice\n\n>: "))
    dr_user_input_1=abs(dr_user_input_1)
    dr_user_input_2=float(input("\nInput the modifier\n\n>: "))
    dr_program_output=[]
    while(dr_user_input_1>0):
      dr_program_output.append(random.randint(1,dr_die))
      dr_user_input_1+=-1
    print("\nIndividual dice:",dr_program_output,"\nTotal:",sum(dr_program_output),"+",dr_user_input_2,"=",sum(dr_program_output)+dr_user_input_2)

# Deck
def Deck():
  d_deck=[["A","♠"],["K","♠"],["Q","♠"],["J","♠"],["10","♠"],["9","♠"],["8","♠"],["7","♠"],["6","♠"],["5","♠"],["4","♠"],["3","♠"],["2","♠"],["A","♥"],["K","♥"],["Q","♥"],["J","♥"],["10","♥"],["9","♥"],["8","♥"],["7","♥"],["6","♥"],["5","♥"],["4","♥"],["3","♥"],["2","♥"],["A","♣"],["K","♣"],["Q","♣"],["J","♣"],["10","♣"],["9","♣"],["8","♣"],["7","♣"],["6","♣"],["5","♣"],["4","♣"],["3","♣"],["2","♣"],["A","♦"],["K","♦"],["Q","♦"],["J","♦"],["10","♦"],["9","♦"],["8","♦"],["7","♦"],["6","♦"],["5","♦"],["4","♦"],["3","♦"],["2","♦"]]
  while(True):
    d_user_input=input("\nDeck\n====\nSelect an action\n1. Draw\n2. Shuffle\n3. Reset\n4. Sort\n5. Status\n6. Exit\n\n>: ")
    if(d_user_input=="1"):
      d_user_input_1=int(input("\nDraw\n====\nInput the amount of cards to draw\n\n>: "))
      if(d_user_input_1>len(d_deck)):
        print("\nNot enough cards.")
      else:
        for d_draw_iteration in range(d_user_input_1):
          d_card=d_deck.pop(0)
          d_draw_iteration+=1
          print("\nCard",d_draw_iteration)
          if(d_card[0]=="10"):
            print("\n┌───────┐\n|",d_card[0],"   |\n|  ",d_card[1],"  |\n|   ",d_card[0],"|\n└───────┘")
          else:
            print("\n┌───────┐\n|",d_card[0],"    |\n|  ",d_card[1],"  |\n|    ",d_card[0],"|\n└───────┘")
    elif(d_user_input=="2"):
      random.shuffle(d_deck)
      print("\nDeck is shuffled.")
    elif(d_user_input=="3"):
      d_deck=[["A","♠"],["K","♠"],["Q","♠"],["J","♠"],["10","♠"],["9","♠"],["8","♠"],["7","♠"],["6","♠"],["5","♠"],["4","♠"],["3","♠"],["2","♠"],["A","♥"],["K","♥"],["Q","♥"],["J","♥"],["10","♥"],["9","♥"],["8","♥"],["7","♥"],["6","♥"],["5","♥"],["4","♥"],["3","♥"],["2","♥"],["A","♣"],["K","♣"],["Q","♣"],["J","♣"],["10","♣"],["9","♣"],["8","♣"],["7","♣"],["6","♣"],["5","♣"],["4","♣"],["3","♣"],["2","♣"],["A","♦"],["K","♦"],["Q","♦"],["J","♦"],["10","♦"],["9","♦"],["8","♦"],["7","♦"],["6","♦"],["5","♦"],["4","♦"],["3","♦"],["2","♦"]]
      print("\nDeck is reset.")
    elif(d_user_input=="4"):
      d_deck.sort()
      print("\nDeck is sorted.")
    elif(d_user_input=="5"):
      if(len(d_deck)>1):
        d_changing_word="cards"
      else:
        d_changing_word="card"
      print("\nContents:\n",d_deck,"\nQuantity:",len(d_deck),d_changing_word)
    elif(d_user_input=="6"):
      print("\nDeck terminated, returning to main menu...")
      break
    else:
      print("\nError: Invalid input.")

# Tic-Tac-Toe
def Tic_Tac_Toe():
  def ttt_board_format():
    print("\n|||||||||||\n||",ttt_board[0],ttt_board[1],ttt_board[2],"|| 1-3\n||",ttt_board[3],ttt_board[4],ttt_board[5],"|| 4-6\n||",ttt_board[6],ttt_board[7],ttt_board[8],"|| 7-9\n|||||||||||")
  def ttt_win_conditions():
    if(((ttt_board[0]==ttt_piece)and(ttt_board[1]==ttt_piece)and(ttt_board[2]==ttt_piece))or((ttt_board[3]==ttt_piece)and(ttt_board[4]==ttt_piece)and(ttt_board[5]==ttt_piece))or((ttt_board[6]==ttt_piece)and(ttt_board[7]==ttt_piece)and(ttt_board[8]==ttt_piece))):
      print("\n",ttt_player,"has made a horizontal line! They win this round.")
      return True
    if(((ttt_board[0]==ttt_piece)and(ttt_board[3]==ttt_piece)and(ttt_board[6]==ttt_piece))or((ttt_board[1]==ttt_piece)and(ttt_board[4]==ttt_piece)and(ttt_board[7]==ttt_piece))or((ttt_board[2]==ttt_piece)and(ttt_board[5]==ttt_piece)and(ttt_board[8]==ttt_piece))):
      print("\n",ttt_player,"has made a vertical line! They win this round.")
      return True
    if(((ttt_board[0]==ttt_piece)and(ttt_board[4]==ttt_piece)and(ttt_board[8]==ttt_piece))or((ttt_board[2]==ttt_piece)and(ttt_board[4]==ttt_piece)and(ttt_board[6]==ttt_piece))):
      print("\n",ttt_player,"has made a diagonal line! They win this round.")
      return True
    else:
      return False
  while(True):
    ttt_board=["_","_","_","_","_","_","_","_","_"]
    ttt_user_input=input("\nTic-Tac-Toe\n===========\nSelect an action\n1. Player versus player\n2. Player versus computer\n3. Exit\n\n>: ")
    if(ttt_user_input=="1"):
      ttt_player="Player one"
      while(True):
        ttt_board_format()
        print("\n",ttt_player)
        ttt_user_input_1=input(">: ")
        if(ttt_user_input_1=="Exit"):
          break
        elif(not(ttt_user_input_1.isdigit())):
          print("\nError: Invalid input.")
        elif(int(ttt_user_input_1)<1)or(int(ttt_user_input_1)>9):
          print("\nError: Invalid input.")
        elif(ttt_board[int(ttt_user_input_1)-1]in("X","O")):
          print("\nError: Invalid input.")
        else:
          if(ttt_player=="Player one"):
            ttt_board[int(ttt_user_input_1)-1]="X"
            ttt_piece="X"
            if(ttt_win_conditions()==True):
              ttt_board_format()
              break
            else:
              ttt_player="Player two"
          elif(ttt_player=="Player two"):
            ttt_board[int(ttt_user_input_1)-1]="O"
            ttt_piece="O"
            if(ttt_win_conditions()==True):
              ttt_board_format()
              break
            else:
              ttt_player="Player one"
    elif(ttt_user_input=="2"):
      while(True):
        ttt_board_format()
        ttt_user_input_1=input("\nYour turn\n>: ")
        if(ttt_user_input_1=="Exit"):
          break
        elif(not(ttt_user_input_1.isdigit())):
          print("\nError: Invalid input.")
        elif(int(ttt_user_input_1)<1)or(int(ttt_user_input_1)>9):
          print("\nError: Invalid input.")
        elif(ttt_board[int(ttt_user_input_1)-1]in("X","O")):
          print("\nError: Invalid input.")
        else:
          ttt_board[int(ttt_user_input_1)-1]="X"
          ttt_player="The player"
          ttt_piece="X"
          if(ttt_win_conditions()==True):
            ttt_board_format()
            break
          while(True):
            ttt_program_output=random.randint(0,8)
            if(not(ttt_board[ttt_program_output]in("X","O"))):
              ttt_board[ttt_program_output]="O"
              break
          ttt_player="The computer"
          ttt_piece="O"
          if(ttt_win_conditions()==True):
            ttt_board_format()
            break
    elif(ttt_user_input=="3"):
      print("\nTic-Tac-Toe terminated, returning to main menu...")
      break
    else:
      print("\nError: Invalid input.")

# chess_v1
def chess_v1():
  def c_exit_prompt():
    while(True):
      c_user_input=input("\nSelect an action\n1. Exit\n\n>: ")
      if(c_user_input=="1"):
        break
      else:
        print("\nError: Invalid input.")
  def c_friendly_fire_check():
    if(c_player=="Player one"):
      if(c_board[c_user_input_2]in("1P","1B","1N","1R","1Q","1K")):
        return True
      else:
        return False
    elif(c_player=="Player two"):
      if(c_board[c_user_input_2]in("2P","2B","2N","2R","2Q","2K")):
        return True
      else:
        return False
  def c_clear_path_check():
    c_rank_difference=c_user_input_1//8-c_user_input_2//8
    c_file_difference=c_user_input_1%8-c_user_input_2%8
    if(c_rank_difference>0)and(c_file_difference==0): # N
      c_direction=-8
    elif(c_rank_difference>0)and(c_file_difference<0): # NE
      c_direction=-7
    elif(c_rank_difference==0)and(c_file_difference<0): # E
      c_direction=1
    elif(c_rank_difference<0)and(c_file_difference<0): # SE
      c_direction=9
    elif(c_rank_difference<0)and(c_file_difference==0): # S
      c_direction=8
    elif(c_rank_difference<0)and(c_file_difference>0): # SW
      c_direction=7
    elif(c_rank_difference==0)and(c_file_difference>0): # W
      c_direction=-1
    elif(c_rank_difference>0)and(c_file_difference>0): # NW
      c_direction=-9
    c_simulated_tile=c_user_input_1+c_direction
    while(True):
      if(c_simulated_tile==c_user_input_2):
        return True
      elif(c_board[c_simulated_tile]!="{}"):
        return False
      else:
        c_simulated_tile+=c_direction
  c_game_menu="\nSelect an action\n1. Start turn\n2. Move history\n3. Save game\n4. Quit game"
  while(True):
    c_board_original=("1R","1N","1B","1K","1Q","1B","1N","1R","1P","1P","1P","1P","1P","1P","1P","1P","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","2P","2P","2P","2P","2P","2P","2P","2P","2R","2N","2B","2K","2Q","2B","2N","2R")
    c_user_input=input("\nchess_v1\n=====\nSelect an action\n1. New game\n2. Load game\n3. Rules\n4. Exit\n\n>: ")
    if(c_user_input in("1","2")):
      if(c_user_input=="2"):
        c_save_code=input("\nInput your save code here\n\n>: ")
        c_game_state=json.loads(c_save_code)
        print(c_game_state)
        c_board=c_game_state[0]
        c_board.reverse()
        c_player=c_game_state[1]
        c_advantage=c_game_state[2]
        c_player_one_score=c_game_state[3]
        c_player_two_score=c_game_state[4]
        c_move=c_game_state[5]
        c_en_passant_index=c_game_state[6]
        if(c_en_passant_index!=None):
          c_en_passant_index=63-c_en_passant_index
        c_player_one_short_castle=c_game_state[7]
        c_player_one_long_castle=c_game_state[8]
        c_player_two_short_castle=c_game_state[9]
        c_player_two_long_castle=c_game_state[10]
        c_previous_turn=c_game_state[11]
        c_move_history=c_game_state[12]
      else:
        c_board=list(c_board_original)
        c_player="Player one"
        c_player_one_score=39
        c_player_two_score=39
        c_move=1
        c_advantage="Nobody"
        c_en_passant_index=None
        c_player_one_short_castle="Available"
        c_player_one_long_castle="Available"
        c_player_two_short_castle="Available"
        c_player_two_long_castle="Available"
        c_previous_turn=["This","is","the","first","turn"]
        c_move_history=[]
      c_capture=None
      c_terminator=False
      while(True):
        if(c_en_passant_index!=None):
          c_en_passant_index=63-c_en_passant_index
          c_en_passant_coord=oct(c_en_passant_index)[2:]
        else:
          c_en_passant_coord=None
        if(c_previous_turn!=["This","is","the","first","turn"]):
          c_move_history.append(c_previous_turn)
        c_board.reverse()
        c_short_one_rook_moved=False
        c_long_one_rook_moved=False
        c_short_two_rook_moved=False
        c_long_two_rook_moved=False
        c_one_king_moved=False
        c_two_king_moved=False
        c_game_state=(c_board,c_player,c_advantage,c_player_one_score,c_player_two_score,c_move,c_en_passant_index,c_player_one_short_castle,
        c_player_one_long_castle,
        c_player_two_short_castle,
        c_player_two_long_castle,c_previous_turn,c_move_history)
        print(formatters.clear)
        print("\nTurn:",c_player,"// Move:",c_move,"     | P = Pawn (1pt)\n|||||||||||||||||||||||||||||    | B = Bishop (3pts)\n||",c_board[0],c_board[1],c_board[2],c_board[3],c_board[4],c_board[5],c_board[6],c_board[7],"|| 0_ | N = Knight (3pts)\n||",c_board[8],c_board[9],c_board[10],c_board[11],c_board[12],c_board[13],c_board[14],c_board[15],"|| 1_ | R = Rook (5pts)\n||",c_board[16],c_board[17],c_board[18],c_board[19],c_board[20],c_board[21],c_board[22],c_board[23],"|| 2_ | Q = Queen (9pts)\n||",c_board[24],c_board[25],c_board[26],c_board[27],c_board[28],c_board[29],c_board[30],c_board[31],"|| 3_ | K = King\n||",c_board[32],c_board[33],c_board[34],c_board[35],c_board[36],c_board[37],c_board[38],c_board[39],"|| 4_ | --------\n||",c_board[40],c_board[41],c_board[42],c_board[43],c_board[44],c_board[45],c_board[46],c_board[47],"|| 5_ |",c_advantage,"has the advantage\n||",c_board[48],c_board[49],c_board[50],c_board[51],c_board[52],c_board[53],c_board[54],c_board[55],"|| 6_ | Player one's score:",c_player_one_score,"\n||",c_board[56],c_board[57],c_board[58],c_board[59],c_board[60],c_board[61],c_board[62],c_board[63],"|| 7_ | Player two's score:",c_player_two_score,"\n|||||||||||||||||||||||||||||    | --------\n   _0 _1 _2 _3 _4 _5 _6 _7       | Player one short castle:",c_player_one_short_castle,"\n-------------------------------- | Player one long castle:",c_player_one_long_castle,"\nSelect an action                 | Player two short castle:",c_player_two_short_castle,"\n1. Start turn                    | Player two long castle:",c_player_two_long_castle,"\n2. Move history                  | --------\n3. Save game                     | En Passant available at:",c_en_passant_coord,"\n4. Quit game                     | --------\n                                 | Previous turn:",c_previous_turn[0],c_previous_turn[1],c_previous_turn[2],c_previous_turn[3],c_previous_turn[4])
        while(c_terminator==False):
          c_user_input=input("\n>: ")
          if(c_user_input=="1"):
            break
          elif(c_user_input=="2"):
            print("\n[START]")
            for c_move_history_iterator in range(len(c_move_history)):
              if(c_move_history_iterator==0):
                print("\nPlayer one")
              elif(c_move_history_iterator%2==0):
                print("\nPlayer one")
              elif(c_move_history_iterator%2!=0):
                print("\nPlayer two")
              c_old_turn=c_move_history[c_move_history_iterator]
              if(c_old_turn=="Short castle")or(c_old_turn=="Long castle"):
                print(c_old_turn)
              else:
                print(c_old_turn[0],c_old_turn[2],c_old_turn[3])
            print("\n[END]\n",c_game_menu)
          elif(c_user_input=="3"):
            c_save_code=json.dumps(c_game_state)
            print("\nYour save code:\n\n",c_save_code,"\n",c_game_menu)
          elif(c_user_input=="4"):
            while(True):
              c_user_input=input("\nAre you sure?\n1. Yes\n2. No\n\n>: ")
              if(c_user_input=="1"):
                c_terminator=True
                break
              elif(c_user_input=="2"):
                print(c_game_menu)
                c_terminator=False
                break
              else:
                print("\nError: Invalid input.")
          else:
            print("\nError: Inalid input.")
        if(c_terminator==True):
          break
        while(True):
          c_user_input_1=input("\nInput the piece location\n\n>: ")
          c_user_input_1=int(c_user_input_1,8)
          if(c_board[c_user_input_1]=="{}"):
            print("\nAction denied: Empty tile.")
          elif(c_player=="Player one")and(c_board[c_user_input_1]in("2P","2B","2N","2R","2Q","2K")):
            print("\nAction denied: Illegal move.")
          elif(c_player=="Player two")and(c_board[c_user_input_1]in("1P","1B","1N","1R","1Q","1K")):
            print("Action denied: Illegal move.")
          else:
            c_piece=c_board[c_user_input_1]
            c_board[c_user_input_1]="{}"
            break
        while(True):
          c_user_input_2=input("\nInput the target location\n\n>: ")
          c_user_input_2=int(c_user_input_2,8)
          c_previous_turn=(c_piece,oct(63-c_user_input_1)[2:],">>",c_board[c_user_input_2],oct(63-c_user_input_2)[2:])
          if(c_piece in("1P","2P")):
            if(c_user_input_1 in(48,49,50,51,52,53,54,55))and(c_user_input_2 in(c_user_input_1-8,c_user_input_1-16)):
              if(c_user_input_1-16==c_user_input_2):
                c_board[c_user_input_2+8]="en passant"
                c_en_passant_index=c_board.index("en passant")
                c_board[c_en_passant_index]="{}"
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                break
            elif(c_user_input_2 in(c_user_input_1-7,c_user_input_1-9)):
              if(c_board[c_user_input_2]!="{}"):
                if(c_friendly_fire_check()==False):
                  c_en_passant_index=None
                  break
              elif(c_en_passant_index!=None):
                if(c_user_input_2==c_en_passant_index):
                  c_previous_turn=(c_piece,oct(63-abs(c_user_input_1))[2:],"EP",c_board[c_user_input_2+8],oct(63-abs(c_user_input_2))[2:])
                  break
            elif(c_user_input_1-8==c_user_input_2):
              if(c_friendly_fire_check()==False):
                c_en_passant_index=None
                break
          elif(c_piece in("1B","2B")):
            if(c_user_input_1%7==c_user_input_2%7)or(c_user_input_1%9==c_user_input_2%9):
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                c_en_passant_index=None
                break
          elif((c_piece in("1N","2N"))):
            if(not(c_user_input_1//8==c_user_input_2//8))and(c_user_input_2 in(c_user_input_1-17,c_user_input_1-15,c_user_input_1-10,c_user_input_1-6,c_user_input_1+6,c_user_input_1+10,c_user_input_1+15,c_user_input_1+17)):
              if(c_friendly_fire_check()==False):
                c_en_passant_index=None
                break
          elif(c_piece in("1R","2R")):
            if(c_user_input_1//8==c_user_input_2//8):
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                if(c_piece=="1R"):
                  if(c_user_input_1==63):
                    c_short_one_rook_moved=True
                  elif(c_user_input_1==56):
                    c_long_one_rook_moved=True
                elif(c_piece=="2R"):
                  if(c_user_input_1==56):
                    c_short_two_rook_moved=True
                  elif(c_user_input_1==63):
                    c_long_two_rook_moved=True
                c_en_passant_index=None
                break
            elif(c_user_input_1%8==c_user_input_2%8):
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                if(c_piece=="1R"):
                  if(c_user_input_1==63):
                    c_short_one_rook_moved=True
                  elif(c_user_input_1==56):
                    c_long_one_rook_moved=True
                elif(c_piece=="2R"):
                  if(c_user_input_1==56):
                    c_short_two_rook_moved=True
                  elif(c_user_input_1==63):
                    c_long_two_rook_moved=True
                c_en_passant_index=None
                break
          elif(c_piece in("1Q","2Q")):
            if(c_user_input_1//8==c_user_input_2//8):
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                c_en_passant_index=None
                break
            elif((c_user_input_1%7==c_user_input_2%7)or(c_user_input_1%8==c_user_input_2%8)or(c_user_input_1%9==c_user_input_2%9)):
              if(c_friendly_fire_check()==False)and(c_clear_path_check()==True):
                c_en_passant_index=None
                break
          elif(c_piece in("1K","2K")):
            if(c_user_input_1//8==c_user_input_2//8)and(c_user_input_2 in(c_user_input_1-1,c_user_input_1+1)):
              if(c_friendly_fire_check()==False):
                if(c_piece=="1K"):
                  c_one_king_moved=True
                elif(c_piece=="2K"):
                  c_two_king_moved=True
                c_en_passant_index=None
                break
            elif(c_user_input_2 in(c_user_input_1-7,c_user_input_1-8,c_user_input_1-9,c_user_input_1+7,c_user_input_1+8,c_user_input_1+9)):
              if(c_friendly_fire_check()==False):
                if(c_piece=="1K"):
                  c_one_king_moved=True
                elif(c_piece=="2K"):
                  c_two_king_moved=True
                c_en_passant_index=None
                break
            elif(c_user_input_2 in(56,63)):
              if(c_piece=="1K")and(c_board[c_user_input_2]=="1R"):
                if(c_user_input_2==63)and(c_player_one_short_castle=="Available")and(c_board[61]=="{}")and(c_board[62]=="{}"):
                  c_board[62]="1K"
                  c_board[61]="1R"
                  c_piece="{}"
                  c_player_one_short_castle="Unavailable"
                  c_previous_turn=("Short castle","","","","")
                  c_en_passant_index=None
                  break
                elif(c_user_input_2==56)and(c_player_one_long_castle=="Available")and(c_board[57]=="{}")and(c_board[58]=="{}")and(c_board[59]=="{}"):
                  c_board[58]="1K"
                  c_board[59]="1R"
                  c_piece="{}"
                  c_player_one_long_castle="Unavailable"
                  c_previous_turn=("Long castle","","","","")
                  c_en_passant_index=None
                  break
              elif(c_piece=="2K")and(c_board[c_user_input_2]=="2R"):
                if(c_user_input_2==56)and(c_player_two_short_castle=="Available")and(c_board[57]=="{}")and(c_board[58]=="{}"):
                  c_board[57]="2K"
                  c_board[58]="2R"
                  c_piece="{}"
                  c_player_two_short_castle="Unavailable"
                  c_previous_turn=("Short castle","","","","")
                  c_en_passant_index=None
                  break
                elif(c_user_input_2==63)and(c_player_two_long_castle=="Available")and(c_board[60]=="{}")and(c_board[61]=="{}")and(c_board[62]=="{}"):
                  c_board[61]="2K"
                  c_board[60]="2R"
                  c_piece="{}"
                  c_player_two_long_castle="Unavailable"
                  c_previous_turn=("Long castle","","","","")
                  c_en_passant_index=None
                  break
          print("\nAction denied: Illegal move.")
        if((c_piece in("1P","2P"))and(c_user_input_2 in(0,1,2,3,4,5,6,7))):
          while(True):
            c_old_piece=c_piece
            c_user_input=input("\nA pawn has reached the end! Select your desired promotion for that pawn\n1. Bishop\n2. Knight\n3. Rook\n4. Queen\n\n>: ")
            if(c_user_input=="1"):
              if(c_piece=="1P"):
                c_piece="1B"
                c_player_one_score+=2
              elif(c_piece=="2P"):
                c_piece="2B"
                c_player_two_score+=2
            elif(c_user_input=="2"):
              if(c_piece=="1P"):
                c_piece="1N"
                c_player_one_score+=2
              elif(c_piece=="2P"):
                c_piece="2N"
                c_player_two_score+=2
            elif(c_user_input=="3"):
              if(c_piece=="1P"):
                c_piece="1R"
                c_player_one_score+=4
              elif(c_piece=="2P"):
                c_piece="2R"
                c_player_two_score+=4
            elif(c_user_input=="4"):
              if(c_piece=="1P"):
                c_piece="1Q"
                c_player_one_score+=8
              elif(c_piece=="2P"):
                c_piece="2Q"
                c_player_two_score+=8
            if(c_user_input in("1","2","3","4")):
              break
            else:
              print("\nError: Invalid input.")
          c_previous_turn=(c_old_piece,"Promoted to",c_piece,oct(63-abs(c_user_input_1))[2:],">>",c_board[c_user_input_2],oct(63-abs(c_user_input_2))[2:])
        c_capture=c_board[c_user_input_2]
        c_board[c_user_input_2]=c_piece
        if(c_en_passant_index!=None):
          if(c_piece in("1P","2P"))and(c_user_input_2==c_en_passant_index):
            c_capture=c_board[c_user_input_2+8]
            c_board[c_user_input_2+8]="{}"
            c_en_passant_index=None
        if(c_player=="Player one"):
          if(c_capture=="2P"):
            c_player_two_score+=-1
          elif(c_capture=="2B")or(c_capture=="2N"):
            c_player_two_score+=-3
          elif(c_capture=="2R"):
            c_player_two_score+=-5
          elif(c_capture=="2Q"):
            c_player_two_score+=-9
          c_player="Player two"
        elif(c_player=="Player two"):
          if(c_capture=="1P"):
            c_player_one_score+=-1
          elif(c_capture=="1B")or(c_capture=="1N"):
            c_player_one_score+=-3
          elif(c_capture=="1R"):
            c_player_one_score+=-5
          elif(c_capture=="1Q"):
            c_player_one_score+=-9
          c_player="Player one"
          c_move+=1
        if(c_player_one_score>c_player_two_score):
          c_advantage="Player one"
        elif(c_player_two_score>c_player_one_score):
          c_advantage="Player two"
        elif(c_player_one_score==c_player_two_score):
          c_advantage="Nobody"
        if(c_one_king_moved==True):
          c_player_one_short_castle="Unavailable"
          c_player_one_long_castle="Unavailable"
          c_one_king_moved==False
        elif(c_two_king_moved==True):
          c_player_two_short_castle="Unavailable"
          c_player_two_long_castle="Unavailable"
          c_two_king_moved=False
        elif(c_short_one_rook_moved==True):
          c_player_one_short_castle="Unavailable"
          c_short_one_rook_moved=False
        elif(c_long_one_rook_moved==True):
          c_player_one_long_castle="Unavailable"
          c_long_one_rook_moved=False
        elif(c_short_two_rook_moved==True):
          c_player_two_short_castle="Unavailable"
          c_short_two_rook_moved=False
        elif(c_long_two_rook_moved==True):
          c_player_two_long_castle="Unavailable"
          c_long_two_rook_moved=False
    elif(c_user_input=="3"):
      while(True):
        c_user_input=input("\nRules\n=====\nSelect a topic\n1. Objective\n2. How to play\n3. Controls\n4. Pieces\n5. Exit\n\n>: ")
        if(c_user_input=="1"):
          print("\nObjective\n=========\nTo win, you must put the opponent's king in a position where it is unable to occupy a safe tile within your opponent's next turn. The reverse also applies to you, so make sure to protect your king as well.")
          c_exit_prompt()
        elif(c_user_input=="2"):
          print("\nHow to play\n===========\nThis is a turn based game, where each player seeks to capture the other player's pieces. On your turn, you may move one piece and one piece only. If said piece moves into the space of an opponent's piece, your piece captures theirs. A captured piece is removed from the board, and their point value is subtracted from the opponent's score. An important thing to note is that a piece cannot move over or through enemy or allied pieces unless otherwise stated.")
          c_exit_prompt()
        elif(c_user_input=="3"):
          print("\nControls\n========\nOn your turn, the program will ask you for the coordinates of both the piece you want to move and where you want it to go. Unlike normal chess_v1, this program interperets coordinates based off of octal numerics. As such, the top left tile is referred to as 00, the one to its right is 01, and the one below 00 is 10. This continues on all the way to the bottom right tile, which is 77. During the game, the board itself will be accompanied with markers along the edges, which will assist you with this process.")
          c_exit_prompt()
        elif(c_user_input=="4"):
          print("\nPieces\n======\nHere you can access specifics of each piece, and a detailed description of how they act during the game.")
          while(True):
            c_user_input=input("\nSelect a piece\n1. Pawns\n2. Bishops\n3. Knights\n4. Rooks\n5. Queens\n6. Kings\n7. Exit\n\n>: ")
            if(c_user_input=="1"):
              print("\nPawns (P)\n=========\nThese pieces are a special case, with many nuances to their functions. Firstly, if a pawn hasn't moved yet, it may move two tiles forwards, it otherwise must move forwards one tile. Secondly, pawns cannot capture a piece by moving forwards. Instead, it must move diagonally forwards, and it can only move this way if doing so would capture a piece. Thirdly, if a pawn reaches the end of the board and can move no more, it recieves a promotion. This promotion transforms it into another kind of piece, remaining as a pawn is not an option. Fourthly, if a pawn moves two tiles, the tile behind it becomes vulnerable to diagnonal captures from other pawns for the next round, this is called En Passant.\n\nPawn movement  | Pawn capture move | Pawn first move\n=============  | ================= | ===============\n{} {} {} {} {} | {} {} {} {} {}    | {} {} XX {} {}\n{} {} XX {} {} | {} XX {} XX {}    | {} {} XX {} {}\n{} {} _P {} {} | {} {} _P {} {}    | {} {} _P {} {}\n{} {} {} {} {} | {} {} {} {} {}    | {} {} {} {} {}\n{} {} {} {} {} | {} {} {} {} {}    | {} {} {} {} {}")
              c_exit_prompt()
            elif(c_user_input=="2"):
              print("\nBishops (B)\n===========\nThese pieces can move an infinite amount in any diagonal direction.\n\nBishop movement\n===============\nXX {} {} {} XX\n{} XX {} XX {}\n{} {} _B {} {}\n{} XX {} XX {}\nXX {} {} {} XX")
              c_exit_prompt()
            elif(c_user_input=="3"):
              print("\nKnights (N)\n===========\nThese pieces are unique in the sense that they can move through other pieces. The way they move is also unique: A knight must move two tiles in a straight direction, and then one tile in a direction that is perpendicular to the first jump. Knights may only capture on the second jump.\n\nKnight movement\n{} XX {} XX {}\nXX {} {} {} XX\n{} {} _N {} {}\nXX {} {} {} XX\n{} XX {} XX {}")
              c_exit_prompt()
            elif(c_user_input=="4"):
              print("\nRooks (R)\n=========\nThese pieces can move an infinite amount in any straight direction. Once a rook has moved, it becomes ineligble for castling. For more information on castling, see: Rules >> Pieces >> Kings\n\nRook movement\n=============\n{} {} XX {} {}\n{} {} XX {} {}\nXX XX _R XX XX\n{} {} XX {} {}\n{} {} XX {} {}")
              c_exit_prompt()
            elif(c_user_input=="5"):
              print("\nQueens (Q)\n==========\nThese pieces can move an infinite amount in all directions.\n\nQueen movement\n==============\nXX {} XX {} XX\n{} XX XX XX {}\nXX XX _Q XX XX\n{} XX XX XX {}\nXX {} XX {} XX")
              c_exit_prompt()
            elif(c_user_input=="6"):
              print("\nKings (K)\n=========\nThese pieces can move one tile in all directions. Kings cannot move into a tile that would let them get captured by the opponent on their next turn, nor can any other piece move in a fashion that would render their king threatened in this way. Kings also have the unique ability to perform a castle, which can only be done if both the chosen rook and itself haven't moved yet. To trigger a castle, first select your king, and then try to move it to the same tile as one of your rooks, doing so will trigger a castle. When a castle is triggered, the king moves two tiles towards the chosen rook, and the chosen rook moves to the tile beside the king that is opposite the side they are currently on.\n\nKing movement\n=============\n{} {} {} {} {}\n{} XX XX XX {}\n{} XX _K XX {}\n{} XX XX XX {}\n{} {} {} {} {}")
              c_exit_prompt()
            elif(c_user_input=="7"):
              break
            else:
              print("\nError: Invalid input")
        elif(c_user_input=="5"):
          break
        else:
          print("\nError: Invalid input.")
    elif(c_user_input=="4"):
      print("\nchess_v1 terminated, returning to main menu...")
      break
    else:
      print("\nError: Invalid input.")

# Blackjack
def Blackjack():
  b_player_balance=100
  def b_card_format():
    if(b_card[0]=="10"):
      print("\n┌───────┐\n|",b_card[0],"   |\n|  ",b_card[1],"  |\n|   ",b_card[0],"|\n└───────┘")
    else:
      print("\n┌───────┐\n|",b_card[0],"    |\n|  ",b_card[1],"  |\n|    ",b_card[0],"|\n└───────┘")
  while(True):
    b_user_input=input("\nBlackjack\n=========\nSelect an action\n1. Play a hand\n2. Exit\n\n>: ")
    if(b_user_input=="1"):
      while(True):
        print("\nYour balance:",b_player_balance)
        b_player_bet=float(input("\nPlace your bet\n\n>: "))
        if(b_player_bet>b_player_balance):
          print("\nYou don't have enough money to do that.")
        else:
          break
      b_deck=[["A","♠",11],["K","♠",10],["Q","♠",10],["J","♠",10],["10","♠",10],["9","♠",9],["8","♠",8],["7","♠",7],["6","♠",6],["5","♠",5],["4","♠",4],["3","♠",3],["2","♠",2],["A","♥",11],["K","♥",10],["Q","♥",10],["J","♥",10],["10","♥",10],["9","♥",9],["8","♥",8],["7","♥",7],["6","♥",6],["5","♥",5],["4","♥",4],["3","♥",3],["2","♥",2],["A","♣",11],["K","♣",10],["Q","♣",10],["J","♣",10],["10","♣",10],["9","♣",9],["8","♣",8],["7","♣",7],["6","♣",6],["5","♣",5],["4","♣",4],["3","♣",3],["2","♣",2],["A","♦",11],["K","♦",10],["Q","♦",10],["J","♦",10],["10","♦",10],["9","♦",9],["8","♦",8],["7","♦",7],["6","♦",6],["5","♦",5],["4","♦",4],["3","♦",3],["2","♦",2]]
      random.shuffle(b_deck)
      b_house_score=[]
      b_player_score=[]
      b_house_hand=[]
      b_player_hand=[]
      b_player_hand_mimic=[]
      b_house_aces_consumed=0
      b_player_aces_consumed=0
      print("\nHouse's hand\n============")
      b_card=b_deck.pop(0)
      b_house_hand.append(b_card)
      b_house_score.append(b_card[2])
      print("\nCard: 1")
      b_card_format()
      print("\nYour hand\n=========")
      for b_hand_iteration in range(2):
        b_card=b_deck.pop(0)
        b_player_hand.append(b_card)
        b_player_score.append(b_card[2])
        b_hand_iteration+=1
        print("\nCard:",b_hand_iteration)
        b_card_format()
      while(True):
        print("\nSelect an action |\n1. Hit           | Your score:",sum(b_player_score),"\n2. Double down   | House's score:",sum(b_house_score),"\n3. Stand         | ")
        b_user_input=input("\n>: ")
        if(b_user_input in("1","2")):
          if(b_user_input=="2"):
            if(b_player_bet*2>b_player_balance):
              b_player_bet+=b_player_balance-b_player_bet
            else:
              b_player_bet=b_player_bet*2
          print("\nYour hand\n=========")
          b_card=b_deck.pop(0)
          b_player_hand.append(b_card)
          b_player_score.append(b_card[2])
          for b_hand_iteration in range(len(b_player_hand)):
            b_card=b_player_hand.pop(0)
            b_player_hand_mimic.append(b_card)
            b_hand_iteration+=1
            print("\nCard:",b_hand_iteration)
            b_card_format()
          b_player_hand=b_player_hand_mimic
          b_player_aces=b_player_score.count(11)
          b_player_aces+=-b_player_aces_consumed
          if((sum(b_player_score)>21)and(b_player_aces>0)):
            b_player_score.append(-10)
            b_player_aces_consumed+=1
          elif(sum(b_player_score)>21):
            break
        elif(b_user_input=="3"):
          break
        else:
          print("\nError: Invalid input.")
      while(True):
        b_card=b_deck.pop(0)
        b_house_hand.append(b_card)
        b_house_score.append(b_card[2])
        b_house_aces=b_house_score.count(11)
        b_house_aces+=-b_house_aces_consumed
        if((sum(b_house_score)>17)and(b_house_aces>0)):
          b_house_score.append(-10)
          b_house_aces_consumed+=1
        elif(sum(b_house_score)>17):
          break
      print("\nHouse's hand\n============")
      for b_hand_iteration in range(len(b_house_hand)):
        b_card=b_house_hand.pop(0)
        b_hand_iteration+=1
        print("\nCard:",b_hand_iteration)
        b_card_format()
      if(sum(b_player_score)>21):
        b_win=False
        print("\nThe house wins, your score exceeded 21.\n\nLosses:",b_player_bet)
      elif(sum(b_house_score)>21):
        b_win=True
        print("\nYou win, the house's score exceeded 21.\n\nWinnings:",b_player_bet)
      elif(sum(b_house_score)>sum(b_player_score)):
        b_win=False
        print("\nThe house wins, their score was higher than yours.\n\nLosses:",b_player_bet)
      elif(sum(b_house_score)==sum(b_player_score)):
        b_win=None
        print("\nNobody wins, your scores were the same.")
      elif(sum(b_player_score)>sum(b_house_score)):
        b_win=True
        print("\nYou win, your score was higher than theirs.\n\nWinnings:",b_player_bet)
      if(b_win==True):
        b_player_balance+=b_player_bet
      elif(b_win==False):
        b_player_balance+=-b_player_bet
      if(b_player_balance==0):
        while(True):
          b_user_input=input("\nYou've lost all of your money! Now you'll need to explain to your family why you won't be able to pay this month's rent. Unless...\n\nWhat will you do?\n1. Call your loan shark\n2. Go home empty handed and quit like the loser you are\n\n>: ")
          if(b_user_input=="1"):
            print("\nYou'd best find a way to pay them back, and fast...")
            b_player_balance=100
            break
          elif(b_user_input=="2"):
            print("\nPathetic.\n\nSimple Blackjack terminated, returning to main menu...")
            break
        if(b_user_input=="2"):
          break
    elif(b_user_input=="2"):
      print("\nSimple Blackjack terminated, returning to main menu...")
      break
    else:
      print("\nError: Invalid input.")

# Main menu
def mm_password_sequence():
  mm_attempts=3
  print("\nAttempts permitted: 3")
  while(True):
    mm_user_input=input("\nPlease input the password\n\n>: ")
    if(mm_user_input=="magrathea"):
      print("\nPassword accepted, starting program...")
      break
    else:
      mm_attempts+=-1
      print("\nIncorrect. Attempts remaining: ",mm_attempts)
    if(mm_attempts==0):
      print("\nIncorrect password entered too many times, system shutdown activated.")
      while(True):
        mm_lockdown=input("\n>: ")
        print("\nError: Invalid input.")
import formatters
import random,json
if __name__=="__main__":
  mm__password_sequence()
  print("\nUnless specified otherwise, use the keyword \"Exit\" to go back to the previous menu ")
  while(True):
    mm_user_input=input("\nMain menu\n=========\nSelect a category\n1. All programs\n2. Games\n3. Utilities\n4. Chatbots\n5. Exit\n\n>: ")
    if(mm_user_input in("1","All programs","ap")):
      while(True):
        mm_user_input=input("\nAll programs\n============\nSelect a program\n1. Blackjack\n2. chess_v1\n3. Deck\n4. Dice Roller\n5. Helpline\n6. Magic 8 Ball\n7. Number Guesser\n8. Tic-Tac-Toe\n9. Simple Calculator\n10. Exit\n\n>: ")
        if(mm_user_input in("1","Blackjack","b")):
          print("\nInitializing Blackjack...")
          Blackjack()
        elif(mm_user_input in("2","chess_v1","c")):
          print("\nInitializing chess_v1...")
          chess_v1()
        elif(mm_user_input in("3","Deck","d")):
          print("\nInitializing Deck...")
          Deck()
        elif(mm_user_input in("4","Dice Roller","dr")):
          print("\nInitializing Dice Roller...")
          Dice_Roller()
        elif(mm_user_input in("5","Helpline","h")):
          print("\nInitializing Helpline...")
          Helpline()
        elif(mm_user_input in("6","Magic 8 Ball","m8b")):
          print("\nInitializing Magic 8 Ball...")
          Magic_8_Ball()
        elif(mm_user_input in("7","Number Guesser","ng")):
          print("\nInitializing Number Guesser...")
          Number_Guesser()
        elif(mm_user_input in("8","Tic-Tac_Toe","ttt")):
          print("\nInitializing Tic-Tac-Toe...")
          Tic_Tac_Toe()
        elif(mm_user_input in("9","Simple Calculator","sc")):
          print("\nInitializing Simple Calculator...")
          Simple_Calculator()
        elif(mm_user_input in("10","Exit","e")):
          break
        else:
          print("\nError: Invalid input.")
    elif(mm_user_input in("2","Games","g")):
      while(True):
        mm_user_input=input("\nGames\n=====\nSelect a game\n1. Blackjack\n2. chess_v1\n3. Number Guesser\n4. Tic-Tac-Toe\n5. Exit\n\n>: ")
        if(mm_user_input in("1","Blackjack","b")):
          print("\nInitializing Blackjack...")
          Blackjack()
        elif(mm_user_input in("2","chess_v1","c")):
          print("\nInitializing chess_v1...")
          chess_v1()
        elif(mm_user_input in("3","Number Guesser","ng")):
          print("\nInitializing Number Guesser...")
          Number_Guesser()
        elif(mm_user_input in("4","Tic-Tac-Toe","ttt")):
          print("\nInitializing Tic-Tac-Toe...")
          Tic_Tac_Toe()
        elif(mm_user_input in("5","Exit","e")):
          break
        else:
          print("\nError: Invalid input.")
    elif(mm_user_input in("3","Utilities","u")):
      while(True):
        mm_user_input=input("\nUtilities\n==========\nSelect a utility\n1. Deck\n2. Dice Roller\n3. Simple Calculator\n4. Exit\n\n>: ")
        if(mm_user_input in("1","Deck","d")):
          print("\nInitializing Deck...")
          Deck()
        elif(mm_user_input in("2","Dice Roller","dr")):
          print("\nInitializing Dice Roller...")
          Dice_Roller()
        elif(mm_user_input in("3","Simple Calculator","sc")):
          print("\nInitializing Simple Calculator...")
          Simple_Calculator()
        elif(mm_user_input in("4","Exit","e")):
          break
        else:
          print("\nError: Invalid input.")
    elif(mm_user_input in("4","Chatbots","c")):
      while(True):
        mm_user_input=input("Chatbots\n========\nSelect a chatbot\n1. Helpline\n2. Magic 8 Ball\n3. Exit\n\n>: ")
        if(mm_user_input in("1","Helpline","h")):
          print("\nInitializing Helpline...")
          Helpline()
        elif(mm_user_input in("2","Magic 8 Ball","m8b")):
          print("\nInitializing Magic 8 Ball...")
          Magic_8_Ball()
        elif(mm_user_input in("3","Exit","e")):
          break
        else:
          print("\nError: Invalid input.")
    elif(mm_user_input in("5","Exit","e")):
      break
    else:
      print("\nError: Invalid input.")
