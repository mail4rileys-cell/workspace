import math
import re
import sys

from typeguard import typechecked

@typechecked
def calculate(radius: float, gm: float, a: float, e: float, i: float, t: float) -> dict[str, str]:

  pe = 1 + e
  ne = 1 - e
  primary_gm = (4 * (math.pi ** 2) * (a ** 3)) / ((t * 86400) ** 2)

  mass = gm / 6.67430e-20
  periapsis_distance = a * ne
  apoapsis_distance = a * pe
  periapsis_speed = math.sqrt((primary_gm * pe) / periapsis_distance)
  apoapsis_speed = math.sqrt((primary_gm * ne) / apoapsis_distance)

  return {
    "mass": f"{mass:e}L",
    "radius": f"{(radius * 1e3):e}L",
    "periapsis_distance": f"{(periapsis_distance * 1e3):e}L",
    "apoapsis_distance": f"{(apoapsis_distance * 1e3):e}L",
    "periapsis_speed": f"{(periapsis_speed * 1e3):e}L",
    "apoapsis_speed": f"{(apoapsis_speed * 1e3):e}L",
    "incline": f"{i}L"
  }

@typechecked
def display(dictionary: dict) -> None:
  for key, value in dictionary.items():
    print(f"{key}: {value}")

@typechecked
def main() -> int:
  result = None
  phase = None
  body_name = None
  filename = None
  if len(sys.argv) == 1:
    result = calculate(
      float(input("Input radius (km): ").strip().lower()),
      float(input("Input GM (km^3/s^2): ").strip().lower()),
      float(input("Input semi_major_axis (km): ").strip().lower()),
      float(input("Input eccentricity: ").strip().lower()),
      float(input("Input inclination (deg): ").strip().lower()),
      float(input("Input orbital_period (d): ").strip().lower())
    )
    phase = input("Use periapsis or apoapsis? (p/a): ").strip().lower()
    body_name = input("Input body name: ")
    filename = input("Input filename: ")
  elif len(sys.argv) == 8:
    result = calculate(
      float(sys.argv[1]),
      float(sys.argv[2]),
      float(sys.argv[3]),
      float(sys.argv[4]),
      float(sys.argv[5]),
      float(sys.argv[6])
    )
    phase = sys.argv[7]
    body_name = sys.argv[8]
    filename = sys.argv[9]
  else:
    print("Usage: <radius> <GM> <semi_major_axis> <eccentricity> <inclination> <orbital_period> <phase> <body_name> <filename>")
    return 1
  data = {
    "mass": result["mass"],
    "radius": result["radius"],
    "distance": None,
    "speed": None,
    "incline": result["incline"]
  }
  if phase == "periapsis" or phase == "p":
    data["distance"] = result["periapsis_distance"]
    data["speed"] = result["periapsis_speed"]
  elif phase == "apoapsis" or phase == "a":
    data["distance"] = result["apoapsis_distance"]
    data["speed"] = result["apoapsis_speed"]
  else:
    print(f"Invalid phase: {phase}")
    return 1
  patterns = [
    (rf"(CONSTANTS\({body_name}_MASS,\s*kilograms\()\s*[^)]+?(L\)\))", data["mass"]),
    (rf"(CONSTANTS\({body_name}_RADIUS,\s*meters\()\s*[^)]+?(L\)\))", data["radius"]),
    (rf"(CONSTANTS\({body_name}_DISTANCE,\s*meters\()\s*[^)]+?(L\)\))", data["distance"]),
    (rf"(CONSTANTS\({body_name}_SPEED,\s*meters_per_second\()\s*[^)]+?(L\)\))", data["speed"]),
    (rf"(CONSTANTS\({body_name}_INCLINE,\s*degrees\()\s*[^)]+?(L\)\))", data["incline"])
  ]
  text = None
  with open(filename, "r") as file:
    text = file.read()
  for pattern, replacement in patterns:
    text = re.sub(pattern, rf"\1{replacement}\2", text)
  with open(filename, "w") as file:
    file.write(text)    

if __name__ == "__main__":
  sys.exit(main())
