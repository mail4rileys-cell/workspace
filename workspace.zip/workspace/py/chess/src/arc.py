import random
import time

import __main__

import deep_thought


class SearchAlgorithm:

  def __init__(self):
    self.transposition_table = {}
    self.move_cache = {}
    self.zobrist = Zobrist()
    while True:
      print(depth_menu)
      try:
        self.max_depth = max(1, int(__main__.get_key()))
        break
      except ValueError:
        pass
    self.killer_moves = {depth: [None, None, None] for depth in range(2, self.max_depth + 1)}
    self.search_data = SearchData(self.max_depth)
    while True:
      print(strategy_menu)
      try:
        choice = strategy_menu[__main__.get_key()]
        break
      except KeyError:
        pass
    if choice == "Material eval":
      self.evaluate = self.material_eval
    elif choice == "Noisy material eval":
      self.evaluate = self.noisy_material_eval
    elif choice == "Neural network":
      deep_thought.initialize()
      self.evaluate = deep_thought.neural_network.predict

  @staticmethod
  def generate_all_moves(team, board):
    return [(x, y, nx, ny) for y, row in enumerate(board) for x, piece in enumerate(row) if piece and piece.team == team for nx, ny in piece.generate_moves(x, y) or []]

  @staticmethod
  def promote(team, opponent_team, board, x, y):
    return __main__.Queen

  def consider_draw(self, team, opponent_team, board):
    return self.evaluate(team, opponent_team, board) <= -20

  def material_eval(self, team, opponent_team, board):
    if board.is_king_in_check(team) and not self.generate_all_moves(team, board):
      return -104
    elif board.is_king_in_check(opponent_team) and not self.generate_all_moves(opponent_team, board):
      return 104
    else:
      score = 0
      for row in board:
        for piece in row:
          if piece:
            score += piece.value if piece.team == team else - piece.value
      return score

  def noisy_material_eval(self, team, opponent_team, board):
    score = self.material_eval(team, opponent_team, board)
    if random.random() <= 0.1:
      score += random.choice((-0.1, 0.1))
    return score

  def rate(self, team, opponent_team, board):
    if self.evaluate == self.material_eval:
      return str(self.evaluate(team, opponent_team, board))
    else:
      material_eval_score = self.material_eval(team, opponent_team, board)
      eval_score = round(self.evaluate(team, opponent_team, board), 2)
      difference = eval_score - material_eval_score
      return f"{material_eval_score:+}, {eval_score:+}, {difference:+}"

  def play(self, team, opponent_team, board):
    for depth in range(1, self.max_depth + 1):
      self.search_data[depth] = 0
    self.search_data["Q"] = 0
    with self.search_data["T"]:
      move, prediction = self.negamax_search(team, opponent_team, board, self.max_depth, -9999, 9999)
    self.search_data["P"] = prediction
    return move if move else self.generate_all_moves(team, board)[0]

  def negamax_search(self, team, opponent_team, board, depth, alpha, beta):
    self.search_data[depth] += 1
    key = self.zobrist.hash(board)
    if key in self.transposition_table:
      entry_move, entry_eval, entry_depth, entry_flag = self.transposition_table[key]
      if entry_depth >= depth:
        if entry_flag == 0:
          return entry_move, entry_eval
        elif entry_flag == -1:
          alpha = max(alpha, entry_eval)
        elif entry_flag == 1:
          beta = min(beta, entry_eval)
        if alpha >= beta:
          return entry_move, entry_eval
    moves = self.generate_all_moves(team, board)
    best_move = None
    best_eval = -104
    alpha_original = alpha
    for x, y, nx, ny in moves:
      move_record = board.make_move(x, y, nx, ny)
      if depth > 1:
        _, eval_score = self.negamax_search(opponent_team, team, board, depth - 1, -beta, -alpha)
        eval_score = -eval_score
      else:
        eval_score = -self.quiescence_search(opponent_team, team, board, -beta, -alpha)
      board.unmake_move(move_record)
      if eval_score > best_eval:
        best_eval = eval_score
        best_move = (x, y, nx, ny)
      alpha = max(alpha, best_eval)
      if alpha >= beta:
        break
    if key in self.transposition_table:
      entry_depth = self.transposition_table[key][2]
    else:
      entry_depth = 0
    if entry_depth <= depth:
      if best_eval <= alpha_original:
        flag = 1
      elif best_eval >= beta:
        flag = -1
      else:
        flag = 0
      self.transposition_table[key] = (best_move, best_eval, depth, flag)
    return best_move, best_eval

  def quiescence_search(self, team, opponent_team, board, alpha, beta):
    self.search_data["Q"] += 1
    stand_pat = self.evaluate(team, opponent_team, board)
    if stand_pat >= beta:
      return beta
    if stand_pat > alpha:
      alpha = stand_pat
    moves = []
    for y, row in enumerate(board):
      for x, piece in enumerate(row):
        if not piece or piece.team != team:
          continue
        for nx, ny in piece.generate_moves(x, y, verify = False):
          if board[ny][nx]:
            moves.append((x, y, nx, ny))
    for x, y, nx, ny in moves:
      move_record = board.make_move(x, y, nx, ny)
      score = -self.quiescence_search(opponent_team, team, board, -beta, -alpha)
      board.unmake_move(move_record)
      if score >= beta:
        return beta
      if score > alpha:
        alpha = score
    return alpha


class Zobrist:
  __slots__ = (
    "piece",
    "turn",
    "castle",
    "ep"
  )
  
  def __init__(self):
    rng = random.Random(0xC0FFEE)
    self.piece = {letter: [rng.getrandbits(64) for _ in range(64)] for letter in "PBNRQKpbnrqk"}
    self.turn = rng.getrandbits(64)
    self.castle = {
      "BQ": rng.getrandbits(64),
      "BK": rng.getrandbits(64),
      "RQ": rng.getrandbits(64),
      "RK": rng.getrandbits(64)
    }
    self.ep = {None: rng.getrandbits(64)}
    for x in range(8):
      for y in range(8):
        self.ep[(x, y)] = rng.getrandbits(64)

  def hash(self, board):
    h = 0
    for y, row in enumerate(board):
      for x, piece in enumerate(row):
        if piece:
          h ^= self.piece[piece.letter][x + (8 * y)]
    if board.turn == 1:
      h ^= self.turn
    blue_king = board[7][4]
    blue_queenside = board[7][0]
    blue_kingside = board[7][7]
    red_king = board[0][4]
    red_queenside = board[0][0]
    red_kingside = board[0][7]
    if blue_king.is_king and not blue_king.moved:
      if blue_queenside.is_rook and not blue_queenside.moved:
        h ^= self.castle["BQ"]
      if blue_kingside.is_rook and not blue_kingside.moved:
        h ^= self.castle["BK"]
    if red_king.is_king and not red_king.moved:
      if red_queenside.is_rook and not red_queenside.moved:
        h ^= self.castle["RQ"]
      if red_kingside.is_rook and not red_kingside.moved:
        h ^= self.castle["RK"]
    h ^= self.ep[board.EP_capture_square]
    return h


class Timer:

  def __init__(self):
    self.elapsed = 0

  def __enter__(self):
    self.start = time.process_time()

  def __exit__(self, _, __, ___):
    self.elapsed = time.process_time() - self.start

  def __repr__(self):
    return str(round(self.elapsed, 2))


class SearchData(dict):
  __slots__ = ()

  def __init__(self, max_depth):
    super().__init__({
      "T": Timer(),
      "P": None,
      "Q": 0,
      **{depth: 0 for depth in range(1, max_depth + 1)}
    })

  def __repr__(self):
    return " | ".join(": ".join((str(key), str(value))) for key, value in self.items())


def initialize():
  global search_algorithm
  search_algorithm = SearchAlgorithm()

depth_menu = __main__.Menu({}, "Input the search depth")
strategy_menu = __main__.Menu({
  "1": "Material eval",
  "2": "Noisy material eval",
  "3": "Neural network"
}, "Strategies")

if __name__ == "__main__":
  print(__main__.Menu({}, "Analytical Reasoning for Chess"))
