import json
import os
import numpy
import pickle

import __main__


class SimpleNN:
  __slots__ = (
    "W1",
    "B1",
    "W2",
    "B2",
    "W3",
    "B3",
    "Z1",
    "A1",
    "Z2",
    "A2"
  )

  def __init__(self, input_size, h1 = 64, h2 = 32):
    self.W1 = numpy.random.randn(input_size, h1) * numpy.sqrt(2 / input_size)
    self.B1 = numpy.zeros((1, h1))
    self.W2 = numpy.random.randn(h1, h2) * numpy.sqrt(2 / h1)
    self.B2 = numpy.zeros((1, h2))
    self.W3 = numpy.random.randn(h2, 1) * numpy.sqrt(2 / h2)
    self.B3 = numpy.zeros((1, 1))

  def __getstate__(self):
    return {
      "W1": self.W1,
      "B1": self.B1,
      "W2": self.W2,
      "B2": self.B2,
      "W3": self.W3,
      "B3": self.B3
    }

  def __setstate__(self, state):
    self.W1 = state["W1"]
    self.B1 = state["B1"]
    self.W2 = state["W2"]
    self.B2 = state["B2"]
    self.W3 = state["W3"]
    self.B3 = state["B3"]

  @staticmethod
  def relu(x):
    return numpy.maximum(0, x)

  @staticmethod
  def relu_derivative(x):
    return (x > 0).astype(float)

  def forward(self, x):
    self.Z1 = x @ self.W1 + self.B1
    self.A1 = self.relu(self.Z1)
    self.Z2 = self.A1 @ self.W2 + self.B2
    self.A2 = self.relu(self.Z2)
    return self.A2 @ self.W3 + self.B3

  def backward(self, x, y, weights, output, lr):
    dZ3 = 2 * weights * (output - y) / x.shape[0]
    dW3 = self.A2.T @ dZ3
    dB3 = numpy.sum(dZ3, axis = 0, keepdims = True)
    dA2 = dZ3 @ self.W3.T
    dZ2 = dA2 * self.relu_derivative(self.Z2)
    dW2 = self.A1.T @ dZ2
    dB2 = numpy.sum(dZ2, axis = 0, keepdims = True)
    dA1 = dZ2 @ self.W2.T
    dZ1 = dA1 * self.relu_derivative(self.Z1)
    dW1 = x.T @ dZ1
    dB1 = numpy.sum(dZ1, axis = 0, keepdims = True)
    self.W1 -= lr * dW1
    self.B1 -= lr * dB1
    self.W2 -= lr * dW2
    self.B2 -= lr * dB2
    self.W3 -= lr * dW3
    self.B3 -= lr * dB3

  def train(self, x, y, weights, epochs = 100, lr = 0.001):
    print(f"{__main__.clear}Training neural network...")
    print("-" * 26)
    for epoch in range(epochs):
      output = self.forward(x)
      loss = numpy.mean(weights * (output - y) ** 2)
      self.backward(x, y, weights, output, lr)
      if epoch % max(1, epochs // 10) == 0:
        print(f"Epoch {epoch}, Loss: {loss:.4f}")

  def predict(self, perspective, _, x):
    return self.forward(encode(x.compressed))[0][0] * (-1 if perspective == 1 else 1)


class SizeError(Exception):

  def __init__(self, board):
    super().__init__(f"Data size for board {board} is {len(board)}, expected 71")


class ConsistencyError(Exception):

  def __init__(self, board, score1, score2):
    super().__init__(f"Inconsistent scores for board {board}: {score1} and {score2}")


def load_data():
  try:
    with open("py/chess/data/training.json", "r") as f:
      return json.load(f)
  except FileNotFoundError:
    return {}

def save_data(board, evaluation):
  if len(board) != 71: raise SizeError(board)
  data = load_data()
  if board in data:
    if data[board][0] != evaluation:
      raise ConsistencyError(board, evaluation, data[board][0])
    else:
      data[board][1] += 1
  else:
    data[board] = [evaluation, 1]
  with open("py/chess/data/training.json", "w") as f:
    json.dump(dict(sorted(data.items(), key = lambda item: (item[1][0], item[1][1]), reverse = True)), f, indent = 2)

def encode(board):
  return[piece_codes[piece] for piece in board[:64]]

def initialize():
  global neural_network
  while True:
    print(model_menu)
    try:
      choice = model_menu[__main__.get_key()]
      break
    except KeyError:
      pass
  fallback = False
  if choice == "Load model":
    try:
      with open("py/chess/data/neural_network.pkl", "rb") as f:
        neural_network = pickle.load(f)
    except FileNotFoundError:
      fallback = True
  if choice == "Train new model" or fallback:
    x = []
    y = []
    weights = []
    data = load_data()
    for board in data:
      x.append(encode(board))
      y.append(data[board][0])
      weights.append(data[board][1])
    x = numpy.array(x, dtype = float)
    y = numpy.array(y, dtype = float).reshape(-1, 1)
    weights = numpy.array(weights, dtype = float).reshape(-1, 1)
    input_size = x.shape[1]
    neural_network = SimpleNN(input_size)
    neural_network.train(x, y, weights)
    try:
      with open("py/chess/data/neural_network.pkl", "rb") as f:
        previous_model = f.read()
      with open("py/chess/data/neural_network_backup.pkl", "wb") as f:
        f.write(previous_model)
    except FileNotFoundError:
      pass
    with open("py/chess/data/neural_network.pkl", "wb") as f:
      pickle.dump(neural_network, f, protocol = pickle.HIGHEST_PROTOCOL)

def sim_initialize():
  global neural_network
  inputs = []
  outputs = []
  weights = []
  data = load_data()
  for board in data:
    inputs.append(encode(board))
    outputs.append(data[board][0])
    weights.append(data[board][1])
  inputs = numpy.array(inputs, dtype = float)
  outputs = numpy.array(outputs,dtype = float).reshape(-1, 1)
  weights = numpy.array(weights, dtype = float).reshape(-1, 1)
  input_size = inputs.shape[1]
  neural_network = SimpleNN(input_size)
  neural_network.train(inputs, outputs, weights)

piece_codes = {
  "P": -1, "p": 1,
  "B": -2, "b": 2,
  "N": -3, "n": 3,
  "R": -4, "r": 4,
  "Q": -5, "q": 5,
  "K": -6, "k": 6,
  ".": 0
}
metadata_codes = {
  (64, "1"): 7,
  (64, "2"): 8,
  (65, "0"): 9,
  (65, "1"): 10,
  (66, "0"): 11,
  (66, "1"): 12,
  (67, "0"): 13,
  (67, "1"): 14,
  (68, "0"): 15,
  (68, "1"): 16,
  (69, "E"): 17,
  (70, "S"): 18
}
model_menu = __main__.Menu({
  "1": "Load model",
  "2": "Train new model"
}, "Model options")

if __name__ == "__main__":
  print(__main__.Menu({
  "Neural network ready": str(os.path.exists("py/chess/neural_network.pkl")),
  "Database entries": str(len(load_data()))
  }, "Deep Thought", divider = ": "))
