import json
import pickle
import resource
import sys
import termios
import tty


class Board(list):
  
  def __init__(self):
    starting_positions = {
      (0, 0): Rook(2, False, self), (1, 0): Knight(2, False, self), (2, 0): Bishop(2, False, self), (3, 0): Queen(2, False, self), (4, 0): King(2, False, self), (5, 0): Bishop(2, False, self), (6, 0): Knight(2, False, self), (7, 0): Rook(2, False, self),
      (0, 1): Pawn(2, False, self), (1, 1): Pawn(2, False, self), (2, 1): Pawn(2, False, self), (3, 1): Pawn(2, False, self), (4, 1): Pawn(2, False, self), (5, 1): Pawn(2, False, self), (6, 1): Pawn(2, False, self), (7, 1): Pawn(2, False, self),
      (0, 6): Pawn(1, False, self), (1, 6): Pawn(1, False, self), (2, 6): Pawn(1, False, self), (3, 6): Pawn(1, False, self), (4, 6): Pawn(1, False, self), (5, 6): Pawn(1, False, self), (6, 6): Pawn(1, False, self), (7, 6): Pawn(1, False, self),
      (0, 7): Rook(1, False, self), (1, 7): Knight(1, False, self), (2, 7): Bishop(1, False, self), (3, 7): Queen(1, False, self), (4, 7): King(1, False, self), (5, 7): Bishop(1, False, self), (6, 7): Knight(1, False, self), (7, 7): Rook(1, False, self)
    }
    super().__init__([starting_positions.get((x, y), null) for x in range(8)] for y in range(8))
    self.stalemate_counter = 0
    self.turn = 1
    self.round = 1
    self.plies = 0
    self.history = []
    self.record = []
    self.previous_move = "--"
    self.EP_target_square = None
    self.EP_capture_square = None
    self.EP_turn = None
    self.simulation = False
    self.blue_AI = False
    self.red_AI = False
    self.threat_map = False
    
  def __repr__(self):
    return self.compressed

  @property
  def compressed(self):
    blue_king = self[7][4]
    blue_queenside = self[7][0]
    blue_kingside = self[7][7]
    red_king = self[0][4]
    red_queenside = self[0][0]
    red_kingside = self[0][7]
    if blue_king.is_king and not blue_king.moved:
      if blue_queenside.is_rook and not blue_queenside.moved:
        blue_queenside_rights = "1"
      else:
        blue_queenside_rights = "0"
      if blue_kingside.is_rook and not blue_kingside.moved:
        blue_kingside_rights = "1"
      else:
        blue_kingside_rights = "0"
    else:
      blue_queenside_rights = "0"
      blue_kingside_rights = "0"
    if red_king.is_king and not red_king.moved:
      if red_queenside.is_rook and not red_queenside.moved:
        red_queenside_rights = "1"
      else:
        red_queenside_rights = "0"
      if red_kingside.is_rook and not red_kingside.moved:
        red_kingside_rights = "1"
      else:
        red_kingside_rights = "0"
    else:
      red_queenside_rights = "0"
      red_kingside_rights = "0"
    return "".join(piece.letter for row in self for piece in row) + str(self.turn) + blue_queenside_rights + blue_kingside_rights + red_queenside_rights + red_kingside_rights + "".join(str(coord) for coord in (self.EP_capture_square if self.EP_capture_square else "ES"))

  @property
  def RAM_usage(_):
    usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return f"{round(usage / (1024 ** 2))} MB" if sys.platform == "darwin" else f"{round(usage / 1024)} MB"

  @staticmethod
  def format_x(x):
    return chr(ord("a") + x)

  @staticmethod
  def format_y(y):
    return str(8 - y)

  @staticmethod
  def notation(piece, target, x, y, nx, ny, code):
    if code == 7:
      return "O-O-O"
    elif code == 8:
      return "O-O"
    if piece.is_pawn:
      piece_letter = "" if not target else chr(ord("a") + x)
    else:
      piece_letter = piece.letter.upper()
    capture = "x" if target else ""
    destination_square = chr(ord("a") + nx) + str(8 - ny)
    promotion = {
      2: "=B",
      3: "=N",
      4: "=R",
      5: "=Q"
    }.get(code, "")
    return piece_letter + capture + destination_square + promotion
  
  def render(self, perspective, highlighted_spaces = {}, selected = None, editor = False):
    if self.is_king_in_check(1):
      notification = "Blue is in check"
    elif self.is_king_in_check(2):
      notification = "Red is in check"
    else:
      notification = ""
    if not highlighted_spaces and self.threat_map:
      highlighted_spaces = {square: True for square in self.generate_threatening(self.turn)}
    if editor:
      print(f"{clear}0: Pawn | 1: Bishop | 2: Knight | 3: Rook | 4: Queen | 5: King")
      print("6: null | 7: Change moved | 8: Change team | 9: Confirm")
    else:
      print(f"{clear}Round: {self.round} | Turn: {'Blue' if self.turn == 1 else 'Red'} | {notification}")
      if (self.red_AI or self.blue_AI) and settings["AI stats"]:
        print(f"{arc.search_algorithm.rate(self.turn, 2 if self.turn == 1 else 1, self)} pts | {len(arc.search_algorithm.transposition_table)} t | {self.RAM_usage}")
        print(arc.search_algorithm.search_data)
      print(f"Click \"1\" to offer a draw | Click \"2\" to forfeit")
    print("      " + "      ".join(chr(ord("a") + (x if perspective == 1 else 7 - x)) for x in range(8)))
    print("  ||" + "||".join("=====" for _ in range(8)) + "||")
    for y, row in enumerate(self if perspective == 1 else [[row[7 - x] for x in range(8)] for row in list(reversed(self))]):
      print(str(8 - y if perspective == 1 else y + 1) + " |" + "".join("|" + piece.render(highlighted_spaces.get((x if perspective == 1 else 7 - x, y if perspective == 1 else 7 - y), False), selected == [x if perspective == 1 else 7 - x, y if perspective == 1 else 7 - y], x, y) + "|" for x, piece in enumerate(row)) + "| " + str(8 - y if perspective == 1 else y + 1))
      print("  ||" + "||".join("=====" for _ in range(8)) + "||")
    print("      " + "      ".join(chr(ord("a") + (x if perspective == 1 else 7 - x)) for x in range(8)))
    if not editor:
      print(f"Previous move: {self.previous_move}")
    if selected and settings["Piece stats"]:
      print(self[selected[1]][selected[0]])
      
  def generate_threatening(self, team):
    threats = set()
    for y, row in enumerate(self):
      for x, piece in enumerate(row):
        if piece.team == team:
          threats |= piece.generate_moves(x, y, verify = False)
    return threats
  
  def is_king_in_check(self, team):
    for x, y in self.generate_threatening(3 - team):
      piece = self[y][x]
      if piece.team == team and piece.is_king:
        return True
    return False

  def game(self):
    self.validate()
    while True:
      print(game_modes_menu)
      try:
        choice = game_modes_menu[get_key()]
        break
      except KeyError:
        pass
    if choice == "Player versus AI":
      self.red_AI = True
      arc.initialize()
    elif choice == "AI versus AI":
      self.red_AI = True
      self.blue_AI = True
      arc.initialize()
    while True:
      print(board_setups_menu)
      try:
        choice = board_setups_menu[get_key()]
        break
      except KeyError:
        pass
    if choice == "Custom positions":
      self.editor()
    moving_piece = False
    cursor = [4, 4]
    moves = set()
    while True:
      self.render(self.turn, highlighted_spaces = {move: True for move in moves}, selected = cursor)
      if (self.red_AI and self.turn == 2) or (self.blue_AI and self.turn == 1):
        print("ARC is thinking...")
        user_input = "AI"
      else:
        user_input = get_key().lower()
      try:
        if self.turn == 1:
          cursor[0] += direction_keybinds[user_input][0]
          cursor[1] += direction_keybinds[user_input][1]
        elif self.turn == 2:
          cursor[0] -= direction_keybinds[user_input][0]
          cursor[1] -= direction_keybinds[user_input][1]
        cursor = [max(0, min(cursor[0], 7)), max(0, min(cursor[1], 7))]
      except KeyError:
        if user_input == "1":
          if not self.red_AI:
            menu = Menu(yes_no, f"{'Blue' if self.turn == 1 else 'Red'} offered a draw, does {'Red' if self.turn == 1 else 'Blue'} accept?")
            while True:
              print(menu)
              try:
                answer = menu[get_key()]
                if answer == "Yes":
                  game_over_message = f"Stalemate | {'Red' if self.turn == 1 else 'Blue'} accepted {'Blue' if self.turn == 1 else 'Red'}'s draw"
                  agreed_stalemate = True
                  break
                elif answer == "No":
                  agreed_stalemate = False
                  break
              except KeyError:
                pass
          else:
            agreed_stalemate = arc.search_algorithm.consider_draw(2 if self.turn == 1 else 1, self.turn, self)
            if agreed_stalemate:
              game_over_message = f"Stalemate | ARC accepted {'Blue' if self.turn == 1 else 'Red'}'s draw"
          if agreed_stalemate:
            break
        elif user_input == "2":
          while True:
            print(forfeit_menu)
            try:
              answer = forfeit_menu[get_key()]
              if answer == "Yes":
                game_over_message = f"{'Red' if self.turn == 1 else 'Blue'} wins | {'Blue' if self.turn == 1 else 'Red'} forfeited"
                forfeit = True
                break
              elif answer == "No":
                forfeit = False
                break
            except KeyError:
              pass
          if forfeit:
            break
        elif user_input == "i":
          self.threat_map = not self.threat_map
        elif user_input == "p":
          self.display_record()
        elif (moving_piece and tuple(cursor) in moves) or user_input == "AI":
          moving_piece = False
          moves.clear()
          self.history.append(self.compressed)
          if user_input == "AI":
            x, y, nx, ny = arc.search_algorithm.play(self.turn, 2 if self.turn == 1 else 1, self)
          else:
            x, y = origin
            nx, ny = cursor
          piece = self[y][x]
          target, code = piece.capture(x, y, nx, ny)
          if target or code:
            self.stalemate_counter = 0
          else:
            self.stalemate_counter += 1
          self.plies += 1
          self.turn = 3 - self.turn
          if self.turn == 1:
            self.round += 1
          if self.turn != self.EP_turn:
            self.EP_target_square = None
            self.EP_capture_square = None
            self.EP_turn = None
          self.previous_move = self.notation(piece, target, x, y, nx, ny, code)
          self.record.append(self.previous_move)
          if self.validate():
            deep_thought.save_data(self.compressed, arc.search_algorithm.material_eval(2, 1, self))
          else:
            raise RuntimeError()
          if not save_game(self):
            raise SaveError(f"Save failed on round {self.round}")
        elif not moving_piece:
          piece = self[cursor[1]][cursor[0]]
          if piece.team == self.turn:
            origin = [cursor[0],cursor[1]]
            moves = piece.generate_moves(cursor[0], cursor[1])
            if moves:
              moving_piece = True
        else:
          moving_piece = False
          moves.clear()
        legal_moves = False
        for y, row in enumerate(self):
          for x, piece in enumerate(row):
            if piece.team == self.turn:
              if piece.generate_moves(x, y):
                legal_moves = True
                break
          if legal_moves:
            break
        if not legal_moves:
          if self.is_king_in_check(self.turn):
            game_over_message = f"{'Red' if self.turn == 1 else 'Blue'} wins | {'Blue' if self.turn == 1 else 'Red'} was checkmated"
            result = 1 if self.turn == 1 else - 1
          else:
            game_over_message = f"Stalemate | {'Blue' if self.turn == 1 else 'Red'} had no legal moves"
            result = 0
          break
        elif self.history.count(self.compressed)>=3:
          game_over_message = "Stalemate | The same game state occurred three times"
          result = 0
          break
        elif self.stalemate_counter >= 100:
          game_over_message = "Stalemate | fifty consecutive reversible roundsd occured"
          result = 0
          break
    self.render(self.turn)
    print(game_over_message)
    get_key()
    
  def editor(self):
    cursor = [4, 4]
    team = 1
    moved = False
    pieces = {
      "0": Pawn,
      "1": Bishop,
      "2": Knight,
      "3": Rook,
      "4": Queen,
      "5": King,
      "6": null
    }
    while True:
      self.render(1, selected = cursor, editor = True)
      user_input = get_key().lower()
      try:
        cursor[0] += direction_keybinds[user_input][0]
        cursor[1] += direction_keybinds[user_input][1]
        cursor = [max(0, min(cursor[0], 7)), max(0, min(cursor[1], 7))]
      except KeyError:
        if user_input in pieces:
          piece = pieces[user_input]
          self[cursor[1]][cursor[0]] = piece(team, self, moved) if piece else piece
        elif user_input == "7":
          moved = not moved
        elif user_input == "8":
          team = 3 - team
        elif user_input == "9":
          try:
            if self.validate():
              break
          except ValidationError as e:
            print(f"{e.__class__.__name__}: {e}")
            get_key()
        elif user_input == "/" and get_key() == "/":
          exec(input())
          
  def display_record(self):
    print(f"{clear}RECORD")
    print("------")
    for round_, moves in enumerate(self.record[index : index + 2] for index in range(0, len(self.record), 2)):
      print(f"{round_ + 1}. {' '.join(moves)}")
    get_key()
    
  def make_move(self, x, y, nx, ny):
    self.simulation = True
    move_record = {}
    move_record["move"] = (x ,y, nx, ny)
    move_record["EP_target_square"] = self.EP_target_square
    move_record["EP_capture_square"] = self.EP_capture_square
    move_record["EP_turn"] = self.EP_turn
    piece = self[y][x]
    move_record["piece_data"] = (piece.__class__, piece.team, piece.moved)
    target,code = piece.capture(x, y, nx, ny)
    move_record["target_data"] = (target.__class__, target.team, target.moved) if target else target
    move_record["code"] = code
    self.turn = 3 - self.turn
    if self.turn != self.EP_turn:
      self.EP_target_square = None
      self.EP_capture_square = None
      self.EP_turn = None
    return move_record
  
  def unmake_move(self, move_record):
    self.simulation = False
    self.EP_target_square = move_record["EP_target_square"]
    self.EP_capture_square = move_record["EP_capture_square"]
    self.EP_turn = move_record["EP_turn"]
    self.turn = 3 - self.turn
    cls, team, moved = move_record["piece_data"]
    piece = cls(team, moved, board)
    target_data = move_record["target_data"]
    if target_data:
      cls, team, moved = target_data
      target = cls(team, moved, board)
    else:
      target = target_data
    x, y, nx, ny = move_record["move"]
    code = move_record["code"]
    if code in (0, 1, 3, 4, 5, 6):
      self[y][x] = piece
      self[ny][nx] = target
    elif code == 2:
      self[y][x] = piece
      self[self.EP_target_square[1]][self.EP_target_square[0]] = target
      self[self.EP_capture_square[1]][self.EP_capture_square[0]] = null
    elif code == 7:
      self[y][4] = piece
      self[y][2] = null
      self[y][0] = target
      self[y][3] = null
    elif code == 8:
      self[y][4] = piece
      self[y][6] = null
      self[y][7] = target
      self[y][5] = null
      
  def validate(self):
    if not isinstance(self, list) or len(self) != 8:
      raise ValidationError(f"Invalid board {repr(self)}")
    piece_quantities = {
      "P": 0,
      "B": 0,
      "N": 0,
      "R": 0,
      "Q": 0,
      "K": 0,
      "p": 0,
      "b": 0,
      "n": 0,
      "r": 0,
      "q": 0,
      "k": 0,
      ".": 0
    }
    for y, row in enumerate(self):
      if not isinstance(row, list) or len(row) != 8:
        raise ValidationError(f"Invalid row in board {repr(self)} at {self.format_y(y)}")
      for x, piece in enumerate(row):
        if piece.__class__ not in (Pawn, Bishop, Knight, Rook, Queen, King, Nullpiece):
          raise ValidationError(f"Invalid class {piece.__class__} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.team not in (0, 1, 2):
          raise ValidationError(f"Invalid team {piece.team} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.value not in (0, 1, 3, 5, 9):
          raise ValidationError(f"Invalid value {piece.value} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.icon not in "♙♗♘♖♕♔ ":
          raise ValidationError(f"Invalid icon {piece.icon} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.letter not in "PBNRQKpbnrqk.":
          raise ValidationError(f"Invalid letter {piece.letter} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.moved not in (True, False, None):
          raise ValidationError(f"Invalid moved {piece.moved} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if piece.board not in (self, None):
          raise ValidationError(f"Invalid board {piece.board} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if not getattr(piece, "is_" + piece.__class__.__name__.lower()):
          raise ValidationError(f"Invalid identity is_{piece.__class__.__name__.lower()} = {getattr(piece, 'is_' + piece.__class__.__name__.lower())} for piece {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if isinstance(piece, Pawn) and y in (0, 7):
          raise ValidationError(f"Illegal pawn {repr(piece)} in board {repr(self)} at {self.format_x(x)}{self.format_y(y)}")
        if isinstance(piece, King):
          if piece.team == 1:
            blue_king = piece
            blue_king_x = x
            blue_king_y = y
          elif piece.team == 2:
            red_king = piece
            red_king_x = x
            red_king_y = y
        piece_quantities[piece.letter] += 1
    if piece_quantities["K"] != 1 or piece_quantities["k"] != 1:
      raise ValidationError(f"Exactly 1 blue king and 1 red king not in board {repr(self)}")
    if max(abs(blue_king_x - red_king_x), abs(blue_king_y - red_king_y)) == 1:
      raise ValidationError(f"Adjacent blue king {repr(blue_king)} and red king {repr(red_king)} in board {repr(self)} at {self.format_x(blue_king_x)}{self.format_y(blue_king_y)} and {self.format_x(red_king_x)}{self.format_y(red_king_y)}")
    for piece_letter, limit in (("P", 8), ("B", 10), ("N", 10), ("R", 10), ("Q", 9), ("p", 8), ("b", 10), ("n", 10), ("r", 10), ("q", 9), (".", 62)):
      if piece_quantities[piece_letter] > limit:
        raise ValidationError(f"Excessive quantity of piece {piece_letter} (counted {piece_quantities[piece_letter]}, expected <= {limit}) in board {repr(self)}")
    if self.turn not in (1, 2):
      raise ValidationError(f"Invalid turn {self.turn} for board {repr(self)}")
    if not isinstance(self.round, int) or self.round < 1:
      raise ValidationError(f"Invalid round {self.round} for board {repr(self)}")
    if not isinstance(self.stalemate_counter, int) or self.stalemate_counter < 0:
      raise ValidationError(f"Invalid stalemate counter {self.stalemate_counter} for board {repr(self)}")
    if not isinstance(self.plies, int) or self.plies < 0:
      raise ValidationError(f"Invalid plies {self.plies} for board {repr(self)}")
    if self.stalemate_counter > self.plies:
      raise ValidationError(f"Stalemate counter {self.stalemate_counter} exceeds plies {self.plies} for board {repr(self)}")
    if not isinstance(self.history, list) or len(self.history) != self.plies:
      raise ValidationError(f"Invalid history {self.history} for board {repr(self)}")
    for h_index, board in enumerate(self.history):
      if not isinstance(board, str) or len(board) != 71:
        raise ValidationError(f"Invalid board string {board} in {self.history} at {h_index} for board {repr(self)}")
      for b_index, character in enumerate(board):
        if b_index <= 63 and character not in "PBNRQKpbnrqk.":
          raise ValidationError(f"Invalid piece character {character} in board string {board} at {b_index} in history {self.history} at {h_index} for board {repr(self)}")
        elif b_index == 64 and character not in "12":
          raise ValidationError(f"Invalid turn character {character} in board string {board} at {b_index} in history {self.history} at {h_index} for board {repr(self)}")
        elif 65 <= b_index <= 68 and character not in "10":
          raise ValidationError(f"Invalid castling right character {character} in board string {board} at {b_index} in history {self.history} at {h_index} for board {repr(self)}")
        elif 69 <= b_index <= 70 and character not in "01234567ES":
          raise ValidationError(f"Invalid EP capture square character {character} in board string {board} at {b_index} in history {self.history} at {h_index} for board {repr(self)}")
    if not isinstance(self.record, list) or len(self.record) != self.plies:
      raise ValidationError(f"Invalid record {self.record} for board {repr(self)}")
    for r_index, notation in enumerate(self.record):
      if not isinstance(notation, str) or not 2 <= len(notation) <= 7:
        raise ValidationError(f"Invalid notation {notation} in record {self.record} at {r_index} for board {repr(self)}")
      for n_index, character in enumerate(notation):
        if character not in "BNRQKabcdefgh12345678x=O-+#":
          raise ValidationError(f"Invalid character {character} in notation {notation} at {n_index} in record {self.record} at {r_index} for board {repr(self)}")
    if not isinstance(self.previous_move, str) or not 2 <= len(self.previous_move) <= 7:
      raise ValidationError(f"Invalid previous move {self.previous_move} for board {repr(self)}")
    for n_index, character in enumerate(self.previous_move):
      if character not in "BNRQKabcdefgh12345678x=O-+#":
        raise ValidationError(f"Invalid character {character} in previous move {self.previous_move} at {n_index} for board {repr(self)}")
    for square, name in ((self.EP_target_square, "target"), (self.EP_capture_square, "capture")):
      if square == None:
        continue
      elif not isinstance(square, tuple) or len(square) != 2:
        raise ValidationError(f"Invalid EP {name} square {square} for board {repr(self)}")
      for value in square:
        if not isinstance(value, int) or not 0 <= value <= 7:
          raise ValidationError(f"Invalid value {value} in EP {name} square for board {repr(self)}")
    if self.EP_turn not in (1, 2, None):
      raise ValidationError(f"Invalid EP turn {self.EP_turn} for board {repr(self)}")
    if not isinstance(self.simulation, bool):
      raise ValidationError(f"Invalid simulation {self.simulation} for board {repr(self)}")
    if not isinstance(self.blue_AI, bool):
      raise ValidationError(f"Invalid blue AI {self.blue_AI} for board {repr(self)}")
    if not isinstance(self.red_AI, bool):
      raise ValidationError(f"Invalid red AI {self.red_AI} for board {repr(self)}")
    if not isinstance(self.threat_map, bool):
      raise ValidationError(f"Invalid threat map {self.threat_map} for board {repr(self)}")
    return True


class Piece:
  
  def __str__(self):
    return f"{self.__class__.__name__} | Team: {self.team} | Moved: {self.moved}"
  
  def render(self, hightlighted, selected, x, y):
    return f"{reset}{'<' if hightlighted else ' '}{(bold + green + '<' + reset) if selected else ' '}{f'{bold}{blue if self.team == 1 else red}' if settings['Piece colours'] else ''}{self.icon if settings['Piece icons'] else self.letter}{reset}{(bold + green + '>' + reset) if selected else ' '}{'>' if hightlighted else ' '}{reset}"

  def capture(self, x, y, nx, ny):
    if not self.moved:
      self.moved = True
    target = self.board[ny][nx]
    self.board[ny][nx] = self
    self.board[y][x] = null
    return target, 0
  
  def verify_moves(self, x, y, moves):
    verified_moves = set()
    for nx, ny in moves:
      move_record = self.board.make_move(x, y, nx, ny)
      if not self.board.is_king_in_check(self.team):
        verified_moves.add((nx, ny))
      self.board.unmake_move(move_record)
    return verified_moves


class Pawn(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 1
  icon = "♙"
  is_pawn = True
  is_bishop = False
  is_knight = False
  is_rook = False
  is_queen = False
  is_king = False
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "P" if team == 1 else "p"
    
  def generate_moves(self, x, y, verify = True):
    moves = set()
    dy = -1 if self.team == 1 else 1
    if 0 <= (y + (dy * 2)) <= 7 and not self.moved and not self.board[y + dy][x] and not self.board[y + (dy * 2)][x]:
      moves.add((x, y + (dy * 2)))
    if 0 <= (y + dy) <= 7 and not self.board[y + dy][x]:
      moves.add((x, y + dy))
    for dx in (-1, 1):
      if not 0 <= (x + dx) <= 7 or not 0 <= (y + dy) <= 7:
        continue
      if self.board[y + dy][x + dx] and not self.team == self.board[y + dy][x + dx].team:
        moves.add((x + dx, y + dy))
      if self.board[y][x + dx] and not self.team == self.board[y][x + dx].team and tuple((x + dx, y + dy)) == self.board.EP_capture_square and not self.board[y + dy][x + dx]:
        moves.add((x + dx, y + dy))
    return self.verify_moves(x, y, moves) if verify else moves

  def capture(self, x, y, nx, ny):
    target = super().capture(x, y, nx, ny)[0]
    code = 1
    if abs(y - ny) == 2:
      self.board.EP_target_square = (nx, ny)
      self.board.EP_capture_square = (nx, ny + (1 if self.team == 1 else -1))
      self.board.EP_turn = 3 - self.team
    elif ((self.team == 1 and ny == 0) or (self.team == 2 and ny == 7)):
      if (self.team == 2 and self.board.red_AI) or (self.team == 1 and self.board.blue_AI) or self.board.simulation:
        self.board[ny][nx] = Queen(self.team, self.moved, self.board)
      else:
        while True:
          print(promotion_menu)
          try:
            self.board[ny][nx] = promotion_menu[get_key()](self.team, self.moved, self.board)
            break
          except KeyError:
            pass
      code = {
        Bishop: 3,
        Knight: 4,
        Rook: 5,
        Queen: 6
      }[self.board[ny][nx].__class__]
    elif (nx, ny) == self.board.EP_capture_square:
      target = self.board[self.board.EP_target_square[1]][self.board.EP_target_square[0]]
      self.board[self.board.EP_target_square[1]][self.board.EP_target_square[0]] = null
      code = 2
    return target, code


class Bishop(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 3
  icon = "♗"
  is_pawn = False
  is_bishop = True
  is_knight = False
  is_rook = False
  is_queen = False
  is_king = False
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "B" if team == 1 else "b"

  def generate_moves(self, x, y, verify = True):
    moves = set()
    for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
      nx = x + dx
      ny = y + dy
      while 0 <= nx <= 7 and 0 <= ny <= 7:
        target = self.board[ny][nx]
        if target.team == self.team:
          break
        moves.add((nx, ny))
        if target:
          break
        nx += dx
        ny += dy
    return self.verify_moves(x, y, moves) if verify else moves


class Knight(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 3
  icon = "♘"
  is_pawn = False
  is_bishop = False
  is_knight = True
  is_rook = False
  is_queen = False
  is_king = False
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "N" if team == 1 else "n"
    
  def generate_moves(self, x, y, verify = True):
    moves = set()
    for dx, dy in ((-1, -2), (1, -2), (2, -1), (2, 1), (1, 2), (-1, 2), (-2, 1), (-2, -1)):
      nx = x + dx
      ny = y + dy
      if not 0 <= nx <= 7 or not 0 <= ny <= 7:
        continue
      if self.board[ny][nx].team != self.team:
        moves.add((nx, ny))
    return self.verify_moves(x, y, moves) if verify else moves


class Rook(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 5
  icon = "♖"
  is_pawn = False
  is_bishop = False
  is_knight = False
  is_rook = True
  is_queen = False
  is_king = False
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "R" if team == 1 else "r"

  def generate_moves(self, x, y, verify = True):
    moves = set()
    for dx, dy in ((0, -1), (-1, 0), (1, 0), (0, 1)):
      nx = x + dx
      ny = y + dy
      while 0 <= nx <= 7 and 0 <= ny <= 7:
        target = self.board[ny][nx]
        if target.team == self.team:
          break
        moves.add((nx, ny))
        if target:
          break
        nx += dx
        ny += dy
    return self.verify_moves(x, y, moves) if verify else moves


class Queen(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 9
  icon = "♕"
  is_pawn = False
  is_bishop = False
  is_knight = False
  is_rook = False
  is_queen = True
  is_king = False
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "Q" if team == 1 else "q"
    
  def generate_moves(self, x, y, verify = True):
    moves = set()
    for dx, dy in ((-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1)):
      nx = x + dx
      ny = y + dy
      while 0 <= nx <= 7 and 0 <= ny <= 7:
        target = self.board[ny][nx]
        if target.team == self.team:
          break
        moves.add((nx, ny))
        if target:
          break
        nx += dx
        ny += dy
    return self.verify_moves(x, y, moves) if verify else moves


class King(Piece):
  __slots__ = (
    "team",
    "board",
    "letter",
    "moved"
  )
  value = 0
  icon = "♔"
  is_pawn = False
  is_bishop = False
  is_knight = False
  is_rook = False
  is_queen = False
  is_king = True
  is_nullpiece = False
  
  def __init__(self, team, moved, board):
    self.team = team
    self.moved = moved
    self.board = board
    self.letter = "K" if team == 1 else "k"
    
  def generate_moves(self, x, y, verify = True):
    moves = set()
    for dx, dy in ((-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1)):
      nx = x + dx
      ny = y + dy
      if not 0 <= nx <= 7 or not 0 <= ny <= 7:
        continue
      if self.board[ny][nx].team != self.team:
        moves.add((nx, ny))
    for dx in (-1, 1):
      offset = 0
      while True:
        offset += 1
        nx = x + (dx * offset)
        if not 0 <= nx <= 7:
          break
        piece = self.board[y][nx]
        if verify and piece.is_rook and not piece.moved and not self.moved and not self.board.is_king_in_check(self.team):
          move_record = self.board.make_move(x, y, x + dx, y)
          if not self.board.is_king_in_check(self.team):
            moves.add((nx, y))
          self.board.unmake_move(move_record)
          break
        elif piece:
          break
    return self.verify_moves(x, y, moves) if verify else moves

  def capture(self, x, y, nx, ny):
    piece = self.board[ny][nx]
    if piece.is_rook and piece.team == self.team and not self.moved:
      dx = 1 if x < nx else -1
      self.board[y][x] = null
      self.board[ny][nx] = null
      self.board[ny][x + (dx * 2)] = self
      self.board[ny][x + dx] = piece
      if not self.moved:
        self.moved = True
      return piece, 7 if dx == -1 else 8
    else:
      target = super().capture(x, y, nx, ny)[0]
      return target, 0


class Nullpiece:
  __slots__ = ()
  team = 0
  board = None
  value = 0
  icon = " "
  letter = "."
  moved = None
  is_pawn = False
  is_bishop = False
  is_knight = False
  is_rook = False
  is_queen = False
  is_king = False
  is_nullpiece = True
  
  @staticmethod
  def __bool__():
    return False
  
  @staticmethod
  def __str__():
    return "Nullpiece"
  
  @staticmethod
  def render(highlighted, selected, x, y):
    return f"{reset}{'<' if highlighted else ' '}{(bold + green + '<' + reset) if selected else ' '}{' ' if settings['Piece icons'] else '.'}{(bold + green + '>' + reset) if selected else ' '}{'>' if highlighted else ' '}{reset}"


class Menu(dict):
  __slots__ = (
    "title",
    "divider",
    "coloured"
  )
  
  def __init__(self, items, title, divider = ". ", coloured = False):
    super().__init__(items)
    self.title = title
    self.divider = divider
    self.coloured = coloured
    
  def __str__(self):
    line = "-" * len(self.title)
    string = clear + self.title + "\n" + line
    for key, option in self.items():
      string += "\n" + key + self.divider + ((green if option else red) if self.coloured else "") + (str(option) if isinstance(option, str) or isinstance(option, bool) else option.__name__.replace("_", " ").capitalize()) + reset
    if self:
      string += "\n" + line
    return string


class SaveError(Exception):
  pass


class ValidationError(Exception):
  pass


def get_key():
  fd = sys.stdin.fileno()
  old_settings = termios.tcgetattr(fd)
  try:
    tty.setraw(fd)
    ch = sys.stdin.read(1)
  finally:
    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
  return ch

def new_game():
  global board
  board = Board()
  return True

def continue_game():
  global board
  try:
    with open("py/chess/data/save.pkl", "rb") as file:
      board=pickle.load(file)
    return True
  except FileNotFoundError:
    return False

def save_game(board):
  with open("py/chess/data/save.pkl","wb")as file:
    pickle.dump(board, file, protocol = pickle.HIGHEST_PROTOCOL)
  return True

def load_settings():
  try:
    with open("py/chess/data/settings.json","r") as file:
      settings = json.load(file)
    for setting in default_settings:
      if setting not in settings:
        settings[setting] = default_settings[setting]
    return settings
  except FileNotFoundError:
    return default_settings

def change_settings():
  while True:
    print(Menu(settings, "Settings", divider = ": ", coloured = True))
    user_input = input()
    try:
      settings[user_input] = not settings[user_input]
    except KeyError:
      break
  with open("py/chess/data/settings.json","w")as file:
    json.dump(settings, file)

import arc
import deep_thought

clear = "\033[2J\033[H"
reset = "\033[0m"
bold = "\033[1m"
dim = "\033[2m"
italic = "\033[3m"
underline = "\033[4m"
blink = "\033[5m"
reverse = "\033[7m"
hidden = "\033[8m"
strikethrough = "\033[9m"
black = "\033[30m"
red = "\033[31m"
green = "\033[32m"
yellow = "\033[33m"
blue = "\033[34m"
magenta = "\033[35m"
cyan = "\033[36m"
white = "\033[37m"
direction_keybinds = {
  "w": (0, -1),
  "a": (-1, 0),
  "d": (1, 0),
  "s": (0, 1)
}
default_settings = {
  "AI stats": False,
  "Piece colours": True,
  "Piece icons": True,
  "Piece stats": False
}
yes_no = {
  "1": "Yes",
  "2": "No"
}
promotion_menu = Menu({
  "1": Bishop,
  "2": Knight,
  "3": Rook,
  "4": Queen
}, "Pawn promotion")
main_menu = Menu({
"1": continue_game,
"2": new_game,
"3": change_settings,
"4": sys.exit
}, "Chess v2")
game_modes_menu = Menu({
  "1": "Player versus player",
  "2": "Player versus AI",
  "3": "AI versus AI"
}, "Game modes")
board_setups_menu = Menu({
  "1": "Default positions",
  "2": "Custom positions"
}, "Board setups")
forfeit_menu = Menu(yes_no, "Do you really want to forfeit?")
settings = load_settings()
null = Nullpiece()
if __name__ == "__main__":
  while True:
    while True:
      print(main_menu)
      try:
        if main_menu[get_key()]():
          break
      except KeyError:
        pass
    board.game()
