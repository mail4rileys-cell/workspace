def walk(user,code=None):
  if(code):path=code
  else:
    formatters.slow_print("{formatters.clear}Specify a path to walk")
    path=input(__main__.prompt)
  for letter in path:
    direction=__main__.direction_keybinds.get(letter,(0,0))
    target_x=user.x +direction[0]
    target_y=user.y +direction[1]
    clearance=[]
    if(0<=target_x<=__main__.board.size -1)and(0<=target_y<=__main__.board.size -1):clearance.append(True)
    else:clearance.append(False)
    if(user.stats.movement >=__main__.board.tiles[target_y][target_x].movement_cost):clearance.append(True)
    else:clearance.append(False)
    clearance.append(__main__.raycast([user.x,user.y],direction,1,"icon",None,"walkable",False))
    clearance.append(__main__.raycast([user.x,user.y],direction,1,"icon",None,"occupied",True))
    if(clearance.count(True)==len(clearance)):
      if(direction!=(0,0)):user.stats.momentum +=5
      user.stats.movement -=__main__.board.tiles[user.y][user.x].movement_cost
      __main__.board.tiles[user.y][user.x].on_exit(user)
      user.x,user.y =target_x,target_y
      __main__.board.tiles[user.y][user.x].on_enter(user)
      __main__.board.tiles[user.y][user.x].on_walk_through(user)

def jump(user,code=None):
  if(user.stats.momentum >=10):jump_distance_limit=max(1,user.stats.strength //5)
  else:jump_distance_limit=max(1,(user.stats.strength //10))
  if(code):
    direction=__main__.direction_keybinds.get(code[0],(0,0))
    if(int(code[1])>jump_distance_limit):jump_distance=jump_distance_limit
    else:jump_distance=int(code[1])
  else:
    while(True):
      formatters.slow_print("Specify a direction to jump")
      direction=__main__.direction_keybinds.get(input(__main__.prompt)[:1])
      if(direction):break
      else:formatters.slow_print("Please input a directional keybind",True)
    while(True):
      formatters.slow_print("Specify a distance to jump")
      try:user_input=abs(int(input(__main__.prompt)))
      except ValueError:formatters.slow_print("Please input a whole number",True)
      if(user_input<=jump_distance_limit):jump_distance=user_input;break
      else:formatters.slow_print(f"{user.name} cannot jump that far")
  for i in range(jump_distance):
    target_x=user.x +direction[0]
    target_y=user.y +direction[1]
    clearance =[]
    if(0<=target_x<=__main__.board.size -1)and(0<=target_y<=__main__.board.size -1):clearance.append(True)
    else:clearance.append(False)
    if(user.stats.movement >=5):clearance.append(True)
    else:clearance.append(False)
    clearance.append(__main__.raycast([user.x,user.y],direction,1,"icon",None,"jumpable",False))
    clearance.append(__main__.raycast([user.x,user.y],direction,1,"icon",None,"occupied",True))
    if(clearance.count(True)==len(clearance)):
      user.stats.movement -=5
      user.stats.momentum =0
      __main__.board.tiles[user.y][user.x].on_exit(user)
      user.x,user.y =target_x,target_y
      __main__.board.tiles[user.y][user.x].on_enter(user)
      __main__.board.tiles[user.y][user.x].on_jump_through(user)
  __main__.board.tiles[user.y][user.x].on_land_at(user)

def dash(user):
  if(user.abilities.actions_remaining >=1):
    user.abilities.actions_remaining -=1
    user.stats.movement +=user.stats.speed

def unarmed_strike(user,code):
  if(user.abilities.actions_remaining >=1):
    user.abilities.actions_remaining -=1
    direction=__main__.direction_keybinds.get(code[0],(0,0))
    distance=min(int(code[1]),1+user.stats.reach_bonus //5)
    entity=__main__.board.tiles[user.y +direction[1]][user.x +direction[0]].entity
    if(entity):
      formatters.slow_print(f"{formatters.clear}{user.name} uses Unarmed Strike on {entity.name}",True)
      attack_roll,critical=__main__.roll(1,20,user.stats.strength_modifier,critical=True)
      formatters.slow_print(f"{user.name} | Attack roll: {attack_roll}",True)
      if(attack_roll>=entity.stats.armor_class)or(critical==2):
        formatters.slow_print(f"{user.name}'s Unarmed Strike hits",True)
        entity.take_damage((1+user.stats.strength_modifier)*critical,"bludgeoning")
      elif(attack_roll<entity.stats.armor_class)or(critical==0):formatters.slow_print(f"{user.name}'s Unarmed Strike misses",True)

def attack(user,code=""):
  if(code==""):
    while(True):
      formatters.slow_print(f"{formatters.clear}Specify a direction to attack")
      user_input=input(__main__.prompt)
      if(__main__.direction_keybinds.get(user_input)):code+=user_input;break
      else:
        formatters.slow_print(f"{formatters.clear}Please input a direction keybind",True)
    while(True):
      formatters.slow_print(f"{formatters.clear}Specify a distance to attack")
      user_input=input(__main__.prompt)
      try:code+=str(abs(int(user_input)));break
      except ValueError:formatters.slow_print(f"{formatters.clear}Please input a whole number",True)
  if(user.equipment.mainhand):user.equipment.mainhand.attack(user,code)
  elif(unarmed_strike in(user.abilities.actions)):unarmed_strike(user,code)

def inspect(user,code=None):
  if(user.abilities.bonus_actions_remaining >=1):
    user.abilities.bonus_actions_remaining -=1
    coordinates=code if code else[]
    while(True):
      while(True):
        if(len(coordinates)==0):coordinates="x"
        try:coordinates=__main__.parse_ordered_pair(coordinates);break
        except ValueError:
          formatters.slow_print(f"{formatters.clear}Please input a set of coordinates",True)
          coordinates=input(__main__.prompt)
      if(0<=coordinates[0]<=__main__.board.size-1)and(0<=coordinates[1]<=__main__.board.size-1):break
      else:
        formatters.slow_print(f"{formatters.clear}Please input a set of coordinates that are on the board",True)
        coordinates=input(__main__.prompt)
    tile=__main__.board.tiles[coordinates[1]][coordinates[0]]
    formatters.slow_print(f"{formatters.clear}Inspection of tile at ({coordinates[0]},{coordinates[1]})")
    formatters.slow_print("-"*10)
    if(tile.information ==[]):
      perception_check=__main__.roll(1,20,user.stats.perception)
      formatters.slow_print(f"{user.name} | {formatters.blue}Perception{formatters.reset} check: {perception_check}",True)
      tile.inspect("perception",perception_check)
    for data in tile.information:formatters.slow_print(data,True)
    formatters.slow_print("-"*10)
    user_input=input(__main__.prompt)

import os,__main__
import formatters
