class Weapon:
  def __init__(self):
    self.name =f"{formatters.yellow}{self.__class__.__name__}{formatters.reset}"
    self.weight =0
    self.melee_damage =(1,4,"bludgeoning")
    self.melee_reach =5
    self.ranged_damage =(1,4,self.melee_damage[2])
    self.ranged_reach =(20,60)
    self.bonus =0
  def attack(self,user,code):
    if(user.abilities.actions_remaining >=1):
      user.abilities.actions_remaining -=1
      direction=__main__.direction_keybinds.get(code[0],(0,0))
      distance=min(int(code[1]),self.melee_reach //5)
      coordinates=__main__.raycast([user.x,user.y],direction,distance,"occupied",True,"cover",1)
      if(isinstance(coordinates,tuple)):
        entity=__main__.board.tiles[coordinates[1]][coordinates[0]].entity
        if("finesse"in self.properties):damage_modifier=max(user.stats.strength_modifier,user.stats.dexterity_modifier)
        elif("melee"in self.properties):damage_modifier=user.stats.strength_modifier
        elif("ranged"in self.properties):damage_modifier=user.stats.dexterity_modifier
        damage_modifier+=self.bonus
        attack_modifier=damage_modifier+user.stats.proficiency_bonus *getattr(user.stats,f"{self.__class__.__name__.lower()}_proficiency")
        formatters.slow_print(f"{formatters.clear}{user.name} uses {self.name} on {entity.name}",True)
        attack_roll,critical=__main__.roll(1,20,attack_modifier,critical=True)
        formatters.slow_print(f"{user.name} | Attack roll: {attack_roll}",True)
        if(attack_roll>=entity.stats.armor_class)or(critical==2):
          formatters.slow_print(f"{user.name}'s {self.name} hits",True)
          entity.take_damage(__main__.roll(self.melee_damage[0],self.melee_damage[1],damage_modifier),self.melee_damage[2])
        elif(attack_roll<entity.stats.armor_class)or(critical==0):formatters.slow_print(f"{user.name}'s {self.name} misses",True)

class Club(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","light")
    self.weight =2

class Dagger(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","finesse","light","thrown")
    self.weight =1
    self.melee_damage =(1,4,"piercing")

class Greatclub(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","two-handed")
    self.weight =10
    self.melee_damage =(1,8,"bludgeoning")

class Handaxe(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","light","thrown")
    self.weight =2
    self.melee_damage =(1,6,"slashing")

class Javelin(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","thrown")
    self.weight =2
    self.melee_damage =(1,6,"piercing")
    self.ranged_damage =self.melee_damage
    self.ranged_reach =(30,120)

class Light_Hammer(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","light","thrown")
    self.weight =2

class Mace(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee")
    self.weight =4
    self.melee_damage =(1,6,"bludgeoning")

class Quarterstaff(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","versatile")
    self.weight =4
    self.melee_damage =(1,6,"bludgeoning")

class Sickle(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","light")
    self.weight =2
    self.melee_damage =(1,4,"slashing")

class Spear(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","thrown","versatile")
    self.weight =3
    self.melee_damage =(1,6,"piercing")
    self.ranged_damage =self.melee_damage

class Dart(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","thrown","finesse")
    self.weight =1/4
    self.ranged_damage =(1,4,"piercing")

class Light_Crossbow(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","loading","two-handed")
    self.weight =5
    self.ranged_damage =(1,8,"piercing")
    self.ranged_reach =(80,320)

class Shortbow(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged,""ammunition","two-handed")
    self.weight =2
    self.ranged_damage =(1,6,"piercing")
    self.ranged_reach =(80,320)

class Sling(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition")
    self.ranged_reach =(30,120)

class Battleaxe(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","versatile")
    self.weight =4
    self.melee_damage =(1,8,"slashing")

class Flail(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee")
    self.weight =2
    self.melee_damage =(1,8,"bludgeoning")

class Glaive(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","reach","two-handed")
    self.weight =6
    self.melee_damage =(1,10,"slashing")
    self.melee_reach =10

class Greataxe(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","two-handed")
    self.weight =7
    self.melee_damage =(1,12,"slashing")

class Greatsword(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","two-handed")
    self.weight =6
    self.melee_damage =(2,6,"slashing")

class Halberd(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","reach","two-handed")
    self.weight =6
    self.melee_damage =(1,10,"slashing")
    self.melee_reach =10

class Lance(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","reach","two-handed")
    self.weight =6
    self.melee_damage =(1,10,"piercing")
    self.melee_reach =10

class Longsword(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","versatile")
    self.weight =3
    self.melee_damage =(1,8,"slashing")

class Maul(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","two-handed")
    self.weight =10
    self.melee_damage =(2,6,"bludgeoning")

class Morningstar(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee")
    self.weight =4
    self.melee_damage =(1,8,"piercing")

class Pike(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","heavy","reach","two-handed")
    self.weight =18
    self.melee_damage =(1,10,"piercing")
    self.melee_reach =10

class Rapier(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","finesse")
    self.weight =2
    self.melee_damage =(1,8,"piercing")

class Scimitar(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","finesse","light")
    self.weight =3
    self.melee_damage =(1,6,"slashing")

class Shortsword(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","finesse","light")
    self.weight =2
    self.melee_damage =(1,6,"piercing")

class Trident(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","thrown","versatile")
    self.weight =4
    self.melee_damage =(1,8,"piercing")
    self.ranged_damage =self.melee_damage

class Warhammer(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","versatile")
    self.weight =5
    self.melee_damage =(1,8,"bludgeoning")

class War_Pick(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","versatile")
    self.weight =2
    self.melee_damage =(1,8,"piercing")

class Whip(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("melee","finesse","reach")
    self.weight =3
    self.melee_damage =(1,4,"slashing")
    self.melee_reach =10

class Blowgun(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","loading")
    self.weight =1
    self.ranged_damage =(1,1,"piercing")
    self.ranged_reach =(25,100)

class Hand_Crossbow(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","light","loading")
    self.weight =3
    self.ranged_damage =(1,6,"piercing")
    self.ranged_reach =(30,120)

class Heavy_Crossbow(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","heavy","loading","two-handed")
    self.weight =18
    self.ranged_damage =(1,10,"piercing")
    self.ranged_reach =(100,400)

class Longbow(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","heavy","two-handed")
    self.weight =2
    self.ranged_damage =(1,8,"piercing")
    self.ranged_reach =(150,600)

class Musket(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","loading","two-handed")
    self.weight =10
    self.ranged_damage =(1,12,"piercing")
    self.ranged_reach =(40,120)

class Pistol(Weapon):
  def __init__(self):
    super().__init__()
    self.properties =("ranged","ammunition","loading")
    self.weight =3
    self.ranged_damage =(1,10,"piercing")
    self.ranged_reach =(30,90)

import os,__main__
import formatters
