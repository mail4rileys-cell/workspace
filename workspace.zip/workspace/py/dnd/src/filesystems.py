class RunBackupFileError(Exception):
  def __init__(self):super().__init__("Attempted to run a backup file while Run backup files was turned off")

def continue_game():
  try:
    with open("py/dnd/data/save.txt","rb")as f:__main__.board,__main__.seed,__main__.player,__main__.game_round,__main__.elapsed_time =pickle.loads(zlib.decompress(f.read()))
    return True
  except FileNotFoundError:formatters.slow_print(f"{formatters.clear}No save file found",True);return False

def load_game():
  formatters.slow_print(f"{formatters.clear}Input your save file name here")
  formatters.slow_print("-"*10)
  try:
    with open("py/dnd/data/"+input(__main__.prompt),"rb")as f:__main__.board,__main__.seed,__main__.player,__main__.game_round,__main__.elapsed_time =pickle.loads(zlib.decompress(f.read()))
    return True
  except FileNotFoundError:formatters.slow_print(f"{formatters.clear}No save file found",True);return False

def new_game():
  __main__.board,__main__.seed =__main__.game_setup()
  __main__.player =entities.Character()
  __main__.game_round,__main__.elapsed_time =0,0
  return True

def save_game():
  with open("py/dnd/data/save.txt","wb")as f:f.write(zlib.compress(pickle.dumps((__main__.board,__main__.seed,__main__.player,__main__.game_round,__main__.elapsed_time),protocol=pickle.HIGHEST_PROTOCOL)))

def load_leaderboard():
  try:
    with open("py/dnd/data/leaderboard.json","r")as f:return json.load(f)
  except (FileNotFoundError,json.JSONDecodeError):return {}

def save_leaderboard(leaderboard):
  with open("py/dnd/data/leaderboard.json","w")as f:json.dump(dict(sorted(leaderboard.items(),key=lambda x:x[1],reverse=True)),f)

def update_leaderboard(name,new_score):
  leaderboard=load_leaderboard()
  if(name not in leaderboard)or(new_score>leaderboard[name]):
    leaderboard[name]=new_score
    save_leaderboard(leaderboard)
  formatters.slow_print(f"{formatters.clear}Score: {new_score} points",True)
  formatters.slow_print(f"High score: {leaderboard[name]} points",True)

def display_leaderboard():
  formatters.slow_print(f"{formatters.clear}Leaderboard")
  formatters.slow_print("-"*10)
  for name,score in load_leaderboard().items():formatters.slow_print(f"{name}: {score}")
  formatters.slow_print("-"*10)
  user_input=input(__main__.prompt)
  return False

def load_settings():
  try:
    with open("py/dnd/data/settings.json","r")as f:return json.load(f)
  except (FileNotFoundError,json.JSONDecodeError):return __main__.default_settings

def change_settings():
  while(True):
    formatters.slow_print(f"{formatters.clear}Settings")
    formatters.slow_print("-"*10)
    for key,setting in __main__.settings_menu.items():formatters.slow_print(f"{key}. {setting}: {formatters.green if(__main__.settings[setting])else formatters.red}{__main__.settings[setting]}{formatters.reset}")
    formatters.slow_print(f"{len(__main__.settings_menu)+1}. Exit")
    formatters.slow_print("-"*10)
    user_input=input(__main__.prompt)
    try:
      __main__.settings[__main__.settings_menu[user_input]]=False if __main__.settings[__main__.settings_menu[user_input]]else True
      with open("py/dnd/data/settings.json","w")as f:json.dump(__main__.settings,f)
    except KeyError:
      if(user_input==str(len(__main__.settings_menu)+1)):break
      else:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(__main__.settings_menu)+1}",True)

import json,os,pickle,zlib,__main__
import entities,formatters
