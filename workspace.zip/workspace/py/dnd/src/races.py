class Race:
  def __init__(self):self.name =f"{formatters.cyan}{self.__class__.__name__}{formatters.reset}"

class Dwarf(Race):
  def __init__(self):super().__init__()
  def modify_stats(self,entity):
    entity.maximum_hit_points +=1
    entity.speed +=30
    entity.movement =entity.speed
    entity.poison -=0.5

class Elf(Race):
  def __init__(self):super().__init__()
  def modify_stats(self,entity):
    entity.speed +=30
    entity.movement =entity.speed

import os
import formatters
options={"1":Dwarf,"2":Elf}
