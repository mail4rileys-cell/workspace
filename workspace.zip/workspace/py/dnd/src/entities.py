class Character:
  ability_scores={"1":"strength","2":"dexterity","3":"constitution","4":"intelligence","5":"wisdom","6":"charisma"}
  def __init__(self):
    self.level =1
    formatters.slow_print(f"{formatters.clear}Input your icon (optional)")
    formatters.slow_print("-"*10)
    self.icon =input(__main__.prompt)
    formatters.slow_print(f"{formatters.clear}Input your name (optional)")
    formatters.slow_print("-"*10)
    self.name =input(__main__.prompt)
    if(self.name ==""):self.name ="Player"
    if(self.icon ==""):self.icon =self.name[:2]
    if(len(self.icon)==1):self.icon +="_"
    elif(len(self.icon)>1):self.icon =self.icon[:2]
    self.icon =f"{formatters.green}{self.icon}{formatters.reset}"
    self.name =f"{formatters.green}{self.name}{formatters.reset}"
    points=27
    ability_score_values=[8]*6
    while(True):
      formatters.slow_print(f"{formatters.clear}Allocate your ability scores, Points remaining: {points}")
      formatters.slow_print("-"*10)
      for key,ability_score in Character.ability_scores.items():
        cost=self.calculate_cost(points,ability_score_values[int(key)-1])
        formatters.slow_print(f"{key}. {formatters.blue}{ability_score.title()}{formatters.reset} ({ability_score_values[int(key)-1]}/20) | Cost: {cost}")
      formatters.slow_print("7. Reset allocations")
      formatters.slow_print("8. Continue")
      formatters.slow_print("-"*10)
      choice=input(__main__.prompt)
      if(choice=="7"):
        points=27
        ability_score_values=[8]*6
      elif(choice=="8"):break
      else:
        try:
          ability_score=Character.ability_scores[choice]
          cost=self.calculate_cost(points,ability_score_values[int(choice)-1])
          if(points>=cost):
            ability_score_values[int(choice)-1]+=1
            points-=cost
        except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(Character.ability_scores)+2}",True)
    while(True):
      formatters.slow_print(f"{formatters.clear}Select a class")
      formatters.slow_print("-"*10)
      for key,class_ in classes.options.items():formatters.slow_print(f"{key}. {formatters.cyan}{class_.__name__}{formatters.reset}")
      formatters.slow_print("-"*10)
      try:self.class_ =classes.options[input(__main__.prompt)]();break
      except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(classes.options)}",True)
    while(True):
      formatters.slow_print(f"{formatters.clear}Select a background")
      formatters.slow_print("-"*10)
      for key,background in backgrounds.options.items():formatters.slow_print(f"{key}. {formatters.cyan}{background.__name__}{formatters.reset}")
      formatters.slow_print("-"*10)
      try:self.background =backgrounds.options[input(__main__.prompt)]();break
      except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(backgrounds.options)}",True)
    while(True):
      formatters.slow_print(f"{formatters.clear}Select a race")
      formatters.slow_print("-"*10)
      for key,race in races.options.items():formatters.slow_print(f"{key}. {formatters.cyan}{race.__name__}{formatters.reset}")
      formatters.slow_print("-"*10)
      try:self.race =races.options[input(__main__.prompt)]();break
      except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(races.options)}",True)
    self.stats =__main__.Stats(self.level,ability_score_values,class_=self.class_,background=self.background,race=self.race)
    self.abilities =__main__.Abilities(1,1,1)
    self.abilities.traversals.append(abilities.walk)
    self.abilities.traversals.append(abilities.jump)
    self.abilities.actions.append(abilities.dash)
    self.abilities.actions.append(abilities.unarmed_strike)
    self.abilities.actions.append(abilities.attack)
    self.abilities.bonus_actions.append(abilities.inspect)
    self.equipment =__main__.Equipment(self.stats.carry_capacity,class_=self.class_)
    while(True):
      self.x =random.randint(1,__main__.board.size -1)
      self.y =random.randint(1,__main__.board.size -1)
      if not(isinstance(__main__.board.tiles[self.y][self.x],tiles.ObstructionTerrain)):break
    self.kills =0
    __main__.board.tiles[self.y][self.x]=tiles.NormalTerrain(self.x,self.y)
    __main__.board.tiles[self.y][self.x].entity =self
    __main__.board.tiles[self.y][self.x].occupied =True
  def calculate_cost(self,points,ability):
    if(ability>=15):return points+1
    elif(ability>=13):return 2
    else:return 1
  def display_character_sheet(self):
    formatters.slow_print(f"{formatters.clear}{self.name} | Character sheet")
    formatters.slow_print("-"*10)
    formatters.slow_print(f"Class: {self.class_.name} | Background: {self.background.name} | Race: {self.race.name}")
    sheet_scores=[]
    for ability_score in Character.ability_scores.values():sheet_scores.append(f"{formatters.blue}{ability_score[:3].upper()}{formatters.reset}: {getattr(self.stats,ability_score):02d}, {getattr(self.stats,ability_score+'_modifier'):+}")
    for i in range(2):formatters.slow_print(" | ".join(sheet_scores[3:]if(i)else sheet_scores[:3]))
    formatters.slow_print(f"Mainhand: {self.equipment.mainhand.name if self.equipment.mainhand else self.equipment.mainhand} | Offhand: {self.equipment.offhand.name if self.equipment.offhand else self.equipment.offhand}")
    for item in self.equipment.inventory.values():formatters.slow_print(f"{item.name} ({item.__class__.__name__})")
    formatters.slow_print("-"*10)
    user_input=input(__main__.prompt)
  def take_damage(self,damage,damage_type):
    damage*=getattr(self.stats,damage_type)
    if(damage>self.stats.hit_points):self.stats.hit_points =0
    else:self.stats.hit_points -=damage
    formatters.slow_print(f"{self.name} takes {formatters.red}{damage} {damage_type} damage{formatters.reset}",True)
  def take_turn(self):
    self.stats.on_turn_start()
    self.abilities.on_turn_start()
    formatters.slow_print(f"{formatters.clear}Your turn, {self.name}",True)
    while(self.stats.hit_points >0):
      __main__.board.render()
      formatters.slow_print("-"*10)
      formatters.slow_print(f"HP: {formatters.format_hit_points(self.stats.hit_points,self.stats.maximum_hit_points)} ({self.stats.hit_points}/{self.stats.maximum_hit_points}) | AC: {self.stats.armor_class}")
      formatters.slow_print(f"1. Move ({self.stats.movement}/{self.stats.speed}) | Momentum: {self.stats.momentum}")
      formatters.slow_print(f"2. Action ({self.abilities.actions_remaining}/{self.abilities.action_limit})")
      formatters.slow_print(f"3. Bonus action ({self.abilities.bonus_actions_remaining}/{self.abilities.bonus_action_limit})")
      formatters.slow_print("4. Character sheet")
      formatters.slow_print("5. End turn")
      formatters.slow_print("-"*10)
      user_input=input(__main__.prompt)
      if(__main__.parse_input(self,user_input)):pass
      elif(user_input=="1"):
        if(self.stats.movement >0):
          formatters.slow_print("\nSelect a traversal\n----------")
          for index,traversal in enumerate(self.abilities.traversals):
            formatters.slow_print(f"{str(index+1)}. {traversal.__name__}")
          user_input=input(__main__.prompt)
          self.abilities.traversals[int(user_input)-1](self)
      elif(user_input=="2"):
        if(self.abilities.actions_remaining >0):
          formatters.slow_print("\nSelect an action\n----------")
          for index,action in enumerate(self.abilities.actions):
            formatters.slow_print(f"{str(index+1)}. {action.__name__.replace('_',' ').title()}")
          user_input=input(__main__.prompt)
          self.abilities.actions[int(user_input)-1](self)
      elif(user_input=="3"):pass
      elif(user_input=="4"):self.display_character_sheet()
      elif(user_input=="5"):break
  def on_round_start(self):pass
  def on_round_end(self):pass

class Creature:
  IDs={0:"0",1:"1",2:"2",3:"3",4:"4",5:"5",6:"6",7:"7",8:"8",9:"9",10:")",11:"!",12:"@",13:"#",14:"$",15:"%",16:"^",17:"&",18:"*",19:"(",20:"a",21:"b",22:"c",23:"d",24:"e",25:"f",26:"g",27:"h",28:"i",29:"j",30:"k",31:"l",32:"m",33:"n",34:"o",35:"p",36:"q",37:"r",38:"s",39:"t",40:"u",41:"v",42:"w",43:"x",44:"y",45:"z"}
  def mindless_pursuit(self):
    formatters.slow_print(f"{self.name} moves",True)
    while(True):
      old_x,old_y=self.x,self.y
      self.direction =[]
      if(self.x <__main__.player.x):self.direction.append(1)
      elif(self.x ==__main__.player.x):self.direction.append(0)
      elif(self.x >__main__.player.x):self.direction.append(-1)
      if(self.y <__main__.player.y):self.direction.append(1)
      elif(self.y ==__main__.player.y):self.direction.append(0)
      elif(self.y >__main__.player.y):self.direction.append(-1)
      self.direction =tuple(self.direction)
      self.move(__main__.direction_keybinds_translator[self.direction])
      if(self.x ==old_x)and(self.y ==old_y):break
    coordinates=__main__.raycast([self.x,self.y],self.direction,1,"occupied",True,"cover",1)
    if(isinstance(coordinates,tuple)):
      if(__main__.board.tiles[coordinates[1]][coordinates[0]].entity is __main__.player):self.attack(__main__.board.tiles[coordinates[1]][coordinates[0]].entity)
  def take_damage(self,damage,damage_type):
    damage*=getattr(self.stats,damage_type)
    if(damage>=self.stats.hit_points):self.stats.hit_points =0
    else:self.stats.hit_points -=damage
    if(self.stats.hit_points ==0):
      __main__.board.tiles[self.y][self.x].entity =None
      if(__main__.initiative_order.count(self)>0):__main__>initiative_order.remove(self)
      __main__.player.kills +=1
    formatters.slow_print(f"{self.name} takes {formatters.red}{damage} {damage_type} damage{formatters.reset}",True)
  def take_turn(self):
    self.stats.on_turn_start
    formatters.slow_print(f"{formatters.clear}{self.name} starts their turn at ({self.x},{self.y})",True)
    getattr(self,self.strategy)()
    formatters.slow_print(f"{self.name} ends their turn at ({self.x},{self.y})",True)
  def on_round_start(self):pass
  def on_round_end(self):pass

class Zombie(Creature):
  number=-1
  def __init__(self,x,y):
    self.x,self.y =x,y
    self.strategy ="mindless_pursuit"
    Zombie.number +=1
    self.ID =Creature.IDs[Zombie.number %len(Creature.IDs)]
    self.icon =f"{formatters.red}{__class__.__name__[0]}{self.ID}{formatters.reset}"
    self.name =f"{formatters.red}{__class__.__name__} {self.ID}{formatters.reset}"
    self.stats =__main__.Stats(1/4,(13,6,16,3,6,5),creature=self)
  def modify_stats(self,entity):
    entity.armor_class =8
    entity.hit_die =8
    entity.maximum_hit_points =15
    entity.hit_points =entity.maximum_hit_points
    entity.speed =20
    entity.movement =entity.speed
    entity.momentum =0
    entity.wisdom_saving_throw =0
    entity.poison =0
    entity.proficiency_bonus =2
  def undead_fortitude(self,damage):
    difficulty_class=5+damage
    saving_throw=__main__.roll(1,20,self.stats.constitution_saving_throw)
    formatters.slow_print(f"{self.name} | {formatters.blue}Constitution{formatters.reset} saving throw: {saving_throw}",True)
    if(saving_throw>=difficulty_class):
      formatters.slow_print(f"{self.name} uses {formatters.magenta}Undead Fortitude{formatters.reset} to resist the grip of death",True)
      self.stats.hit_points =1
    else:
      formatters.slow_print(f"{self.name} is defeated",True)
      __main__.board.tiles[self.y][self.x].entity =None
      if(__main__.initiative_order.count(self)>0):__main__.initiative_order.remove(self)
      __main__.player.kills +=1
  def slam(self,entity):
    formatters.slow_print(f"{self.name} uses Slam on {entity.name}",True)
    attack_roll,critical=__main__.roll(1,20,3,critical=True)
    formatters.slow_print(f"{self.name} | Attack roll: {attack_roll}",True)
    if(attack_roll>=entity.stats.armor_class)or(critical==2):
      formatters.slow_print(f"{self.name}'s Slam hits",True)
      entity.take_damage(__main__.roll(1,6,1)*critical,"bludgeoning")
    elif(attack_roll<entity.stats.armor_class)or(critical==0):formatters.slow_print(f"{self.name}'s Slam misses",True)
  def take_damage(self,damage,damage_type):
    damage*=getattr(self.stats,damage_type)
    formatters.slow_print(f"{self.name} takes {formatters.red}{damage} {damage_type} damage{formatters.reset}",True)
    if(damage>=self.stats.hit_points):self.undead_fortitude(damage)
    else:self.stats.hit_points -=damage
  def move(self,direction):abilities.walk(self,direction)
  def attack(self,entity):self.slam(entity)

import os,random,__main__
import abilities,backgrounds,classes,formatters,races,tiles,weapons
