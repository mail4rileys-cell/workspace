class Abilities:
  def __init__(self,action_limit,bonus_action_limit,reaction_limit):
    self.traversals =[]
    self.actions =[]
    self.bonus_actions =[]
    self.reactions =[]
    self.action_limit =action_limit
    self.actions_remaining =self.action_limit
    self.bonus_action_limit =bonus_action_limit
    self.bonus_actions_remaining =self.bonus_action_limit
    self.reaction_limit =reaction_limit
    self.reactions_remaining =self.reaction_limit
  def on_turn_start(self):
    self.actions_remaining =self.action_limit
    self.bonus_actions_remaining =self.bonus_action_limit
    self.reactions_remaining =self.reaction_limit

class Stats:
  def __init__(self,level,ability_scores,class_=None,background=None,race=None,creature=None):
    self.hit_die =0
    self.maximum_hit_points =0
    self.speed =0
    self.movement =self.speed
    self.momentum =0
    self.reach_bonus =0
    self.acid =1
    self.bludgeoning =1
    self.cold =1
    self.fire =1
    self.force =1
    self.lightning =1
    self.necrotic =1
    self.piercing =1
    self.poison =1
    self.psychic =1
    self.radiant =1
    self.slashing =1
    self.thunder =1
    self.true =1
    self.strength =0
    self.dexterity =0
    self.constitution =0
    self.intelligence =0
    self.wisdom =0
    self.charisma =0
    self.strength_proficiency =0
    self.dexterity_proficiency =0
    self.constitution_proficiency =0
    self.intelligence_proficiency =0
    self.wisdom_proficiency =0
    self.charisma_proficiency =0
    self.acrobatics_proficiency =0
    self.animal_handling_proficiency =0
    self.arcana_proficiency =0
    self.athletics_proficiency =0
    self.deception_proficiency =0
    self.history_proficiency =0
    self.insight_proficiency =0
    self.intimidation_proficiency =0
    self.investigation_proficiency =0
    self.medicine_proficiency =0
    self.nature_proficiency =0
    self.perception_proficiency =0
    self.performance_proficiency =0
    self.persuasion_proficiency =0
    self.religion_proficiency =0
    self.sleight_of_hand_proficiency =0
    self.stealth_proficiency =0
    self.survival_proficiency =0
    self.simple_weapon_proficiency =0
    self.martial_weapon_proficiency =0

    self.level =level
    if(self.level <1):self.proficiency_bonus =0
    elif(self.level in(1,2,3,4)):self.proficiency_bonus =2
    elif(self.level in(5,6,7,8)):self.proficiency_bonus =3
    elif(self.level in(9,10,11,12)):self.proficiency_bonus =4
    elif(self.level in(13,14,15,16)):self.proficiency_bonus =5
    elif(self.level in(17,18,19,20)):self.proficiency_bonus =6

    if(class_):class_.modify_stats(self)
    if(background):background.modify_stats(self)
    if(race):race.modify_stats(self)

    self.strength +=ability_scores[0]
    self.strength_modifier =(self.strength -10)//2
    self.strength_saving_throw =self.strength_modifier +self.proficiency_bonus *self.strength_proficiency
    self.athletics =self.strength_modifier +self.proficiency_bonus *self.athletics_proficiency
    self.carry_capacity =self.strength *15

    self.dexterity +=ability_scores[1]
    self.dexterity_modifier =(self.dexterity -10)//2
    self.dexterity_saving_throw =self.dexterity_modifier +self.proficiency_bonus *self.dexterity_proficiency
    self.acrobatics =self.dexterity_modifier +self.proficiency_bonus *self.acrobatics_proficiency
    self.sleight_of_hand =self.dexterity_modifier +self.proficiency_bonus *self.sleight_of_hand_proficiency
    self.stealth =self.dexterity_modifier +self.proficiency_bonus *self.stealth_proficiency
    self.initiative_modifier =self.dexterity_modifier
    self.armor_class =10+self.dexterity_modifier
    
    self.constitution +=ability_scores[2]
    self.constitution_modifier =(self.constitution -10)//2
    self.constitution_saving_throw =self.constitution_modifier +self.proficiency_bonus *self.constitution_proficiency
    self.maximum_hit_points +=(self.hit_die +self.constitution_modifier)*self.level
    self.hit_points =self.maximum_hit_points

    self.intelligence +=ability_scores[3]
    self.intelligence_modifier =(self.intelligence -10)//2
    self.intelligence_saving_throw =self.intelligence_modifier +self.proficiency_bonus *self.intelligence_proficiency
    self.arcana =self.intelligence_modifier +self.proficiency_bonus *self.arcana_proficiency
    self.history =self.intelligence_modifier +self.proficiency_bonus *self.history_proficiency
    self.nature =self.intelligence_modifier +self.proficiency_bonus *self.nature_proficiency
    self.investigation =self.intelligence_modifier +self.proficiency_bonus *self.investigation_proficiency
    self.religion =self.intelligence_modifier +self.proficiency_bonus *self.religion_proficiency

    self.wisdom +=ability_scores[4]
    self.wisdom_modifier =(self.wisdom -10)//2
    self.wisdom_saving_throw =self.wisdom_modifier +self.proficiency_bonus *self.wisdom_proficiency
    self.animal_handling =self.wisdom_modifier +self.proficiency_bonus *self.animal_handling_proficiency
    self.insight =self.wisdom_modifier +self.proficiency_bonus *self.insight_proficiency
    self.medicine =self.wisdom_modifier +self.proficiency_bonus *self.medicine_proficiency
    self.perception =self.wisdom_modifier +self.proficiency_bonus *self.perception_proficiency
    self.survival =self.wisdom_modifier +self.proficiency_bonus *self.survival_proficiency
    self.passive_perception =10+self.perception
    
    self.charisma +=ability_scores[5]
    self.charisma_modifier =(self.charisma -10)//2
    self.charisma_saving_throw =self.charisma_modifier +self.proficiency_bonus *self.charisma_proficiency
    self.deception =self.charisma_modifier +self.proficiency_bonus *self.deception_proficiency
    self.intimidation =self.charisma_modifier +self.proficiency_bonus *self.intimidation_proficiency
    self.performance =self.charisma_modifier +self.proficiency_bonus *self.performance_proficiency
    self.persuasion =self.charisma_modifier +self.proficiency_bonus *self.persuasion_proficiency

    for weapon in simple_weapons:setattr(self,f"{weapon.replace(' ','_')}_proficiency",self.simple_weapon_proficiency)
    for weapon in martial_weapons:setattr(self,f"{weapon.replace(' ','_')}_proficiency",self.martial_weapon_proficiency)

    if(creature):creature.modify_stats(self)

  def on_turn_start(self):
    self.movement =self.speed
    self.momentum =0

class Equipment:
  def __init__(self,carry_capacity,class_=None):
    self.mainhand =None
    self.offhand =None
    self.armor =None
    self.inventory ={}
    self.update_total_weight()
    self.carry_capacity =carry_capacity
    if(class_):class_.modify_equipment(self)
  def update_total_weight(self):
    self.total_weight =self.mainhand.weight if(self.mainhand)else 0
    for item in self.inventory.values():self.total_weight +=item.weight
  def add_to_inventory(self,item):
    self.update_total_weight()
    if(item.weight <=self.carry_capacity -self.total_weight):self.inventory[formatters.strip_colors(item.name)]=item
    else:formatters.slow_print(f"{entity.name} doesn't have enough carry capacity to carry {item.name}",True)
    self.update_total_weight()
  def remove_from_inventory(self,item):
    del self.inventory[item.name]
    self.update_total_weight()
  def add_to_mainhand(self,item):
    if(self.mainhand):self.add_to_inventory(self.mainhand)
    self.mainhand =self.inventory[formatters.strip_colors(item.name)]
    del self.inventory[formatters.strip_colors(item.name)]

class Board:
  def __init__(self,size,layout):
    self.size =size
    self.tiles =[[self.random_tile(x,y) for x in range(self.size)]for y in range(self.size)]
    getattr(self,layout)()
    self.round =0
    self.x_coordinates =[]
    self.y_coordinates =[]
    for coordinate in range(self.size):
      coordinate=str(coordinate)
      if(len(coordinate)==1):coordinate="0"+coordinate
      self.x_coordinates.append(coordinate)
      self.y_coordinates.append(coordinate)
  def random_tile(self,x,y):
    tile_kind=roll(1,20,0)
    if(tile_kind in range(1,11)):return tiles.NormalTerrain(x,y)
    elif(tile_kind in range(11,15)):return tiles.DifficultTerrain(x,y)
    elif(tile_kind in range(15,19)):return tiles.ChasmHazard(x,y)
    elif(tile_kind==19):
      trap_kind=roll(1,20,0)
      if(trap_kind in range(1,20)):return tiles.SpikeTrap(x,y)
      elif(trap_kind==20):return tiles.CrusherTrap(x,y)
    elif(tile_kind==20):return tiles.NormalTerrain(x,y,entities.Zombie(x,y))
  def render(self):
    if(settings["Stats for nerds"]):formatters.slow_print(f"{formatters.clear}Seed: {seed} | RAM usage: {formatters.format_RAM_usage()}")
    for y,row in enumerate(self.tiles):formatters.slow_print(f"{' '.join(tile.render()for tile in row)} {self.y_coordinates[y]if settings['Stats for nerds']else'|'}")
    formatters.slow_print(" ".join(x_coordinate if(settings["Stats for nerds"])else"--" for x_coordinate in self.x_coordinates))
    if(settings["Stats for nerds"]):formatters.slow_print(f"Round: {game_round} | Game: {formatters.format_time(game_round*6-6)} | Real: {formatters.format_time(elapsed_time)}")
  def grid(self):
    clearance=False
    while(clearance==False):
      for y,row in enumerate(self.tiles):
        for x,tile in enumerate(row):
          wall_tile=roll(1,20,0)
          if(wall_tile in(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)):wall_tile=tiles.ObstructionTerrain(x,y)
          elif(wall_tile in(16,17,18,19)):wall_tile=tiles.NormalTerrain(x,y)
          elif(wall_tile==20):wall_tile=tiles.ArrowTrap(x,y)
          if(x in(0,self.size- 1))or(y in(0,self.size -1)):self.tiles[y][x]=tiles.ObstructionTerrain(x,y)
          elif(x%5==0)or(y%5==0):self.tiles[y][x]=wall_tile
      good_lines=[]
      for y in range(self.size):
        if(y in(0,self.size -1)):continue
        obstruction_count=sum(1 for x in range(self.size) if isinstance(self.tiles[y][x],tiles.ObstructionTerrain))
        if(obstruction_count<self.size -(self.size //5)):good_lines.append(True)
        else:good_lines.append(False);break
      for x in range(self.size):
        if(x in(0,self.size -1)):continue
        obstruction_count=sum(1 for y in range(self.size)if isinstance(self.tiles[y][x],tiles.ObstructionTerrain))
        if(obstruction_count<self.size -(self.size //5)):good_lines.append(True)
        else:good_lines.append(False);break
      if(good_lines.count(False)==0):clearance=True
      else:clearance=False
  def open(self):pass
  def uniform(self):
    for y,row in enumerate(self.tiles):
      for x,tile in enumerate(row):
        if not(isinstance(tile,tiles.NormalTerrain)):self.tiles[y][x]=tiles.NormalTerrain(x,y)

def roll(amount,kind,modifier,advantage=None,critical=None):
  if(advantage==True):rolls=[max(random.randint(1,kind),random.randint(1,kind))for roll in range(amount)]
  elif(advantage==False):rolls=[min(random.randint(1,kind),random.randint(1,kind))for roll in range(amount)]
  elif(advantage==None):rolls=[random.randint(1,kind)for roll in range(amount)]
  if(critical):
    if(rolls==[1]):return(sum(rolls)+modifier,0)
    elif(rolls==[kind]):return(sum(rolls)+modifier,2)
    else:return sum(rolls)+modifier,1
  else:return sum(rolls)+modifier

def raycast(coordinates,direction,distance,true_attribute,true_state,false_attribute,false_state):
  for step in range(distance):
    if(getattr(board.tiles[coordinates[1]+direction[1]][coordinates[0]+direction[0]],false_attribute)==false_state)or((getattr(board.tiles[coordinates[1]][coordinates[0]+direction[0]],false_attribute)==false_state)and(getattr(board.tiles[coordinates[1]+direction[1]][coordinates[0]],false_attribute)==false_state)):return False
    elif(getattr(board.tiles[coordinates[1]+direction[1]][coordinates[0]+direction[0]],true_attribute)==true_state):return (coordinates[0]+direction[0],coordinates[1]+direction[1])
    coordinates[0]+=direction[0];coordinates[1]+=direction[1]
  return True

def parse_ordered_pair(coordinates):return tuple(int(coordinate)for coordinate in coordinates.strip("()").replace(","," ").split())

def parse_input(user,code):
  global player
  hotkeys={"w":abilities.walk,"j":abilities.jump,"d":abilities.dash,"a":abilities.attack,"i":abilities.inspect}
  code=code.split()
  if(code==[]):return False
  try:
    command=hotkeys[code[0]]
    if(command in(*user.abilities.traversals,*user.abilities.actions,*user.abilities.bonus_actions)):
      command(user)if(len(code)==1)else command(user,code[1]);return True
    else:return False
  except KeyError:
    try:
      if(code[0]=="/")and(settings["Cheats"]==False):raise Exception("Cheats are disabled")
      match code:
        case("/","summon",creature,coordinates):
          x,y=parse_ordered_pair(coordinates)
          board.tiles[y][x].entity =getattr(creatures,creature)(x,y)
          board.tiles[y][x].check_occupation()
          return True
        case("/","give",target,item):globals()[target].equipment.mainhand =globals()[item]();return True
        case("/","heal",target,amount):globals()[target].stats.hit_points +=int(amount);return True
        case("/","teleport",target,coordinates):
          x,y=parse_ordered_pair(coordinates)
          board.tiles[globals()[target].y][globals()[target].x].entity =None
          board.tiles[int(y)][int(x)].entity =globals()[target]
          globals()[target].x,globals()[target].y =int(x),int(y)
          return True
        case("/","kaboom"):
          for row in board.tiles:
            for tile in row:
              if(tile.entity is player):continue
              tile.entity =None
              tile.check_occupation()
          return True
        case("/","remake"):
          board.tiles[player.y][player.x].entity =None
          player=Character()
          return True
        case("/","execute",line):exec(line.replace("~"," ").replace("#","'"),{**globals(),"true":True,"false":False,"none":None});return True
        case other:
          if(other[0]=="/"):formatters.slow_print(f"{formatters.clear}Command not recognized",True)
    except Exception as error:formatters.slow_print(f"{formatters.clear}{type(error).__name__}: {str(error)}",True)

def game_setup():
  while(True):
    formatters.slow_print(f"{formatters.clear}Select a board size")
    formatters.slow_print("-"*10)
    for key,size in sizes.items():formatters.slow_print(f"{key}. {size[0]}")
    formatters.slow_print("-"*10)
    try:size=sizes[input(prompt)][1];break
    except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(sizes)}",True)
  while(True):
    formatters.slow_print(f"{formatters.clear}Select a board layout")
    formatters.slow_print("-"*10)
    for key,layout in layouts.items():formatters.slow_print(f"{key}. {layout.replace('_',' ').title()}")
    formatters.slow_print("-"*10)
    try:layout=layouts[input(prompt)];break
    except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(layouts)}",True)
  formatters.slow_print(f"{formatters.clear}Input a seed (optional)")
  formatters.slow_print("-"*10)
  user_input=input(prompt)
  try:
    if(int(user_input)>=0):seed=int(user_input)%max(seed_limit)
    else:seed=int(user_input)%min(seed_limit)
  except ValueError:seed=random.randint(min(seed_limit),max(seed_limit))
  random.seed(seed)
  board=Board(size,layout)
  random.seed()
  return board,seed

def game_loop():
  global game_round
  terminator=False
  formatters.slow_print(f"{formatters.clear}{os.path.basename(__file__)} {inspect.currentframe().f_code.co_name}")
  formatters.slow_print("-"*10)
  formatters.slow_print("Input anything to start")
  formatters.slow_print("-"*10)
  user_input=input(prompt)
  while(True):
    while(True):
      formatters.slow_print(f"{formatters.clear}Main menu")
      formatters.slow_print("-"*10)
      for key,option in main_menu.items():formatters.slow_print(f"{key}. {option.__name__.replace('_',' ').capitalize()}")
      formatters.slow_print(f"{len(main_menu)+1}. Exit")
      formatters.slow_print("-"*10)
      user_input=input(prompt)
      try:
        if(main_menu[user_input]()):break
      except KeyError:
        if(user_input==str(len(main_menu)+1)):
          terminator=True
          break
        else:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(main_menu)+1}",True)
    if(terminator==True):break
    for row in board.tiles:
      for tile in row:
        if isinstance(tile,tiles.TrapTile):
          perception_check,critical=roll(1,20,player.stats.perception,critical=True)
          if(perception_check>=tile.difficulty_class)or(critical==2):tile.icon =tile.revealed_icon
    while(True):
      filesystems.save_game()
      game_round +=1
      formatters.slow_print(f"{formatters.clear}ROUND {game_round}")
      formatters.slow_print("-"*10)
      user_input=input(prompt)
      initiative_order=[]
      for row in board.tiles:
        for tile in row:
          tile.on_round_start()
          if(tile.entity):
            tile.entity.on_round_start()
            initiative_order.append((tile.entity,roll(1,20,tile.entity.stats.initiative_modifier)))
      initiative_order=sorted(initiative_order,key=lambda x:x[1],reverse=True)
      formatters.slow_print(f"{formatters.clear}Initiative order")
      formatters.slow_print("-"*10)
      for entity,initiative in initiative_order:formatters.slow_print(f"{entity.name} | {initiative}")
      formatters.slow_print("-"*10)
      user_input=input(prompt)
      while(initiative_order):
        if(initiative_order[0][0]is player):round_start_time=time.time()
        initiative_order[0][0].take_turn()
        if(initiative_order[0][0]is player):round_end_time=time.time()
        initiative_order.pop(0)
        if(player.stats.hit_points ==0):
          formatters.slow_print(f"{player.name} is dead!",True)
          if(settings["Permadeath"]):
            try:os.remove("D&D_save.txt")
            except FileNotFoundError:pass
            formatters.slow_print("Save file deleted",True)
          filesystems.update_leaderboard(player.name,round(player.kills /game_round)*1000)
          break
      for row in board.tiles:
        for tile in row:
          tile.on_round_end()
          if(tile.entity):tile.entity.on_round_end()
      elapsed_time=round(round_end_time-round_start_time)
      if(player.stats.hit_points ==0):break
  formatters.slow_print(f"{formatters.clear}{os.path.basename(__file__)} {inspect.currentframe().f_code.co_name} terminated")

import inspect,os,random,time
import abilities,entities,filesystems,formatters,tiles
board,seed,player,game_round,elapsed_time=None,None,None,None,None
prompt=f"{formatters.blink}>:{formatters.reset} "
sizes={"1":("Tiny",6),"2":("Small",11),"3":("Medium",16),"4":("Large",21),"5":("Huge",26),"6":("Gargantuan",31)}
layouts={"1":"grid","2":"open","3":"uniform"}
seed_limit=(-9_999_999_999,9_999_999_999)
directions=((-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1))
direction_indicators={directions[0]:"↖",directions[1]:"↑",directions[2]:"↗",directions[3]:"←",directions[4]:"→",directions[5]:"↙",directions[6]:"↓",directions[7]:"↘"}
direction_keybinds={"q":directions[0],"w":directions[1],"e":directions[2],"a":directions[3],"d":directions[4],"z":directions[5],"x":directions[6],"c":directions[7]}
direction_keybinds_translator={value:key for key,value in direction_keybinds.items()}
simple_weapons=("club","dagger","greatclub","handaxe","javelin","light hammer","mace","quarterstaff","sickle","spear","dart","light crossbow","shortbow","sling")
martial_weapons=("battleaxe","flail","glaive","greataxe","greatsword","halberd","lance","longsword","maul","morningstar","pike","rapier","scimitar","shortsword","trident","warhammer","war pick","whip","blowgun","hand crossbow","heavy crossbow","longbow","musket","pistol")
main_menu={"1":filesystems.continue_game,"2":filesystems.load_game,"3":filesystems.new_game,"4":filesystems.display_leaderboard,"5":filesystems.change_settings}
default_settings={"Cheats":False,"Colored text":True,"Permadeath":False,"Run backup files":False,"Scrolling text":True,"Show chasms":False,"Stats for nerds":False}
settings=filesystems.load_settings()
settings_menu={str(key+1):value for key,value in enumerate(default_settings)}
if(__name__=="__main__"):game_loop()
