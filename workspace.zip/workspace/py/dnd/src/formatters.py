def strip_colors(text):return re.sub(f"\x1B\[[0-9]*m","",text)

def slow_print(text,delay=False):
  text=text if(__main__.settings["Colored text"])else strip_colors(text)
  if(__main__.settings["Scrolling text"]):
    for symbol in text:
      sys.stdout.write(symbol)
      sys.stdout.flush()
      time.sleep(0.125/len(text))
    print()
  else:print(text)
  if(delay):time.sleep(1)

def format_time(time):
  time=[str(time//3600),str((time%3600)//60),str(time%60)]
  for index,unit in enumerate(time):
    if(len(unit)==1):time[index]="0"+unit
  return f"{time[0]}:{time[1]}:{time[2]}"

def format_hit_points(hit_points,maximum_hit_points):
  filled_segments=round((hit_points/maximum_hit_points)*10)
  if(filled_segments<=3):color=red
  elif(filled_segments<=6):color=yellow
  else:color=green
  return f"[{color}{'='*filled_segments}{' '*(10-filled_segments)}{reset}]"

def format_RAM_usage():
  usage=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
  return f"{round(usage/1024**2)} MB"if(sys.platform =="darwin")else f"{round(usage/1024)} MB"

def display_formats():
  print(f"{clear}{os.path.basename(__file__)}")
  print("-"*10)
  print(f"{bold}bold{reset}")
  print(f"{dim}dim{reset}")
  print(f"{italic}italic{reset}")
  print(f"{underline}underline{reset}")
  print(f"{blink}blink{reset}")
  print(f"{reverse}reverse{reset}")
  print(f"{strikethrough}strikethrough{reset}")
  print(f"{black}black{reset}")
  print(f"{red}red{reset}")
  print(f"{green}green{reset}")
  print(f"{yellow}yellow{reset}")
  print(f"{blue}blue{reset}")
  print(f"{magenta}magenta{reset}")
  print(f"{cyan}cyan{reset}")
  print(f"{white}white{reset}")
  print("-"*10)
  user_input=input(__main__.prompt)

import os,re,resource,sys,time,__main__
clear="\033[2J\033[H"
reset="\033[0m"
bold="\033[1m"
dim="\033[2m"
italic="\033[3m"
underline="\033[4m"
blink="\033[5m"
reverse="\033[7m"
hidden="\033[8m"
strikethrough="\033[9m"
black="\033[30m"
red="\033[31m"
green="\033[32m"
yellow="\033[33m"
blue="\033[34m"
magenta="\033[35m"
cyan="\033[36m"
white="\033[37m"
prompt=f"{os.path.basename(__file__)} >>> "

if(__name__=="__main__"):display_formats()
