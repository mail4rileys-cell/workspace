class Class:
  def __init__(self):self.name =f"{formatters.cyan}{self.__class__.__name__}{formatters.reset}"
  def proficiency_selection(self,stats,options):
    for i in range(2):
      while(True):
        formatters.slow_print(f"{formatters.clear}{self.name} | Select a skill proficiency ({i+1} of 2)")
        formatters.slow_print("-"*10)
        for key,proficiency in options.items():formatters.slow_print(f"{key}. {formatters.blue}{proficiency.replace('_',' ').capitalize()}{formatters.reset}")
        formatters.slow_print("-"*10)
        try:
          proficiency=options[input(__main__.prompt)]
          setattr(stats,proficiency,getattr(stats,proficiency)+1);break
        except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(options)}",True)
  def weapon_selection(self,equipment,options):
    while(True):
      formatters.slow_print(f"{formatters.clear}{self.name} | Select a weapon")
      formatters.slow_print("-"*10)
      for key,weapon in options.items():formatters.slow_print(f"{key}. {formatters.yellow}{weapon}{formatters.reset}")
      formatters.slow_print("-"*10)
      try:equipment.add_to_inventory(getattr(weapons,options[input(__main__.prompt)])());break
      except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(options)}",True)

class Fighter(Class):
  proficiencies={"1":"acrobatics_proficiency","2":"animal_handling_proficiency","3":"athletics_proficiency","4":"history_proficiency","5":"insight_proficiency","6":"intimidation_proficiency","7":"persuasion_proficiency","8":"perception_proficiency","9":"survival_proficiency"}
  weapons={"1":"Battleaxe","2":"Flail","3":"Glaive","4":"Greataxe","5":"Greatsword","6":"Halberd","7":"Lance","8":"Longsword","9":"Maul","10":"Morningstar","11":"Pike","12":"Rapier","13":"Scimitar","14":"Shortsword","15":"Trident","16":"Warhammer","17":"War_Pick","18":"Whip","19":"Blowgun","20":"Hand_Crossbow","21":"Heavy_Crossbow","22":"Longbow","23":"Musket","24":"Pistol"}
  def __init__(self):super().__init__()
  def modify_stats(self,stats):
    stats.hit_die +=10
    stats.strength_proficiency +=1
    stats.constitution_proficiency +=1
    self.proficiency_selection(stats,Fighter.proficiencies)
    stats.simple_weapon_proficiency +=1
    stats.martial_weapon_proficiency +=1
  def modify_equipment(self,equipment):self.weapon_selection(equipment,Fighter.weapons)

class Wizard(Class):
  proficiencies={"1":"arcana_proficiency","2":"history_proficiency","3":"insight_proficiency","4":"investigation_proficiency","5":"medicine_proficiency","6":"nature_proficiency","7":"religion_proficiency"}
  weapons={"1":"Quarterstaff","2":"Dagger"}
  def __init__(self):super().__init__()
  def modify_stats(self,entity):
    entity.hit_die +=6
    entity.intelligence_proficiency +=1
    entity.wisdom_proficiency +=1
    self.proficiency_selection(entity,Wizard.proficiencies)
  def modify_equipment(self,equipment):self.weapon_selection(equipment,Wizard.weapons)

import os,__main__
import formatters,weapons
options={"1":Fighter,"2":Wizard}
