class Tile:
  graphics={"NormalTerrain":"░░","DifficultTerrain":"▒▒","ObstructionTerrain":"██","ChasmHazard":"  ","SpikeTrap":"▲▲","CrusherTrap":"⯂⯂","ArrowTrap":"█"}
  def __init__(self,x,y,entity):
    self.x,self.y =x,y
    self.entity =entity
    self.check_occupation()
    self.icon =Tile.graphics[self.__class__.__name__]
    self.information =[]
  def render(self):
    if(self.entity):return self.entity.icon
    elif(self.icon):return self.icon
    else:return"X"
  def check_occupation(self):
    if(self.entity):self.occupied =True
    else:self.occupied =False
  def inspect(self,skill,check):
    data=getattr(self.__class__,skill)
    self.information.append(data)
  def on_round_start(self):pass
  def on_round_end(self):pass
  def on_exit(self,entity):
    self.entity =None
    self.occupied =False
  def on_enter(self,entity):
    self.entity =entity
    self.occupied =True
  def on_walk_through(self,entity):pass
  def on_jump_through(self,entity):pass
  def on_land_at(self,entity):pass

class TerrainTile(Tile):pass

class NormalTerrain(TerrainTile):
  perception="You see flat, smooth terrain, which appears to be mundane and featureless"
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.movement_cost =5
    self.walkable =True
    self.jumpable =True
    self.cover =0

class DifficultTerrain(TerrainTile):
  perception="The ground here is littered with jagged rocks that protrude from it at unsightly angles"
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.movement_cost =10
    self.walkable =True
    self.jumpable =True
    self.cover =0
  def on_land_at(self,entity):
    acrobatics_check=__main__.roll(1,20,entity.stats.acrobatics)
    formatters.slow_print(f"{formatters.clear}{entity.name} | {formatters.blue}Acrobatics{formatters.reset} check: {acrobatics_check}",True)
    if(acrobatics_check<10):
      entity.stats.movement -=entity.stats.speed //2
      if(entity.stats.movement <0):entity.stats.movement =0
      formatters.slow_print(f"{entity.name} fails their landing",True)

class ObstructionTerrain(TerrainTile):
  perception="This space is completely occupied by solid stone"
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.movement_cost =10
    self.walkable =False
    self.jumpable =False
    self.cover =1

class HazardTile(Tile):pass

class ChasmHazard(HazardTile):
  perception="There is nothing here, a pit plummets downwards as far as you can see."
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.movement_cost =5
    self.walkable =False
    self.jumpable =True
    self.cover =0
  def render(self):
    return "[]"if(__main__.settings["Show chasms"])else super().render()
  def fall_into_chasm(self,entity):
    formatters.slow_print(f"{formatters.clear}{entity.name} falls into a chasm",True)
    entity.take_damage(entity.stats.hit_points,"true")
  def on_land_at(self,entity):self.fall_into_chasm(entity)

class TrapTile(Tile):
  def __init__(self,x,y,entity):
    super().__init__(x,y,entity)
    self.icon =Tile.graphics[self.__class__.mask.__name__]
    self.active =True
    initial_state=__main__.roll(1,4,0)
    if(initial_state in(1,2)):self.armed =True
    elif(initial_state in(3,4)):self.armed =False
  def inspect(self,skill,check):
    data=getattr(self.__class__.mask,skill)
    self.information.append(data)
    if(check>=10):
      self.icon =self.revealed_icon
      data=getattr(self.__class__,skill)
      self.information.append(data)
  def on_round_end(self):
    if(self.active):self.armed =True

class SpikeTrap(TrapTile):
  mask=NormalTerrain
  perception="Upon closer examination, you notice a multitude of holes arranged along the floor, there is a spike trap here"
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.revealed_icon =Tile.graphics["SpikeTrap"]
    self.movement_cost =5
    self.walkable =True
    self.jumpable =True
    self.cover =0
    self.difficulty_class =15
    self.damage_type ="piercing"
  def trigger(self,entity):
    self.armed =False
    self.icon =self.revealed_icon
    damage=__main__.roll(2,6,0)
    saving_throw,critical=__main__.roll(1,20,entity.stats.dexterity_saving_throw,critical=True)
    formatters.slow_print(f"{entity.name} triggers a trap",True)
    formatters.slow_print(f"Sharp iron spikes shoot out of the ground beneath {entity.name}",True)
    formatters.slow_print(f"{entity.name} | {formatters.blue}Dexterity{formatters.reset} saving throw: {saving_throw}",True)
    if(saving_throw>=self.difficulty_class)or(critical==2):
      formatters.slow_print(f"{entity.name} is grazed by the spikes",True)
      entity.take_damage(round(damage/2),self.damage_type)
    elif(saving_throw<self.difficulty_class)or(critical==0):
      formatters.slow_print(f"{entity.name} is impaled by the spikes",True)
      entity.take_damage(damage,self.damage_type)
    outcome=__main__.roll(1,6,0)
    if(outcome in(1,2,3,4,5)):
      formatters.slow_print("The spikes recede back into the ground",True)
    elif(outcome==6):
      formatters.slow_print("The spikes fail to lower, and remain jutting from the ground",True)
      self=DifficultTerrain(self.x,self.y,self.entity)
  def on_walk_through(self,entity):
    if(self.armed):self.trigger(entity)
  def on_land_at(self,entity):
    if(self.armed):self.trigger(entity)

class CrusherTrap(TrapTile):
  mask=NormalTerrain
  perception="However, the ceiling above this floor is riddled with fine cracks, a crusher trap lies in wait here"
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.revealed_icon =Tile.graphics["CrusherTrap"]
    self.movement_cost =5
    self.walkable =True
    self.jumpable =False
    self.cover =0
    self.difficulty_class =15
    self.damage_type ="bludgeoning"
  def trigger(self,entity):
    self.armed =False
    self.icon =self.revealed_icon
    damage=__main__.roll(4,10,0)
    saving_throw,critical=__main__.roll(1,20,self.entity.stats.strength_saving_throw,critical=True)
    formatters.slow_print(f"{entity.name} triggers a trap",True)
    formatters.slow_print(f"The stone ceiling above {self.entity.name} surges downwards",True)
    formatters.slow_print(f"{entity.name} | {formatters.blue}Strength{formatters.reset} saving throw: {saving_throw}",True)
    if(saving_throw>=self.difficulty_class)or(critical==2):
      formatters.slow_print(f"{entity.name} pushes the crusher back into the ceiling",True)
      entity.take_damage(round(damage/2),self.damage_type)
    elif(saving_throw<self.difficulty_class)or(critical==0):
      formatters.slow_print(f"{entity.name} is pulverized by the crusher",True)
      entity.take_damage(damage,self.damage_type)
      outcome=__main__.roll(1,6,0)
      if(outcome in(1,2,3,4,5)):
        formatters.slow_print("The crusher slowly rises upwards, sealing itself seamlessly with the ordinary roof tiles",True)
      elif(outcome==6):
        formatters.slow_print(f"The crusher fails to move back into the ceiling, and {self.entity.name} is trapped underneath it",True)
        entity.take_damage(entity.stats.hit_points,"true")
        self=ObstructionTerrain(self.x,self.y,self.entity)
  def on_walk_through(self,entity):
    if(self.armed):self.trigger(entity)
  def on_land_at(self,entity):
    if(self.armed):self.trigger(entity)

class ArrowTrap(TrapTile):
  mask=ObstructionTerrain
  perception="Within this stone sits a small circular notch that is perfectly suited for arrows, the gaze of an arrow trap pervades this area."
  def __init__(self,x,y,entity=None):
    super().__init__(x,y,entity)
    self.direction =random.choice(__main__.directions)
    self.revealed_icon =Tile.graphics["ArrowTrap"]+__main__.direction_indicators[self.direction]
    self.movement_cost =10
    self.walkable =False
    self.jumpable =False
    self.cover =1
    self.difficulty_class =15
  def check_line_of_sight(self):
    coordinates=__main__.raycast([self.x,self.y],self.direction,10,"entity",__main__.player,"cover",1)
    if(isinstance(coordinates,tuple)):self.trigger(__main__.board.tiles[coordinates[1]][coordinates[0]].entity)
  def trigger(self,entity):
    self.armed =False
    self.icon =self.revealed_icon
    attack_roll,critical=__main__.roll(1,20,5,critical=True)
    formatters.slow_print(f"{formatters.clear}{entity.name} triggers a trap",True)
    formatters.slow_print(f"An arrow fires out of a wall at ({self.x},{self.y})",True)
    formatters.slow_print(f"ArrowTrap | Attack roll: {attack_roll}",True)
    if(attack_roll>=entity.stats.armor_class)or(critical==2):
      formatters.slow_print(f"The arrow punctures {entity.name}",True)
      entity.take_damage(__main__.roll(1,6,3)*critical,"piercing")
    elif(attack_roll<entity.stats.armor_class)or(critical==0):
      formatters.slow_print(f"The arrow soars past {entity.name}",True)
  def on_round_start(self):
    if(self.armed):self.check_line_of_sight()

import os,random,__main__
import formatters
