class Background:
  def __init__(self):self.name =f"{formatters.cyan}{self.__class__.__name__}{formatters.reset}"
  def ability_score_increases(self,entity,options):
    while(True):
      formatters.slow_print(f"{formatters.clear}{self.name} | Select an ability score increase")
      formatters.slow_print("-"*10)
      for key,ability_increases in options.items():
        formatters.slow_print(f"{key}. {formatters.blue}{', '.join(f'+{increment} {ability}'for ability,increment in ability_increases).title()}{formatters.reset}")
      formatters.slow_print("-"*10)
      try:
        ability_increases=options[input(__main__.prompt)]
        for ability,increment in ability_increases:setattr(entity,ability,getattr(entity,ability)+increment)
        break
      except KeyError:formatters.slow_print(f"{formatters.clear}Please input a number from 1 to {len(options)}",True)

class Sage(Background):
  ability_scores={"1":(("constitution",2),("intelligence",1)),"2":(("constitution",2),("wisdom",1)),"3":(("intelligence",2),("constitution",1)),"4":(("intelligence",2),("wisdom",1)),"5":(("wisdom",2),("constitution",1)),"6":(("wisdom",2),("intelligence",1)),"7":(("constitution",1),("intelligence",1),("wisdom",1))}
  def __init__(self):super().__init__()
  def modify_stats(self,entity):
    self.ability_score_increases(entity,self.__class__.ability_scores)
    entity.arcana_proficiency +=1
    entity.history_proficiency +=1

class Soldier(Background):
  ability_scores={"1":(("strength",2),("dexterity",1)),"2":(("strength",2),("constitution",1)),"3":(("dexterity",2),("strength",1)),"4":(("dexterity",2),("constitution",1)),"5":(("constitution",2),("strength",1)),"6":(("constitution",2),("dexterity",1)),"7":(("strength",1),("dexterity",1),("constitution",1))}
  def __init__(self):super().__init__()
  def modify_stats(self,entity):
    self.ability_score_increases(entity,self.__class__.ability_scores)
    entity.athletics_proficiency +=1
    entity.intimidation_proficiency +=1

import os,__main__
import formatters
options={"1":Sage,"2":Soldier}
