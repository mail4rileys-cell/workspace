import math
import re
import sys

from typeguard import typechecked

@typechecked
def calculate(radius: float, gm: float, semi_major_axis: float, eccentricity: float, inclination: float, orbital_period: float) -> dict[str, str]:
  pe = 1 + eccentricity
  ne = 1 - eccentricity
  primary_gm = (4 * (math.pi ** 2) * (semi_major_axis ** 3)) / (orbital_period ** 2)
  mass = gm / 6.67430e-11
  periapsis_distance = semi_major_axis * ne
  apoapsis_distance = semi_major_axis * pe
  periapsis_speed = math.sqrt((primary_gm * pe) / periapsis_distance)
  apoapsis_speed = math.sqrt((primary_gm * ne) / apoapsis_distance)
  return {
    "mass": f"{mass:e}L",
    "radius": f"{(radius):e}L",
    "periapsis_distance": f"{(periapsis_distance):e}L",
    "apoapsis_distance": f"{(apoapsis_distance):e}L",
    "periapsis_speed": f"{(periapsis_speed):e}L",
    "apoapsis_speed": f"{(apoapsis_speed):e}L",
    "incline": f"{inclination}L"
  }

@typechecked
def main() -> int:
  result = None
  phase = None
  name = None
  if len(sys.argv) == 1:
    radius = input("Input radius (m | km | AU): ").strip().lower()
    match radius.split(" ")[1]:
      case "m": radius = float(radius.split(" ")[0])
      case "km": radius = float(radius.split(" ")[0]) * 1e3
      case "au": radius = float(radius.split(" ")[0]) * 149597870700
      case _: raise RuntimeError("Invalid distance unit: " + radius.split(" ")[1])
    gm = float(input("Input GM (km^3/s^2): ").strip().lower()) * 1e9
    semi_major_axis = input("Input semi_major_axis (m | km | AU): ").strip().lower()
    match semi_major_axis.split(" ")[1]:
      case "m": semi_major_axis = float(semi_major_axis.split(" ")[0])
      case "km": semi_major_axis = float(semi_major_axis.split(" ")[0]) * 1e3
      case "au": semi_major_axis = float(semi_major_axis.split(" ")[0]) * 149597870700
      case _: raise RuntimeError("Invalid distance unit: " + semi_major_axis.split(" ")[1])
    eccentricity = float(input("Input eccentricity: ").strip().lower())
    inclination = float(input("Input inclination (deg): ").strip().lower())
    orbital_period = input("Input orbital_period (s | min | h | d | y): ").strip().lower()
    match orbital_period.split(" ")[1]:
      case "s": orbital_period = float(orbital_period.split(" ")[0])
      case "min": orbital_period = float(orbital_period.split(" ")[0]) * 60
      case "h": orbital_period = float(orbital_period.split(" ")[0]) * 3600
      case "d": orbital_period = float(orbital_period.split(" ")[0]) * 86400
      case "y": orbital_period = float(orbital_period.split(" ")[0]) * 31536000
      case _: raise RuntimeError("Invalid time unit: " + orbital_period.split(" ")[1])
    result = calculate(
      radius,
      gm,
      semi_major_axis,
      eccentricity,
      inclination,
      orbital_period
    )
    phase = input("Use periapsis or apoapsis? (p/a): ").strip().lower()
    name = input("Input name: ").upper()
  elif len(sys.argv) == 9:
    result = calculate(
      float(sys.argv[1]),
      float(sys.argv[2]),
      float(sys.argv[3]),
      float(sys.argv[4]),
      float(sys.argv[5]),
      float(sys.argv[6])
    )
    phase = sys.argv[7]
    name = sys.argv[8]
  else:
    print("Usage: <radius> <GM> <semi_major_axis> <eccentricity> <inclination> <orbital_period> <phase> <body_name>")
    return 1
  data = {
    "mass": result["mass"],
    "radius": result["radius"],
    "distance": None,
    "speed": None,
    "incline": result["incline"]
  }
  if phase == "periapsis" or phase == "p":
    data["distance"] = result["periapsis_distance"]
    data["speed"] = result["periapsis_speed"]
  elif phase == "apoapsis" or phase == "a":
    data["distance"] = result["apoapsis_distance"]
    data["speed"] = result["apoapsis_speed"]
  else:
    print(f"Invalid phase: {phase}")
    return 1
  patterns = [
    (rf"(CONSTANT\({name}_MASS,\s*kilograms\()[^)]*(\)\))", data["mass"]),
    (rf"(CONSTANT\({name}_RADIUS,\s*meters\()[^)]*(\)\))", data["radius"]),
    (rf"(CONSTANT\({name}_DISTANCE,\s*meters\()[^)]*(\)\))", data["distance"]),
    (rf"(CONSTANT\({name}_SPEED,\s*meters_per_second\()[^)]*(\)\))", data["speed"]),
    (rf"(CONSTANT\({name}_INCLINE,\s*degrees\()[^)]*(\)\))", data["incline"])
  ]
  text = None
  with open("cpp/utils/constants.hpp", "r") as file:
    text = file.read()
  for pattern, replacement in patterns:
    text = re.sub(pattern, rf"\g<1>{replacement}\g<2>", text)
  with open("cpp/utils/constants.hpp", "w") as file:
    file.write(text)
  return 0  

if __name__ == "__main__":
  sys.exit(main())
