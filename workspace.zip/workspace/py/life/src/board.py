import copy
import os
import pickle
import subprocess
import sys
import time

import __main__

import utils.terminal as terminal

from cell import Cell


class Board:

  def __init__(self: Board) -> None:
    subprocess.run(["clear"])
    print("Input rules notation | Default: B3/S23")
    print("-" * 10)
    match input(">: ").replace("B", "").replace("S", "").split("/"):
      case birth_set, survival_set:
        self.birth_set = tuple(map(int, birth_set))
        self.survival_set = tuple(map(int, survival_set))
      case _:
        self.birth_set = (3,)
        self.survival_set = (2, 3)
    subprocess.run(["clear"])
    print("Input the width and height of the board | Default: 19 19")
    print("-" * 10)
    try:
      self.width, self.height = tuple(map(int, input(">: ").split(" ")))
    except ValueError:
      self.width = 19
      self.height = 19
      
    self.repeating = False
    self.data = set()
    self.generation = 0
    self.cells = [[Cell() for _ in range(self.width)] for _ in range(self.height)]
    self.x_coords = ()
    self.y_coords = ()
    self.coordinates = ()
    self.update_metadata()
    
    self.hidden_cursor = False
    self.previous_cells = [[]]
    self.snapshot()
    self.previous_undo = copy.deepcopy(self.cells)
    self.trace_mode = False
    self.preview_mode = False
    self.message = f"Editor | Input \"execute\" to run your design"

  def render(self: Board) -> None:
    print("     " + " ".join("==" for _ in range(self.width)))
    for y, row in enumerate(self.cells):
      print(self.y_coords[y] + " ||" + " ".join(cell.render(self, x, y) for x, cell in enumerate(row)) + "||")
    print("     " + " ".join("==" for _ in range(self.width)))
    print("     " + " ".join(x for x in self.x_coords))

  def serialize(self: Board) -> int:
    serial = 0
    for row in self.cells:
      for cell in row:
        serial = (serial << 1) | cell.condition
    return serial

  def new_iteration(self: Board) -> None:
    data = self.serialize()
    self.repeating = data in self.data
    self.data.add(data)
    self.generation += 1
    for y, row in enumerate(self.cells):
      for x, cell in enumerate(row):
        cell.next_condition = cell.determine_next_condition(self, x, y)
    for row in self.cells:
      for cell in row:
        cell.resolve()

  def execute(self: Board) -> None:
    self.snapshot()
    self.generation = 0
    self.repeating = False
    self.data.clear()
    self.cells[self.cursor[1]][self.cursor[0]].selected = False
    while not self.repeating:
      self.new_iteration()
      subprocess.run(["clear"])
      print(f"Current generation: {self.generation}")
      self.render()
      time.sleep(0.1)

  def update_metadata(self: Board) -> None:
    self.width = len(self.cells[0])
    self.height = len(self.cells)
    self.x_coords = tuple(str(x) + " " if len(str(x)) == 1 else str(x) for x in range(self.width))
    self.y_coords = tuple(" " + str(y) if len(str(y)) == 1 else str(y) for y in range(self.height - 1, -1, -1))
    self.coordinates = tuple((x, y) for x in range(self.width) for y in range(self.height))
    self.home()

  def clear(self: Board) -> None:
    self.snapshot()
    for row in self.cells:
      for cell in row:
        cell.kill()

  def column(self: Board, snapshot: bool = True) -> None:
    if snapshot:
      self.snapshot()
    for y in range(self.height):
      self.cells[y][self.cursor[0]].toggle()

  def copy_(self: Board, name: str, x: str, y: str, cut: bool = False) -> None:
    x1, y1 = self.cursor
    try:
      x2 = int(x)
    except ValueError:
      self.message = "X coordinate invalid"
      return
    if not 0 <= x2 < self.width:
      self.message = "X coordinate out of bounds"
      return
    try:
      y2 = self.height - int(y) - 1
    except ValueError:
      self.message = "Y coordinate invalid"
      return
    if not 0 <= y2 < self.height:
      self.message = "Y coordinate out of bounds"
      return
    if x1 > x2:
      x1, x2 = x2, x1
    if y1 > y2:
      y1, y2 = y2, y1
    clip = []
    for y_ in range(y1, y2 + 1):
      clip.append(self.cells[y_][x1 : x2 + 1])
      if cut:
        self.snapshot()
        try:
          for row in self.cells[y_][x1 : x2 + 1]:
            if type(row) is not list:
              row = [] 
            for cell in row:
              cell.kill()
        except IndexError:
          pass
    with open("py/life/data/" + name + ".pkl", "wb") as file:
      file.write(pickle.dumps(clip, protocol = pickle.HIGHEST_PROTOCOL))

  def crosshair(self: Board) -> None:
    self.column(snapshot = False)
    self.row(snapshot = False)

  def delete(self: Board, name: str) -> None:
    try:
      os.remove("py/life/data/" + name + ".pkl")
    except FileNotFoundError:
      self.message = "File not found"

  def expand_reduce_column(self: Board, action: str, amount: str) -> None:
    self.snapshot()
    try:
      amount_ = int(amount)
    except ValueError:
      self.message = "Number of columns invalid"
      return
    if action == "expand":
      for _ in range(amount_):
        for row in self.cells:
          row.append(Cell(False))
    elif action == "reduce":
      for _ in range(amount_):
        for row in self.cells:
          row.pop()
    else:
      self.message = "Action invalid"
      return
    self.update_metadata()

  def expand_reduce_row(self: Board, action: str, amount: str) -> None:
    self.snapshot()
    try:
      amount_ = int(amount)
    except ValueError:
      self.message = "Number of rows invalid"
      return
    if action == "expand":
      for _ in range(amount_):
        self.cells.append([Cell(False) for _ in range(self.width)])
    elif action == "reduce":
      for _ in range(amount_):
        self.cells.pop()
    else:
      self.message = "Action invalid"
      return
    self.update_metadata()

  def hide(self: Board) -> None:
    self.hidden_cursor = not self.hidden_cursor

  def home(self: Board) -> None:
    self.cursor = [self.width // 2, self.height // 2]

  def invert(self: Board) -> None:
    self.snapshot()
    for row in self.cells:
      for cell in row:
        cell.toggle()

  def jump(self: Board, x: str, y: str) -> None:
    try:
      x_ = int(x)
    except ValueError:
      self.message = "X coordinate invalid"
      return
    if not 0 <= x_ < self.width:
      self.message = "X coordinate out of bounds"
      return
    try:
      y_ = self.height - int(y) - 1
    except ValueError:
      self.message = "Y coordinate invalid"
      return
    if not 0 <= y_ < self.height:
      self.message = "Y coordinate out of bounds"
      return
    self.cursor = [x_, y_]

  def load(self: Board, name: str) -> None:
    self.snapshot()
    try:
      with open("py/life/data/" + name + ".pkl", "rb") as file:
        self.cells = pickle.loads(file.read())
    except FileNotFoundError:
      self.message = "File not found"
    self.update_metadata()

  def lock(self: Board) -> None:
    self.snapshot()
    cell = self.cells[self.cursor[1]][self.cursor[0]]
    cell.locked = not cell.locked

  def paste(self: Board, name: str) -> None:
    self.snapshot()
    try:
      with open("py/life/data/" + name + ".pkl", "rb") as file:
        clip = pickle.loads(file.read())
      for y in range(len(clip)):
        for x in range(len(clip[0])):
          self.cells[(self.cursor[1] + y) % self.height][(self.cursor[0] + x) % self.width] = clip[y][x]
    except FileNotFoundError:
      self.message = "File not found"

  def preview(self: Board) -> None:
    self.preview_mode = not self.preview_mode

  def random_(self: Board, percentage: str) -> None:
    self.snapshot()
    try:
      self.cells = [[Cell(weight = int(percentage) / 100) for _ in range(self.width)] for _ in range(self.height)]
    except ValueError:
      self.message = "Percentage invalid"

  def redo(self: Board) -> None:
    self.snapshot()
    self.cells = copy.deepcopy(self.previous_undo)

  def reflect(self: Board, axis: str) -> None:
    self.snapshot()
    if axis.lower() in ("x", "y"):
      for y, row in enumerate(self.cells):
        for x, cell in enumerate(row):
          cell.next_condition = self.cells[(self.height - 1) - y if axis == "x" else y][x if axis == "x" else (self.width - 1) - x].condition
    else:
      self.message = "Axis invalid"
    for row in self.cells:
      for cell in row:
        cell.resolve()

  def rotate(self: Board, angle: str) -> None:
    self.snapshot()
    try:
      angle_ = 4 - (int(angle) // 90)
    except ValueError:
      try:
        angle_ = {
          "right": 3,
          "clockwise": 3,
          "left": 1,
          "counterclockwise": 1,
          "anticlockwise": 1
        }[angle.lower()]
      except KeyError:
        self.message = "Angle invalid"
        return
    for _ in range(angle_):
      for y, row in enumerate(self.cells):
        for x, cell in enumerate(row):
          try:
            cell.next_condition = self.cells[x][(self.height - 1) - y].condition
          except IndexError:
            pass
      for row in self.cells:
        for cell in row:
          cell.resolve()

  def row(self: Board, snapshot: bool = True) -> None:
    if snapshot:
      self.snapshot()
    for cell in self.cells[self.cursor[1]]:
      cell.toggle()

  def save(self, name):
    with open("py/life/data/" + name + ".pkl", "wb") as file:
      file.write(pickle.dumps(self.cells, protocol = pickle.HIGHEST_PROTOCOL))

  def slowtick(self: Board, amount: str) -> None:
    self.snapshot()
    try:
      try:
        amount_ = int(amount)
      except ValueError:
        self.message = "Number of ticks invalid"
        return
      generation = 0
      for _ in range(amount_):
        self.tick(snapshot = False)
        generation += 1
        subprocess.run(["clear"])
        print(f"Slowtick | Generation: {generation}")
        self.render()
        time.sleep(0.1)
    except KeyboardInterrupt:
      self.message = "slowtick terminated by user"

  def snapshot(self: Board) -> None:
    self.previous_cells = copy.deepcopy(self.cells)

  def tick(self: Board, snapshot: bool = True) -> None:
    if snapshot:
      self.snapshot()
    for y, row in enumerate(self.cells):
      for x, cell in enumerate(row):
        cell.next_condition = cell.determine_next_condition(self, x, y)
    for row in self.cells:
      for cell in row:
        cell.resolve()

  def tick_n(self: Board, amount: str) -> None:
    self.snapshot()
    try:
      try:
        amount_ = int(amount)
      except ValueError:
        self.message = "Number of ticks invalid"
        return
      for _ in range(amount_):
        self.tick(snapshot = False)
    except KeyboardInterrupt:
      self.message = "tick_n terminated by user"

  def toggle_cell(self: Board) -> None:
    self.snapshot()
    self.cells[self.cursor[1]][self.cursor[0]].toggle()

  def trace(self: Board) -> None:
    self.trace_mode = not self.trace_mode

  def translate(self: Board, direction: str, distance: str) -> None:
    self.snapshot()
    try:
      direction_ = __main__.cardinal_directions[direction.upper()]
    except KeyError:
      self.message = "Direction invalid"
      return
    try:
      distance_ = int(distance)
    except ValueError:
      self.message = "Distance invalid"
      return
    for _ in range(distance_):
      for y, row in enumerate(self.cells):
        for x, cell in enumerate(row):
          cell.next_condition = self.cells[(y - direction_[1]) % self.height][(x - direction_[0]) % self.width].condition
      for row in self.cells:
        for cell in row:
          cell.resolve()

  def undo(self: Board) -> None:
    self.previous_undo = copy.deepcopy(self.cells)
    self.cells = copy.deepcopy(self.previous_cells)

  def editor(self: Board) -> None:
    while True:
      self.cells[self.cursor[1]][self.cursor[0]].selected = True
      subprocess.run(["clear"])
      print(f"{self.message if self.message else ""}")
      self.render()
      user_input = terminal.get_key()
      try:
        self.cells[self.cursor[1]][self.cursor[0]].selected = False
        self.cursor[0] += __main__.direction_keybinds[user_input][0]
        self.cursor[1] += __main__.direction_keybinds[user_input][1]
        if self.cursor[0] == self.width:
          self.cursor[0] = self.width - 1
        elif self.cursor[0] == -1:
          self.cursor[0] = 0
        elif self.cursor[1] == self.height:
          self.cursor[1] = self.height - 1
        elif self.cursor[1] == -1:
          self.cursor[1] = 0
        self.cells[self.cursor[1]][self.cursor[0]].selected = True
        if self.trace_mode:
          cell = self.cells[self.cursor[1]][self.cursor[0]]
          cell.condition = not cell.condition
      except KeyError:
        self.message = None
        match input(">: ").split(" "):
          case "clear",: self.clear()
          case "column",: self.column()
          case "copy", name, x, y: self.copy_(name, x, y)
          case "cut", name, x, y: self.copy_(name, x, y, cut = True)
          case "crosshair",: self.crosshair()
          case "delete", name: self.delete(name)
          case "execute",: self.execute()
          case action, "column", n: self.expand_reduce_column(action, n)
          case action, "row", n: self.expand_reduce_row(action, n)
          case "hide",: self.hide()
          case "home",: self.home()
          case "invert",: self.invert()
          case "jump", x, y: self.jump(x, y)
          case "load", name: self.load(name)
          case "lock",: self.lock()
          case "paste", name: self.paste(name)
          case "preview",: self.preview()
          case "quit",: sys.exit(0)
          case "random", n: self.random_(n)
          case "redo",: self.redo()
          case "reflect", axis: self.reflect(axis)
          case "rotate", angle: self.rotate(angle)
          case "row",: self.row()
          case "save", name: self.save(name)
          case "slowtick", n: self.slowtick(n)
          case "tick",: self.tick()
          case "tick", n: self.tick_n(n)
          case "",: self.toggle_cell()
          case "trace",: self.trace()
          case "translate", direction, distance: self.translate(direction, distance)
          case "undo",: self.undo()
          case _: self.message = "Command invalid"
