__version__ = "2.0.1"
__name__ = "life"
