from board import Board

directions = (
  (-1, -1),
  (0, -1),
  (1, -1),
  (-1, 0),
  (1, 0),
  (-1, 1),
  (0, 1),
  (1, 1)
)
direction_keybinds = {
  "w": directions[1],
  "a": directions[3],
  "d": directions[4],
  "s": directions[6]
}
cardinal_directions = {
  "NW": directions[0],
  "N": directions[1],
  "NE": directions[2],
  "W": directions[3],
  "E": directions[4],
  "SW": directions[5],
  "S": directions[6],
  "SE": directions[7]
}

def main() -> None:
  board = Board()
  while True:
    board.editor()

if __name__ == "__main__":
  main()
