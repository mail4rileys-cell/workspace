import random

import __main__

import utils.formatlib as formatlib


class Cell:
  __slots__ = (
    "condition",
    "next_condition",
    "selected",
    "locked"
  )

  def __init__(self: Cell, condition: bool | None = None, weight: float = 0.25) -> None:
    if condition is None:
      self.condition = True if random.random() < weight else False
    else:
      self.condition = condition
    self.next_condition = self.condition
    self.selected = False
    self.locked = False

  def render(self: Cell, board: __main__.Board, x: int, y: int) -> str:
    if self.selected and not board.hidden_cursor:
      return formatlib.chain("██" if self.condition else "[]", formatlib.blue, formatlib.bold)
    elif self.locked:
      return formatlib.chain("██" if self.condition else "[]", formatlib.yellow, formatlib.bold)
    elif board.preview_mode and self.determine_next_condition(board, x, y) != self.condition:
      if self.determine_next_condition(board, x, y) == True and self.condition == False:
        color = formatlib.green
      elif self.determine_next_condition(board, x, y) == False and self.condition == True:
        color = formatlib.red
      else:
        color = lambda _: _
      return formatlib.chain("██" if self.condition else "[]", color, formatlib.bold)
    else:
      return "██" if self.condition else "  "

  def determine_next_condition(self: Cell, board: __main__.Board, x: int, y: int) -> bool:
    neighbours = []
    for dx, dy in __main__.directions:
      nx = (x + dx) % board.width
      ny = (y + dy) % board.height
      neighbours.append(board.cells[ny][nx].condition)
    if self.condition:
      return True if neighbours.count(True) in board.survival_set else False
    else:
      return True if neighbours.count(True) in board.birth_set else False

  def resolve(self: Cell) -> None:
    if not self.locked:
      self.condition = self.next_condition
    else:
      self.next_condition = self.condition

  def revive(self: Cell) -> None:
    if not self.locked:
      self.condition = True

  def kill(self: Cell) -> None:
    if not self.locked:
      self.condition = False

  def toggle(self: Cell) -> None:
    if not self.locked:
      self.condition = not self.condition

  def change(self: Cell, condition: bool) -> None:
    if not self.locked:
      self.condition = condition
