# Life
  - My Conway's Game of Life program, recovered from my iPhone's filesystem

# Dependencies
  - py/utils 2.0.0 or later
