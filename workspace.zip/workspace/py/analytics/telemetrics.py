from __future__ import annotations

import json
import math
import pickle
import typing

import utils.formatlib as formatlib
from utils.safefloat import SafeFloat
from utils.typecheck import typecheck

class Metric(list):
  __slots__ = (
    "units",
    "id",
    "step_one_completed",
    "step_two_completed",
    "x_axis",
    "cleansed",
    "mean",
    "variance",
    "standard_deviation",
    "covariances",
    "slopes",
    "intercepts",
    "correlations",
    "aggregate",
    "graph"
  )
  ID = 0

  @typecheck
  def __init__(self, values: list[SafeFloat], units: str = "") -> None:
    super().__init__(values)
    self.units = units
    self.id = Metric.ID
    Metric.ID += 1
    self.step_one_completed = False
    self.step_two_completed = False
    self.x_axis = []
    self.cleansed = []
    self.mean = SafeFloat(math.nan)
    self.variance = SafeFloat(math.nan)
    self.standard_deviation = SafeFloat(math.nan)
    self.covariances = {}
    self.slopes = {}
    self.intercepts = {}
    self.correlations = {}
    self.aggregate = []
    self.graph = []

  @typecheck
  def step_one(self, x_axis: Metric, nan_map: list[bool]) -> None:
    self.x_axis = x_axis
    self.cleansed = [value for value, nan in zip(self, nan_map) if not nan]
    self.mean = sum(self.cleansed, SafeFloat(0)) / len(self.cleansed)
    self.variance = sum([(value - self.mean) ** 2 for value in self.cleansed], SafeFloat(0)) / len(self.cleansed)
    self.standard_deviation = self.variance ** 0.5
    self.step_one_completed = True

  @typecheck
  def step_two(self, metrics: list[Metric]) -> None:
    assert self.step_one_completed
    self.covariances = {}
    self.slopes = {}
    self.intercepts = {}
    self.correlations = {}
    for metric in metrics:
      self.covariances[metric.id] = sum([(x - self.mean) * (y - metric.mean) for x, y in zip(self.cleansed, metric.cleansed)], SafeFloat(0)) / len(self.cleansed)
      self.slopes[metric.id] = self.covariances[metric.id] / self.variance
      self.intercepts[metric.id] = metric.mean - (self.slopes[metric.id] * self.mean)
      self.correlations[metric.id] = self.covariances[metric.id] / (self.standard_deviation * metric.standard_deviation)
    self.step_two_completed = True

  @typecheck
  def step_three(self) -> None:
    assert self.step_two_completed and type(self.x_axis) is Metric
    self.aggregate = []
    value = None
    previous_x = None
    for x, y in zip(self.x_axis, self):
      if math.isnan(y):
        value = (self.x_axis.slopes[self.id] * x) + self.x_axis.intercepts[self.id]
      else:
        value = y
      if x == previous_x:
        self.aggregate[-1].append(value)
      else:
        self.aggregate.append([value])
        previous_x = x
    self.aggregate = [sum(values, SafeFloat(0)) / len(values) for values in self.aggregate]
    self.graph = [[False for _ in range(len(self.aggregate))] for _ in range(11)]
    for y, percentage in enumerate(range(100, -10, -10)):
      for x in range(len(self.aggregate)):
        point = (self.aggregate[x] / max(self.aggregate)) * 100
        self.graph[y][x] = (percentage - 5) <= point <= (percentage + 5)

  @typecheck
  def draw_graph(self) -> None:
    print("-" * (len(self.aggregate) + 2))
    for y, percentage in enumerate(range(100, -10, -10)):
      line = "|"
      for x in range(len(self.aggregate)):
        line += formatlib.green("#") if self.graph[y][x] else " "
      print(f"{line}| ~{max(self) * (percentage / 100):,}{self.units}")
    print("-" * (len(self.aggregate) + 2))

  @typecheck
  def summarize(self) -> None:
    print(f"Mean: {self.mean:,}{self.units} ± {self.standard_deviation:,}{self.units}")
    print(f"Maximum: {max(self):,}{self.units}")
    print(f"Minimum: {min(self):,}{self.units}")
  
  @typecheck
  def elementwise(self, operand: Metric | SafeFloat | float | int | bool, operator: typing.Callable) -> Metric:
    if type(operand) is Metric:
      return Metric([operator(a, b) for a, b in zip(self, operand)])
    elif type(operand) in (SafeFloat, float, int, bool):
      return Metric ([operator(value, operand) for value in self])
    raise TypeError("Operand must be a Metric or a number")

  @typecheck
  def __pos__(self) -> Metric:
    return Metric([value for value in self])

  @typecheck
  def __neg__(self) -> Metric:
    return Metric([-value for value in self])

  @typecheck
  def __abs__(self) -> Metric:
    return Metric([abs(value) for value in self])

  @typecheck
  def __bool__(self) -> bool:
    return sum([bool(value) for value in self], SafeFloat(0)) / len(self) >= 0.5

  @typecheck
  def __add__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a + b)

  @typecheck
  def __radd__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b + a)

  @typecheck
  def __sub__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a - b)

  @typecheck
  def __rsub__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b - a)

  @typecheck
  def __mul__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a * b)

  @typecheck
  def __rmul__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b * a)

  @typecheck
  def __truediv__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a / b)

  @typecheck
  def __rtruediv__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b / a)

  @typecheck
  def __mod__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a % b)

  @typecheck
  def __rmod__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b % a)

  @typecheck
  def __pow__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: a ** b)

  @typecheck
  def __rpow__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: b ** a)

  @typecheck
  def __eq__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a == b))

  @typecheck
  def __ne__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a != b))

  @typecheck
  def __lt__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a < b))

  @typecheck
  def __le__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a <= b))

  @typecheck
  def __gt__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a > b))

  @typecheck
  def __ge__(self, operand: Metric | SafeFloat | float | int | bool) -> Metric:
    return self.elementwise(operand, lambda a, b: SafeFloat(a >= b))

class AbortAnalysis(Exception):
  @typecheck
  def __init__(self, reason: str) -> None:
    super().__init__(reason)

class Telemetry(dict):

  @typecheck
  def __init__(self, filename: str) -> None:
    super().__init__({})
    self.x_axis = Metric([])
    self.x_axis_name = ""
    self.accuracy = SafeFloat(math.nan)
    self.aliases = {}
    self.comments = []
    self.alias_collision = False
    if "." not in filename:
      raise TypeError("File format not specified")
    elif filename.endswith(".ana"):
      with open(filename, "r") as file:
        instructions = False
        for line in file:
          line = line.strip()
          if line.startswith("#"):
            self.comments.append(line[1:])
          elif line == "INSTRUCTIONS":
            instructions = True
          elif not instructions:
            identifier, values = line.split(" = ")
            if ":" in identifier:
              name, units = identifier.split(":")
              self[name] = Metric([], units)
            else:
              name = identifier
              self[name] = Metric([])
            for value in values.split(","):
              try:
                self[name].append(SafeFloat(value))
              except ValueError:
                pass
          else:
            identifier, expression = line.split(" = ")
            if identifier == "__x_axis__":
              self.x_axis = self[expression]
              self.x_axis_name = expression
              continue
            elif":"in identifier:
              name, units = identifier.split(":")
            else:
              name = identifier
              units = ""
            names = [name for name in self if name in expression]
            self[name] = eval(expression, {}, {name: self[name] for name in names})
            if units:
              self[name].units = units
      self.finalize()
    elif filename.endswith(".pkl"):
      with open(filename, "rb") as file:
        data = pickle.load(file)
        self.__dict__.update(data.__dict__)
        self.update(data)
    elif filename.endswith(".json"):
      with open(filename, "r") as file:
        for name, metric in json.load(file).items():
          if name == "__x_axis__":
            self.x_axis = Metric([SafeFloat(math.nan if value is None else value) for value in metric])
            self.x_axis_name = name
          else:
            self[name] = Metric([SafeFloat(math.nan if value is None else value) for value in metric])
      self.finalize()
    else:
      raise TypeError(f"{filename.split('.')[1]} file format not supported")

  @typecheck
  def finalize(self) -> None:
    print("Assembling aliases...")
    self.aliases = {}
    for name, metric in self.items():
      alias = "".join([part[0] for part in name.split("_")])
      if alias in self.aliases:
        self.alias_collision = True
      self.aliases[alias] = metric
    print("Calculating accuracy...")
    nan_map = [False for _ in range(len(self.x_axis))]
    for metric in self.values():
      for index, value in enumerate(metric):
        if math.isnan(value):
          nan_map[index] = True
    self.accuracy = SafeFloat(nan_map.count(False) / len(nan_map))
    if self.accuracy < 0.5:
      print("Warning: NaN values are majority of data, do you wish to continue? [y/n]")
      while True:
        match input().lower():
          case "y" | "yes":
            break
          case "n" | "no":
            raise AbortAnalysis("NaN values were majority of data, user chose to abort")
    print("Calculating means, variances, and standard deviations...")
    for metric in self.values():
      metric.step_one(self.x_axis, nan_map)
    print("Calculating covariances, slopes, intercepts, and correlations...")
    for metric in self.values():
      metric.step_two(list(self.values()))
    print("Calculating aggregates and graphs...")
    for metric in self.values():
      metric.step_three()

  @typecheck
  def dump(self,filename: str) -> None:
    if "." not in filename:
      print("Dump aborted: File format not specified")
    elif filename.endswith(".ana"):
      with open(filename, "w") as file:
        for name, metric in self.items():
          file.write(f"{name}{(':' + metric.units) if metric.units else ''} = {','.join([str(value) for value in metric])}\n")
        file.write("INSTRUCTIONS\n")
        file.write(f"__x_axis__ = {self.x_axis_name}")
      print("Done")
    elif filename.endswith(".pkl"):
      with open(filename, "wb") as file:
        pickle.dump(self, file, protocol = pickle.HIGHEST_PROTOCOL)
      print("Done")
    elif filename.endswith(".json"):
      with open(filename, "w") as file:
        data = {}
        data["__x_axis__"] = [None if math.isnan(value )else value for value in self.x_axis]
        for name, metric in self.items():
          data[name] = [None if math.isnan(value) else value for value in metric]
        json.dump(data, file, indent = 2)
      print("Done")
    else:
      print(f"Dump aborted: {filename.split('.')[1]} file format not supported")

  @typecheck
  def all(self) -> None:
    print("All metrics")
    print("-" * 11)
    for name in self:
      print(name)
    print("-" * 11)

  @typecheck
  def metadata(self) -> None:
    print("Metadata")
    print("-" * 8)
    for entry in self.comments:
      print(entry)
    print("-" * 8)

  @typecheck
  def get(self, name: str, default = None) -> Metric | None:
    metric = super().get(name, default)
    if metric is None:
      metric = self.aliases.get(name, default)
    return metric

  @typecheck
  def graph(self, name: str) -> None:
    metric = self.get(name)
    if metric is None:
      print(f"{name} not found")
      return
    print(name)
    print("-" * len(name))
    metric.draw_graph()

  @typecheck
  def compare(self, n1: str, n2: str) -> None:
    m1 = self.get(n1)
    if m1 is None:
      print(f"{n1} not found")
      return
    m2 = self.get(n2)
    if m2 is None:
      print(f"{n2} not found")
      return
    print(f"{formatlib.blue(n1)} vs {formatlib.red(n2)} | Correlation: {formatlib.green(f'{m1.correlations[m2.id] * 100}%')}")
    print("-" * (len(m1.aggregate) + 2))
    for y, percentage in enumerate(range(100, -10, -10)):
      line = "|"
      for x in range(len(m1.aggregate)):
        if m1.graph[y][x] and m2.graph[y][x]:
          line += formatlib.green("#")
        elif m1.graph[y][x]:
          line += formatlib.blue("#")
        elif m2.graph[y][x]:
          line += formatlib.red("#")
        else:
          line += " "
      print(f"{line}| {formatlib.blue(f'~{max(m1) * (percentage / 100):,}{m1.units}')} | {formatlib.red(f'~{max(m2) * (percentage / 100):,}{m2.units}')}")
    print("-" * (len(m1.aggregate) + 2))

  @typecheck
  def summarize(self, name: str) -> None:
    metric = self.get(name)
    if metric is None:
      print(f"{name} not found")
      return
    print(name)
    print("-" * len(name))
    metric.summarize()
    print("-" * len(name))

  @typecheck
  def retrieve(self, name: str) -> None:
    metric = self.get(name)
    if metric is None:
      print(f"{name} not found")
      return
    print(name)
    print("-" * len(name))
    print(metric)
    print("-" * len(name))