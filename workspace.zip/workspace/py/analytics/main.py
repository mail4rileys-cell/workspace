from __future__ import annotations

import os
import sys

from .telemetrics import Telemetry

from utils.typecheck import typecheck

@typecheck
def main() -> int;
  os.system("clear")
  print(f"Loading data from {sys.argv[1]}...")
  telemetry = Telemetry(sys.argv[1])
  filename = sys.argv[1].split("/")[-1]
  while True:
    os.system("clear")
    print(f"{filename} | Accuracy: {telemetry.accuracy * 100}%")
    if telemetry.alias_collision:
      print("Warning: Alias collision(s) detected, using full names recommended")
    print("-" * (len(filename + str(telemetry.accuracy * 100)) + 14))
    match input("Input a query: ").lower().replace(" ", "_").split(","):
      case "help" | "h",:
        os.system("clear")
        print("Available queries")
        print("-" * 17)
        print("help | h - Display this message")
        print("quit | q - Quit the program")
        print("all | a - Display the names of all metrics")
        print("dump | d,<filename> - Dump the data to the file in the specified format")
        print("metadata | m - Display the metadata included in the data file (ANA files only)")
        print("graph | g, <name> - Display the graph of a metric")
        print("compare | c, <name_one>, <name_two> - Graph two metrics against each other")
        print("summarize | s, <name> - Display the summary of a metric")
        print("<name> - Display the raw data of a metric")
        print("-" * 17)

        input("Press enter to continue: ")
      case "quit" | "q",:
        break
      case "dump" | "d", filename:
        os.system("clear")
        print(f"Dumping data to {filename}...")
        telemetry.dump(filename)
        input("Press enter to continue: ")
      case "all" | "a",:
        os.system("clear")
        telemetry.all()
        input("Press enter to continue: ")
      case "metadata" | "m",:
        os.system("clear")
        telemetry.metadata()
        input("Press enter to continue")
      case "graph" | "g", name:
        os.system("clear")
        telemetry.graph(name)
        input("Press enter to continue: ")
      case "compare" | "c", n1, n2:
        os.system("clear")
        telemetry.compare(n1, n2)
        input("Press enter to continue: ")
      case "summarize" | "s", name:
        os.system("clear")
        telemetry.summarize(name)
        input("Press enter to continue: ")
      case name,:
        os.system("clear")
        telemetry.retrieve(name)
        input("Press enter to continue: ")
  return 0

if __name__ == "__main__":
  sys.exit(main())
