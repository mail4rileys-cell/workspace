import subprocess
import sys

from typeguard import typechecked

from utils import formatlib


class Board:
  __slots__ = (
    "pockets", # list[int]
    "one_turn", # bool
  )
  one_pockets = (0, 1, 2, 3, 4, 5)
  one_store = 6
  two_pockets = (7, 8, 9, 10, 11, 12)
  two_store = 13

  @typechecked
  def __init__(self: Board) -> None:
    self.pockets = [
      4, 4, 4, 4, 4, 4, 0, # store = 6
      4, 4, 4, 4, 4, 4, 0 # store = 13
    ]
    self.one_turn = True

  @typechecked
  def render(self: Board) -> str:
    lines = [f"    {self.pockets[Board.two_store]:02}"]
    for one_pocket, two_pocket, separator in zip(Board.one_pockets, reversed(Board.two_pockets), ("al", "bk", "cj", "di", "eh", "fg")):
      lines.append(f" {self.pockets[one_pocket]:02} {separator} {self.pockets[two_pocket]:02} ")
    lines.append(f"    {self.pockets[Board.one_store]:02}")
    return formatlib.title_box("Player one" if self.one_turn else "Player two", lines)

  @typechecked
  def is_move_legal(self: Board, index: int) -> bool:
    if index < 0 or index >= len(self.pockets):
      return False
    if index in (Board.two_pockets if self.one_turn else Board.one_pockets):
      return False
    if index in (Board.one_store, Board.two_store):
      return False
    if self.pockets[index] == 0:
      return False
    return True

  @typechecked
  def move_stones(self: Board, index: int) -> None:
    stones = self.pockets[index]
    self.pockets[index] = 0
    while stones > 0:
      index = (index + 1) % len(self.pockets)
      if index != (Board.two_store if self.one_turn else Board.one_store):
        self.pockets[index] += 1
        stones -= 1
    if index in (Board.one_pockets if self.one_turn else Board.two_pockets) and self.pockets[index] == 1 and self.pockets[12 - index] > 0:
      self.pockets[Board.one_store if self.one_turn else Board.two_store] += self.pockets[index] + self.pockets[12 - index]
      self.pockets[index] = 0
      self.pockets[12 - index] = 0
    if index != (Board.one_store if self.one_turn else Board.two_store):
      self.one_turn = not self.one_turn


@typechecked
def main() -> int:
  board = Board()
  while True:
    subprocess.run("clear")
    print(board.render())
    move = None
    match input("Input move: ").strip().lower():
      case "a": move = 0
      case "b": move = 1
      case "c": move = 2
      case "d": move = 3
      case "e": move = 4
      case "f": move = 5
      case "g": move = 7
      case "h": move = 8
      case "i": move = 9
      case "j": move = 10
      case "k": move = 11
      case "l": move = 12
      case _: move = -1
    if board.is_move_legal(move):
      board.move_stones(move)
  return 0

if __name__ == "__main__":
  sys.exit(main())
