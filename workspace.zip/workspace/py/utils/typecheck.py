import collections.abc as abc
import inspect
import types
import typing

def recurse(value, expected) -> bool:
  origin = typing.get_origin(expected)
  args = typing.get_args(expected)
  match origin:
    case None:
      return isinstance(value, expected) if isinstance(expected, type) else value == expected
    case typing.Literal:
      return value in args
    case typing.Annotated:
      return recurse(value, args[0])
    case typing.Union | types.UnionType:
      return any(recurse(value, arg) for arg in args)
    case typing.Callable:
      return callable(value)
    case _ if origin and issubclass(origin, abc.Mapping):
      if not isinstance(value, abc.Mapping):
        return False
      return all(recurse(key, args[0]) and recurse(value_, args[1]) for key, value_ in value.items()) if args and len(args) == 2 else True
    case _ if origin and issubclass(origin, abc.Iterable):
      if not isinstance(value, abc.Iterable):
        return False
      return all(recurse(item, args[0]) for item in value) if args else True
    case _:
      return isinstance(value, origin)

def typecheck(function: typing.Callable) -> typing.Callable:
  signature = inspect.signature(function)
  def wrapper(*args, **kwargs) -> typing.Callable:
    annotations = typing.get_type_hints(function)
    bound = signature.bind(*args, **kwargs)
    bound.apply_defaults()
    for name, value in bound.arguments.items():
      if name in annotations:
        expected = annotations[name]
        if not recurse(value, expected):
          raise TypeError(f"{name} must be {expected}, got {type(value)}")
    result = function(*args, **kwargs)
    if "return" in annotations:
      expected = annotations["return"]
      if not recurse(result, expected):
        raise TypeError(f"Return value must be {expected}, got {type(result)}")
    return result
  return wrapper