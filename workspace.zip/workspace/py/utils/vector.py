import math

from abc import ABC, abstractmethod
from enum import Enum, auto
from typing import Self


class Vector(ABC):

  @property
  @abstractmethod
  def components(self: Self) -> tuple[int | float, ...]:
    pass

  def __add__(self: Self, vector: Self) -> Self:
    return self.__class__(*(x + y for x, y in zip(self.components, vector.components)))

  def __sub__(self: Self, vector: Self) -> Self:
    return self.__class__(*(x - y for x, y in zip(self.components, vector.components)))

  def __mul__(self: Self, scalar: int | float) -> Self:
    return self.__class__(*(component * scalar for component in self.components))

  def __rmul__(self: Self, scalar: int | float) -> Self:
    return self.__mul__(scalar)

  def __truediv__(self: Self, scalar: int | float) -> Self:
    return self.__class__(*(component / scalar for component in self.components))

  def __matmul__(self: Self, vector: Self) -> int | float:
    return sum(x * y for x, y in zip(self.components, vector.components))

  def __pos__(self: Self) -> Self:
    return self

  def __neg__(self: Self) -> Self:
    return self * -1

  def __eq__(self: Self, other: object) -> bool:
    if not isinstance(other, type(self)):
      return False
    return self.components == other.components

  @property
  def magnitude(self: Self) -> float:
    return math.hypot(*self.components)

  @property
  def normal(self: Self) -> Self:
    return self / self.magnitude


class Vector2D(Vector):
  class Axis(Enum):
    X = auto()
    Y = auto()
  __slots__ = tuple(axis.name.lower() for axis in Axis)

  def __init__(self: Vector2D, x: int | float, y: int | float) -> None:
    self.x = x
    self.y = y

  @property
  def components(self: Vector2D) -> tuple[int | float, int | float]:
    return (self.x, self.y)

  def rotate(self: Vector2D, angle: int | float) -> Vector2D:
    cos = math.cos(angle)
    sin = math.sin(angle)
    return Vector2D (
      (self.x * cos) - (self.y * sin),
      (self.x * sin) + (self.y * cos)
    )


class Vector3D(Vector):
  class Axis(Enum):
    X = auto()
    Y = auto()
    Z = auto()
  __slots__ = tuple(axis.name.lower() for axis in Axis)

  def __init__(self: Vector3D, x: int | float, y: int | float, z: int | float) -> None:
    self.x = x
    self.y = y
    self.z = z

  @property
  def components(self: Vector3D) -> tuple[int | float, int | float, int | float]:
    return (self.x, self.y, self.z)

  def rotate(self: Vector3D, angle: int | float, axis: Vector3D.Axis) -> Vector3D:
    cos = math.cos(angle)
    sin = math.sin(angle)
    match axis:
      case Vector3D.Axis.X:
        return Vector3D(
          self.x,
          (self.y * cos) - (self.z * sin),
          (self.y * sin) + (self.z * cos)
        )
      case Vector3D.Axis.Y:
        return Vector3D(
          (self.x * cos) + (self.z * sin),
          self.y,
          -(self.x * sin) + (self.z * cos)
        )
      case Vector3D.Axis.Z:
        return Vector3D(
          (self.x * cos) - (self.y * sin),
          (self.x * sin) + (self.y * cos),
          self.z
        )
