from __future__ import annotations

import math
import sys

from typeguard import typechecked


class SafeFloat(float):

  __slots__ = ()

  @typechecked
  def __pos__(self: SafeFloat) -> SafeFloat:
    return SafeFloat(super().__pos__())

  @typechecked
  def __neg__(self: SafeFloat) -> SafeFloat:
    return SafeFloat(super().__neg__())

  @typechecked
  def __abs__(self: SafeFloat) -> SafeFloat:
    return SafeFloat(super().__abs__())

  @typechecked
  def __add__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__add__(operand))

  @typechecked
  def __radd__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__radd__(operand))

  @typechecked
  def __sub__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__sub__(operand))

  @typechecked
  def __rsub__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__rsub__(operand))

  @typechecked
  def __mul__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__mul__(operand))

  @typechecked
  def __rmul__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__rmul__(operand))

  @typechecked
  def __truediv__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if operand == 0 else super().__truediv__(operand))

  @typechecked
  def __rtruediv__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if self == 0 else super().__rtruediv__(operand))

  @typechecked
  def __mod__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if operand == 0 else super().__mod__(operand))

  @typechecked
  def __rmod__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if self==0 else super().__rmod__(operand))

  @typechecked
  def __pow__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if (self == 0 and operand < 0) or (self < 0 and not SafeFloat(operand).is_integer()) else super().__pow__(operand))

  @typechecked
  def __rpow__(self: SafeFloat, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if (operand == 0 and self < 0) or (operand < 0 and not self.is_integer() )else super().__rpow__(operand))
