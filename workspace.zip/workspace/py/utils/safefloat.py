# since 1.0.0

from __future__ import annotations

import math
import sys


from .typecheck import typecheck

class SafeFloat(float):

  __slots__ = ()

  @typecheck
  def __pos__(self) -> SafeFloat:
    return SafeFloat(super().__pos__())

  @typecheck
  def __neg__(self) -> SafeFloat:
    return SafeFloat(super().__neg__())

  @typecheck
  def __abs__(self) -> SafeFloat:
    return SafeFloat(super().__abs__())

  @typecheck
  def __add__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__add__(operand))

  @typecheck
  def __radd__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__radd__(operand))

  @typecheck
  def __sub__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__sub__(operand))

  @typecheck
  def __rsub__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__rsub__(operand))

  @typecheck
  def __mul__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__mul__(operand))

  @typecheck
  def __rmul__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(super().__rmul__(operand))

  @typecheck
  def __truediv__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if operand == 0 else super().__truediv__(operand))

  @typecheck
  def __rtruediv__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if self == 0 else super().__rtruediv__(operand))

  @typecheck
  def __mod__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if operand == 0 else super().__mod__(operand))

  @typecheck
  def __rmod__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if self==0 else super().__rmod__(operand))

  @typecheck
  def __pow__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if (self == 0 and operand < 0) or (self < 0 and not SafeFloat(operand).is_integer()) else super().__pow__(operand))

  @typecheck
  def __rpow__(self, operand: SafeFloat | float | int | bool) -> SafeFloat:
    return SafeFloat(math.nan if (operand == 0 and self < 0) or (operand < 0 and not self.is_integer() )else super().__rpow__(operand))
