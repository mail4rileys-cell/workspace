from collections.abc import Iterable
from collections.abc import Callable

from typeguard import typechecked

@typechecked
def make_formatter(code: int) -> Callable[[str], str]:
  @typechecked
  def formatter(text: str) -> str:
    return f"\033[{code}m{text}\033[0m"
  return formatter

for prefix, code in (("", 30), ("bg_", 40), ("bright_", 90), ("bg_bright_", 100)):
  for colour in ("black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"):
    globals()[prefix + colour] = make_formatter(code)
    code += 1

code = 1
for effect in ("bold", "dim", "italic", "underline", "blink", "rapid_blink", "reverse", "hidden", "strikethrough"):
  globals()[effect] = make_formatter(code)
  code += 1

del make_formatter
del prefix
del colour
del effect
del code

@typechecked
def chain(text: str, *funcs: Callable[[str], str] | Iterable[Callable[[str], str]]) -> str:
  if len(funcs) == 1 and isinstance(funcs[0], Iterable):
    funcs = funcs[0]
  for func in funcs:
    text = func(text)
  return text

H = "\u2500"
V = "\u2502"
TL = "\u250c"
TR = "\u2510"
BL = "\u2514"
BR = "\u2518"

@typechecked
def box(lines: list[str]) -> str:
  width = max(len(line) for line in lines)
  return "\n".join([
    TL + (H * width) + TR,
    *(V + line.ljust(width) + V for line in lines),
    BL + (H * width) + BR
  ])

@typechecked
def title_box(title: str, lines: list[str]) -> str:
  width = max(len(line) for line in [title, *lines])
  top = TL + (H * width) + TR
  bottom = BL + (H * width) + BR
  title_section = "\n".join([
    top,
    V + title.ljust(width) + V,
    bottom
  ])
  body_section = "\n".join([
    top,
    *(V + line.ljust(width) + V for line in lines),
    bottom
  ])
  return title_section + "\n" + body_section
