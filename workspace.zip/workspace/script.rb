arr=[1,2,3,4,5,6,7,8,9,10]
arr.each do|value|
  value.times do
    print value.to_s+" "
  end
  puts
end