#!/bin/bash
set -euo pipefail

if [ $# -gt 2 ]; then
  echo "Usage: bash $0 <directory>"
  exit 1
elif [ ! -d archive ]; then
  echo "Error: archive not found"
  exit 1
elif [ ! -d archive/$1 ]; then
  echo "Error: archive/$1 not found"
  exit 1
fi

if [ $# -eq 1 ]; then
  version=$(ls archive/$1 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -n 1)
else
  version=$2
fi

if [ -z $version ]; then
  echo "Error: no versions found"
  exit 1
elif [ -d $1 ]; then
  while [ true ]; do
    read -p "$1 will be overwritten, continue? (yes/no): " choice
    if [ $choice == "yes" ] || [ $choice == "y" ]; then
      rm -rf $1
      break
    elif [ $choice == "no" ] || [ $choice == "n" ]; then
      echo "Restoration aborted"
      exit 0
    else
      echo "Invalid input"
    fi
  done
fi

echo "Restoring $1 from archive/$1"
temp_dir=$(mktemp -d)
unzip -q archive/$1/$version.zip -d $temp_dir
mkdir -p $1
mv $temp_dir/$1/* $1/
rm -rf $temp_dir
echo "Restoration complete"
exit 0