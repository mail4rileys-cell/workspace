# 0.0.0
  - Original

# 0.1.0
  - Finished 2D motion
  - Added friction
  - Added wall collisions

# 0.2.0
  - Expanded to 3D motion
  - Added gravity
  - Added floor collisions

# 0.3.0
  - Added ball collisions
  - Added keyup and keydown
  - Bound " " to pause / resume
  - Bound ArrowUp to spawn a ball with random position and speed
  - Bound ArrowDown to delete the last ball spawned

# 0.4.0
  - Added air resistance
  - Added rack initialization
  - Bound Enter to strike the cue ball
  - Bound table mousedown, ArrowLeft, and ArrowRight to strike direction
  - Bound "<" to decrease table element size
  - Bound ">" to increase table element size
  - Rebound ArrowUp to strike magnitude increase
  - Rebound ArrowDown to strike magnitude decrease
  - Minor OOP model refactor

# 0.5.0
  - Added strike magnitude bar
  - Bound bar mousedown to change strike magnitude
  - Removed template boilerplate
  - Major OOP model refactor

# 0.6.0
  - Added pockets
  - Added ball in hand
  - Gives ball in hand when cue ball is sunk
  - Bound WASD to move cue ball when allowed
  - Added racking
  - Bound "r" to rack
  - Racks when eight ball is sunk

# 0.7.0
  - Added slider for strike pitch (top = 90 degrees, bottom = flat)
  - added shadows and other 3D perspective helpers

# 0.7.1
  - Polished UI

# 0.7.2
  - Abstracted walls and floor into the Surface class

# 0.7.3
  - Improved element removal safety

# 0.8.0
  - Bound double click to strike
  - Bound single click to setCueBall when the cue ball is missing
  - Bound double click Enter to skip animation
  - Added some (simplified) rules, mostly pertaining to turn alternations
  - Added the Box class to help display the current player's group
  - Minor OOP refactor

# 0.9.0
  - Improved rules
  - Added Player class
  - Separated turn from group
  - Added win messages (as a console.log for now)

# 1.0.0
  - Finalized simple ruleset
  - Added text content to box
  - Modified game.box to display the current player's name in addition to the group
  - Spin will be added in 2.0.0

# 1.1.0
  - Added game.console for textual output, currently mimics what the global console says
  - Textual input to be added in 1.2.0

# 1.1.1
  - Optimized table.evaluate function
  - Fixed some evaluation logic errors

# 1.1.2
  - Patched rules

# 1.2.0
  - Added percentage display to console when dragging bar or slider
  - Fixed bugs

# 1.3.0
  - Added another box to indicate ball in hand rights
  - Fixed pocketing eight ball on break resulting in win bug
  - Fixed pocketing ball on break and pocketing cue ball next shot resulting in group being "white"
  - Added pocketed messages
  - Added kitchen boundaries for break shot

# 1.3.1
  - Added index.html file for offline use
