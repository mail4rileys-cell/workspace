# 1.0.0
  - Original

# 1.1.0
  - Fixed filesystem path errors
  - Added quit command to editor

# 1.1.1
  - Cleaned up code in main.py
  - Fixed indexing bug in rotate

# 1.1.2
  - Optimized some code in main.py
  - Removed redundant zlib complexity
  - Restructured coordinate display

# 2.0.0
  - Moved source code into src directory
  - Refactored Cell class into cell.py
  - Removed poorly written evolution feature
  - Added __init__.py

# 2.0.1
  - Refactored Board class into board.py
