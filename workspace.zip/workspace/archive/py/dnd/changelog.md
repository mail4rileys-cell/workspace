# 1.0.0
  - Original

# 1.0.1
  - Removed broken internal backup system in favour of archive system

# 1.0.2
  - Fixed some bugs in abilities.py

# 1.0.3
  - Moved source files to src directory
  - Moved data files to data directory
