# 1.0.0
  - Original

# 1.1.0
  - Introduced format.py
  - Fixed typecheck.py nested type issues

# 1.1.1
  - Fixed formatlib.py name bug

# 1.2.0
	- Added H, V, TL, TR, BL, BR Unicode characters to formatlib.py
	- Added box(lines) and title_box(title, lines) to formatlib.py

# 2.0.0
  - Removed @typechck from every function
  - Added @typechecked to every function