# 1.0.0
  - Original

# 1.1.0
  - Introduced format.py
  - Fixed typecheck.py nested type issues

# 1.1.1
  - Fixed formatlib.py name bug

# 1.2.0
	- Added H, V, TL, TR, BL, BR Unicode characters to formatlib.py
	- Added box(lines) and title_box(title, lines) to formatlib.py

# 2.0.0
  - Removed @typechck from every function
  - Added @typechecked to every function

# 2.0.1
  - Added empty formatter function definitions to satisfy language servers

# 2.1.0
  - Added vector.py

# 2.2.0
  - Added terminal.py
  - Fixed bugs in safefloat.py

# 2.2.1
  - Added __init__.py
