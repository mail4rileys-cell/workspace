# 1.0.0
  - Original

# 1.0.1
  - Fixed bug where forced mate resulted in AI move being None

# 1.0.2
  - Fixed bug where offering a draw to AI crashed the program due to improper argument structures

# 1.0.3
  - Cleaned up code in ARC.py

# 1.0.4
  - Fixed filesystem path errors

# 1.0.5
  - Cleaned up code in deep_thought.py
  - Renamed data.json to training.json
  - Moved data files to data directory
  - Moved source files to src directory

# 1.0.6
  - Cleaned up code in main.py
