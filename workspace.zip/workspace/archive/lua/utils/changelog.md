# 1.0.0
	- Original

# 1.0.1
	- Removed false metamethods from vector.lua
