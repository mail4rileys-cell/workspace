# 1.0.0
  - Original

# 1.0.1
  - Replaced ANSI escape codes with cpp/utils/format.hpp

# 1.0.2
  - Fixed typo in save file board constructor
  - Replaced cpp/cryptic 1.0.0 with cpp/cryptic 2.0.0

# 1.0.3
  - Improved bug safety