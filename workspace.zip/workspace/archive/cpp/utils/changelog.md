# 1.0.0
  - Original

# 1.1.0
  - Added format.hpp

# 2.0.0
  - Added physics.hpp
  - Added windowlib.hpp
  - Added bitwise.hpp
  - Added pad_left and pad_right in format.hpp
  - Moved bitwise functions out of math.hpp and into bitwise.hpp

# 2.1.0
  - Added terminal.hpp

# 2.1.1
  - Improved performance for windowlib.hpp

# 2.1.2
  - Improved performance for physics.hpp
  - Improved performance for windowlib.hpp

# 2.2.0
  - Added grayscale to format.hpp

# 2.3.0
  - Added pad_center to format.hpp
  - Added title to windowlib.hpp

# 3.0.0
  - Added potential energy to the return values for physics.hpp's get_gravity
  - Removed displacement from the return values for physics.hpp's get_gravity

# 3.1.0
  - Added enable raw to terminal.hpp
  - Added disable raw to terminal.hpp
  - Added get_key to terminal.hpp
  - Added Keyboard to terminal.hpp

# 4.0.0
  - Removed everything past Vectors from physics.hpp

# 5.0.0
  - Removed constants from physics.hpp
  - Added constants.hpp

# 5.1.0
  - Added units to constants.hpp

# 5.2.0
  - Added keybinds to terminal.hpp

# 5.3.0
  - Added offset parameter to constants.hpp's astrophysics dataset

# 5.4.0
  - Added get_dot to physics.hpp

# 5.5.0
  - Added line drawer to windowlib.hpp
  - Updated README.md

# 5.6.0
  - Added Martian trojan Eureka to constants.hpp

# 5.7.0
  - Upgraded windowlib.hpp's border function to use unicode glyphs
  - Updated windowlib.hpp's title function

# 5.7.1
  - Updated smaller Plutonian moon dataset for constants.hpp
  - Added Sycorax dataset to constants.hpp (experimental)

# 5.7.2
  - Fixed Encke dataset for constants.hpp

# 5.8.0
  - Added Orcus and Vanth datasets to constants.hpp

# 5.9.0
  - Added Lempo, Hiisi and Paha datasets to constants.hpp

# 5.10.0
  - Added to_axis to physics.hpp

# 5.10.0
  - Added Gongong and its moon Xiangliu datasets to constants.hpp
  - Added Quaoar and its moon Weywot datasets to consstants.hpp
  - Improved Paha dataset for constants.hpp

# 5.12.0
  - Added Typhon and Echidna datasets to constants.hpp

# 5.13.0
  - Added Chiron dataset to constants.hpp
  - Added Chariklo dataset to constants.hpp
  - Fixed Sycorax dataset for constants.hpp

# 5.14.0
  - Added Cordelia dataset to constants.hpp
  - Added Portia dataset to constants.hpp
  - Added Puck dataset to constants.hpp

# 5.15.0
  - Added Hippocamp dataset to constants.hpp
  - Added Nereid dataset to constants.hpp
  - Added Halimede dataset to constants.hpp
  - Added Sao dataset to constants.hpp
  - Added Laomedeia dataset to constants.hpp
  - Added Psamathe dataset to constants.hpp
  - Added Neso dataset to constants.hpp

# 5.16.0
  - Added Ophelia dataset to constants.hpp
  - Added Bianca dataset to constants.hpp
  - Added Cressida dataset to constants.hpp
  - Added Desdemona dataset to constants.hpp
  - Added Juliet dataset to constants.hpp
  - Added Rosalind dataset to constants.hpp
  - Added Cupid dataset to constants.hpp
  - Added Belinda dataset to constants.hpp
  - Added Perdita dataset to constants.hpp
  - Added Mab dataset to constants.hpp
  - Added Francisco dataset to constants.hpp
  - Added Caliban dataset to constants.hpp
  - Added Stephano dataset to constants.hpp
  - Added Trinculo dataset to constants.hpp
  - Added Margaret dataset to constants.hpp
  - Added Prospero dataset to constants.hpp
  - Added Setebos dataset to constants.hpp
  - Added Ferdinand dataset to constants.hpp

# 5.17.0
  - Added Amalthea dataset to constants.hpp

# 5.18.0
  - Introduced JPL standard for astronomical datasets of satellites for constants.hpp
  - Over the next releases of version 5, all satellite datasets will be standardized
  - Standardized Luna dataset for constants.hpp
  - Standardized Phobos dataset for constants.hpp
  - Standardized Deimos dataset for constants.hpp
  - Standardized Amalthea dataset for constants.hpp
  - Standardized Io dataset for constants.hpp
  - Standardized Europa dataset for constants.hpp
  - Standardized Ganymede dataset for constants.hpp
  - Standardized Callisto dataset for constants.hpp
  - Added Himalia dataset to constants.hpp
  - Added Elara dataset to constants.hpp
  - Added Pasiphae dataset to constants.hpp
  - Added Sinope dataset to constants.hpp
  - Added Lysithea dataset to constants.hpp
  - Added Carme dataset to constants.hpp
  - Added Ananke dataset to constants.hpp
  - Added Leda dataset to constants.hpp
  - Added Thebe dataset to constants.hpp

# 5.19.0
  - Added Adrastea dataset to constants.hpp
  - Added Metis dataset to constants.hpp
  - Added Callirrhoe dataset to constants.hpp

# 5.20.0
  - Added Themisto dataset to constants.hpp
  - Added Megaclite dataset to constants.hpp
  - Added Taygete dataset to constants.hpp

# 5.21.0
  - Added Chaldene dataset to constants.hpp
  - Added Harpalyke dataset to constants.hpp
  - Added Kalyke dataset to constants.hpp

# 5.22.0
  - Added Iocaste dataset to constants.hpp
  - Added Erinome dataset to constants.hpp
  - Added Isonoe dataset to constants.hpp
  - Added Praxidike dataset to constants.hpp
  - Added Autonoe dataset to constants.hpp
  - Added Thyone dataset to constants.hpp
  - Added Hermippe dataset to constants.hpp
  - Added Aitne dataset to constants.hpp

# 5.23.0
  - Added Eurydome dataset to constants.hpp
  - Added Euanthe dataset to constants.hpp
  - Added Euporie dataset to constants.hpp
  - Added Orthosie dataset to constants.hpp

# 5.24.0
  - Added Sponde dataset to constants.hpp
  - Added Kale dataset to constants.hpp
  - Added Pasithee dataset to constants.hpp
  - Added Hegemone dataset to constants.hpp
  - Added Mneme dataset to constants.hpp
  - Added Aoede dataset to constants.hpp

# 5.25.0
  - Added Thelxinoe dataset to constants.hpp
  - Added Arche dataset to constants.hpp
  - Added Kallichore dataset to constants.hpp
  - Added Helike dataset to constants.hpp
  - Added Carpo dataset to constants.hpp
  - Added Eukelade dataset to constants.hpp
  - Added Cyllene dataset to constants.hpp
  - Added Kore dataset to constants.hpp
  - Added Herse dataset to constants.hpp
  - Added Dia dataset to constants.hpp
  - Added Eirene dataset to constants.hpp
  - Added Philophrosyne dataset to constants.hpp
  - Added Eupheme dataset to constants.hpp
  - Added Valetudo dataset to constants.hpp

# 5.26.0
  - Added Pandia dataset to constants.hpp
  - Added Ersa dataset to constants.hpp

# 5.27.0
  - Added Potato dataset to constants.hpp

# 5.28.0
  - Standardized Mimas dataset for constants.hpp
  - Standardized Enceladus dataset for constants.hpp
  - Standardized Tethys dataset for constants.hpp
  - Standardized Dione dataset for constants.hpp
  - Standardized Rhea dataset for constants.hpp
  - Standardized Titan dataset for constants.hpp
  - Standardized Hyperion dataset for constants.hpp
  - Standardized Iapetus dataset for constants.hpp
  - Added Phoebe dataset to constants.hpp
  - Added Janus dataset to constants.hpp
  - Added Epimetheus dataset to constants.hpp
  - Added Helene dataset to constants.hpp
  - Added Telesto dataset to constants.hpp

# 5.29.0
  - Fixed Telesto's OFFSET value for constants.hpp
  - Added Calypso dataset to constants.hpp
  - Added Atlas dataset to constants.hpp
  - Added Prometheus dataset to constants.hpp

# 5.29.1
  - Fixed Helene's OFFSET value for constants.hpp

# 5.30.0
  - Added Pandora dataset to constants.hpp
  - Added Pan dataset to constants.hpp
  - Simplified code for terminal.hpp

# 5.31.0
  - Fixed Iapetus's INCLINE value for constants.hpp
  - Added Ymir dataset to constants.hpp
  - Added Paaliaq dataset to constants.hpp

# 5.32.0
  - Added Tarvos dataset to constants.hpp
  - Added Ijiraq dataset to constants.hpp
  - Added Suttungr dataset to constants.hpp
  - Added Kiviuq dataset to constants.hpp
  - Added Mundilfari dataset to constants.hpp
  - Added Albiorix dataset to constants.hpp
  - Added Skathi dataset to constants.hpp

# 6.0.0
  - Renamed physics.hpp to geometry.hpp

# 6.1.0
  - Added Erriapus dataset to constants.hpp
  - Added Siarnaq dataset to constants.hpp
  - Added Thrymr dataset to constants.hpp
  - Added Narvi dataset to constants.hpp
  - Added Methone dataset to constants.hpp
  - Added Pallene dataset to constants.hpp
  - Added Polydeuces dataset to constants.hpp
  - Added Daphnis dataset to constants.hpp
  - Added Aegir dataset to constants.hpp
  - Added Bebhionn dataset to constants.hpp
  - Added Bergelmir dataset to constants.hpp
  - Added Bestla dataset to constants.hpp
  - Added Farbauti dataset to constants.hpp

# 6.2.0
  - Added Fenrir dataset to constants.hpp
  - Added Fornjot dataset to constants.hpp
  - Added Hati dataset to constants.hpp
  - Added Hyrrokkin dataset to constants.hpp
  - Added Kari dataset to constants.hpp
  - Added Loge dataset to constants.hpp
  - Added Skoll dataset to constants.hpp
  - Added Surtur dataset to constants.hpp
  - Added Anthe dataset to constants.hpp
  - Added Jarnsaxa dataset to constants.hpp
  - Added Greip dataset to constants.hpp

# 6.3.0
  - Added Tarqeq dataset to constants.hpp
  - Added Aegaeon dataset to constants.hpp
  - Added Gridr dataset to constants.hpp
  - Added Angrboda dataset to constants.hpp
  - Added Skrymir dataset to constants.hpp
  - Added Gerd dataset to constants.hpp
  - Added Eggther dataset to constants.hpp
  - Added Beli dataset to constants.hpp
  - Added Gunnlod dataset to constants.hpp
  - Added Thiazzi dataset to constants.hpp
  - Added Alvaldi dataset to constants.hpp
  - Added Geirrod dataset to constants.hpp

# 6.3.1
  - Standardized Ariel dataset for constants.hpp
  - Standardized Umbriel dataset for constants.hpp
  - Standardized Titania dataset for constants.hpp
  - Standardized Oberon dataset for constants.hpp
  - Standardized Miranda dataset for constants.hpp
  - Standardized Cordelia dataset for constants.hpp
  - Standardized Ophelia dataset for constants.hpp
  - Standardized Bianca dataset for constants.hpp
  - Standardized Cressida dataset for constants.hpp
  - Standardized Desdemona dataset for constants.hpp
  - Standardized Juliet dataset for constants.hpp
  - Standardized Portia dataset for constants.hpp
  - Standardized Rosalind dataset for constants.hpp
  - Standardized Belinda dataset for constants.hpp
  - Standardized Puck dataset for constants.hpp
  - Standardized Caliban dataset for constants.hpp
  - Standardized Sycorax dataset for constants.hpp
  - Standardized Prospero dataset for constants.hpp
  - Standardized Setebos dataset for constants.hpp
  - Standardized Stephano dataset for constants.hpp
  - Standardized Trinculo dataset for constants.hpp
  - Standardized Francisco dataset for constants.hpp
  - Standardized Margaret dataset for constants.hpp
  - Standardized Ferdinand dataset for constants.hpp
  - Standardized Perdita dataset for constants.hpp
  - Standardized Mab dataset for constants.hpp
  - Standardized Cupid dataset for constants.hpp

# 6.3.2
  - Standardized Triton dataset for constants.hpp
  - Standardized Nereid dataset for constants.hpp
  - Standardized Naiad dataset for constants.hpp
  - Standardized Thalassa dataset for constants.hpp
  - Standardized Despina dataset for constants.hpp
  - Standardized Galatea dataset for constants.hpp
  - Standardized Larissa dataset for constants.hpp
  - Standardized Proteus dataset for constants.hpp
  - Standardized Halimede dataset for constants.hpp
  - Standardized Psamathe dataset for constants.hpp
  - Standardized Sao dataset for constants.hpp
  - Standardized Laomedeia dataset for constants.hpp
  - Standardized Neso dataset for constants.hpp
  - Standardized Hippocamp dataset for constants.hpp

# 6.4.0
  - Added Rigil Kentaurus dataset to constants.hpp
  - Added Toliman dataset to constants.hpp
  - Added Proxima Centauri dataset to constants.hpp
  - Added Proxima Centauri b dataset to constants.hpp
  - Added Proxima Centauri d dataset to constants.hpp

# 6.5.0
  - Added TRAPPIST-1 dataset to constants.hpp
  - Added TRAPPIST-1b dataset to constants.hpp
  - Added TRAPPIST-1c dataset to constants.hpp
  - Added TRAPPIST-1d dataset to constants.hpp
  - Added TRAPPIST-1e dataset to constants.hpp
  - Added TRAPPIST-1f dataset to constants.hpp
  - Added TRAPPIST-1g dataset to constants.hpp
  - Added TRAPPIST-1h dataset to constants.hpp

# 6.6.0
  - Added Lich dataset to constants.hpp
  - Added Draugr dataset to constants.hpp
  - Added Poltergeist dataset to constants.hpp
  - Added Phobetor dataset to constants.hpp