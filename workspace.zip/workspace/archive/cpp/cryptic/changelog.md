# 1.0.0
  - Original

# 2.0.0
  - Fixed pool iteration bug
  - Fixed size initialization bug
  - Fixed library pathing bug
  - Fixed usage display bug
  - Upgraded algorithm
  - Changed function name from encrypt to cryptic

# 2.0.1
  - Replaced cpp/utils 1.0.0 with cpp/utils 2.0.0