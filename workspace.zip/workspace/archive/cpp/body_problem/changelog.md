# 1.0.0
  - Original

# 1.1.0
  - Added pause / resume functionality
  - Fixed echo bug with cpp/utils/terminal.hpp

# 1.2.0
  - Added save functionality
  - Added load functionality
  - Added simulation DSL (".sim") for saving and loading

# 1.3.0
  - Added stop functionality
  - Added autosave functionality
  - Added Asteroid Belt and Kuiper Belt objects
  - Stabilized FPS
  - Restructured filesystem

# 1.4.0
  - Added barycentric view functionality

# 1.4.1
  - Made collisions toggleable
  - Fixed DSL parsing error

# 1.4.2
  - Improved performance

# 1.4.3
  - Standardized physics types

# 1.5.0
  - Added modify body functionality

# 1.6.0
  - Added Z axis grayscale
  - Improved console data

# 1.6.1
  - Improved Z axis grayscale

# 1.7.0
  - Added view titles
  - Restructured window assembly

# 1.7.1
  - Fixed "not found" rendering bug

# 1.8.0
  - Added simulation energy monitor
  - Improved class structure

# 1.9.0
  - Added input echo

# 1.10.0
  - Added energy drift monitor
  - Added launch.py, a filesystem manager and Pythonn shell
  - Added filename parameter to body_problem.exe
  - Added -c (compile), -nc (no compile), and filename parameters to build.sh

# 1.10.1
  - Fixed save file distortion issue

# 1.11.0
  - Added simulate command functionality (custom total_time and timestep)

# 1.12.0
  - Added metadata extraction functionality to Python shell
  - Added documentation display functionality to Python shell

# 1.12.1
  - Fixed no error message when loading file with invalid version

# 1.12.2
  - Fixed no error message when loading nonexistent file