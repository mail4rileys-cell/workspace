# 1.0.0
  - Original

# 1.1.0
  - Added pause / resume functionality
  - Fixed echo bug with cpp/utils/terminal.hpp

# 1.2.0
  - Added save functionality
  - Added load functionality
  - Added simulation DSL (".sim") for saving and loading

# 1.3.0
  - Added stop functionality
  - Added autosave functionality
  - Added Asteroid Belt and Kuiper Belt objects
  - Stabilized FPS
  - Restructured filesystem

# 1.4.0
  - Added barycentric view functionality

# 1.4.1
  - Made collisions toggleable
  - Fixed DSL parsing error

# 1.4.2
  - Improved performance

# 1.4.3
  - Standardized physics types

# 1.5.0
  - Added modify body functionality

# 1.6.0
  - Added Z axis grayscale
  - Improved console data

# 1.6.1
  - Improved Z axis grayscale

# 1.7.0
  - Added view titles
  - Restructured window assembly

# 1.7.1
  - Fixed "not found" rendering bug

# 1.8.0
  - Added simulation energy monitor
  - Improved class structure

# 1.9.0
  - Added input echo

# 1.10.0
  - Added energy drift monitor
  - Added launch.py, a filesystem manager and Python shell
  - Added filename parameter to body_problem.exe
  - Added -c (compile), -nc (no compile), and filename parameters to build.sh

# 1.10.1
  - Fixed save file distortion issue

# 1.11.0
  - Added simulate command functionality (custom total_time and timestep)

# 1.12.0
  - Added metadata extraction functionality to Python shell
  - Added documentation display functionality to Python shell

# 1.12.1
  - Fixed no error message when loading file with invalid version

# 1.12.2
  - Fixed no error message when loading nonexistent file

# 2.0.0
  - Added luminosity
  - Added radiation pressure
  - Added radiative mass loss
  - Adopted utils 4.0.0
  - Defined internal Body struct

# 2.0.1
  - Improved error handling
  - Updated README.md

# 2.0.2
  - Improved initialization

# 2.1.0
  - Changed UI units to more intuitive scales
  - Improved internal unit safety

# 2.1.1
  - Fixed window desynchronization bug

# 2.1.2
  - Fixed barycentric title with created bodies being blank bug

# 2.2.0
  - Added keybinds
  - Bound 'esc' to stop
  - Bound '/' to pause / resume
  - Added purgesave
  - Added stopsave
  - Removed autosave

# 2.3.0
  - Added background task scheduler
  - Scheduled autosave for every five minutes
  - Removed years metadata display from Python shell
  - Added last modified metadata display to Python shell
  - Updated README.md

# 2.4.0
  - Added speed up and slow down commands
  - Bound up arrow to speed up
  - Bound down arrow to slow down
  - Added the Haumea system
  - Added the Makemake system
  - Added the Eris system
  - Added offsets to the initialization model
  - Added the Hektor system
  - Added the Patroclus system

# 2.5.0
  - Added total_time to DSL
  - Added timestep to DSL
  - Added original_energy to DSL

# 2.6.0
  - Added perspective
  - Added rotate perspective commands
  - Bound rotate X to '!'
  - Bound rotate Y to '@'
  - Bound rotate Z to '#'
  - Bound '~' to stop

# 2.7.0
  - Added axes gizmo to visualize perspective rotations
	- Replaced top right system view with axes gizmo

# 2.7.1
  - Adapted build.sh to Android architecture
	- Increased timestep from 5 seconds to 400 seconds
	- 2.8.0 will include arbitrary timestep modification

# 2.7.2
  - Performance optimizations
	- Changed scalar_t from long double to double
	- Decreased timestep from 400 seconds to 9 seconds
	- Added Martian trojan Eureka

# 3.0.0
  - Added Lua scripting to runtime!
	- Added modify option to Python shell to edit modify.lua
	- Added tool integration to Python shell via EDITOR and PAGER
	- Moved build.sh, launch.py, and modify.lua into scripts directory

# 3.1.0
  - Added get_body to Lua scripting

# 3.2.0
  - Added get_names to Lua scripting

# 3.2.1
  - Fixed Lua scripting bugs
	- Added traceback to Lua scripting errors

# 3.3.0
  - Fixed bugs
  - Added run.sh
  - Improved type safety for launch.py with typeguard
  - Made Python interpreter selection dynamic
  - Made Lua interpreter selection dynamic
  - Changed cpp/body_problem/scripts/modify.lua to cpp/body_problem/mods/main.lua
  - Added cpp/body_problem/mods to require path

# 3.4.0
  - Fixed bugs
  - Added speed up command to interface
  - Bound '+' to speed up
  - Bound '_' to slow down (speed up with factor < 1)
  - Bound '>' to view presets increment for window 0
  - Bound '<' to view presets decrement for window 0

# 3.5.0
  - Added rotate perspective to interface

# 3.6.0
  - Added zoom in command
  - Bound '}' to zoom in
  - Bound '{' to zoom in (zoom in with factor < 1)
  - Updated README.md

# 3.6.1
  - Stabilized smaller Plutonian moons
  - Smoothed keybound zoom factor to 1.1x instead of 2.0x

# 3.7.0
  - Changed timestep from 30 seconds to 1 second
  - Changed tick(dt) and init() to TICK(dt) and INIT() for Lua scripting
  - Added .luarc.json to mods directory language server support

# 4.0.0
  - Added SFML GUI for continuous graphics!
  - Added toggle GUI command
  - Bound '$' to toggle GUI

# 4.1.0
  - Added axes gizmo to SFML view
  - Fixed Z axis convention bugs
  - Removed grayscaling because the extra "characters" break the rendering logic

# 4.1.1
  - Fixed UI bugs

# 4.2.0
  - Added compatibility for headless users

# 4.3.0
  - Added Orcus and Vanth
  - Added depth to GUI (closer objects appear larger)

# 4.4.0
  - Added Lempo and Hiisi, and their moon Paha
  - Improved GUI
  
# 4.5.0
  - Added pan perspective command
  - Renamed zoom in to zoom perspective
  - Improved TUI
  - Rebound toggle GUI to '|'

# 4.6.0
  - Added Gonggong and its moon Xiangliu
  - Added Quaoar and its moon Weywot

# 4.7.0
  - Added Typhon and Echidna, binary centaur

# 4.8,0
  - Added Chiron, centaur
  - Added Chariklo, centaur
  - Added Sycorax, moon of Uranus

# 4.9.0
  - Added Cordelia, moon of Uranus
  - Added Portia, moon of Uranus
  - Added Puck, moon of Uranus

# 4.10.0
  - Added Hippocamp, moon of Neptune
  - Added Nereid, moon of Neptune
  - Added Halimede, moon of Neptune
  - Added Sao, moon of Neptune
  - Added Laomedeia, moon of Neptune
  - Added Psamathe, moon of Neptune
  - Added Neso, moon of Neptune

# 4.11.0
  - Added Ophelia, moon of Uranus
  - Added Bianca, moon of Uranus
  - Added Cressida, moon of Uranus
  - Added Desdemona, moon of Uranus
  - Added Juliet, moon of Uranus
  - Added Rosalind, moon of Uranus
  - Added Cupid, moon of Uranus
  - Added Belinda, moon of Uranus
  - Added Perdita, moon of Uranus
  - Added Mab, moon of Uranus
  - Added Francisco, moon of Uranus
  - Added Caliban, moon of Uranus
  - Added Stephano, moon of Uranus
  - Added Trinculo, moon of Uranus
  - Added Margaret, moon of Uranus
  - Added Prospero, moon of Uranus
  - Added Setebos, moon of Uranus
  - Added Ferdinand, moon of Uranus
  - Divided Uranus views into Inner, Middle, and Outer
  - Divided Neptune views into Inner, Middle, and Outer

# 4.11.1
  - Fixed duplicate system.simulate call bug

# 4.12.0
  - Added Amalthea, moon of Jupiter

# 4.13.0
  - Added Himalia, moon of Jupiter
  - Added Elara, moon of Jupiter
  - Added Pasiphae, moon of Jupiter
  - Added Sinope, moon of Jupiter
  - Added Lysithea, moon of Jupiter
  - Added Carme, moon of Jupiter
  - Added Ananke, mooon of Jupiter
  - Added Leda, moon of Jupiter
  - Added Thebe, moon of Jupiter

# 4.14.0
  - Added Adrastea, moon of Jupiter
  - Added Metis, moon of Jupiter
  - Added Callirrhoe, moon of Jupiter

# 4.15.0
  - Divided Jupiter views into Inner, Galilean, and Outer

# 4.16.0
  - Added Themisto, moon of Jupiter
  - Added Megaclite, moon of Jupiter
  - Added Taygete, moon of Jupiter

# 4.17.0
  - Added Chaldene, moon of Jupiter
  - Added Harpalyke, moon of Jupiter
  - Added Kalyke, moon of Jupiter

# 4.18.0
  - Added Iocaste, moon of Jupiter
  - Added Erinome, moon of Jupiter
  - Added Isonoe, moon of Jupiter
  - Added Praxidike, moon of Jupiter
  - Added Autonoe, moon of Jupiter
  - Added Thyone, moon of Jupiter
  - Added Hermippe, moon of Jupiter
  - Added Aitne, moon of Jupiter

# 4.19.0
  - Added Eurydome, moon of Jupiter
  - Added Euanthe, moon of Jupiter
  - Added Euporie, moon of Jupiter
  - Added Orthosie, moon of Jupiter

# 4.20.0
  - Added Sponde, moon of Jupiter
  - Added Kale, moon of Jupiter
  - Added Pasithee, moon of Jupiter
  - Added Hegemone, moon of Jupiter
  - Added Mneme, moon of Jupiter
  - Added Aoede, moon of Jupiter

# 4.21.0
  - Added Thelxinoe, moon of Jupiter
  - Added Arche, moon of Jupiter
  - Added Kallichore, moon of Jupiter
  - Added Helike, moon of Jupiter
  - Added Carpo, moon of Jupiter
  - Added Eukelade, moon of Jupiter
  - Added Cyllene, moon of Jupiter
  - Added Kore, moon of Jupiter
  - Added Herse, moon of Jupiter
  - Added Dia, moon of Jupiter
  - Added Eirene, moon of Jupiter
  - Added Philophrosyne, moon of Jupiter
  - Added Eupheme, moon of Jupiter
  - Added Valetudo, moon of Jupiter

# 4.22.0
  - Added Pandia, moon of Jupiter
  - Added Ersa, moon of Jupiter
