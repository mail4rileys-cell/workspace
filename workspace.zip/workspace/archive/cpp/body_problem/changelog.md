# 1.0.0
  - Original

# 1.1.0
  - Added pause / resume functionality
  - Fixed echo bug with cpp/utils/terminal.hpp

# 1.2.0
  - Added save functionality
  - Added load functionality
  - Added simulation DSL (".sim") for saving and loading

# 1.3.0
  - Added stop functionality
  - Added autosave functionality
  - Added Asteroid Belt and Kuiper Belt objects
  - Stabilized FPS
  - Restructured filesystem

# 1.4.0
  - Added barycentric view functionality

# 1.4.1
  - Made collisions toggleable
  - Fixed DSL parsing error

# 1.4.2
  - Improved performance

# 1.4.3
  - Standardized physics types

# 1.5.0
  - Added modify body functionality

# 1.6.0
  - Added Z axis grayscale
  - Improved console data

# 1.6.1
  - Improved Z axis grayscale

# 1.7.0
  - Added view titles
  - Restructured window assembly

# 1.7.1
  - Fixed "not found" rendering bug

# 1.8.0
  - Added simulation energy monitor
  - Improved class structure

# 1.9.0
  - Added input echo

# 1.10.0
  - Added energy drift monitor
  - Added launch.py, a filesystem manager and Python shell
  - Added filename parameter to body_problem.exe
  - Added -c (compile), -nc (no compile), and filename parameters to build.sh

# 1.10.1
  - Fixed save file distortion issue

# 1.11.0
  - Added simulate command functionality (custom total_time and timestep)

# 1.12.0
  - Added metadata extraction functionality to Python shell
  - Added documentation display functionality to Python shell

# 1.12.1
  - Fixed no error message when loading file with invalid version

# 1.12.2
  - Fixed no error message when loading nonexistent file

# 2.0.0
  - Added luminosity
  - Added radiation pressure
  - Added radiative mass loss
  - Adopted utils 4.0.0
  - Defined internal Body struct

# 2.0.1
  - Improved error handling
  - Updated README.md

# 2.0.2
  - Improved initialization

# 2.1.0
  - Changed UI units to more intuitive scales
  - Improved internal unit safety

# 2.1.1
  - Fixed window desynchronization bug

# 2.1.2
  - Fixed barycentric title with created bodies being blank bug

# 2.2.0
  - Added keybinds
  - Bound 'esc' to stop
  - Bound '/' to pause / resume
  - Added purgesave
  - Added stopsave
  - Removed autosave

# 2.3.0
  - Added background task scheduler
  - Scheduled autosave for every five minutes
  - Removed years metadata display from Python shell
  - Added last modified metadata display to Python shell
  - Updated README.md

# 2.4.0
  - Added speed up and slow down commands
  - Bound up arrow to speed up
  - Bound down arrow to slow down
  - Added the Haumea system
  - Added the Makemake system
  - Added the Eris system
  - Added offsets to the initialization model
  - Added the Hektor system
  - Added the Patroclus system

# 2.5.0
  - Added total_time to DSL
  - Added timestep to DSL
  - Added original_energy to DSL

# 2.6.0
  - Added perspective
  - Added rotate perspective commands
  - Bound rotate X to '!'
  - Bound rotate Y to '@'
  - Bound rotate Z to '#'
  - Bound '~' to stop

# 2.7.0
  - Added axes gizmo to visualize perspective rotations
	- Replaced top right system view with axes gizmo

# 2.7.1
  - Adapted build.sh to Android architecture
	- Increased timestep from 5 seconds to 400 seconds
	- 2.8.0 will include arbitrary timestep modification

# 2.7.2
  - Performance optimizations
	- Changed scalar_t from long double to double
	- Decreased timestep from 400 seconds to 9 seconds
	- Added Martian trojan Eureka

# 3.0.0
  - Added Lua scripting to runtime!
	- Added modify option to Python shell to edit modify.lua
	- Added tool integration to Python shell via EDITOR and PAGER
	- Moved build.sh, launch.py, and modify.lua into scripts directory

# 3.1.0
  - Added get_body to Lua scripting

# 3.2.0
  - Added get_names to Lua scripting

# 3.2.1
  - Fixed Lua scripting bugs
	- Added traceback to Lua scripting errors

# 3.3.0
  - Fixed bugs
  - Added run.sh
  - Improved type safety for launch.py with typeguard
  - Made Python interpreter selection dynamic
  - Made Lua interpreter selection dynamic
  - Changed cpp/body_problem/scripts/modify.lua to cpp/body_problem/mods/main.lua
  - Added cpp/body_problem/mods to require path

# 3.4.0
  - Fixed bugs
  - Bound '+' to speed up
  - Bound '_' to slow down (speed up with factor < 1)
  - Added speed up command to interface
  - TODO: Add zoom out and add rotate perspective to interface
