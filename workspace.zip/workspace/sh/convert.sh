#!/bin/bash
set -euo pipefail

echo "Converting .zip directory $1 to .tar.xz directory $2 ..."
rm -rf "$2"
mkdir -p "$2"
shopt -s nullglob

for zipfile in "$1"/*.zip; do
  name=$(basename "$zipfile" .zip)
  echo "Converting $1/$name.zip to $2/$name.tar.xz ..."
  name=$(basename "$zipfile" .zip)
  temp_dir=$(mktemp -d)
  unzip -q "$zipfile" -d "$temp_dir"
  tar -C "$temp_dir" -cf - . \
    | xz -9e -T0 \
    > "$2/$name.tar.xz"
  rm -rf "$temp_dir"
  echo "Converted $2/$name.tar.xz from $1/$name.zip"
done

exit 0
