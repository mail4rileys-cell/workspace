#!/bin/bash
set -euo pipefail

echo "Connecting to iPhone 4..."
ssh \
	-t \
	-o HostKeyAlgorithms=+ssh-rsa \
	-o PubKeyAcceptedAlgorithms=+ssh-rsa \
	"root@$1" \
	"/bin/bash --login -c 'exec bash -i'"
