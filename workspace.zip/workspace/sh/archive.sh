#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: archive <directory>"
  exit 1
elif [ ! -d "$1" ]; then
  echo "Error: $1 not found"
  exit 1
elif [ ! -f "$1/version.txt" ] && [ ! -f "$1/docs/version.txt" ]; then
  echo "Error: $1/version.txt and $1/docs/version not found"
  exit 1
fi

if [ -f "$1/version.txt" ]; then
  version=$(<"$1"/version.txt)
else
  version=$(<"$1/docs/version.txt")
fi

if [ -f "archive/$1/$version.zip" ]; then
  while true; do
    read -p "archive/$1/$version.zip will be overwritten, continue? (yes/no): " choice
    if [ "$choice" == "yes" ] || [ "$choice" == "y" ]; then
      break
    elif [ "$choice" == "no" ] || [ "$choice" == "n" ]; then
      echo "Archival aborted"
      exit 0
    else
      echo "Invalid input"
    fi
  done
fi

echo "Archiving $1 to archive/$1/$version.zip"
mkdir -p "archive/$1"
if [ -f "archive/$1/$version.zip" ]; then
  rm "archive/$1/$version.zip"
fi
zip -9 -r "archive/$1/$version.zip" "$1"
echo "Archival complete"
exit 0
