#!/bin/bash
set -euo pipefail

echo "Panicking..."
rm ../workspace.zip
zip -9 -r -q ../workspace.zip ../workspace
echo "Panic complete"
exit 0