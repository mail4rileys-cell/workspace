#!/bin/bash
set -euo pipefail

echo "Extracting workspace..."
bash sh/panic.sh
cp ../workspace.zip ~/storage/downloads/workspace.zip
echo "Extraction complete"