#!/bin/bash
set -euo pipefail

start_time="$(TZ=America/Edmonton date '+%Y-%m-%d-%H-%M-%S')"

cmd=(
  "g++"
  "-std=c++23"
  "-o cpp/checkers/checkers.elf"
  "-march=native" "-flto"
  "-Wno-psabi"
  "-Wno-attributes"
  "-Wno-unknown-pragmas"
)

files=(
  "cpp/checkers/src/main.cpp"
  "cpp/checkers/src/board.cpp"
  "cpp/checkers/src/negamax.cpp"
  "cpp/checkers/src/quiescence.cpp"
  "cpp/checkers/src/ai.cpp"
)

if [ ! -f cpp/checkers/src/telemetrics.cpp ] || [ ! -f cpp/checkers/src/telemetrics.hpp ]; then
  cmd+=("-DNO_TELEMETRY")
else
  files+=("cpp/checkers/src/telemetrics.cpp")
fi

if [ $(nproc) -eq 1 ] || [ ! -f cpp/checkers/src/speculate.cpp ] || [ ! -f cpp/checkers/src/speculate.hpp ]; then
  cmd+=("-DNO_SPECULATE")
else
  files+=("cpp/checkers/src/speculate.cpp")
fi

if [ ! -f cpp/cryptic/cryptic.cpp ] || [ -f cpp/crytpic/cryptic.hpp ]; then
  cmd+=("-DNO_ENCRYPT")
else
  files+=("cpp/cryptic/cryptic.cpp")
fi

for file in "${files[@]}"; do
  cmd+=($file)
done

compile(){
  {
    echo $start_time
    for arg in "${cmd[@]}"; do
      echo $arg
    done
  } > cpp/checkers/build.log
  ${cmd[@]}
}

run(){
  ./cpp/checkers/checkers.elf cpp/checkers/data/$start_time.ana
  count=$(ls -1 cpp/checkers/data | wc -l)
  while [ $count -gt 10 ]; do
    oldest=$(ls -1t cpp/checkers/data | tail -n 1)
    rm cpp/checkers/data/$oldest
    ((count--))
  done
  if [ -f py/analytics/main.py ]; then
    cd py
    python3 -m analytics.main ../cpp/checkers/data/$start_time.ana
    cd ..
  else
    echo "py/analytics/main.py not found"
  fi
}

if [ $# -eq 0 ]; then
  if [ ! -f cpp/checkers/checkers.elf ]; then
    echo "checkers.elf not found: Compiling C++ code..."
    compile
  else
    for file in "${files[@]}"; do
      if [ $file -nt cpp/checkers/checkers.elf ]; then
        echo "$file newer than checkers.elf: Recompiling C++ code..."
        compile
        break
      fi
    done
  fi
  run
  exit 0
elif [ $# -ge 1 ]; then
  arg_one=$1
  if [ $# -ge 2 ]; then
    arg_two=$2
    case $arg_two in
      -Oz|-Os|-Og|-Ofast|-O0|-O1|-O2|-O3)
        cmd+=("$arg_two" "-DNO_OPTIMIZE")
        ;;
      *)
        echo "Invalid argument at position 2 ($arg_two): Program terminated"
        exit 1
        ;;
    esac
  fi
  case $arg_one in
    c|compile)
      echo "Compiling C++ code..."
      compile
      echo "Compilation complete"
      exit 0
      ;;
    r|run)
      if [ ! -f cpp/checkers/checkers.elf ]; then
        echo "checkers.elf not found: Program terminated"
        exit 1
      else
        run
        exit 0
      fi
      ;;
      
    cr|compile-run)
      echo "Compiling and running C++ code..."
      compile
      run
      exit 0
      ;;
    *)
      echo "Invalid argument at position 1 ($arg_one): Program terminated"
      exit 1
      ;;
  esac
fi
