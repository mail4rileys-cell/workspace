# American Checkers (English Draughts)
  - 8x8 board
  - 12 pieces per side, all start as men
  - Men move diagonally forwards
  - Kings move diagonally forwards AND backwards
  - Men promote to kings when they reach the end of the board
  - Mandatory captures with capture chains, only one chain active at a time
  - A promotion ends any active capture chain
  - A player loses when they have no legal moves

# Main Menu Controls
  - 1 | play | p -> Start a new game
  - 2 | load | l -> Attempt to load a game from a specified save file
  - 3 | quit | q -> Terminate the current runtime

# Game Controls
  - The format for a move is X1, Y1, X2, Y2. Examples: d3e4, c4e6
  - quit | q -> Quit the current game and return to the main menu
  - previous | p -> View previous user move
  - undo | u -> Revert the game state to the previous user move (no stack)
  - moves | m -> Display a list of all legal moves at the current game state
  - history | h -> Display a list of all previous moves done by both players
  - dump | d -> Enter the save menu, it will ask for a name (and a password if the cryptic module is available and the filename ends with ".cry")

# Run and Build
 - Ensure that the current working directory is workspace
 - Run the following command: bash cpp/checkers/build.sh

# Supported Operating Systems
  - Linux (tested)
  - Windows (untested)

# System Requirements
  - 64 bit
  - 2 GB RAM
  - 1 processor; 2+ for full functionality

# Compiler Requirements
  - GCC compatible
  - C++23 or later

# Dependencies
  - cpp/utils 1.1.0 or later

# Modules (for full functionality)
  - cpp/checkers/source/speculate.hpp, cpp/checkers/source/speculate.cpp, and 2+ processors, for faster thinking
  - cpp/checkers/source/telemetrics.hpp and cpp/checkers/source/telemetrics.cpp, for data collection
  - cpp/cryptic 2.0.0 or later, for save file encryption
  - py/analytics 1.0.0 or later, for data processing
  - Note: cpp/checkers/build.sh handles any missing modules, and will work without them