#include <chrono>
// std::chrono::

#include <cstdint>
// std::uintmax_t

#include "ai.hpp"
// ai

#include "board.hpp"
// Move
// MoveMap
// Board

#include "constants.hpp"
// MAX_SCORE
// MIN_SCORE

#include "negamax.hpp"
// MAX_DEPTH
// Node
// get_ntt_size
// negamax

#include "quiescence.hpp"
// get_qtt_size

#ifndef NO_TELEMETRY
  #include "telemetrics.hpp"
  // telemetry
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

[[nodiscard]] __attribute__((cold, noinline))
Move ai(const Board& board, const std::uintmax_t ply) noexcept {
  Move move;
  const MoveMap move_map = board.generate_move_map();
  if (move_map.is_forced_move()) {
    return move_map.get_forced_move();
  } else {
    #ifndef NO_TELEMETRY
      telemetry.reset_numbers();
      telemetry.depth = MAX_DEPTH;
      const auto start = std::chrono::high_resolution_clock::now();
    #endif
    const Node result = negamax(board, MAX_DEPTH, MIN_SCORE, MAX_SCORE);
    #ifndef NO_TELEMETRY
      const auto end = std::chrono::high_resolution_clock::now();
      telemetry.ply = ply;
      telemetry.search_time = std::chrono::duration<double>(end - start).count();
      telemetry.prediction = result.score;
      telemetry.qtt_size = get_qtt_size();
      telemetry.ntt_size = get_ntt_size();
      telemetry.store_data();
    #endif
    return result.move;
  }
}

#ifndef NO_OPTIMIZE
  #pragma pop_options
#endif