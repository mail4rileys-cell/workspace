#include <cmath>
// std::abs

#include <cstdint>
// std::int8_t
// std::uint8_t
// std::uint16_t
// std::uint64_t

#include <cstdlib>
// std::system

#include <fstream>
// std::ifstream
// std::ofstream

#include <ios>
// std::ios

#include <iostream>
// std::cout
// std::endl

#include <random>
// std::mt19937_64

#include <string>
// std::string
// std::to_string

#include "board.hpp"
// Coordinate
// MoveSet
// MoveMap
// Board

#include "../../utils/format.hpp"
// format::

#ifndef NO_TELEMETRY
  #include "telemetrics.hpp"
  // telemetry
#endif

#ifndef NO_ENCRYPT
  #include "../../cryptic/cryptic.hpp"
  // cryptic
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

namespace zobrist {

  std::uint64_t grid[HEIGHT][WIDTH][5];
  std::uint64_t capture_chain_start[HEIGHT][WIDTH];
  std::uint64_t turn;
  std::mt19937_64 rng{12345};
  bool initialized = false;

  __attribute__((cold, noinline))
  void ensure_init() noexcept {
    if (initialized) {
      return;
    }
    for (std::int8_t y = 0; y < HEIGHT; y++) {
      for (std::int8_t x = 0; x < WIDTH; x++) {
        for (std::int8_t p = 0; p < 5; p++) {
          if (p == 2) {
            continue;
          }
          grid[y][x][p] = rng();
        }
        capture_chain_start[y][x] = rng();
      }
    }
    turn = rng();
  }
}

namespace directions {
  constexpr Coordinate BlueMan[4] = {{-1, -1}, {1, -1}, {0, 0}, {0, 0}};
  constexpr Coordinate RedMan[4] = {{-1, 1}, {1, 1}, {0, 0}, {0, 0}};
  constexpr Coordinate King[4] = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}};
  constexpr Coordinate Null[4] = {{0, 0}, {0, 0}, {0, 0}, {0, 0}};
}

[[nodiscard]] __attribute__((hot, pure, leaf))
const Coordinate(&get_directions(const Piece piece)noexcept)[4] {
  [[assume(
    (piece == Piece::BlueMan)
    || (piece == Piece::RedMan)
    || (piece == Piece::BlueKing)
    || (piece == Piece::RedKing)
    || (piece == Piece::Null)
  )]];
  switch(piece) {
    case Piece::BlueMan:
      return directions::BlueMan;
    case Piece::RedMan:
      return directions::RedMan;
    case Piece::BlueKing:
      return directions::King;
    case Piece::RedKing:
      return directions::King;
    case Piece::Null:
      return directions::Null;
  }
  return directions::Null;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

[[nodiscard]] __attribute__((hot, pure, leaf))
Coordinate Coordinate::operator+(const Coordinate operand) const noexcept {
  return {static_cast<std::int8_t>(this->x + operand.x), static_cast<std::int8_t>(this->y + operand.y)};
}

[[nodiscard]] __attribute__((hot, pure, leaf))
bool Coordinate::operator==(const Coordinate operand) const noexcept {
  return (this->x == operand.x) && (this->y == operand.y);
}

[[nodiscard]] __attribute__((hot, pure, leaf))
bool Coordinate::is_valid() const noexcept {
  return (this->x >= 0) && (this->x < WIDTH) && (this->y >= 0) && (this->y < HEIGHT);
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

[[nodiscard]] __attribute__((cold, noinline, pure))
std::string Move::format() const noexcept {
  return ""
  + std::string(1,'a' + this->from.x)
  + std::to_string(HEIGHT - this->from.y)
  + std::string(1,'a' + this->to.x)
  + std::to_string(HEIGHT - this->to.y);
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

[[nodiscard]] __attribute__((hot, pure))
bool Move::is_valid() const noexcept {
  return this->from.is_valid() && this->to.is_valid();
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

[[nodiscard]] __attribute__((cold, noinline, pure))
bool MoveMap::validate_move(const Move move) const noexcept {
  if (!move.from.is_valid() || !move.to.is_valid()) {
    return false;
  }
  const MoveSet& move_set = this->map[move.from.y][move.from.x];
  for (const Coordinate coordinate : (this->capture_required ? move_set.captures : move_set.passives)) {
    if (coordinate == move.to) {
      return true;
    }
  }
  return false;
}

[[nodiscard]] __attribute__((cold, noinline, pure, leaf))
bool MoveMap::is_forced_move() const noexcept {
  std::uint8_t move_count = 0;
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      if (this->capture_required) {
        move_count += this->map[y][x].capture_count;
      } else {
        move_count += this->map[y][x].passive_count;
      }
      if (move_count > 1) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] __attribute__((cold, noinline, pure, leaf))
Move MoveMap::get_forced_move() const noexcept {
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      if (this->capture_required) {
        if (this->map[y][x].capture_count != 0) {
          return {{x, y}, this->map[y][x].captures[0]};
        }
      } else {
        if (this->map[y][x].passive_count != 0) {
          return {{x, y}, this->map[y][x].passives[0]};
        }
      }
    }
  }
  return {};
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

__attribute__((cold, noinline, leaf))
Board::Board() noexcept {
  zobrist::ensure_init();
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      const Piece piece = this->grid[y][x];
      if (piece == Piece::Null) {
        continue;
      }
      this->hash ^= zobrist::grid[y][x][piece + 2];
    }
  }
}

__attribute__((cold, noinline))
Board::Board(const std::string filename) noexcept {
  #ifndef NO_ENCRYPT
    if (filename.ends_with(".cry")) {
      cryptic("decrypt", filename, filename);
    }
  #endif
  std::ifstream file(filename, std::ios::binary);
  std::uint64_t fragments[4];
  file.read(reinterpret_cast<char*>(fragments), sizeof(fragments));
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      this->grid[y][x] = static_cast<Piece>(((fragments[y / 2] >> ((x * 4) + ((y % 2) * 32))) & 0b1111) - 2);
    }
  }
  std::uint16_t metadata;
  file.read(reinterpret_cast<char*>(&metadata), sizeof(metadata));
  this->capture_chain_start = {
    static_cast<std::int8_t>(((metadata >> 6) & 0b1111) - 1),
    static_cast<std::int8_t>(((metadata >> 2) & 0b1111) - 1)
  };
  this->capture_chain = (metadata >> 1) & 0b1;
  this->turn = (metadata & 0b1) ? BLUE : RED;
  file.close();
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      const Piece piece = this->grid[y][x];
      if (piece == Piece::Null) {
        continue;
      }
      this->score += piece;
      this->hash ^= zobrist::grid[y][x][piece + 2];
    }
  }
}

__attribute__((cold, noinline))
void Board::dump(const std::string filename) const noexcept {
  std::ofstream file(filename, std::ios::binary);
  std::uint64_t fragments[4] = {0, 0, 0, 0};
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    for (std::int8_t x = 0; x < WIDTH; x++) {
      fragments[y / 2] |= (std::uint64_t)((this->grid[y][x] + 2) & 0b1111) << ((x * 4) + ((y % 2) * 32));
    }
  }
  file.write(reinterpret_cast<const char*>(fragments), sizeof(fragments));
  std::uint16_t metadata = 0;
  metadata |= ((this->capture_chain_start.x + 1) & 0b1111) << 6;
  metadata |= ((this->capture_chain_start.y + 1) & 0b1111) << 2;
  metadata |= (this->capture_chain & 0b1) << 1;
  metadata |= this->turn == BLUE ? 0b1 : 0b0;
  file.write(reinterpret_cast<const char*>(&metadata), sizeof(metadata));
  file.close();
  #ifndef NO_ENCRYPT
    if (filename.ends_with(".cry")) {
      cryptic("encrypt", filename, filename);
    }
  #endif
}

__attribute__((cold, noinline))
void Board::render() const noexcept {
  std::system("clear");
  std::cout
  << "Turn: "
  << (this->turn == BLUE ? "Blue" : "Red")
  << " | Score: "
  << (int)this->score
  << " | Capture chain: "
  << (this->capture_chain ? "Yes" : "No")
  << std::endl;
  std::string graphic;
  std::cout << "     ";
  for (std::int8_t x = 0; x < WIDTH; x++) {
    std::cout << (char)('a' + x) << ((x < WIDTH - 1) ? "    " : "");
  }
  std::cout << std::endl;
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    std::cout << "  ||===||===||===||===||===||===||===||===||" << std::endl;
    std::cout << (HEIGHT - y) << " |";
    for (std::int8_t x = 0; x < WIDTH; x++) {
      switch (this->grid[y][x]) {
        case Piece::BlueMan:
          graphic = format::chain("⬤", {format::bold, format::blue});
          break;
        case Piece::RedMan:
          graphic = format::chain("⬤", {format::bold, format::red});
          break;
        case Piece::BlueKing:
          graphic = format::chain("✪", {format::bold, format::blue});
          break;
        case Piece::RedKing:
          graphic = format::chain("✪", {format::bold, format::red});
          break;
        case Piece::Null:
          graphic = " ";
          break;
      }
      std::cout << "| " << graphic << " |";
    }
    std::cout << "| " << (HEIGHT - y) << std::endl;
  }
  std::cout << "  ||===||===||===||===||===||===||===||===||" << std::endl;
  std::cout << "     ";
  for (std::int8_t x = 0; x < WIDTH; x++) {
    std::cout << (char)('a' + x) << ((x < WIDTH - 1) ? "    " : "");
  }
  std::cout << std::endl;
}

[[nodiscard]] __attribute__((cold, noinline))
bool Board::is_terminal() const noexcept {
  const MoveMap move_map = this->generate_move_map();
  if (move_map.capture_required) {
    for (std::int8_t y = 0; y < HEIGHT; y++) {
      for (std::int8_t x = 0; x < WIDTH; x++) {
        if (((this->grid[y][x] * this->turn) > 0) && (move_map.map[y][x].capture_count > 0)) {
          return false;
        }
      }
    }
  } else {
    for (std::int8_t y = 0; y < HEIGHT; y++) {
      for (std::int8_t x = 0; x < WIDTH; x++) {
        if (((this->grid[y][x] * this->turn) > 0) && (move_map.map[y][x].passive_count > 0)) {
          return false;
        }
      }
    }
  }
  return true;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

[[nodiscard]] __attribute__((hot))
MoveMap Board::generate_move_map() const noexcept {
  #ifndef NO_TELEMETRY
    telemetry.movegen_calls++;
  #endif
  MoveMap move_map;
  #pragma GCC ivdep
  #pragma GCC unroll HEIGHT
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    #pragma GCC ivdep
    #pragma GCC unroll WIDTH
    for (std::int8_t x = 0; x < WIDTH; x++) {
      const Piece piece = this->grid[y][x];
      if (__builtin_expect(((piece * this->turn) <= 0) || (this->capture_chain && ((x != this->capture_chain_start.x) || (y != this->capture_chain_start.y))), true)) {
        continue;
      }
      for (const Coordinate direction : get_directions(piece)) {
        if (__builtin_expect(direction.x == 0, false)) {
          break;
        }
        const Coordinate to = {static_cast<std::int8_t>(x + direction.x), static_cast<std::int8_t>(y + direction.y)};
        if (__builtin_expect(!to.is_valid(), false)) {
          continue;
        }
        if (__builtin_expect((this->grid[to.y][to.x] * this->turn) < 0, false)) {
          const Coordinate jump = to + direction;
          if (jump.is_valid() && (this->grid[jump.y][jump.x] == Piece::Null)) {
            move_map.map[y][x].captures[move_map.map[y][x].capture_count++] = jump;
            #ifndef NO_TELEMETRY
              telemetry.moves_generated++;
            #endif
            move_map.capture_required = true;
          }
        } else if (__builtin_expect((this->grid[to.y][to.x] == Piece::Null) && !this->capture_chain, true)) {
          #ifndef NO_TELEMETRY
            telemetry.moves_generated++;
          #endif
          move_map.map[y][x].passives[move_map.map[y][x].passive_count++] = to;
        }
      }
    }
  }
  return move_map;
}

__attribute__((hot))
void Board::move_piece(const Move move) noexcept {
  [[assume(move.is_valid())]];
  Piece piece = this->grid[move.from.y][move.from.x];
  bool promotion = false;
  this->hash ^= zobrist::grid[move.from.y][move.from.x][piece + 2];
  this->hash ^= zobrist::grid[move.to.y][move.to.x][piece + 2];
  this->grid[move.from.y][move.from.x] = Piece::Null;
  this->grid[move.to.y][move.to.x] = piece;
  if (__builtin_expect((piece == Piece::BlueMan) && (move.to.y == 0), false)) {
    this->score += 1;
    this->hash ^= zobrist::grid[move.to.y][move.to.x][Piece::BlueMan + 2];
    this->hash ^= zobrist::grid[move.to.y][move.to.x][Piece::BlueKing + 2];
    this->grid[move.to.y][move.to.x] = Piece::BlueKing;
    piece = this->grid[move.to.y][move.to.x];
    promotion = true;
  } else if (__builtin_expect((piece == Piece::RedMan) && (move.to.y == (HEIGHT - 1)),false)) {
    this->score -= 1;
    this->hash ^= zobrist::grid[move.to.y][move.to.x][Piece::RedMan + 2];
    this->hash ^= zobrist::grid[move.to.y][move.to.x][Piece::RedKing + 2];
    this->grid[move.to.y][move.to.x] = Piece::RedKing;
    piece = this->grid[move.to.y][move.to.x];
    promotion = true;
  }
  if (__builtin_expect(std::abs(move.from.x - move.to.x) == 2, false)) {
    const Coordinate middle = {
      static_cast<std::int8_t>((move.from.x + move.to.x) / 2),
      static_cast<std::int8_t>((move.from.y + move.to.y) / 2)
    };
    const Piece captured = this->grid[middle.y][middle.x];
    this->score -= captured;
    this->hash ^= zobrist::grid[middle.y][middle.x][captured + 2];
    this->grid[middle.y][middle.x] = Piece::Null;
    if (this->capture_chain) {
      this->hash ^= zobrist::capture_chain_start[this->capture_chain_start.y][this->capture_chain_start.x];
    }
    this->capture_chain = false;
    if (__builtin_expect(!promotion, true)) {
      for (const Coordinate direction : get_directions(piece)) {
        if (__builtin_expect(direction.x == 0, false)) {
          break;
        }
        const Coordinate new_ = move.to + direction;
        const Coordinate jump = new_ + direction;
        if (__builtin_expect(jump.is_valid() && ((this->grid[new_.y][new_.x] * piece) < 0) && (this->grid[jump.y][jump.x] == Piece::Null), false)) {
          this->hash ^= zobrist::capture_chain_start[move.to.y][move.to.x];
          this->capture_chain = true;
          this->capture_chain_start = move.to;
          break;
        }
      }
    }     
  }
  if (!this->capture_chain) {
    this->hash ^= zobrist::turn;
    this->turn =- this->turn;
  }
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif