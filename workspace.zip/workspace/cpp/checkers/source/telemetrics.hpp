#pragma once

#include <cstdint>
// std::uint64_t

#include <string>
// std::string

#include <vector>
// std::vector

struct Metric {
  std::string name;
  std::string units;
  long double* const number;
  std::vector<long double> values;
};

struct Telemetry {
  long double ply = 0;
  long double depth = 0;
  long double prediction = 0;
  long double search_time = 0;
  long double movegen_calls = 0;
  long double moves_generated = 0;
  long double quiescence_nodes = 0;
  long double qtt_size = 0;
  long double qtt_hits = 0;
  long double qtt_upper_hits = 0;
  long double qtt_exact_hits = 0;
  long double negamax_nodes = 0;
  long double ab_prunes = 0;
  long double ntt_size = 0;
  long double ntt_hits = 0;
  long double ntt_upper_hits = 0;
  long double ntt_lower_hits = 0;
  long double ntt_exact_hits = 0;
  Metric metrics[18] = {
    Metric("plies", "pl", &ply), {"depths", "d", &depth}, {"predictions", "pts", &prediction},
    {"search_times", "s", &search_time}, {"movegen_calls", "ca", &movegen_calls}, {"moves_generated", "m", &moves_generated},
    {"quiescence_nodes", "n", &quiescence_nodes}, {"qtt_sizes", "e", &qtt_size}, {"qtt_hits", "h", &qtt_hits},
    {"qtt_upper_hits", "h", &qtt_upper_hits}, {"qtt_exact_hits", "h", &qtt_exact_hits}, {"negamax_nodes", "n", &negamax_nodes},
    {"ab_prunes", "pr", &ab_prunes}, {"ntt_sizes", "e", &ntt_size}, {"ntt_hits", "h", &ntt_hits},
    {"ntt_upper_hits", "h", &ntt_upper_hits}, {"ntt_lower_hits", "h", &ntt_lower_hits}, {"ntt_exact_hits", "h", &ntt_exact_hits}
  };

  Telemetry() = default;
    
  __attribute__((cold, noinline, leaf))
  void reset_numbers() noexcept;

  __attribute__((cold, noinline))
  void store_data() noexcept;

  __attribute__((cold, noinline))
  void save_data(const std::string filename) const noexcept;

  [[nodiscard]] __attribute__((cold, noinline, pure))
  std::uint64_t get_memory_usage() const noexcept;
};

extern Telemetry telemetry;