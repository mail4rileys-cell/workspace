#pragma once

#include <cstdint>
// std::int8_t
// std::uint8_t
// std::uintmax_t

#include "board.hpp"
// Move
// Board

#include "constants.hpp"
// MIN_SCORE

constexpr std::uint8_t MAX_DEPTH = 20;
// tested depth limit: 25

struct Node {
  Move move;
  std::int8_t score = MIN_SCORE;
};

[[nodiscard]] __attribute__((cold, noinline))
std::uintmax_t get_ntt_size() noexcept;

[[nodiscard]] __attribute__((hot))
Node negamax(const Board& board, const std::uint8_t depth, std::int8_t alpha, std::int8_t beta) noexcept;
