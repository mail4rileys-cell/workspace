#pragma once

#include <cstdint>
// std::int8_t 

constexpr std::int8_t MAX_SCORE = 24;
constexpr std::int8_t MIN_SCORE = -MAX_SCORE;