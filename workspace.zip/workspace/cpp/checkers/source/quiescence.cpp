#include <cstdint>
// std::int8_t
// std::uint64_t
// std::uintmax_t

#include "board.hpp"
// MoveSet
// MoveMap
// Board

#include "constants.hpp"
// MAX_SCORE
// MIN_SCORE

#include "quiescence.hpp"
// get_qtt_size
// quiescence

#ifndef NO_TELEMETRY
  #include "telemetrics.hpp"
  // telemetry
#endif

namespace {

  enum Bound : bool {
    Upper = false,
    Exact = true
  };

  constexpr std::uint8_t BITS = 25;
  constexpr std::uint64_t SIZE = (1ULL << BITS);
  constexpr std::uint64_t MASK = SIZE - 1;

  struct Entry {
    std::uint64_t data = 0;
    // SSSSSS B
    // 6----- 1 = 7 bits

    Entry() = default;

    #ifndef NO_OPTIMIZE
      #pragma GCC push_options
      #pragma GCC optimize("Ofast")
    #endif

    __attribute__((hot, leaf))
    Entry(const std::uint64_t hash, const std::int8_t score, const Bound bound) noexcept {
      [[assume((score >= MIN_SCORE) && (score <= MAX_SCORE))]];
      [[assume((bound == Bound::Upper) || (bound == Bound::Exact))]];
      this->data = 0;
      this->data |= (hash >> BITS) << 7;
      this->data |= ((score + MAX_SCORE) & 0b111111) << 1;
      this->data |= bound & 0b1;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline std::uint64_t get_shard() const noexcept {
      return this->data >> 7;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline std::int8_t get_score() const noexcept {
      return ((this->data >> 1) & 0b111111) - MAX_SCORE;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Bound get_bound() const noexcept {
      return static_cast<Bound>(this->data & 0b1);
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline bool is_valid() const noexcept {
      return this->data != 0;
    }

    #ifndef NO_OPTIMIZE
      #pragma GCC pop_options
    #endif
  };

  Entry qtt[SIZE];
}

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

[[nodiscard]] __attribute__((cold, noinline))
std::uintmax_t get_qtt_size() noexcept {
  std::uintmax_t size = 0;
  for (std::uintmax_t i = 0; i < SIZE; i++) {
    if (qtt[i].is_valid()) {
      size++;
    }
  }
  return size;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

[[nodiscard]] __attribute__((hot))
std::int8_t quiescence(const Board& board, std::int8_t alpha, const std::int8_t beta) noexcept {
  [[assume((alpha >= MIN_SCORE) && (alpha <= MAX_SCORE))]];
  [[assume((beta >= MIN_SCORE) && (beta <= MAX_SCORE))]];
  #ifndef NO_TELEMETRY
    telemetry.quiescence_nodes++;
  #endif
  const std::int8_t alpha_original = alpha;
  const std::uint64_t shard = board.hash & MASK;
  const Entry entry = qtt[shard];
  const bool hit = entry.is_valid() && (entry.get_shard() == (board.hash >> BITS));
  if (__builtin_expect(hit, false)) {
    #ifndef NO_TELEMETRY
      telemetry.qtt_hits++;
    #endif
    if (__builtin_expect((entry.get_bound() == Bound::Upper) && (entry.get_score() <= alpha), true)) {
      #ifndef NO_TELEMETRY
        telemetry.qtt_upper_hits++;
      #endif
      return entry.get_score();
    } else if (__builtin_expect(entry.get_bound() == Bound::Exact, true)) {
      #ifndef NO_TELEMETRY
        telemetry.qtt_exact_hits++;
      #endif
      return entry.get_score();
    }
  }
  const std::int8_t stand_pat = board.score * board.turn;
  if (stand_pat >= beta) {
    return beta;
  } else if (stand_pat > alpha) {
    alpha = stand_pat;
  }
  const MoveMap move_map = board.generate_move_map();
  #pragma GCC unroll HEIGHT
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    #pragma GCC unroll WIDTH
    for (std::int8_t x = 0; x < WIDTH; x++) {
      const MoveSet& move_set = move_map.map[y][x];
      for (std::int8_t i = 0; i < move_set.capture_count; i++) {
        Board temp_board = board;
        temp_board.move_piece({{x, y}, move_set.captures[i]});
        std::int8_t score;
        if (__builtin_expect(temp_board.capture_chain, false)) {
          score = quiescence(temp_board, alpha, beta);
        } else {
          score =- quiescence(temp_board, -beta, -alpha);
        }
        if (score >= beta) {
          return beta;
        } else if (score > alpha) {
          alpha = score;
        }
      }
    }
  }
  if (!hit) {
    qtt[shard] = {board.hash, alpha, (alpha <= alpha_original) ? Bound::Upper : Bound::Exact};
  }
  return alpha;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif
