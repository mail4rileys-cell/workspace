#pragma once

#include <cstdint>
// std::uintmax_t

#include "board.hpp"
// Move
// Board

[[nodiscard]] __attribute__((cold, noinline))
Move ai(const Board& board, const std::uintmax_t ply) noexcept;