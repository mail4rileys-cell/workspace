#include <cstddef>
// std::size_t;

#include <cstdint>
// std::uint64_t;

#include <fstream>
// std::ofstream;

#include <iostream>
// std::endl;

#include <string>
// std::string;

#include "telemetrics.hpp"
// Metric
// Telemetry

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

__attribute__((cold, noinline, leaf))
void Telemetry::reset_numbers() noexcept {
  for (const Metric& metric : this->metrics) {
    *metric.number = 0;
  }
}

__attribute__((cold, noinline))
void Telemetry::store_data() noexcept {
  for (Metric& metric : this->metrics) {
    metric.values.push_back(*metric.number);
  }
}

__attribute__((cold, noinline))
void Telemetry::save_data(const std::string filename) const noexcept {
  std::ofstream file(filename);
  for (const Metric& metric : this->metrics) {
    file << metric.name << ((metric.units.size() >= 1) ? (":" + metric.units) : "") << " = ";
    for (std::size_t i = 0; i < metric.values.size(); i++) {
      file << metric.values[i];
      if (i != (metric.values.size() - 1)) {
        file << ",";
      }
    }
    file << std::endl;
  }
  file
  << "INSTRUCTIONS" << std::endl
  << "__x_axis__ = plies" << std::endl
  << "total_nodes:n = negamax_nodes + quiescence_nodes" << std::endl
  << "speeds:n/s = total_nodes / search_times" << std::endl
  << "effective_branching_factors:m = total_nodes ** (1 / depths)" << std::endl
  << "literal_branching_factors:m = moves_generated / movegen_calls" << std::endl
  << "efficiencies:% = (1 - (effective_branching_factors / literal_branching_factors)) * 100" << std::endl
  << "quiescence_rates:% = (quiescence_nodes / total_nodes) * 100" << std::endl
  << "qtt_hit_rates:% = (qtt_hits / quiescence_nodes) * 100" << std::endl
  << "qtt_upper_hit_rates:% = (qtt_upper_hits / qtt_hits) * 100" << std::endl
  << "qtt_exact_hit_rates:% = (qtt_exact_hits / qtt_hits) * 100" << std::endl
  << "negamax_rates:% = (negamax_nodes / total_nodes) * 100" << std::endl
  << "ab_prune_rates:% = (ab_prunes / negamax_nodes) * 100" << std::endl
  << "ntt_hit_rates:% = (ntt_hits / negamax_nodes) * 100" << std::endl
  << "ntt_upper_hit_rates:% = (ntt_upper_hits / ntt_hits) * 100" << std::endl
  << "ntt_lower_hit_rates:% = (ntt_lower_hits / ntt_hits) * 100" << std::endl
  << "ntt_exact_hit_rates:% = (ntt_exact_hits / ntt_hits) * 100" << std::endl;
  file.close();
}

[[nodiscard]] __attribute__((cold, noinline, pure))
std::uint64_t Telemetry::get_memory_usage() const noexcept {
  std::uint64_t bytes = 0;
  for (const Metric& metric : this->metrics) {
    bytes += sizeof(metric) + sizeof(*metric.number) + (metric.values.capacity() * sizeof(long double));
  }
  return bytes;
}
  
#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

Telemetry telemetry;