#pragma once

#include <cstdint>
// std::int8_t
// std::uint8_t
// std::uint64_t

#include <string>
// std::string

constexpr std::int8_t WIDTH = 8;
constexpr std::int8_t HEIGHT = WIDTH;
constexpr std::int8_t BLUE = 1;
constexpr std::int8_t RED = -BLUE;

enum Piece:std::int8_t {
  BlueMan = 1,
  RedMan = -1,
  BlueKing = 2,
  RedKing = -2,
  Null = 0
};

struct Coordinate {
  std::int8_t x = -1;
  std::int8_t y = -1;

  [[nodiscard]] __attribute__((hot, pure, leaf))
  Coordinate operator+(const Coordinate operand) const noexcept;

  [[nodiscard]] __attribute__((hot, pure, leaf))
  bool operator==(const Coordinate operand) const noexcept;

  [[nodiscard]] __attribute__((hot, pure, leaf))
  bool is_valid() const noexcept;
};

struct Move {
  Coordinate from;
  Coordinate to;

  [[nodiscard]] __attribute__((cold, noinline, pure))
  std::string format() const noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  bool is_valid() const noexcept;
};

struct MoveSet {
  Coordinate passives[4];
  Coordinate captures[4];
  std::uint8_t passive_count = 0;
  std::uint8_t capture_count = 0;

  MoveSet() = default;
};

struct MoveMap {
  alignas(64) MoveSet map[HEIGHT][WIDTH];
  bool capture_required = false;

  MoveMap() = default;

  [[nodiscard]] __attribute__((cold, noinline, pure))
  bool validate_move(const Move move) const noexcept;

  [[nodiscard]] __attribute__((cold, noinline, pure, leaf))
  bool is_forced_move() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline, pure, leaf))
  Move get_forced_move()const noexcept;
};

struct Board {
  alignas(64) Piece grid[HEIGHT][WIDTH] {
    {Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null},
    {Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan},
    {Piece::RedMan, Piece::Null, Piece::RedMan, Piece::Null, Piece::RedMan,Piece::Null,Piece::RedMan,Piece::Null},
    {Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null},
    {Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null, Piece::Null},
    {Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan},
    {Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null},
    {Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan, Piece::Null, Piece::BlueMan}
  };
  std::uint64_t hash = 0;
  std::int8_t turn = BLUE;
  std::int8_t score = 0;
  bool capture_chain = false;
  Coordinate capture_chain_start;

  __attribute__((cold, noinline, leaf))
  explicit Board() noexcept;

  __attribute__((cold, noinline))
  explicit Board(const std::string filename) noexcept;

  __attribute__((cold, noinline))
  void dump(const std::string filename) const noexcept;

  __attribute__((cold, noinline))
  void render() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  bool is_terminal() const noexcept;

  [[nodiscard]] __attribute__((hot))
  MoveMap generate_move_map() const noexcept;

  __attribute__((hot))
  void move_piece(const Move move) noexcept;
};