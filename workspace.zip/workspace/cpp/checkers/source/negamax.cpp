#include <algorithm>
// std::min
// std::max

#include <cstdint>
// std::int8_t
// std::uint8_t
// std::uint64_t
// std::uintmax_t

#include "board.hpp"
// Coordinate
// Move
// MoveSet
// MoveMap
// Board

#include "constants.hpp"
// MAX_SCORE
// MIN_SCORE

#include "negamax.hpp"
// MAX_DEPTH
// Node
// get_ntt_size
// negamax

#include "quiescence.hpp"
// quiescence

#ifndef NO_TELEMETRY
  #include "telemetrics.hpp"
  // telemetry
#endif

namespace {
  
  enum Bound : std::uint8_t {
    Upper = 0,
    Lower = 1,
    Exact = 2
  };

  constexpr std::uint8_t BITS = 27;
  constexpr std::uint64_t SIZE = ((std::uint64_t) 1 << BITS);
  constexpr std::uint64_t MASK = SIZE - 1;

  struct Entry {
    std::uint64_t data = 0;
    //  FXFX FYFY DTX DTY SSSSSS DDDDD BB
    //  4--- 4--- 3-- 3-- 6----- 5---- 2- = 27 bits

    Entry() = default;

    #ifndef NO_OPTIMIZE
      #pragma GCC push_options
      #pragma GCC optimize("Ofast")
    #endif

    __attribute__((hot, leaf))
    Entry(const std::uint64_t hash, const Node node, const std::uint8_t depth, const Bound bound) noexcept {
      [[assume((node.score >= MIN_SCORE) && (node.score <= MAX_SCORE))]];
      [[assume(depth <= MAX_DEPTH)]];
      [[assume((bound == Bound::Upper) || (bound == Bound::Lower) || (bound == Bound::Exact))]];
      this->data = 0;
      this->data |= (hash >> BITS) << 27;
      this->data |= ((node.move.from.x + 1) & 0b1111) << 23;
      this->data |= ((node.move.from.y + 1) & 0b1111) << 19;
      this->data |= (((node.move.to.x - node.move.from.x) + 2) & 0b111) << 16;
      this->data |= (((node.move.to.y - node.move.from.y) + 2) & 0b111) << 13;
      this->data |= ((node.score + MAX_SCORE) & 0b111111) << 7;
      this->data |= (depth & 0b11111) << 2;
      this->data |= bound & 0b11;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline std::uint64_t get_shard() const noexcept {
      return this->data >> 27;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    Move get_move() const noexcept {
      const std::int8_t from_x = ((this->data >> 23) & 0b1111) - 1;
      const std::int8_t from_y = ((this->data >> 19) & 0b1111) - 1;
      const std::int8_t to_x = from_x + (((this->data >> 16) & 0b111) - 2);
      const std::int8_t to_y = from_y + (((this->data >> 13) & 0b111) - 2);
      return {{from_x, from_y}, {to_x, to_y}};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline std::int8_t get_score() const noexcept {
      return ((this->data >> 7) & 0b111111) - MAX_SCORE;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Node get_node() const noexcept {
      return {this->get_move(), this->get_score()};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline std::uint8_t get_depth() const noexcept {
      return (this->data >> 2) & 0b11111;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Bound get_bound() const noexcept {
      return static_cast<Bound>(this->data & 0b11);
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline bool is_valid() const noexcept {
      return this->data != 0;
    }

    #ifndef NO_OPTIMIZE
      #pragma GCC pop_options
    #endif
  };

  Entry ntt[SIZE];
}

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

[[nodiscard]] __attribute__((cold, noinline))
std::uintmax_t get_ntt_size() noexcept {
  std::uintmax_t size = 0;
  for (std::uintmax_t i = 0; i < SIZE; i++) {
    if (ntt[i].is_valid()) {
      size++;
    }
  }
  return size;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Ofast")
#endif

[[nodiscard]] __attribute__((hot))
Node negamax(const Board& board, const std::uint8_t depth, std::int8_t alpha, std::int8_t beta) noexcept {
  [[assume(depth <= MAX_DEPTH)]];
  [[assume((alpha >= MIN_SCORE) && (alpha <= MAX_SCORE))]];
  [[assume((beta >= MIN_SCORE) && (beta <= MAX_SCORE))]];
  #ifndef NO_TELEMETRY
    telemetry.negamax_nodes++;
  #endif
  const std::int8_t alpha_original = alpha;
  const std::uint64_t shard = board.hash & MASK;
  const Entry entry = ntt[shard];
  const bool hit = entry.is_valid() && (entry.get_shard() == (board.hash >> BITS)) && (entry.get_depth() >= depth) && ((depth != MAX_DEPTH) || entry.get_move().is_valid());
  if (hit) {
    #ifndef NO_TELEMETRY
      telemetry.ntt_hits++;
    #endif
    switch (entry.get_bound()) {
      case Bound::Upper:
        #ifndef NO_TELEMETRY
          telemetry.ntt_upper_hits++;
        #endif
        beta = std::min(beta, entry.get_score());
        break;
      case Bound::Lower:
        #ifndef NO_TELEMETRY
          telemetry.ntt_lower_hits++;
        #endif
        alpha = std::max(alpha, entry.get_score());
        break;
      case Bound::Exact:
        #ifndef NO_TELEMETRY
          telemetry.ntt_exact_hits++;
        #endif
        return entry.get_node();
    }
    if (alpha >= beta) {
      return entry.get_node();
    }
  }
  const MoveMap move_map = board.generate_move_map();
  if (depth == 0) {
    if (__builtin_expect(move_map.capture_required, false)) {
      return {{}, quiescence(board, alpha, beta)};
    } else {
      return {{}, static_cast<std::int8_t>(board.score * board.turn)};
    }
  }
  Node best;
  #pragma GCC unroll HEIGHT
  for (std::int8_t y = 0; y < HEIGHT; y++) {
    #pragma GCC unroll WIDTH
    for (std::int8_t x = 0; x < WIDTH; x++) {
      const Coordinate from{x, y};
      const MoveSet& move_set = move_map.map[y][x];
      for (const Coordinate to : (move_map.capture_required ? move_set.captures : move_set.passives)) {
        if (!to.is_valid()) {
          continue;
        }
        const Move move = {from, to};
        Board temp_board = board;
        temp_board.move_piece(move);
        Node result;
        if (__builtin_expect(temp_board.capture_chain, false)) {
          result = negamax(temp_board, depth, alpha, beta);
        } else {
          result = negamax(temp_board, depth - 1, -beta, -alpha);
          result.score = -result.score;
        }
        if (result.score > best.score) {
          best.score = result.score;
          best.move = move;
        }
        alpha = std::max(alpha, best.score);
        if (alpha >= beta) {
          #ifndef NO_TELEMETRY
            telemetry.ab_prunes++;
          #endif
          goto search_end;
        }
      }
    }
  }
  search_end:
    if (!hit) {
      Bound bound;
      if (best.score <= alpha_original) {
        bound = Bound::Upper;
      } else if (best.score >= beta) {
        bound = Bound::Lower;
      } else {
        bound = Bound::Exact;
      }
      ntt[shard] = {board.hash, best, depth, bound};
    }
    return best;
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif