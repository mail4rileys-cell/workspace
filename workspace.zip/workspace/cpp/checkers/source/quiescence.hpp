#pragma once

#include <cstdint>
// std::int8_t
// std::uintmax_t

#include "board.hpp"
// Board

[[nodiscard]] __attribute__((cold, noinline))
std::uintmax_t get_qtt_size() noexcept;

[[nodiscard]] __attribute__((hot))
std::int8_t quiescence(const Board& board, std::int8_t alpha, const std::int8_t beta) noexcept;