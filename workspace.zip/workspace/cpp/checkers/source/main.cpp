#if !defined(__GNUC__) && !defined(COMPILER_OVERRIDE)
  #error Unsupported C++ compiler: Must be compatible with GCC, define COMPILER_OVERRIDE to override
#endif

#pragma GCC diagnostic error "-Wall"

#include <cstddef>
// std::size_t

#include <cstdint>
// std::int8_t
// std::uintmax_t

#include <cstdlib>
// std::system

#include <filesystem>
// std::filesystem::

#include <iostream>
// std::cin
// std::cout
// std::endl

#include <stdexcept>
// std::runtime_error

#include <string>
// std::string

#include <vector>
// std::vector

#include "ai.hpp"
// ai

#include "board.hpp"
// Coordinate
// MoveSet
// MoveMap
// Board

#ifndef NO_TELEMETRY
  #include "telemetrics.hpp"
  // telemetry
#endif

#ifndef NO_SPECULATE
  #include "speculate.hpp"
  // Speculator
#endif

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

__attribute__((cold, noinline))
void wait() noexcept {
  std::cout << "Input enter to continue: ";
  std::cin.ignore();
  std::cin.get();
}

__attribute__((cold, noinline))
void game(Board& board) {
  std::uintmax_t ply = 0;
  std::vector<Move> history;
  Board previous_board;
  #ifndef NO_SPECULATE
    Speculator speculator;
  #endif
  while (true) {
    MoveMap move_map = board.generate_move_map();
    if (board.turn == BLUE) {
      board.render();
      std::cout << "Input move: ";
      std::string input;
      std::cin >> input;
      if ((input == "quit") || (input == "q")) {
        break;
      } else if ((input == "previous") || (input == "p")) {
        previous_board.render();
        wait();
      } else if ((input == "undo") || (input == "u")) {
        board = previous_board;
        if (history.size() == 1) {
          history.clear();
        } else if (history.size() > 1) {
          history.pop_back();
        }
      } else if ((input == "moves") || (input == "m")) {
        std::system("clear");
        std::cout << "Moves" << std::endl;
        std::cout << "-----" << std::endl;
        for (std::int8_t y = 0; y < HEIGHT; y++) {
          for (std::int8_t x = 0; x < WIDTH; x++) {
            const MoveSet& move_set = move_map.map[y][x];
            for (const Coordinate to : move_set.passives) {
              if (!to.is_valid()) {
                continue;
              }
              std::cout << Move({x, y}, to).format() << std::endl;
            }
            for (const Coordinate to : move_set.captures) {
              if (!to.is_valid()) {
                continue;
              }
              std::cout << Move{{x, y}, to}.format() << std::endl;
            }
          }
        }
        std::cout << "-----" << std::endl;
        std::cout << std::endl;
        wait();
      } else if ((input == "history") || (input == "h")) {
        std::system("clear");
        std::cout << "History" << std::endl;
        std::cout << "-------" << std::endl;
        for (std::size_t i = 0; i < history.size(); i += 2) {
          if ((history.size() % 2) == 0) {
            std::cout << ((i / 2) + 1) << ". " << history[i].format() << " " << history[i + 1].format() << std::endl;
          } else {
            std::cout << ((i / 2) + 1) << ". " << history[i].format() << std::endl;
          }
        }
        std::cout << "-------" << std::endl;
        std::cout << std::endl;
        wait();
      } else if ((input == "dump") || (input == "d")) {
        std::system("clear");
        std::cout << "Input filename: ";
        std::string filename;
        std::cin >> filename;
        board.dump("cpp/checkers/saves/" + filename);
      } else if (input.size() == 4) {
        const Move move = {
          {static_cast<std::int8_t>(input[0] - 'a'), static_cast<std::int8_t>(7 - (input[1] - '1'))},
          {static_cast<std::int8_t>(input[2] - 'a'), static_cast<std::int8_t>(7 - (input[3] - '1'))}
        };
        if (move_map.validate_move(move)) {
          board.dump("cpp/checkers/saves/autosave");
          previous_board = board;
          history.push_back(move);
          board.move_piece(move);
          if (board.is_terminal()) {
            board.render();
            std::cout << "Blue wins!" << std::endl;
            wait();
            break;
          } else if (!board.capture_chain) {
            ply++;
            #ifndef NO_SPECULATE
              board.render();
              std::cout << "Resolving speculation..." << std::endl;
              speculator.stop();
            #endif
          }
        }
      }
    } else {
      board.render();
      std::cout << "Thinking..." << std::endl;
      const Move move = ai(board, ply);
      if (!move_map.validate_move(move)) {
        throw std::runtime_error("AI generated invalid move (" + move.format() + ")");
      }
      history.push_back(move);
      board.move_piece(move);
      if (board.is_terminal()) {
        board.render();
        std::cout << "Red wins!" << std::endl;
        wait();
        break;
      }
      if (!board.capture_chain) {
        ply++;
        #ifndef NO_SPECULATE
          speculator.start(board,ply);
        #endif
      }
    }
  }
  std::system("clear");
  std::cout << "Exiting game..." << std::endl;
  #ifndef NO_SPECULATE
    speculator.stop();
  #endif
}

#ifndef NO_OPTIMIZE
  #pragma GCC pop_options
#endif

int main(const int argc, const char* argv[]) {
  while (true) {
    std::system("clear");
    std::cout << argv[0] << std::endl;
    std::cout << "--------------" << std::endl;
    std::cout << "1. Play" << std::endl;
    std::cout << "2. Load" << std::endl;
    std::cout << "3. Quit" << std::endl;
    std::cout << "--------------" << std::endl;
    std::cout << "Input choice: ";
    std::string input;
    std::cin >> input;
    if ((input == "1") || (input == "play") || (input == "p")) {
      Board board;
      game(board);
    } else if ((input == "2") || (input == "load") || (input == "l")) {
      std::system("clear");
      std::cout << "Input filename: ";
      std::string filename;
      std::cin >> filename;
      if (std::filesystem::exists("cpp/checkers/saves/" + filename)) {
        Board board("cpp/checkers/saves/" + filename);
        game(board);
      } else {
        std::system("clear");
        std::cout << "File \"" << filename << "\" not found" << std::endl;
        wait();
      }
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      std::system("clear");
      std::cout << "Terminating Checkers..." << std::endl;
      #ifndef NO_TELEMETRY
        telemetry.save_data((argc >= 2) ? argv[1] : "default.ana");
      #endif
      break;
    }
  }
  return 0;
}
