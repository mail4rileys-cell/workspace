#pragma once

#include <atomic>
// std::atomic

#include <cstdint>
// std::uintmax_t

#include <thread>
// std::thread

#include "board.hpp"
// Board

struct Speculator {
  private:
  std::thread worker;
  std::atomic<bool> flag{false};
  public:

  Speculator() = default;

  __attribute__((cold, noinline))
  void start(const Board board, const std::uintmax_t ply) noexcept;

  __attribute__((cold, noinline))
  void stop() noexcept;
};