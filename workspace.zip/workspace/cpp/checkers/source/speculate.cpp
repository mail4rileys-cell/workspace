#include <algorithm>
// std::shuffle

#include <atomic>
// std::atomic
// std::memory_order_relaxed

#include <cstdint>
// std::int8_t
// std::uintmax_t

#include <functional>
// std::ref

#include <iterator>
// std::begin
// std::end

#include <random>
// std::random_device
// std::mt19937

#include <thread>
// std::thread

#include "board.hpp"
// Coordinate
// MoveSet
// MoveMap
// Board

#include "constants.hpp"
// MAX_SCORE
// MIN_SCORE

#include "negamax.hpp"
// MAX_DEPTH
// get_ntt_size
// negamax

#include "quiescence.hpp"
// get_qtt_size

#include "speculate.hpp"
// speculate

#ifndef NO_TELEMETRY
  #include <chrono>
  // std::chrono::high_resolution_clock
  // std::chrono::duration
  #include "telemetrics.hpp"
  // telemetry
#endif

namespace {
  std::mt19937 gen(std::random_device{}());
}

#ifndef NO_OPTIMIZE
  #pragma GCC push_options
  #pragma GCC optimize("Og")
#endif

__attribute__((cold, noinline))
void search(const Board board, const std::uintmax_t ply, const std::atomic<bool>& flag) noexcept {
  const MoveMap move_map = board.generate_move_map();
  std::int8_t y_array[HEIGHT];
  for (std::int8_t i = 0; i < HEIGHT; i++) {
    y_array[i] = i;
  }
  std::shuffle(std::begin(y_array), std::end(y_array), gen);
  for (const std::int8_t y : y_array) {
    std::int8_t x_array[WIDTH];
    for (std::int8_t i = 0; i < WIDTH; i++) {
      x_array[i] = i;
    }
    std::shuffle(std::begin(x_array), std::end(x_array), gen);
    for (const std::int8_t x : x_array) {
      const MoveSet& move_set = move_map.map[y][x];
      for (const Coordinate to : (move_map.capture_required ? move_set.captures : move_set.passives)) {
        if (flag.load(std::memory_order_relaxed)) {
          return;
        } else if (!to.is_valid()) {
          continue;
        }
        Board temp_board = board;
        temp_board.move_piece({{x, y}, to});
        if (temp_board.capture_chain) {
          continue;
        }
        #ifndef NO_TELEMETRY
          telemetry.reset_numbers();
          telemetry.depth = MAX_DEPTH;
          const auto start = std::chrono::high_resolution_clock::now();
        #endif
        const Node result = negamax(temp_board, MAX_DEPTH, MIN_SCORE, MAX_SCORE);
        #ifndef NO_TELEMETRY
          const auto end = std::chrono::high_resolution_clock::now();
          telemetry.ply = ply + 1;
          telemetry.search_time = std::chrono::duration<double>(end - start).count();
          telemetry.prediction = result.score;
          telemetry.qtt_size = get_qtt_size();
          telemetry.ntt_size = get_ntt_size();
          telemetry.store_data();
        #endif
      }
    }
  }
}

__attribute__((cold, noinline))
void Speculator::start(const Board board, const std::uintmax_t ply) noexcept {
  this->flag.store(false, std::memory_order_relaxed);
  this->worker = std::thread(search, board, ply, std::ref(this->flag));
}

__attribute__((cold, noinline))
void Speculator::stop() noexcept {
  this->flag.store(true, std::memory_order_relaxed);
  if (this->worker.joinable()) {
    worker.join();
  }
}

#ifndef NO_OPTIMIZE
 #pragma GCC pop_options
#endif