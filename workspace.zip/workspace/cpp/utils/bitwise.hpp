// since 2.0.0

#pragma once

#include <cstdint>
// std::uint8_t

#include "concepts.hpp"
// concepts::

namespace bitwise {

  namespace rotate {

    #define ROTATE(NAME, NORMAL, REVERSE) \
      template<typename Value, typename Shift> \
      requires \
        concepts::lshift_c::val<Value, Shift, Value> && \
        concepts::rshift_c::val<Value, Shift, Value> && \
        concepts::or_c::val<Value, Value, Value> && \
        concepts::mod_c::mut<Shift, std::uint8_t, Shift> && \
        concepts::eq_c<Shift, int> && \
        concepts::sub_c::val<std::uint8_t, Shift, Shift> \
      inline Value NAME(const Value value, Shift shift) noexcept { \
        const std::uint8_t bits = sizeof(value) * 8; \
        shift %= bits; \
        return (shift == 0) ? value : ((value NORMAL shift) | (value REVERSE (bits - shift))); \
      }
    // end

    ROTATE(left, <<, >>)
    ROTATE(right, >>, <<)

    #undef ROTATE
  }
}