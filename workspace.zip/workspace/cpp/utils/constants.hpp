#pragma once

#include <concepts>
// std::floating_point

// Config values: number, mass, distance, time
template<typename number_t, number_t MASS, number_t DISTANCE, number_t TIME>
requires std::floating_point<number_t>
struct Constants final {

  #define CONSTANT(NAME, NUMBER) \
    static constexpr number_t NAME = static_cast<number_t>(NUMBER);
  // end

  #define FROM(NAME, FACTOR) \
    inline static constexpr number_t NAME(const number_t number) noexcept { \
      return number * static_cast<number_t>(FACTOR); \
    }
  // end

  #define TO(NAME, FACTOR) \
    inline static constexpr number_t to_##NAME(const number_t number) noexcept { \
      return number / static_cast<number_t>(FACTOR); \
    }
  // end

  #define UNIT(NAME, FACTOR) \
    FROM(NAME, FACTOR) \
    TO(NAME, FACTOR)
  // end
  
  CONSTANT(PI, 3.14159265358979323846L)
  UNIT(degrees, PI / static_cast<number_t>(180.0L))

  UNIT(kilograms, MASS)
  UNIT(grams, MASS / 1000.0L)
  UNIT(solar_masses, MASS * 1.98847e30L)\
  UNIT(earth_masses, MASS * 5.9722e24L)

  UNIT(meters, DISTANCE)
  UNIT(kilometers, DISTANCE * 1000.0L)
  UNIT(astronomical_units, DISTANCE * 1.495978707e11L)

  UNIT(seconds, TIME)
  UNIT(minutes, TIME * 60.0L)
  UNIT(hours, TIME * 3600.0L)
  UNIT(days, TIME * 86400.0L)
  UNIT(years, TIME * 31557600.0L)

  UNIT(meters_per_second, DISTANCE / TIME)
  UNIT(kilometers_per_second, (DISTANCE * 1000.0L) / TIME)

  UNIT(meters_per_second_squared, DISTANCE / (TIME * TIME))
  
  UNIT(newtons, (MASS * DISTANCE) / (TIME * TIME))

  UNIT(joules, (MASS * DISTANCE * DISTANCE ) / (TIME * TIME))

  UNIT(watts, (MASS * DISTANCE * DISTANCE) / (TIME * TIME * TIME))
  UNIT(solar_luminosities, (MASS * DISTANCE * DISTANCE * 3.828e26L) / (TIME * TIME * TIME))

  #undef UNIT
  #undef FROM
  #undef TO

  CONSTANT(GRAVITATIONAL_CONSTANT, (static_cast<number_t>(6.67430e-11L) * DISTANCE * DISTANCE * DISTANCE) / (MASS * TIME * TIME))
  CONSTANT(LIGHTSPEED, meters_per_second(299792458.0L))

  CONSTANT(SOL_MASS, kilograms(1.98847e30L))
  CONSTANT(SOL_RADIUS, meters(6.957e8L))
  CONSTANT(SOL_LUMINOSITY, watts(3.828e26L))

    // Inner System

    CONSTANT(MERCURY_MASS, kilograms(3.3011e23L))
    CONSTANT(MERCURY_RADIUS, meters(2.4397e6L))
    CONSTANT(MERCURY_DISTANCE, meters(5.7909227e10L))
    CONSTANT(MERCURY_SPEED, meters_per_second(47360.0L))
    CONSTANT(MERCURY_INCLINE, degrees(7.005L))
    CONSTANT(MERCURY_OFFSET, degrees(0.0L))
    CONSTANT(MERCURY_AXIAL, degrees(0.034L))
    CONSTANT(MERCURY_PERIOD, seconds(7.6005e6L))

    CONSTANT(VENUS_MASS, kilograms(4.8675e24L))
    CONSTANT(VENUS_RADIUS, meters(6.0518e6L))
    CONSTANT(VENUS_DISTANCE, meters(1.0820949e11L))
    CONSTANT(VENUS_SPEED, meters_per_second(35020.0L))
    CONSTANT(VENUS_INCLINE, degrees(3.394L))
    CONSTANT(VENUS_OFFSET, degrees(0.0L))
    CONSTANT(VENUS_AXIAL, degrees(177.36L))
    CONSTANT(VENUS_PERIOD, seconds(1.9414e7L))

    CONSTANT(EARTH_MASS, kilograms(5.9722e24L))
    CONSTANT(EARTH_RADIUS, meters(6.3710e6L))
    CONSTANT(EARTH_DISTANCE, meters(1.495978707e11L))
    CONSTANT(EARTH_SPEED, meters_per_second(29782.7L))
    CONSTANT(EARTH_INCLINE, degrees(0.0L))
    CONSTANT(EARTH_OFFSET, degrees(0.0L))
    CONSTANT(EARTH_AXIAL, degrees(23.43928L))
    CONSTANT(EARTH_PERIOD, seconds(3.15581e7L))

      CONSTANT(LUNA_MASS, kilograms(7.342e22L))
      CONSTANT(LUNA_RADIUS, meters(1.7374e6L))
      CONSTANT(LUNA_DISTANCE, meters(3.84400e8L))
      CONSTANT(LUNA_SPEED, meters_per_second(1022.0L))
      CONSTANT(LUNA_INCLINE, degrees(10.0L))
      CONSTANT(LUNA_PERIOD, seconds(2.3606e6L))

    CONSTANT(MARS_MASS, kilograms(6.4171e23L))
    CONSTANT(MARS_RADIUS, meters(3.3895e6L))
    CONSTANT(MARS_DISTANCE, meters(2.2793925e11L))
    CONSTANT(MARS_SPEED, meters_per_second(24077.0L))
    CONSTANT(MARS_INCLINE, degrees(1.850L))
    CONSTANT(MARS_OFFSET, degrees(0.0L))
    CONSTANT(MARS_AXIAL, degrees(25.19L))
    CONSTANT(MARS_PERIOD, seconds(5.93544e7L))

      CONSTANT(PHOBOS_MASS, kilograms(1.0659e16L))
      CONSTANT(PHOBOS_RADIUS, meters(1.1266e4L))
      CONSTANT(PHOBOS_DISTANCE, meters(9.376e6L))
      CONSTANT(PHOBOS_SPEED, meters_per_second(2138.0L))
      CONSTANT(PHOBOS_INCLINE, degrees(1.093L))
      CONSTANT(PHOBOS_PERIOD, seconds(2.758e4L))

      CONSTANT(DEIMOS_MASS, kilograms(1.4762e15L))
      CONSTANT(DEIMOS_RADIUS, meters(6.2e3L))
      CONSTANT(DEIMOS_DISTANCE, meters(2.345e7L))
      CONSTANT(DEIMOS_SPEED, meters_per_second(1351.0L))
      CONSTANT(DEIMOS_INCLINE, degrees(0.93L))
      CONSTANT(DEIMOS_PERIOD, seconds(1.096e5L))

    CONSTANT(EUREKA_MASS, kilograms(3.5e15L))
    CONSTANT(EUREKA_RADIUS, meters(6.40e2L))
    CONSTANT(EUREKA_DISTANCE, meters(2.282e11L))
    CONSTANT(EUREKA_SPEED, meters_per_second(2.41e4L))
    CONSTANT(EUREKA_INCLINE, degrees(20.2803507L))
    CONSTANT(EUREKA_OFFSET, degrees(-60.0L))
    CONSTANT(EUREKA_AXIAL, degrees(0.0L)) // unknown

        // The Asteriod Belt
    
    CONSTANT(CERES_MASS, kilograms(9.3839e20L))
    CONSTANT(CERES_RADIUS, meters(4.696e5L))
    CONSTANT(CERES_DISTANCE, meters(4.14111e11L))
    CONSTANT(CERES_SPEED, meters_per_second(1.79e4L))
    CONSTANT(CERES_INCLINE, degrees(10.6L))
    CONSTANT(CERES_OFFSET, degrees(0.0L))


    CONSTANT(VESTA_MASS, kilograms(2.59076e20L))
    CONSTANT(VESTA_RADIUS, meters(2.626e5L))
    CONSTANT(VESTA_DISTANCE, meters(3.536e11L))
    CONSTANT(VESTA_SPEED, meters_per_second(1.93e4L))
    CONSTANT(VESTA_INCLINE, degrees(7.14L))
    CONSTANT(VESTA_OFFSET, degrees(0.0L))

    CONSTANT(JUNO_MASS, kilograms(2.82e19L))
    CONSTANT(JUNO_RADIUS, meters(1.17e5L))
    CONSTANT(JUNO_DISTANCE, meters(3.99e11L))
    CONSTANT(JUNO_SPEED, meters_per_second(1.79e4L))
    CONSTANT(JUNO_INCLINE, degrees(12.99L))
    CONSTANT(JUNO_OFFSET, degrees(0.0L))

    CONSTANT(PALLAS_MASS, kilograms(2.14e20L))
    CONSTANT(PALLAS_RADIUS, meters(2.56e5L))
    CONSTANT(PALLAS_DISTANCE, meters(4.144e11L))
    CONSTANT(PALLAS_SPEED, meters_per_second(1.79e4L))
    CONSTANT(PALLAS_INCLINE, degrees(34.8L))
    CONSTANT(PALLAS_OFFSET, degrees(0.0L))

    // Outer System
    
    CONSTANT(JUPITER_MASS, kilograms(1.8982e27L))
    CONSTANT(JUPITER_RADIUS, meters(6.9911e7L))
    CONSTANT(JUPITER_DISTANCE, meters(7.78412027e11L))
    CONSTANT(JUPITER_SPEED, meters_per_second(1.3056e4L))
    CONSTANT(JUPITER_INCLINE, degrees(1.304L))
    CONSTANT(JUPITER_OFFSET, degrees(0.0L))
    CONSTANT(JUPITER_AXIAL, degrees(3.13L))
    CONSTANT(JUPITER_PERIOD, seconds(3.743556e8L))

      CONSTANT(IO_MASS, kilograms(8.9319e22L))
      CONSTANT(IO_RADIUS, meters(1.8216e6L))
      CONSTANT(IO_DISTANCE, meters(4.217e8L))
      CONSTANT(IO_SPEED, meters_per_second(1.731e4L))
      CONSTANT(IO_INCLINE, degrees(0.036L))
      CONSTANT(IO_PERIOD, seconds(1.52853e5L))

      CONSTANT(EUROPA_MASS, kilograms(4.7998e22L))
      CONSTANT(EUROPA_RADIUS, meters(1.5608e6L))
      CONSTANT(EUROPA_DISTANCE, meters(6.711e8L))
      CONSTANT(EUROPA_SPEED, meters_per_second(1.374e4L))
      CONSTANT(EUROPA_INCLINE, degrees(0.466L))
      CONSTANT(EUROPA_PERIOD, seconds(3.06785e5L))

      CONSTANT(GANYMEDE_MASS, kilograms(1.4819e23L))
      CONSTANT(GANYMEDE_RADIUS, meters(2.6341e6L))
      CONSTANT(GANYMEDE_DISTANCE, meters(1.0704e9L))
      CONSTANT(GANYMEDE_SPEED, meters_per_second(1.088e4L))
      CONSTANT(GANYMEDE_INCLINE, degrees(0.20L))
      CONSTANT(GANYMEDE_PERIOD, seconds(6.18153e5L))

      CONSTANT(CALLISTO_MASS, kilograms(1.0759e23L))
      CONSTANT(CALLISTO_RADIUS, meters(2.4103e6L))
      CONSTANT(CALLISTO_DISTANCE, meters(1.8827e9L))
      CONSTANT(CALLISTO_SPEED, meters_per_second(8.204e3L))
      CONSTANT(CALLISTO_INCLINE, degrees(0.28L))
      CONSTANT(CALLISTO_PERIOD, seconds(1.44193e6L))

    CONSTANT(HEKTOR_MASS, kilograms(2.18e18L))
    CONSTANT(HEKTOR_RADIUS, meters(1.25e5L))
    CONSTANT(HEKTOR_DISTANCE, meters(7.867e11))
    CONSTANT(HEKTOR_SPEED, meters_per_second(1.31e4L))
    CONSTANT(HEKTOR_INCLINE, degrees(18.166L))
    CONSTANT(HEKTOR_OFFSET, degrees(60.0L))
    CONSTANT(HEKTOR_AXIAL, degrees(99.0L))

      // derived from semi major axis and orbital period
      CONSTANT(SKAMANDRIOS_MASS, kilograms(8.9e14L))
      CONSTANT(SKAMANDRIOS_RADIUS, meters(6.0e3L))
      CONSTANT(SKAMANDRIOS_DISTANCE, meters(6.235e5L))
      CONSTANT(SKAMANDRIOS_SPEED, meters_per_second(15.29L))
      CONSTANT(SKAMANDRIOS_INCLINE, degrees(50.0L))

    CONSTANT(PATROCLUS_MASS, kilograms(1.35e18L))
    CONSTANT(PATROCLUS_RADIUS, meters(1.0e5L))
    CONSTANT(PATROCLUS_DISTANCE, meters(7.78e11L))
    CONSTANT(PATROCLUS_SPEED, meters_per_second(1.31e4L))
    CONSTANT(PATROCLUS_INCLINE, degrees(22.0L))
    CONSTANT(PATROCLUS_OFFSET, degrees(-60.0L))
    CONSTANT(PATROCLUS_AXIAL, degrees(0.0L)) // unknown

      // data is poor, this is mostly guesswork, but produces qualitatively correct behaviour
      CONSTANT(MENOETIUS_MASS, kilograms(1.0e18L))
      CONSTANT(MENOETIUS_RADIUS, meters(7.0e4L))
      CONSTANT(MENOETIUS_DISTANCE, meters_per_second(6.8e5L))
      CONSTANT(MENOETIUS_SPEED, meters_per_second(15.0L))
      CONSTANT(MENOETIUS_INCLINE, degrees(5.0L)) // approx

    CONSTANT(SATURN_MASS, kilograms(5.6834e26L))
    CONSTANT(SATURN_RADIUS, meters(5.8232e7L))
    CONSTANT(SATURN_DISTANCE, meters(1.43353e12L))
    CONSTANT(SATURN_SPEED, meters_per_second(9.68e3L))
    CONSTANT(SATURN_INCLINE, degrees(2.485L))
    CONSTANT(SATURN_OFFSET, degrees(0.0L))
    CONSTANT(SATURN_AXIAL, degrees(26.73L))
    CONSTANT(SATURN_PERIOD, seconds(2.928e9L))

      CONSTANT(TITAN_MASS, kilograms(1.3452e23L))
      CONSTANT(TITAN_RADIUS, meters(2.57473e6L))
      CONSTANT(TITAN_DISTANCE, meters(1.22187e9L))
      CONSTANT(TITAN_SPEED, meters_per_second(5.574e3L))
      CONSTANT(TITAN_INCLINE, degrees(0.348L))
      CONSTANT(TITAN_PERIOD, seconds(1.377e6L))

      CONSTANT(RHEA_MASS, kilograms(2.3065e21L))
      CONSTANT(RHEA_RADIUS, meters(7.638e5L))
      CONSTANT(RHEA_DISTANCE, meters(5.27108e8L))
      CONSTANT(RHEA_SPEED, meters_per_second(8.48e3L))
      CONSTANT(RHEA_INCLINE, degrees(0.345L))
      CONSTANT(RHEA_PERIOD, seconds(3.908e5L))

      CONSTANT(IAPETUS_MASS, kilograms(1.805e21L))
      CONSTANT(IAPETUS_RADIUS, meters(7.349e5L))
      CONSTANT(IAPETUS_DISTANCE, meters(3.56082e9L))
      CONSTANT(IAPETUS_SPEED, meters_per_second(3.26e3L))
      CONSTANT(IAPETUS_INCLINE, degrees(8.298L))
      CONSTANT(IAPETUS_PERIOD, seconds(6.852e6L))

      CONSTANT(DIONE_MASS, kilograms(1.095e21L))
      CONSTANT(DIONE_RADIUS, meters(5.614e5L))
      CONSTANT(DIONE_DISTANCE, meters(3.774e8L))
      CONSTANT(DIONE_SPEED, meters_per_second(1.003e4L))
      CONSTANT(DIONE_INCLINE, degrees(0.028L))
      CONSTANT(DIONE_PERIOD, seconds(2.737e5L))

      CONSTANT(TETHYS_MASS, kilograms(6.174e20L))
      CONSTANT(TETHYS_RADIUS, meters(5.311e5L))
      CONSTANT(TETHYS_DISTANCE, meters(2.946e8L))
      CONSTANT(TETHYS_SPEED, meters_per_second(1.135e4L))
      CONSTANT(TETHYS_INCLINE, degrees(1.091L))
      CONSTANT(TETHYS_PERIOD, seconds(1.888e5L))

      CONSTANT(ENCELADUS_MASS, kilograms(1.080e20L))
      CONSTANT(ENCELADUS_RADIUS, meters(2.521e5L))
      CONSTANT(ENCELADUS_DISTANCE, meters(2.379e8L))
      CONSTANT(ENCELADUS_SPEED, meters_per_second(1.263e4L))
      CONSTANT(ENCELADUS_INCLINE, degrees(0.009L))
      CONSTANT(ENCELADUS_PERIOD, seconds(1.184e5L))

      CONSTANT(MIMAS_MASS, kilograms(3.749e19L))
      CONSTANT(MIMAS_RADIUS, meters(1.982e5L))
      CONSTANT(MIMAS_DISTANCE, meters(1.855e8L))
      CONSTANT(MIMAS_SPEED, meters_per_second(1.432e4L))
      CONSTANT(MIMAS_INCLINE, degrees(1.574L))
      CONSTANT(MIMAS_PERIOD, seconds(8.19e4L))

      CONSTANT(HYPERION_MASS, kilograms(5.62e18L))
      CONSTANT(HYPERION_RADIUS, meters(1.35e5L))
      CONSTANT(HYPERION_DISTANCE, meters(1.4811e9L))
      CONSTANT(HYPERION_SPEED, meters_per_second(4.92e3L))
      CONSTANT(HYPERION_INCLINE, degrees(0.43L))
      CONSTANT(HYPERION_PERIOD, seconds(2.138e6L))
    
    CONSTANT(URANUS_MASS, kilograms(8.6810e25L))
    CONSTANT(URANUS_RADIUS, meters(2.5362e7L))
    CONSTANT(URANUS_DISTANCE, meters(2.87246e12L))
    CONSTANT(URANUS_SPEED, meters_per_second(6.81e3L))
    CONSTANT(URANUS_INCLINE, degrees(0.76989L))
    CONSTANT(URANUS_OFFSET, degrees(0.0L))
    CONSTANT(URANUS_AXIAL, degrees(97.769L))
    CONSTANT(URANUS_PERIOD, seconds(2.651e9L))

      CONSTANT(TITANIA_MASS, kilograms(3.527e21L))
      CONSTANT(TITANIA_RADIUS, meters(7.889e5L))
      CONSTANT(TITANIA_DISTANCE, meters(4.362e8L))
      CONSTANT(TITANIA_SPEED, meters_per_second(3.64e3L))
      CONSTANT(TITANIA_INCLINE, degrees(0.079L))
      CONSTANT(TITANIA_PERIOD, seconds(7.391e5L))

      CONSTANT(OBERON_MASS, kilograms(3.014e21L))
      CONSTANT(OBERON_RADIUS, meters(7.614e5L))
      CONSTANT(OBERON_DISTANCE, meters(5.835e8L))
      CONSTANT(OBERON_SPEED, meters_per_second(3.15e3L))
      CONSTANT(OBERON_INCLINE, degrees(0.068L))
      CONSTANT(OBERON_PERIOD, seconds(1.146e6L))

      CONSTANT(UMBRIEL_MASS, kilograms(1.172e21L))
      CONSTANT(UMBRIEL_RADIUS, meters(5.847e5L))
      CONSTANT(UMBRIEL_DISTANCE, meters(2.661e8L))
      CONSTANT(UMBRIEL_SPEED, meters_per_second(4.67e3L))
      CONSTANT(UMBRIEL_INCLINE, degrees(0.128L))
      CONSTANT(UMBRIEL_PERIOD, seconds(4.118e5L))

      CONSTANT(ARIEL_MASS, kilograms(1.353e21L))
      CONSTANT(ARIEL_RADIUS, meters(5.788e5L))
      CONSTANT(ARIEL_DISTANCE, meters(1.909e8L))
      CONSTANT(ARIEL_SPEED, meters_per_second(5.51e3L))
      CONSTANT(ARIEL_INCLINE, degrees(0.260L))
      CONSTANT(ARIEL_PERIOD, seconds(2.363e5L))

      CONSTANT(MIRANDA_MASS, kilograms(6.59e19L))
      CONSTANT(MIRANDA_RADIUS, meters(2.358e5L))
      CONSTANT(MIRANDA_DISTANCE, meters(1.299e8L))
      CONSTANT(MIRANDA_SPEED, meters_per_second(6.66e3L))
      CONSTANT(MIRANDA_INCLINE, degrees(4.338L))
      CONSTANT(MIRANDA_PERIOD, seconds(1.236e5L))

    CONSTANT(NEPTUNE_MASS, kilograms(1.024e26L))
    CONSTANT(NEPTUNE_RADIUS, meters(2.4622e7L))
    CONSTANT(NEPTUNE_DISTANCE, meters(4.495e12L))
    CONSTANT(NEPTUNE_SPEED, meters_per_second(5.43e3L))
    CONSTANT(NEPTUNE_INCLINE, degrees(1.77L))
    CONSTANT(NEPTUNE_OFFSET, degrees(0.0L))
    CONSTANT(NEPTUNE_AXIAL, degrees(28.32L))
    CONSTANT(NEPTUNE_PERIOD, seconds(5.50e9L))

      CONSTANT(TRITON_MASS, kilograms(2.14e22L))
      CONSTANT(TRITON_RADIUS, meters(1.3534e6L))
      CONSTANT(TRITON_DISTANCE, meters(3.547e8L))
      CONSTANT(TRITON_SPEED, meters_per_second(4.39e3L))
      CONSTANT(TRITON_INCLINE, degrees(156.8L))
      CONSTANT(TRITON_PERIOD, seconds(5.88e5L))

      CONSTANT(PROTEUS_MASS, kilograms(5.0e19L))
      CONSTANT(PROTEUS_RADIUS, meters(2.10e5L))
      CONSTANT(PROTEUS_DISTANCE, meters(1.176e8L))
      CONSTANT(PROTEUS_SPEED, meters_per_second(7.60e3L))
      CONSTANT(PROTEUS_INCLINE, degrees(0.1L))
      CONSTANT(PROTEUS_PERIOD, seconds(1.17e5L))

      CONSTANT(LARISSA_MASS, kilograms(4.9e18L))
      CONSTANT(LARISSA_RADIUS, meters(9.7e4L))
      CONSTANT(LARISSA_DISTANCE, meters(7.35e7L))
      CONSTANT(LARISSA_SPEED, meters_per_second(9.60e3L))
      CONSTANT(LARISSA_INCLINE, degrees(0.2L))
      CONSTANT(LARISSA_PERIOD, seconds(3.29e4L))

      CONSTANT(GALATEA_MASS, kilograms(2.12e18L))
      CONSTANT(GALATEA_RADIUS, meters(8.8e4L))
      CONSTANT(GALATEA_DISTANCE, meters(6.20e7L))
      CONSTANT(GALATEA_SPEED, meters_per_second(1.05e4L))
      CONSTANT(GALATEA_INCLINE, degrees(0.05L))
      CONSTANT(GALATEA_PERIOD, seconds(2.73e4L))

      CONSTANT(DESPINA_MASS, kilograms(2.1e18L))
      CONSTANT(DESPINA_RADIUS, meters(7.4e4L))
      CONSTANT(DESPINA_DISTANCE, meters(5.24e7L))
      CONSTANT(DESPINA_SPEED, meters_per_second(1.13e4L))
      CONSTANT(DESPINA_INCLINE, degrees(0.07L))
      CONSTANT(DESPINA_PERIOD, seconds(2.40e4L))

      CONSTANT(THALASSA_MASS, kilograms(3.5e17L))
      CONSTANT(THALASSA_RADIUS, meters(4.05e4L))
      CONSTANT(THALASSA_DISTANCE, meters(5.00e7L))
      CONSTANT(THALASSA_SPEED, meters_per_second(1.16e4L))
      CONSTANT(THALASSA_INCLINE, degrees(0.2L))
      CONSTANT(THALASSA_PERIOD, seconds(2.30e4L))

      CONSTANT(NAIAD_MASS, kilograms(1.9e17L))
      CONSTANT(NAIAD_RADIUS, meters(3.3e4L))
      CONSTANT(NAIAD_DISTANCE, meters(4.82e7L))
      CONSTANT(NAIAD_SPEED, meters_per_second(1.19e4L))
      CONSTANT(NAIAD_INCLINE, degrees(4.7L))
      CONSTANT(NAIAD_PERIOD, seconds(2.18e4L))

    // Kuiper Belt

    CONSTANT(PLUTO_MASS, kilograms(1.303e22L))
    CONSTANT(PLUTO_RADIUS, meters(1.1883e6L))
    CONSTANT(PLUTO_DISTANCE, meters(5.90638e12L))
    CONSTANT(PLUTO_SPEED, meters_per_second(4.67e3L))
    CONSTANT(PLUTO_INCLINE, degrees(17.16L))
    CONSTANT(PLUTO_OFFSET, degrees(0.0L))
    CONSTANT(PLUTO_AXIAL, degrees(122.53L))

      CONSTANT(CHARON_MASS, kilograms(1.586e21L))
      CONSTANT(CHARON_RADIUS, meters(6.06e5L))
      CONSTANT(CHARON_DISTANCE, meters(1.9571e7L))
      CONSTANT(CHARON_SPEED, meters_per_second(2.21e2L))
      CONSTANT(CHARON_INCLINE, degrees(0.0L))

      CONSTANT(STYX_MASS, kilograms(7.5e15L))
      CONSTANT(STYX_RADIUS, meters(1.0e4L))
      CONSTANT(STYX_DISTANCE, meters(4.22e7L))
      CONSTANT(STYX_SPEED, meters_per_second(1.60e2L))
      CONSTANT(STYX_INCLINE, degrees(0.8L))

      CONSTANT(NIX_MASS, kilograms(4.5e16L))
      CONSTANT(NIX_RADIUS, meters(2.5e4L))
      CONSTANT(NIX_DISTANCE, meters(4.87e7L))
      CONSTANT(NIX_SPEED, meters_per_second(1.47e2L))
      CONSTANT(NIX_INCLINE, degrees(0.2L))

      CONSTANT(KERBEROS_MASS, kilograms(1.0e16L))
      CONSTANT(KERBEROS_RADIUS, meters(1.2e4L))
      CONSTANT(KERBEROS_DISTANCE, meters(5.77e7L))
      CONSTANT(KERBEROS_SPEED, meters_per_second(1.35e2L))
      CONSTANT(KERBEROS_INCLINE, degrees(0.4L))

      CONSTANT(HYDRA_MASS, kilograms(4.8e16L))
      CONSTANT(HYDRA_RADIUS, meters(2.2e4L))
      CONSTANT(HYDRA_DISTANCE, meters(6.48e7L))
      CONSTANT(HYDRA_SPEED, meters_per_second(1.23e2L))
      CONSTANT(HYDRA_INCLINE, degrees(0.25L))

    CONSTANT(HAUMEA_MASS, kilograms(4.006e21L))
    CONSTANT(HAUMEA_RADIUS, meters(7.96e5L))
    CONSTANT(HAUMEA_DISTANCE, meters(6.425e12L))
    CONSTANT(HAUMEA_SPEED, meters_per_second(4.53e3L))
    CONSTANT(HAUMEA_INCLINE, degrees(28.19L))
    CONSTANT(HAUMEA_OFFSET, degrees(0.0L))
    CONSTANT(HAUMEA_AXIAL, degrees(126.0L))

      CONSTANT(HI_IAKA_MASS, kilograms(1.8e19L)) // +- 0.5e19 kg
      CONSTANT(HI_IAKA_RADIUS, meters(2.1e5L))
      CONSTANT(HI_IAKA_DISTANCE, meters(4.949e7L))
      CONSTANT(HI_IAKA_SPEED, meters_per_second(7.35e1))
      CONSTANT(HI_IAKA_INCLINE, degrees(1.0L)) // +- 1.0 degree

      CONSTANT(NAMAKA_MASS, kilograms(2.0e18L)) // +- 1.0e18 kg
      CONSTANT(NAMAKA_RADIUS, meters(8.5e4L))
      CONSTANT(NAMAKA_DISTANCE, meters(2.573e7L))
      CONSTANT(NAMAKA_SPEED, meters_per_second(1.04e2L))
      CONSTANT(NAMAKA_INCLINE, degrees(13.0L))

    CONSTANT(MAKEMAKE_MASS, kilograms(3.1e21L))
    CONSTANT(MAKEMAKE_RADIUS, meters(7.15e5L))
    CONSTANT(MAKEMAKE_DISTANCE, meters(6.882e12L))
    CONSTANT(MAKEMAKE_SPEED, meters_per_second(4.30e3L))
    CONSTANT(MAKEMAKE_INCLINE, degrees(29.0L))
    CONSTANT(MAKEMAKE_OFFSET, degrees(0.0L))
    CONSTANT(MAKEMAKE_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(MO_O_MASS, kilograms(1.0e18L)) // magnitude only
      CONSTANT(MO_O_RADIUS, meters(8.0e4L)) // +- 0.5e5 m
      CONSTANT(MO_O_DISTANCE, meters(2.100e7L))
      CONSTANT(MO_O_SPEED, meters_per_second(9.9e1L)) // derived
      CONSTANT(MO_O_INCLINE, degrees(0.0L)) // unknown
    
    CONSTANT(ERIS_MASS, kilograms(1.646e22L))
    CONSTANT(ERIS_RADIUS, meters(1.163e6L))
    CONSTANT(ERIS_DISTANCE, meters(1.015e13L))
    CONSTANT(ERIS_SPEED, meters_per_second(3.44e3L))
    CONSTANT(ERIS_INCLINE, degrees(44.04L))
    CONSTANT(ERIS_OFFSET, degrees(0.0L))
    CONSTANT(ERIS_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(DYSNOMIA_MASS, kilograms(4.0e19L)) // +- 1.0e19 kg
      CONSTANT(DYSNOMIA_RADIUS, meters(3.5e5L)) // +- 1.5e5 m
      CONSTANT(DYSNOMIA_DISTANCE, meters(3.737e7L))
      CONSTANT(DYSNOMIA_SPEED, meters_per_second(1.71e2L))
      CONSTANT(DYSNOMIA_INCLINE, degrees(0.0L)) // unknown

    // Comets

    CONSTANT(HALLEY_MASS, kilograms(2.2e14L))
    CONSTANT(HALLEY_RADIUS, meters(5.5e3L))
    CONSTANT(HALLEY_DISTANCE, meters(8.766e10L))
    CONSTANT(HALLEY_SPEED, meters_per_second(5.46e4L))
    CONSTANT(HALLEY_INCLINE, degrees(162.26L))
    CONSTANT(HALLEY_OFFSET, degrees(0.0L))
    CONSTANT(HALLEY_PERIOD, seconds(2.3769e9L))

    CONSTANT(ENCKE_MASS, kilograms(5.79e13L))
    CONSTANT(ENCKE_RADIUS, meters(2.4e3L))
    CONSTANT(ENCKE_DISTANCE, meters(4.98e10L))
    CONSTANT(ENCKE_SPEED, meters_per_second(5.50e4L))
    CONSTANT(ENCKE_INCLINE, degrees(11.8L))
    CONSTANT(ENCKE_OFFSET, degrees(0.0L))
    CONSTANT(ENCKE_PERIOD, seconds(1.041e8L))
  
  #undef CONSTANT
};
