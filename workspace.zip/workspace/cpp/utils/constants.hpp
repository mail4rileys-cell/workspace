#pragma once

#include <concepts>
// std::floating_point

// Config values: number, mass, distance, time
template<typename number_t, number_t MASS, number_t DISTANCE, number_t TIME>
requires std::floating_point<number_t>
struct Constants final {

  #define CONSTANT(NAME, NUMBER) \
    static constexpr number_t NAME = static_cast<number_t>(NUMBER);
  // end

  #define FROM(NAME, FACTOR) \
    inline static constexpr number_t NAME(const number_t number) noexcept { \
      return number * static_cast<number_t>(FACTOR); \
    }
  // end

  #define TO(NAME, FACTOR) \
    inline static constexpr number_t to_##NAME(const number_t number) noexcept { \
      return number / static_cast<number_t>(FACTOR); \
    }
  // end

  #define UNIT(NAME, FACTOR) \
    FROM(NAME, FACTOR) \
    TO(NAME, FACTOR)
  // end
  
  CONSTANT(PI, 3.14159265358979323846L)
  UNIT(degrees, PI / static_cast<number_t>(180.0L))

  UNIT(kilograms, MASS)
  UNIT(grams, MASS / 1000.0L)
  UNIT(solar_masses, MASS * 1.98847e30L)\
  UNIT(earth_masses, MASS * 5.9722e24L)

  UNIT(meters, DISTANCE)
  UNIT(kilometers, DISTANCE * 1000.0L)
  UNIT(astronomical_units, DISTANCE * 1.495978707e11L)

  UNIT(seconds, TIME)
  UNIT(minutes, TIME * 60.0L)
  UNIT(hours, TIME * 3600.0L)
  UNIT(days, TIME * 86400.0L)
  UNIT(years, TIME * 31557600.0L)

  UNIT(meters_per_second, DISTANCE / TIME)
  UNIT(kilometers_per_second, (DISTANCE * 1000.0L) / TIME)

  UNIT(meters_per_second_squared, DISTANCE / (TIME * TIME))
  
  UNIT(newtons, (MASS * DISTANCE) / (TIME * TIME))

  UNIT(joules, (MASS * DISTANCE * DISTANCE ) / (TIME * TIME))

  UNIT(watts, (MASS * DISTANCE * DISTANCE) / (TIME * TIME * TIME))
  UNIT(solar_luminosities, (MASS * DISTANCE * DISTANCE * 3.828e26L) / (TIME * TIME * TIME))

  #undef UNIT
  #undef FROM
  #undef TO

  CONSTANT(GRAVITATIONAL_CONSTANT, (static_cast<number_t>(6.67430e-11L) * DISTANCE * DISTANCE * DISTANCE) / (MASS * TIME * TIME))
  CONSTANT(LIGHTSPEED, meters_per_second(299792458.0L))

  CONSTANT(SOL_MASS, kilograms(1.98841e30L))
  CONSTANT(SOL_RADIUS, meters(6.957e8L))
  CONSTANT(SOL_LUMINOSITY, watts(3.828e26L))

    // Inner System

    CONSTANT(MERCURY_MASS, kilograms(3.3011e23L))
    CONSTANT(MERCURY_RADIUS, meters(2.4397e6L))
    CONSTANT(MERCURY_DISTANCE, meters(5.7909227e10L))
    CONSTANT(MERCURY_SPEED, meters_per_second(47360.0L))
    CONSTANT(MERCURY_INCLINE, degrees(7.005L))
    CONSTANT(MERCURY_OFFSET, degrees(0.0L))
    CONSTANT(MERCURY_AXIAL, degrees(0.034L))
    CONSTANT(MERCURY_PERIOD, seconds(7.6005e6L))

    CONSTANT(VENUS_MASS, kilograms(4.8675e24L))
    CONSTANT(VENUS_RADIUS, meters(6.0518e6L))
    CONSTANT(VENUS_DISTANCE, meters(1.0820949e11L))
    CONSTANT(VENUS_SPEED, meters_per_second(35020.0L))
    CONSTANT(VENUS_INCLINE, degrees(3.394L))
    CONSTANT(VENUS_OFFSET, degrees(0.0L))
    CONSTANT(VENUS_AXIAL, degrees(177.36L))
    CONSTANT(VENUS_PERIOD, seconds(1.9414e7L))

    CONSTANT(EARTH_MASS, kilograms(5.9722e24L))
    CONSTANT(EARTH_RADIUS, meters(6.3710e6L))
    CONSTANT(EARTH_DISTANCE, meters(1.495978707e11L))
    CONSTANT(EARTH_SPEED, meters_per_second(29782.7L))
    CONSTANT(EARTH_INCLINE, degrees(0.0L))
    CONSTANT(EARTH_OFFSET, degrees(0.0L))
    CONSTANT(EARTH_AXIAL, degrees(23.43928L))
    CONSTANT(EARTH_PERIOD, seconds(3.15581e7L))

      // Horizons
      CONSTANT(LUNA_MASS, kilograms(7.345789e22L))
      CONSTANT(LUNA_RADIUS, meters(1.738e6L))
      CONSTANT(LUNA_DISTANCE, meters(4.055036e8L))
      CONSTANT(LUNA_SPEED, meters_per_second(9.684493e2L))
      CONSTANT(LUNA_INCLINE, degrees(5.145L))
      CONSTANT(LUNA_PERIOD, seconds(2.3606e6L))

    CONSTANT(MARS_MASS, kilograms(6.4171e23L))
    CONSTANT(MARS_RADIUS, meters(3.3895e6L))
    CONSTANT(MARS_DISTANCE, meters(2.2793925e11L))
    CONSTANT(MARS_SPEED, meters_per_second(24077.0L))
    CONSTANT(MARS_INCLINE, degrees(1.850L))
    CONSTANT(MARS_OFFSET, degrees(0.0L))
    CONSTANT(MARS_AXIAL, degrees(25.19L))
    CONSTANT(MARS_PERIOD, seconds(5.93544e7L))

      // Horizons
      CONSTANT(PHOBOS_MASS, kilograms(1.0659e16L))
      CONSTANT(PHOBOS_RADIUS, meters(1.1266e4L))
      CONSTANT(PHOBOS_DISTANCE, meters(9.518796e6L))
      CONSTANT(PHOBOS_SPEED, meters_per_second(2.105670e3L))
      CONSTANT(PHOBOS_INCLINE, degrees(1.082L))
      CONSTANT(PHOBOS_PERIOD, seconds(2.758e4L))

      // Horizons
      CONSTANT(DEIMOS_MASS, kilograms(1.44135e15L))
      CONSTANT(DEIMOS_RADIUS, meters(6.2e3L))
      CONSTANT(DEIMOS_DISTANCE, meters(2.347094e7L))
      CONSTANT(DEIMOS_SPEED, meters_per_second(1.350538e3L))
      CONSTANT(DEIMOS_INCLINE, degrees(1.791L))
      CONSTANT(DEIMOS_PERIOD, seconds(1.096e5L))

    CONSTANT(EUREKA_MASS, kilograms(3.5e15L))
    CONSTANT(EUREKA_RADIUS, meters(6.40e2L))
    CONSTANT(EUREKA_DISTANCE, meters(2.282e11L))
    CONSTANT(EUREKA_SPEED, meters_per_second(2.41e4L))
    CONSTANT(EUREKA_INCLINE, degrees(20.2803507L))
    CONSTANT(EUREKA_OFFSET, degrees(-60.0L))
    CONSTANT(EUREKA_AXIAL, degrees(0.0L)) // unknown

        // The Asteriod Belt
    
    CONSTANT(CERES_MASS, kilograms(9.3839e20L))
    CONSTANT(CERES_RADIUS, meters(4.696e5L))
    CONSTANT(CERES_DISTANCE, meters(4.14111e11L))
    CONSTANT(CERES_SPEED, meters_per_second(1.79e4L))
    CONSTANT(CERES_INCLINE, degrees(10.6L))
    CONSTANT(CERES_OFFSET, degrees(0.0L))


    CONSTANT(VESTA_MASS, kilograms(2.59076e20L))
    CONSTANT(VESTA_RADIUS, meters(2.626e5L))
    CONSTANT(VESTA_DISTANCE, meters(3.536e11L))
    CONSTANT(VESTA_SPEED, meters_per_second(1.93e4L))
    CONSTANT(VESTA_INCLINE, degrees(7.14L))
    CONSTANT(VESTA_OFFSET, degrees(0.0L))

    CONSTANT(JUNO_MASS, kilograms(2.82e19L))
    CONSTANT(JUNO_RADIUS, meters(1.17e5L))
    CONSTANT(JUNO_DISTANCE, meters(3.99e11L))
    CONSTANT(JUNO_SPEED, meters_per_second(1.79e4L))
    CONSTANT(JUNO_INCLINE, degrees(12.99L))
    CONSTANT(JUNO_OFFSET, degrees(0.0L))

    CONSTANT(PALLAS_MASS, kilograms(2.14e20L))
    CONSTANT(PALLAS_RADIUS, meters(2.56e5L))
    CONSTANT(PALLAS_DISTANCE, meters(4.144e11L))
    CONSTANT(PALLAS_SPEED, meters_per_second(1.79e4L))
    CONSTANT(PALLAS_INCLINE, degrees(34.8L))
    CONSTANT(PALLAS_OFFSET, degrees(0.0L))

    // Outer System
    
    CONSTANT(JUPITER_MASS, kilograms(1.8982e27L))
    CONSTANT(JUPITER_RADIUS, meters(6.9911e7L))
    CONSTANT(JUPITER_DISTANCE, meters(7.78412027e11L))
    CONSTANT(JUPITER_SPEED, meters_per_second(1.3056e4L))
    CONSTANT(JUPITER_INCLINE, degrees(1.304L))
    CONSTANT(JUPITER_OFFSET, degrees(0.0L))
    CONSTANT(JUPITER_AXIAL, degrees(3.13L))
    CONSTANT(JUPITER_PERIOD, seconds(3.743556e8L))

      // Horizons
      CONSTANT(AMALTHEA_MASS, kilograms(2.466176e18L))
      CONSTANT(AMALTHEA_RADIUS, meters(8.35e4L))
      CONSTANT(AMALTHEA_DISTANCE, meters(1.831157e8L))
      CONSTANT(AMALTHEA_SPEED, meters_per_second(2.625654e4L))
      CONSTANT(AMALTHEA_INCLINE, degrees(0.376L))

      // Horizons
      CONSTANT(THEBE_MASS, kilograms(4.509836e+17L))
      CONSTANT(THEBE_RADIUS, meters(4.930000e+04L))
      CONSTANT(THEBE_DISTANCE, meters(2.253300e+08L))
      CONSTANT(THEBE_SPEED, meters_per_second(2.347096e+04L))
      CONSTANT(THEBE_INCLINE, degrees(1.1L))

      // Horizons
      CONSTANT(IO_MASS, kilograms(8.929649e+22L))
      CONSTANT(IO_RADIUS, meters(1.821490e+06L))
      CONSTANT(IO_DISTANCE, meters(4.239918e+08L))
      CONSTANT(IO_SPEED, meters_per_second(1.725661e+04L))
      CONSTANT(IO_INCLINE, degrees(0.0375L))
      CONSTANT(IO_PERIOD, seconds(1.52853e5L))

      // Horizons
      CONSTANT(EUROPA_MASS, kilograms(4.798574e+22L))
      CONSTANT(EUROPA_RADIUS, meters(1.560800e+06L))
      CONSTANT(EUROPA_DISTANCE, meters(6.775825e+08L))
      CONSTANT(EUROPA_SPEED, meters_per_second(1.361130e+04L))
      CONSTANT(EUROPA_INCLINE, degrees(0.462L))
      CONSTANT(EUROPA_PERIOD, seconds(3.06785e5L))

      // Horizons
      CONSTANT(GANYMEDE_MASS, kilograms(1.481479e+23L))
      CONSTANT(GANYMEDE_RADIUS, meters(2.631200e+06L))
      CONSTANT(GANYMEDE_DISTANCE, meters(1.071562e+09L))
      CONSTANT(GANYMEDE_SPEED, meters_per_second(1.085941e+04L))
      CONSTANT(GANYMEDE_INCLINE, degrees(0.207L))
      CONSTANT(GANYMEDE_PERIOD, seconds(6.18153e5L))

      // Horizons
      CONSTANT(CALLISTO_MASS, kilograms(1.075661e+23L))
      CONSTANT(CALLISTO_RADIUS, meters(2.410300e+06L))
      CONSTANT(CALLISTO_DISTANCE, meters(1.897010e+09L))
      CONSTANT(CALLISTO_SPEED, meters_per_second(8.143346e+03L))
      CONSTANT(CALLISTO_INCLINE, degrees(0.2L))
      CONSTANT(CALLISTO_PERIOD, seconds(1.44193e6L))

      // Horizons
      CONSTANT(LEDA_MASS, kilograms(1.093748e+16L))
      CONSTANT(LEDA_RADIUS, meters(5.000000e+03L))
      CONSTANT(LEDA_DISTANCE, meters(1.273591e+10L))
      CONSTANT(LEDA_SPEED, meters_per_second(2.911484e+03L))
      CONSTANT(LEDA_INCLINE, degrees(27.0L))

      // Horizons
      CONSTANT(LYSITHEA_MASS, kilograms(5.993138e+16L))
      CONSTANT(LYSITHEA_RADIUS, meters(1.200000e+04L))
      CONSTANT(LYSITHEA_DISTANCE, meters(1.297404e+10L))
      CONSTANT(LYSITHEA_SPEED, meters_per_second(2.953093e+03L))
      CONSTANT(LYSITHEA_INCLINE, degrees(29.0L))

      // Horizons
      CONSTANT(HIMALIA_MASS, kilograms(2.270680e+18L))
      CONSTANT(HIMALIA_RADIUS, meters(8.500000e+04L))
      CONSTANT(HIMALIA_DISTANCE, meters(1.325742e+10L))
      CONSTANT(HIMALIA_SPEED, meters_per_second(2.822264e+03L))
      CONSTANT(HIMALIA_INCLINE, degrees(30.18L))

      // Horizons
      CONSTANT(ELARA_MASS, kilograms(2.247427e+17L))
      CONSTANT(ELARA_RADIUS, meters(4.000000e+04L))
      CONSTANT(ELARA_DISTANCE, meters(1.416656e+10L))
      CONSTANT(ELARA_SPEED, meters_per_second(2.664484e+03L))
      CONSTANT(ELARA_INCLINE, degrees(28.0L))

      // Horizons
      CONSTANT(ANANKE_MASS, kilograms(2.996569e+16L))
      CONSTANT(ANANKE_RADIUS, meters(1.000000e+04L))
      CONSTANT(ANANKE_DISTANCE, meters(2.478280e+10L))
      CONSTANT(ANANKE_SPEED, meters_per_second(2.059994e+03L))
      CONSTANT(ANANKE_INCLINE, degrees(147.0L))

      // Horizons
      CONSTANT(CARME_MASS, kilograms(1.303507e+17L))
      CONSTANT(CARME_RADIUS, meters(1.500000e+04L))
      CONSTANT(CARME_DISTANCE, meters(2.727820e+10L))
      CONSTANT(CARME_SPEED, meters_per_second(1.925092e+03L))
      CONSTANT(CARME_INCLINE, degrees(163.0L))

      // Horizons
      CONSTANT(SINOPE_MASS, kilograms(7.641251e+16L))
      CONSTANT(SINOPE_RADIUS, meters(1.400000e+04L))
      CONSTANT(SINOPE_DISTANCE, meters(3.021750e+10L))
      CONSTANT(SINOPE_SPEED, meters_per_second(1.714586e+03L))
      CONSTANT(SINOPE_INCLINE, degrees(153.0L))

      // Horizons
      CONSTANT(PASIPHAE_MASS, kilograms(2.996569e+16L))
      CONSTANT(PASIPHAE_RADIUS, meters(1.800000e+04L))
      CONSTANT(PASIPHAE_DISTANCE, meters(3.238300e+10L))
      CONSTANT(PASIPHAE_SPEED, meters_per_second(1.562130e+03L))
      CONSTANT(PASIPHAE_INCLINE, degrees(148.0L))

    CONSTANT(HEKTOR_MASS, kilograms(2.18e18L))
    CONSTANT(HEKTOR_RADIUS, meters(1.25e5L))
    CONSTANT(HEKTOR_DISTANCE, meters(7.867e11))
    CONSTANT(HEKTOR_SPEED, meters_per_second(1.31e4L))
    CONSTANT(HEKTOR_INCLINE, degrees(18.166L))
    CONSTANT(HEKTOR_OFFSET, degrees(60.0L))
    CONSTANT(HEKTOR_AXIAL, degrees(99.0L))

      // derived from semi major axis and orbital period
      CONSTANT(SKAMANDRIOS_MASS, kilograms(8.9e14L))
      CONSTANT(SKAMANDRIOS_RADIUS, meters(6.0e3L))
      CONSTANT(SKAMANDRIOS_DISTANCE, meters(6.235e5L))
      CONSTANT(SKAMANDRIOS_SPEED, meters_per_second(15.29L))
      CONSTANT(SKAMANDRIOS_INCLINE, degrees(50.0L))

    CONSTANT(PATROCLUS_MASS, kilograms(1.35e18L))
    CONSTANT(PATROCLUS_RADIUS, meters(1.0e5L))
    CONSTANT(PATROCLUS_DISTANCE, meters(7.78e11L))
    CONSTANT(PATROCLUS_SPEED, meters_per_second(1.31e4L))
    CONSTANT(PATROCLUS_INCLINE, degrees(22.0L))
    CONSTANT(PATROCLUS_OFFSET, degrees(-60.0L))
    CONSTANT(PATROCLUS_AXIAL, degrees(0.0L)) // unknown

      // data is poor, this is mostly guesswork, but produces qualitatively correct behaviour
      CONSTANT(MENOETIUS_MASS, kilograms(1.0e18L))
      CONSTANT(MENOETIUS_RADIUS, meters(7.0e4L))
      CONSTANT(MENOETIUS_DISTANCE, meters_per_second(6.8e5L))
      CONSTANT(MENOETIUS_SPEED, meters_per_second(15.0L))
      CONSTANT(MENOETIUS_INCLINE, degrees(5.0L)) // approx

    CONSTANT(CHIRON_MASS, kilograms(4.80e18L))
    CONSTANT(CHIRON_RADIUS, meters(8.30e4L))
    CONSTANT(CHIRON_DISTANCE, meters(1.26021e12L))
    CONSTANT(CHIRON_SPEED, meters_per_second(1.20610e4L))
    CONSTANT(CHIRON_INCLINE, degrees(6.92L))
    CONSTANT(CHIRON_OFFSET, degrees(0.0L))

    CONSTANT(SATURN_MASS, kilograms(5.6834e26L))
    CONSTANT(SATURN_RADIUS, meters(5.8232e7L))
    CONSTANT(SATURN_DISTANCE, meters(1.43353e12L))
    CONSTANT(SATURN_SPEED, meters_per_second(9.68e3L))
    CONSTANT(SATURN_INCLINE, degrees(2.485L))
    CONSTANT(SATURN_OFFSET, degrees(0.0L))
    CONSTANT(SATURN_AXIAL, degrees(26.73L))
    CONSTANT(SATURN_PERIOD, seconds(2.928e9L))

      CONSTANT(MIMAS_MASS, kilograms(3.750939e+19L))
      CONSTANT(MIMAS_RADIUS, meters(1.988000e+05L))
      CONSTANT(MIMAS_DISTANCE, meters(1.891766e+08L))
      CONSTANT(MIMAS_SPEED, meters_per_second(1.403929e+04L))
      CONSTANT(MIMAS_INCLINE, degrees(1.572L))
      CONSTANT(MIMAS_PERIOD, seconds(8.19e4L))

      CONSTANT(ENCELADUS_MASS, kilograms(1.080e20L))
      CONSTANT(ENCELADUS_RADIUS, meters(2.521e5L))
      CONSTANT(ENCELADUS_DISTANCE, meters(2.379e8L))
      CONSTANT(ENCELADUS_SPEED, meters_per_second(1.263e4L))
      CONSTANT(ENCELADUS_INCLINE, degrees(0.009L))
      CONSTANT(ENCELADUS_PERIOD, seconds(1.184e5L))

      CONSTANT(TETHYS_MASS, kilograms(6.174e20L))
      CONSTANT(TETHYS_RADIUS, meters(5.311e5L))
      CONSTANT(TETHYS_DISTANCE, meters(2.946e8L))
      CONSTANT(TETHYS_SPEED, meters_per_second(1.135e4L))
      CONSTANT(TETHYS_INCLINE, degrees(1.091L))
      CONSTANT(TETHYS_PERIOD, seconds(1.888e5L))

      CONSTANT(DIONE_MASS, kilograms(1.095e21L))
      CONSTANT(DIONE_RADIUS, meters(5.614e5L))
      CONSTANT(DIONE_DISTANCE, meters(3.774e8L))
      CONSTANT(DIONE_SPEED, meters_per_second(1.003e4L))
      CONSTANT(DIONE_INCLINE, degrees(0.028L))
      CONSTANT(DIONE_PERIOD, seconds(2.737e5L))

      CONSTANT(RHEA_MASS, kilograms(2.3065e21L))
      CONSTANT(RHEA_RADIUS, meters(7.638e5L))
      CONSTANT(RHEA_DISTANCE, meters(5.27108e8L))
      CONSTANT(RHEA_SPEED, meters_per_second(8.48e3L))
      CONSTANT(RHEA_INCLINE, degrees(0.345L))
      CONSTANT(RHEA_PERIOD, seconds(3.908e5L))

      CONSTANT(TITAN_MASS, kilograms(1.3452e23L))
      CONSTANT(TITAN_RADIUS, meters(2.57473e6L))
      CONSTANT(TITAN_DISTANCE, meters(1.22187e9L))
      CONSTANT(TITAN_SPEED, meters_per_second(5.574e3L))
      CONSTANT(TITAN_INCLINE, degrees(0.348L))
      CONSTANT(TITAN_PERIOD, seconds(1.377e6L))

      CONSTANT(HYPERION_MASS, kilograms(5.62e18L))
      CONSTANT(HYPERION_RADIUS, meters(1.35e5L))
      CONSTANT(HYPERION_DISTANCE, meters(1.4811e9L))
      CONSTANT(HYPERION_SPEED, meters_per_second(4.92e3L))
      CONSTANT(HYPERION_INCLINE, degrees(0.43L))
      CONSTANT(HYPERION_PERIOD, seconds(2.138e6L))

      CONSTANT(IAPETUS_MASS, kilograms(1.805e21L))
      CONSTANT(IAPETUS_RADIUS, meters(7.349e5L))
      CONSTANT(IAPETUS_DISTANCE, meters(3.56082e9L))
      CONSTANT(IAPETUS_SPEED, meters_per_second(3.26e3L))
      CONSTANT(IAPETUS_INCLINE, degrees(8.298L))
      CONSTANT(IAPETUS_PERIOD, seconds(6.852e6L))

    CONSTANT(CHARIKLO_MASS, kilograms(6.30e18L))
    CONSTANT(CHARIKLO_RADIUS, meters(1.25e5L))
    CONSTANT(CHARIKLO_DISTANCE, meters(1.95563e12L))
    CONSTANT(CHARIKLO_SPEED, meters_per_second(8.90715e3L))
    CONSTANT(CHARIKLO_INCLINE, degrees(23.39L))
    CONSTANT(CHARIKLO_OFFSET, degrees(0.0L))
    
    CONSTANT(TYPHON_MASS, kilograms(8.12e17L))
    CONSTANT(TYPHON_RADIUS, meters(7.60e4L))
    CONSTANT(TYPHON_DISTANCE, meters(2.61e12L))
    CONSTANT(TYPHON_SPEED, meters_per_second(8.82e3L))
    CONSTANT(TYPHON_INCLINE, degrees(2.43L))
    CONSTANT(TYPHON_OFFSET, degrees(0.0L))
    CONSTANT(TYPHON_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(ECHIDNA_MASS, kilograms(1.37e17L))
      CONSTANT(ECHIDNA_RADIUS, meters(4.20e4L))
      CONSTANT(ECHIDNA_DISTANCE, meters(2.48e6))
      CONSTANT(ECHIDNA_SPEED, meters_per_second(3.48L))
      CONSTANT(ECHIDNA_INCLINE, degrees(25.0L))
    
    CONSTANT(URANUS_MASS, kilograms(8.6810e25L))
    CONSTANT(URANUS_RADIUS, meters(2.5362e7L))
    CONSTANT(URANUS_DISTANCE, meters(2.87246e12L))
    CONSTANT(URANUS_SPEED, meters_per_second(6.81e3L))
    CONSTANT(URANUS_INCLINE, degrees(0.76989L))
    CONSTANT(URANUS_OFFSET, degrees(0.0L))
    CONSTANT(URANUS_AXIAL, degrees(97.769L))
    CONSTANT(URANUS_PERIOD, seconds(2.651e9L))

      CONSTANT(CORDELIA_MASS, kilograms(6.08e16L))
      CONSTANT(CORDELIA_RADIUS, meters(2.01e4L))
      CONSTANT(CORDELIA_DISTANCE, meters(4.9752e7L))
      CONSTANT(CORDELIA_SPEED, meters_per_second(1.079e4L))
      CONSTANT(CORDELIA_INCLINE, degrees(0.08479L))

      CONSTANT(OPHELIA_MASS, kilograms(5.4e16L))
      CONSTANT(OPHELIA_RADIUS, meters(2.14e4L))
      CONSTANT(OPHELIA_DISTANCE, meters(5.430e7L))
      CONSTANT(OPHELIA_SPEED, meters_per_second(1.028e4L))
      CONSTANT(OPHELIA_INCLINE, degrees(0.10L))

      CONSTANT(BIANCA_MASS, kilograms(9.2e16L))
      CONSTANT(BIANCA_RADIUS, meters(2.57e4L))
      CONSTANT(BIANCA_DISTANCE, meters(5.917e7L))
      CONSTANT(BIANCA_SPEED, meters_per_second(9.896e3L))
      CONSTANT(BIANCA_INCLINE, degrees(0.19L))

      CONSTANT(CRESSIDA_MASS, kilograms(3.4e17L))
      CONSTANT(CRESSIDA_RADIUS, meters(3.98e4L))
      CONSTANT(CRESSIDA_DISTANCE, meters(6.177e7L))
      CONSTANT(CRESSIDA_SPEED, meters_per_second(9.685e3L))
      CONSTANT(CRESSIDA_INCLINE, degrees(0.04L))

      CONSTANT(DESDEMONA_MASS, kilograms(2.3e17L))
      CONSTANT(DESDEMONA_RADIUS, meters(3.20e4L))
      CONSTANT(DESDEMONA_DISTANCE, meters(6.266e7L))
      CONSTANT(DESDEMONA_SPEED, meters_per_second(9.616e3L))
      CONSTANT(DESDEMONA_INCLINE, degrees(0.11L))

      CONSTANT(JULIET_MASS, kilograms(5.6e17L))
      CONSTANT(JULIET_RADIUS, meters(4.68e4L))
      CONSTANT(JULIET_DISTANCE, meters(6.436e7L))
      CONSTANT(JULIET_SPEED, meters_per_second(9.488e3L))
      CONSTANT(JULIET_INCLINE, degrees(0.06L))

      CONSTANT(PORTIA_MASS, kilograms(1.167e18L))
      CONSTANT(PORTIA_RADIUS, meters(6.76e4L))
      CONSTANT(PORTIA_DISTANCE, meters(6.6097e7L))
      CONSTANT(PORTIA_SPEED, meters_per_second(9.36e3L))
      CONSTANT(PORTIA_INCLINE, degrees(0.05908L))

      CONSTANT(ROSALIND_MASS, kilograms(2.5e17L))
      CONSTANT(ROSALIND_RADIUS, meters(3.60e4L))
      CONSTANT(ROSALIND_DISTANCE, meters(6.993e7L))
      CONSTANT(ROSALIND_SPEED, meters_per_second(9.103e3L))
      CONSTANT(ROSALIND_INCLINE, degrees(0.28L))

      CONSTANT(CUPID_MASS, kilograms(3.8e15L))
      CONSTANT(CUPID_RADIUS, meters(9.0e3L))
      CONSTANT(CUPID_DISTANCE, meters(7.439e7L))
      CONSTANT(CUPID_SPEED, meters_per_second(8.825e3L))
      CONSTANT(CUPID_INCLINE, degrees(0.10L))

      CONSTANT(BELINDA_MASS, kilograms(4.0e17L))
      CONSTANT(BELINDA_RADIUS, meters(4.03e4L))
      CONSTANT(BELINDA_DISTANCE, meters(7.526e7L))
      CONSTANT(BELINDA_SPEED, meters_per_second(8.774e3L))
      CONSTANT(BELINDA_INCLINE, degrees(0.03L))

      CONSTANT(PERDITA_MASS, kilograms(1.3e16L))
      CONSTANT(PERDITA_RADIUS, meters(1.50e4L))
      CONSTANT(PERDITA_DISTANCE, meters(7.642e7L))
      CONSTANT(PERDITA_SPEED, meters_per_second(8.707e3L))
      CONSTANT(PERDITA_INCLINE, degrees(0.00L))

      CONSTANT(PUCK_MASS, kilograms(1.91e18L))
      CONSTANT(PUCK_RADIUS, meters(8.10e4L))
      CONSTANT(PUCK_DISTANCE, meters(8.6004e7L))
      CONSTANT(PUCK_SPEED, meters_per_second(8.21e3L))
      CONSTANT(PUCK_INCLINE, degrees(0.3192L))

      CONSTANT(MAB_MASS, kilograms(1.0e15L))
      CONSTANT(MAB_RADIUS, meters(1.20e4L))
      CONSTANT(MAB_DISTANCE, meters(9.774e7L))
      CONSTANT(MAB_SPEED, meters_per_second(7.699e3L))
      CONSTANT(MAB_INCLINE, degrees(0.13L))

      CONSTANT(MIRANDA_MASS, kilograms(6.59e19L))
      CONSTANT(MIRANDA_RADIUS, meters(2.358e5L))
      CONSTANT(MIRANDA_DISTANCE, meters(1.299e8L))
      CONSTANT(MIRANDA_SPEED, meters_per_second(6.66e3L))
      CONSTANT(MIRANDA_INCLINE, degrees(4.338L))
      CONSTANT(MIRANDA_PERIOD, seconds(1.236e5L))

      CONSTANT(ARIEL_MASS, kilograms(1.353e21L))
      CONSTANT(ARIEL_RADIUS, meters(5.788e5L))
      CONSTANT(ARIEL_DISTANCE, meters(1.909e8L))
      CONSTANT(ARIEL_SPEED, meters_per_second(5.51e3L))
      CONSTANT(ARIEL_INCLINE, degrees(0.260L))
      CONSTANT(ARIEL_PERIOD, seconds(2.363e5L))

      CONSTANT(UMBRIEL_MASS, kilograms(1.172e21L))
      CONSTANT(UMBRIEL_RADIUS, meters(5.847e5L))
      CONSTANT(UMBRIEL_DISTANCE, meters(2.661e8L))
      CONSTANT(UMBRIEL_SPEED, meters_per_second(4.67e3L))
      CONSTANT(UMBRIEL_INCLINE, degrees(0.128L))
      CONSTANT(UMBRIEL_PERIOD, seconds(4.118e5L))

      CONSTANT(TITANIA_MASS, kilograms(3.527e21L))
      CONSTANT(TITANIA_RADIUS, meters(7.889e5L))
      CONSTANT(TITANIA_DISTANCE, meters(4.362e8L))
      CONSTANT(TITANIA_SPEED, meters_per_second(3.64e3L))
      CONSTANT(TITANIA_INCLINE, degrees(0.079L))
      CONSTANT(TITANIA_PERIOD, seconds(7.391e5L))

      CONSTANT(OBERON_MASS, kilograms(3.014e21L))
      CONSTANT(OBERON_RADIUS, meters(7.614e5L))
      CONSTANT(OBERON_DISTANCE, meters(5.835e8L))
      CONSTANT(OBERON_SPEED, meters_per_second(3.15e3L))
      CONSTANT(OBERON_INCLINE, degrees(0.068L))
      CONSTANT(OBERON_PERIOD, seconds(1.146e6L))

      CONSTANT(FRANCISCO_MASS, kilograms(7.2e15))
      CONSTANT(FRANCISCO_RADIUS, meters(1.10e4L))
      CONSTANT(FRANCISCO_DISTANCE, meters(4.900e9L))
      CONSTANT(FRANCISCO_SPEED, meters_per_second(1.005e3L))
      CONSTANT(FRANCISCO_INCLINE, degrees(145.20L))

      CONSTANT(CALIBAN_MASS, kilograms(2.5e17L))
      CONSTANT(CALIBAN_RADIUS, meters(3.60e4L))
      CONSTANT(CALIBAN_DISTANCE, meters(8.379e9L))
      CONSTANT(CALIBAN_SPEED, meters_per_second(7.627e2L))
      CONSTANT(CALIBAN_INCLINE, degrees(140.90L))

      CONSTANT(STEPHANO_MASS, kilograms(2.2e16L))
      CONSTANT(STEPHANO_RADIUS, meters(1.60e4L))
      CONSTANT(STEPHANO_DISTANCE, meters(9.839e9L))
      CONSTANT(STEPHANO_SPEED, meters_per_second(6.737e2L))
      CONSTANT(STEPHANO_INCLINE, degrees(144.10L))

      CONSTANT(TRINCULO_MASS, kilograms(3.9e15L))
      CONSTANT(TRINCULO_RADIUS, meters(9.0e3L))
      CONSTANT(TRINCULO_DISTANCE, meters(1.037e10L))
      CONSTANT(TRINCULO_SPEED, meters_per_second(6.600e2L))
      CONSTANT(TRINCULO_INCLINE, degrees(167.00L))

      CONSTANT(SYCORAX_MASS, kilograms(2.5e18L))
      CONSTANT(SYCORAX_RADIUS, meters(7.5e4L))
      CONSTANT(SYCORAX_DISTANCE, meters(1.8535e10L))
      CONSTANT(SYCORAX_SPEED, meters_per_second(3.8637e2L))
      CONSTANT(SYCORAX_INCLINE, degrees(159.42L))

      CONSTANT(PROSPERO_MASS, kilograms(2.1e16L))
      CONSTANT(PROSPERO_RADIUS, meters(2.50e4L))
      CONSTANT(PROSPERO_DISTANCE, meters(2.349e10L))
      CONSTANT(PROSPERO_SPEED, meters_per_second(3.701e2L))
      CONSTANT(PROSPERO_INCLINE, degrees(152.00L))

      CONSTANT(MARGARET_MASS, kilograms(1.0e16L))
      CONSTANT(MARGARET_RADIUS, meters(1.00e4L))
      CONSTANT(MARGARET_DISTANCE, meters(2.382e10L))
      CONSTANT(MARGARET_SPEED, meters_per_second(2.872e2L))
      CONSTANT(MARGARET_INCLINE, degrees(56.60L))

      CONSTANT(SETEBOS_MASS, kilograms(2.1e16L))
      CONSTANT(SETEBOS_RADIUS, meters(2.40e4L))
      CONSTANT(SETEBOS_DISTANCE, meters(2.772e10L))
      CONSTANT(SETEBOS_SPEED, meters_per_second(2.922e2L))
      CONSTANT(SETEBOS_INCLINE, degrees(152.00L))

      CONSTANT(FERDINAND_MASS, kilograms(1.3e16L))
      CONSTANT(FERDINAND_RADIUS, meters(1.00e4L))
      CONSTANT(FERDINAND_DISTANCE, meters(2.860e10L))
      CONSTANT(FERDINAND_SPEED, meters_per_second(3.578e2L))
      CONSTANT(FERDINAND_INCLINE, degrees(169.80L))
      
    CONSTANT(NEPTUNE_MASS, kilograms(1.024e26L))
    CONSTANT(NEPTUNE_RADIUS, meters(2.4622e7L))
    CONSTANT(NEPTUNE_DISTANCE, meters(4.495e12L))
    CONSTANT(NEPTUNE_SPEED, meters_per_second(5.43e3L))
    CONSTANT(NEPTUNE_INCLINE, degrees(1.77L))
    CONSTANT(NEPTUNE_OFFSET, degrees(0.0L))
    CONSTANT(NEPTUNE_AXIAL, degrees(28.32L))
    CONSTANT(NEPTUNE_PERIOD, seconds(5.50e9L))

      CONSTANT(NAIAD_MASS, kilograms(1.9e17L))
      CONSTANT(NAIAD_RADIUS, meters(3.3e4L))
      CONSTANT(NAIAD_DISTANCE, meters(4.82e7L))
      CONSTANT(NAIAD_SPEED, meters_per_second(1.19e4L))
      CONSTANT(NAIAD_INCLINE, degrees(4.7L))
      CONSTANT(NAIAD_PERIOD, seconds(2.18e4L))

      CONSTANT(THALASSA_MASS, kilograms(3.5e17L))
      CONSTANT(THALASSA_RADIUS, meters(4.05e4L))
      CONSTANT(THALASSA_DISTANCE, meters(5.00e7L))
      CONSTANT(THALASSA_SPEED, meters_per_second(1.16e4L))
      CONSTANT(THALASSA_INCLINE, degrees(0.2L))
      CONSTANT(THALASSA_PERIOD, seconds(2.30e4L))

      CONSTANT(DESPINA_MASS, kilograms(2.1e18L))
      CONSTANT(DESPINA_RADIUS, meters(7.4e4L))
      CONSTANT(DESPINA_DISTANCE, meters(5.24e7L))
      CONSTANT(DESPINA_SPEED, meters_per_second(1.13e4L))
      CONSTANT(DESPINA_INCLINE, degrees(0.07L))
      CONSTANT(DESPINA_PERIOD, seconds(2.40e4L))

      CONSTANT(GALATEA_MASS, kilograms(2.12e18L))
      CONSTANT(GALATEA_RADIUS, meters(8.8e4L))
      CONSTANT(GALATEA_DISTANCE, meters(6.20e7L))
      CONSTANT(GALATEA_SPEED, meters_per_second(1.05e4L))
      CONSTANT(GALATEA_INCLINE, degrees(0.05L))
      CONSTANT(GALATEA_PERIOD, seconds(2.73e4L))

      CONSTANT(LARISSA_MASS, kilograms(4.9e18L))
      CONSTANT(LARISSA_RADIUS, meters(9.7e4L))
      CONSTANT(LARISSA_DISTANCE, meters(7.35e7L))
      CONSTANT(LARISSA_SPEED, meters_per_second(9.60e3L))
      CONSTANT(LARISSA_INCLINE, degrees(0.2L))
      CONSTANT(LARISSA_PERIOD, seconds(3.29e4L))

      CONSTANT(HIPPOCAMP_MASS, kilograms(2.4695e16L))
      CONSTANT(HIPPOCAMP_RADIUS, meters(1.7000e4L))
      CONSTANT(HIPPOCAMP_DISTANCE, meters(1.0537e8L))
      CONSTANT(HIPPOCAMP_SPEED, meters_per_second(8.0514e3L))
      CONSTANT(HIPPOCAMP_INCLINE, degrees(0.002L))

      CONSTANT(PROTEUS_MASS, kilograms(5.0e19L))
      CONSTANT(PROTEUS_RADIUS, meters(2.10e5L))
      CONSTANT(PROTEUS_DISTANCE, meters(1.176e8L))
      CONSTANT(PROTEUS_SPEED, meters_per_second(7.60e3L))
      CONSTANT(PROTEUS_INCLINE, degrees(0.1L))
      CONSTANT(PROTEUS_PERIOD, seconds(1.17e5L))

      CONSTANT(TRITON_MASS, kilograms(2.14e22L))
      CONSTANT(TRITON_RADIUS, meters(1.3534e6L))
      CONSTANT(TRITON_DISTANCE, meters(3.547e8L))
      CONSTANT(TRITON_SPEED, meters_per_second(4.39e3L))
      CONSTANT(TRITON_INCLINE, degrees(156.8L))
      CONSTANT(TRITON_PERIOD, seconds(5.88e5L))

      CONSTANT(NEREID_MASS, kilograms(2.6000e19L))
      CONSTANT(NEREID_RADIUS, meters(1.7000e5L))
      CONSTANT(NEREID_DISTANCE, meters(9.6523e9L))
      CONSTANT(NEREID_SPEED, meters_per_second(4.2021e2L))
      CONSTANT(NEREID_INCLINE, degrees(27.600L))

      CONSTANT(HALIMEDE_MASS, kilograms(1.6000e17L))
      CONSTANT(HALIMEDE_RADIUS, meters(3.1000e4L))
      CONSTANT(HALIMEDE_DISTANCE, meters(2.1006e10L))
      CONSTANT(HALIMEDE_SPEED, meters_per_second(4.8922e2L))
      CONSTANT(HALIMEDE_INCLINE, degrees(112.71L))

      CONSTANT(SAO_MASS, kilograms(6.6903e16L))
      CONSTANT(SAO_RADIUS, meters(2.2000e4L))
      CONSTANT(SAO_DISTANCE, meters(2.5262e10L))
      CONSTANT(SAO_SPEED, meters_per_second(4.8341e2L))
      CONSTANT(SAO_INCLINE, degrees(53.483L))

      CONSTANT(LAOMEDEIA_MASS, kilograms(5.8000e16L))
      CONSTANT(LAOMEDEIA_RADIUS, meters(2.1000e4L))
      CONSTANT(LAOMEDEIA_DISTANCE, meters(3.2985e10L))
      CONSTANT(LAOMEDEIA_SPEED, meters_per_second(3.5355e2L))
      CONSTANT(LAOMEDEIA_INCLINE, degrees(37.874L))

      CONSTANT(PSAMATHE_MASS, kilograms(4.9000e16L))
      CONSTANT(PSAMATHE_RADIUS, meters(1.9000e4L))
      CONSTANT(PSAMATHE_DISTANCE, meters(6.8254e10L))
      CONSTANT(PSAMATHE_SPEED, meters_per_second(2.3220e2L))
      CONSTANT(PSAMATHE_INCLINE, degrees(137.68L))

      CONSTANT(NESO_MASS, kilograms(1.6000e17L))
      CONSTANT(NESO_RADIUS, meters(3.0000e4L))
      CONSTANT(NESO_DISTANCE, meters(7.3647e10L))
      CONSTANT(NESO_SPEED, meters_per_second(2.1666e2L))
      CONSTANT(NESO_INCLINE, degrees(136.40L))

    // Kuiper Belt

    CONSTANT(ORCUS_MASS, kilograms(5.48e20L))
    CONSTANT(ORCUS_RADIUS, meters(4.59e5L))
    CONSTANT(ORCUS_DISTANCE, meters(5.86e12L))
    CONSTANT(ORCUS_SPEED, meters_per_second(4.68e3L))
    CONSTANT(ORCUS_INCLINE, degrees(20.59L))
    CONSTANT(ORCUS_OFFSET, degrees(0.0L))
    CONSTANT(ORCUS_AXIAL, degrees(10.3L))

      CONSTANT(VANTH_MASS, kilograms(8.70e19L))
      CONSTANT(VANTH_RADIUS, meters(2.22e5L))
      CONSTANT(VANTH_DISTANCE, meters(8.98e6L))
      CONSTANT(VANTH_SPEED, meters_per_second(6.85e1L))
      CONSTANT(VANTH_INCLINE, degrees(0.0L))

    CONSTANT(LEMPO_MASS, kilograms(6.68e18L))
    CONSTANT(LEMPO_RADIUS, meters(1.36e5L))
    CONSTANT(LEMPO_DISTANCE, meters(5.905e12L))
    CONSTANT(LEMPO_SPEED, meters_per_second(4.74e3L))
    CONSTANT(LEMPO_INCLINE, degrees(8.41L))
    CONSTANT(LEMPO_OFFSET, degrees(0.0L))
    CONSTANT(LEMPO_AXIAL, degrees(0.0L))

      CONSTANT(HIISI_MASS, kilograms(5.25e18L))
      CONSTANT(HIISI_RADIUS, meters(1.255e5L))
      CONSTANT(HIISI_DISTANCE, meters(8.67e5L))
      CONSTANT(HIISI_SPEED, meters_per_second(3.03e1L))
      CONSTANT(HIISI_INCLINE, degrees(0.0L))

      CONSTANT(PAHA_MASS, kilograms(8.20e17L))
      CONSTANT(PAHA_RADIUS, meters(6.6e4L))
      CONSTANT(PAHA_DISTANCE, meters(1.00e7L))
      CONSTANT(PAHA_SPEED, meters_per_second(7.86L))
      CONSTANT(PAHA_INCLINE, degrees(2.40e1L))
    
    CONSTANT(PLUTO_MASS, kilograms(1.303e22L))
    CONSTANT(PLUTO_RADIUS, meters(1.1883e6L))
    CONSTANT(PLUTO_DISTANCE, meters(5.90638e12L))
    CONSTANT(PLUTO_SPEED, meters_per_second(4.67e3L))
    CONSTANT(PLUTO_INCLINE, degrees(17.16L))
    CONSTANT(PLUTO_OFFSET, degrees(0.0L))
    CONSTANT(PLUTO_AXIAL, degrees(122.53L))

      CONSTANT(CHARON_MASS, kilograms(1.586e21L))
      CONSTANT(CHARON_RADIUS, meters(6.06e5L))
      CONSTANT(CHARON_DISTANCE, meters(1.9596e7L))
      CONSTANT(CHARON_SPEED, meters_per_second(2.2312e2L))
      CONSTANT(CHARON_INCLINE, degrees(0.0L))

      CONSTANT(STYX_MASS, kilograms(7.500e14L))
      CONSTANT(STYX_RADIUS, meters(5.0e3L))
      CONSTANT(STYX_DISTANCE, meters(4.4782e7L))
      CONSTANT(STYX_SPEED, meters_per_second(1.7544e2L))
      CONSTANT(STYX_INCLINE, degrees(8.090e-1L))

      CONSTANT(NIX_MASS, kilograms(2.700e15L))
      CONSTANT(NIX_RADIUS, meters(1.8500e4L))
      CONSTANT(NIX_DISTANCE, meters(5.0820e7L))
      CONSTANT(NIX_SPEED, meters_per_second(1.6575e2L))
      CONSTANT(NIX_INCLINE, degrees(1.330e-1L))

      CONSTANT(KERBEROS_MASS, kilograms(1.6500e15L))
      CONSTANT(KERBEROS_RADIUS, meters(6.0e3L))
      CONSTANT(KERBEROS_DISTANCE, meters(5.9909e7L))
      CONSTANT(KERBEROS_SPEED, meters_per_second(1.5414e2L))
      CONSTANT(KERBEROS_INCLINE, degrees(3.890e-1L))

      CONSTANT(HYDRA_MASS, kilograms(3.0e15L))
      CONSTANT(HYDRA_RADIUS, meters(2.54e4L))
      CONSTANT(HYDRA_DISTANCE, meters(6.6864e7L))
      CONSTANT(HYDRA_SPEED, meters_per_second(1.4697e2L))
      CONSTANT(HYDRA_INCLINE, degrees(2.420e-1L))

    CONSTANT(HAUMEA_MASS, kilograms(4.006e21L))
    CONSTANT(HAUMEA_RADIUS, meters(7.96e5L))
    CONSTANT(HAUMEA_DISTANCE, meters(6.425e12L))
    CONSTANT(HAUMEA_SPEED, meters_per_second(4.53e3L))
    CONSTANT(HAUMEA_INCLINE, degrees(28.19L))
    CONSTANT(HAUMEA_OFFSET, degrees(0.0L))
    CONSTANT(HAUMEA_AXIAL, degrees(126.0L))

      CONSTANT(HI_IAKA_MASS, kilograms(1.8e19L)) // +- 0.5e19 kg
      CONSTANT(HI_IAKA_RADIUS, meters(2.1e5L))
      CONSTANT(HI_IAKA_DISTANCE, meters(4.949e7L))
      CONSTANT(HI_IAKA_SPEED, meters_per_second(7.35e1))
      CONSTANT(HI_IAKA_INCLINE, degrees(1.0L)) // +- 1.0 degree

      CONSTANT(NAMAKA_MASS, kilograms(2.0e18L)) // +- 1.0e18 kg
      CONSTANT(NAMAKA_RADIUS, meters(8.5e4L))
      CONSTANT(NAMAKA_DISTANCE, meters(2.573e7L))
      CONSTANT(NAMAKA_SPEED, meters_per_second(1.04e2L))
      CONSTANT(NAMAKA_INCLINE, degrees(13.0L))

    CONSTANT(QUAOAR_MASS, kilograms(1.212e21L))
    CONSTANT(QUAOAR_RADIUS, meters(5.488e5L))
    CONSTANT(QUAOAR_DISTANCE, meters(6.537e12L))
    CONSTANT(QUAOAR_SPEED, meters_per_second(4.530e3L))
    CONSTANT(QUAOAR_INCLINE, degrees(7.9895L))
    CONSTANT(QUAOAR_OFFSET, degrees(0.0L))
    CONSTANT(QUAOAR_AXIAL, degrees(12.60L))

      CONSTANT(WEYWOT_MASS, kilograms(2.400e18L))
      CONSTANT(WEYWOT_RADIUS, meters(8.250e4L))
      CONSTANT(WEYWOT_DISTANCE, meters(1.3329e7L))
      CONSTANT(WEYWOT_SPEED, meters_per_second(7.800e1L))
      CONSTANT(WEYWOT_INCLINE, degrees(5.000L))

    CONSTANT(GONGGONG_MASS, kilograms(1.75e21L))
    CONSTANT(GONGGONG_RADIUS, meters(6.15e5L))
    CONSTANT(GONGGONG_DISTANCE, meters(6.65e12L))
    CONSTANT(GONGGONG_SPEED, meters_per_second(4.49e3L))
    CONSTANT(GONGGONG_INCLINE, degrees(30.7L))
    CONSTANT(GONGGONG_OFFSET, degrees(0.0L))
    CONSTANT(GONGGONG_AXIAL, degrees(83.0L)) // +- 20 degrees

      CONSTANT(XIANGLIU_MASS, kilograms(2.0e18L))
      CONSTANT(XIANGLIU_RADIUS, meters(4.0e4L))
      CONSTANT(XIANGLIU_DISTANCE, meters(3.0987e7L))
      CONSTANT(XIANGLIU_SPEED, meters_per_second(51.73L))
      CONSTANT(XIANGLIU_INCLINE, degrees(0.0L)) // += 20 degrees

    CONSTANT(MAKEMAKE_MASS, kilograms(3.1e21L))
    CONSTANT(MAKEMAKE_RADIUS, meters(7.15e5L))
    CONSTANT(MAKEMAKE_DISTANCE, meters(6.882e12L))
    CONSTANT(MAKEMAKE_SPEED, meters_per_second(4.30e3L))
    CONSTANT(MAKEMAKE_INCLINE, degrees(29.0L))
    CONSTANT(MAKEMAKE_OFFSET, degrees(0.0L))
    CONSTANT(MAKEMAKE_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(MO_O_MASS, kilograms(1.0e18L)) // magnitude only
      CONSTANT(MO_O_RADIUS, meters(8.0e4L)) // +- 0.5e5 m
      CONSTANT(MO_O_DISTANCE, meters(2.100e7L))
      CONSTANT(MO_O_SPEED, meters_per_second(9.9e1L)) // derived
      CONSTANT(MO_O_INCLINE, degrees(0.0L)) // unknown
    
    CONSTANT(ERIS_MASS, kilograms(1.646e22L))
    CONSTANT(ERIS_RADIUS, meters(1.163e6L))
    CONSTANT(ERIS_DISTANCE, meters(1.015e13L))
    CONSTANT(ERIS_SPEED, meters_per_second(3.44e3L))
    CONSTANT(ERIS_INCLINE, degrees(44.04L))
    CONSTANT(ERIS_OFFSET, degrees(0.0L))
    CONSTANT(ERIS_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(DYSNOMIA_MASS, kilograms(4.0e19L)) // +- 1.0e19 kg
      CONSTANT(DYSNOMIA_RADIUS, meters(3.5e5L)) // +- 1.5e5 m
      CONSTANT(DYSNOMIA_DISTANCE, meters(3.737e7L))
      CONSTANT(DYSNOMIA_SPEED, meters_per_second(1.71e2L))
      CONSTANT(DYSNOMIA_INCLINE, degrees(0.0L)) // unknown

    // Comets

    CONSTANT(HALLEY_MASS, kilograms(2.2e14L))
    CONSTANT(HALLEY_RADIUS, meters(5.5e3L))
    CONSTANT(HALLEY_DISTANCE, meters(8.766e10L))
    CONSTANT(HALLEY_SPEED, meters_per_second(5.46e4L))
    CONSTANT(HALLEY_INCLINE, degrees(162.26L))
    CONSTANT(HALLEY_OFFSET, degrees(0.0L))
    CONSTANT(HALLEY_PERIOD, seconds(2.3769e9L))

    CONSTANT(ENCKE_MASS, kilograms(5.79e13L))
    CONSTANT(ENCKE_RADIUS, meters(2.4e3L))
    CONSTANT(ENCKE_DISTANCE, meters(5.0556e10L))
    CONSTANT(ENCKE_SPEED, meters_per_second(6.95e4L))
    CONSTANT(ENCKE_INCLINE, degrees(11.77L))
    CONSTANT(ENCKE_OFFSET, degrees(0.0L))
    CONSTANT(ENCKE_PERIOD, seconds(1.043e8L))
  
  #undef CONSTANT
};
