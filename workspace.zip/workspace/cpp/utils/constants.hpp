#pragma once

#include <concepts>
// std::floating_point

template<typename number_t, number_t MASS, number_t DISTANCE, number_t TIME>
requires std::floating_point<number_t>
struct Constants final {

  #define CONSTANT(NAME, NUMBER) \
    static constexpr number_t NAME = static_cast<number_t>(NUMBER);
  // end

  #define FROM(NAME, FACTOR) \
    inline static constexpr number_t NAME(const number_t number) noexcept { \
      return number * static_cast<number_t>(FACTOR); \
    }
  // end

  #define TO(NAME, FACTOR) \
    inline static constexpr number_t to_##NAME(const number_t number) noexcept { \
      return number / static_cast<number_t>(FACTOR); \
    }
  // end

  #define UNIT(NAME, FACTOR) \
    FROM(NAME, FACTOR) \
    TO(NAME, FACTOR)
  // end
  
  CONSTANT(PI, 3.14159265358979323846L)
  UNIT(degrees, PI / static_cast<number_t>(180.0L))

  UNIT(kilograms, MASS)
  UNIT(grams, MASS / 1000.0L)
  UNIT(solar_masses, MASS * 1.98847e30L)\
  UNIT(earth_masses, MASS * 5.9722e24L)

  UNIT(meters, DISTANCE)
  UNIT(kilometers, DISTANCE * 1000.0L)
  UNIT(astronomical_units, DISTANCE * 1.495978707e11L)

  UNIT(seconds, TIME)
  UNIT(minutes, TIME * 60.0L)
  UNIT(hours, TIME * 3600.0L)
  UNIT(days, TIME * 86400.0L)
  UNIT(years, TIME * 31557600.0L)

  UNIT(meters_per_second, DISTANCE / TIME)
  UNIT(kilometers_per_second, (DISTANCE * 1000.0L) / TIME)

  UNIT(meters_per_second_squared, DISTANCE / (TIME * TIME))
  
  UNIT(newtons, (MASS * DISTANCE) / (TIME * TIME))

  UNIT(joules, (MASS * DISTANCE * DISTANCE ) / (TIME * TIME))

  UNIT(watts, (MASS * DISTANCE * DISTANCE) / (TIME * TIME * TIME))
  UNIT(solar_luminosities, (MASS * DISTANCE * DISTANCE * 3.828e26L) / (TIME * TIME * TIME))

  #undef UNIT
  #undef FROM
  #undef TO

  CONSTANT(GRAVITATIONAL_CONSTANT, (static_cast<number_t>(6.67430e-11L) * DISTANCE * DISTANCE * DISTANCE) / (MASS * TIME * TIME))
  CONSTANT(LIGHTSPEED, meters_per_second(299792458.0L))

  CONSTANT(SOL_MASS, kilograms(1.98841e30L))
  CONSTANT(SOL_RADIUS, meters(6.957e8L))
  CONSTANT(SOL_LUMINOSITY, watts(3.828e26L))

    // Inner System

    CONSTANT(MERCURY_MASS, kilograms(3.3011e23L))
    CONSTANT(MERCURY_RADIUS, meters(2.4397e6L))
    CONSTANT(MERCURY_DISTANCE, meters(5.7909227e10L))
    CONSTANT(MERCURY_SPEED, meters_per_second(47360.0L))
    CONSTANT(MERCURY_INCLINE, degrees(7.005L))
    CONSTANT(MERCURY_OFFSET, degrees(0.0L))
    CONSTANT(MERCURY_AXIAL, degrees(0.034L))
    CONSTANT(MERCURY_PERIOD, seconds(7.6005e6L))

    CONSTANT(VENUS_MASS, kilograms(4.8675e24L))
    CONSTANT(VENUS_RADIUS, meters(6.0518e6L))
    CONSTANT(VENUS_DISTANCE, meters(1.0820949e11L))
    CONSTANT(VENUS_SPEED, meters_per_second(35020.0L))
    CONSTANT(VENUS_INCLINE, degrees(3.394L))
    CONSTANT(VENUS_OFFSET, degrees(0.0L))
    CONSTANT(VENUS_AXIAL, degrees(177.36L))
    CONSTANT(VENUS_PERIOD, seconds(1.9414e7L))

    CONSTANT(EARTH_MASS, kilograms(5.9722e24L))
    CONSTANT(EARTH_RADIUS, meters(6.3710e6L))
    CONSTANT(EARTH_DISTANCE, meters(1.495978707e11L))
    CONSTANT(EARTH_SPEED, meters_per_second(29782.7L))
    CONSTANT(EARTH_INCLINE, degrees(0.0L))
    CONSTANT(EARTH_OFFSET, degrees(0.0L))
    CONSTANT(EARTH_AXIAL, degrees(23.43928L))
    CONSTANT(EARTH_PERIOD, seconds(3.15581e7L))

      // Horizons
      CONSTANT(LUNA_MASS, kilograms(7.345789e22L))
      CONSTANT(LUNA_RADIUS, meters(1.738e6L))
      CONSTANT(LUNA_DISTANCE, meters(4.055036e8L))
      CONSTANT(LUNA_SPEED, meters_per_second(9.684493e2L))
      CONSTANT(LUNA_INCLINE, degrees(5.145L))
      CONSTANT(LUNA_OFFSET, degrees(0.0L))
      CONSTANT(LUNA_PERIOD, seconds(2.3606e6L))

    CONSTANT(MARS_MASS, kilograms(6.4171e23L))
    CONSTANT(MARS_RADIUS, meters(3.3895e6L))
    CONSTANT(MARS_DISTANCE, meters(2.2793925e11L))
    CONSTANT(MARS_SPEED, meters_per_second(24077.0L))
    CONSTANT(MARS_INCLINE, degrees(1.850L))
    CONSTANT(MARS_OFFSET, degrees(0.0L))
    CONSTANT(MARS_AXIAL, degrees(25.19L))
    CONSTANT(MARS_PERIOD, seconds(5.93544e7L))

      // Horizons
      CONSTANT(PHOBOS_MASS, kilograms(1.0659e16L))
      CONSTANT(PHOBOS_RADIUS, meters(1.1266e4L))
      CONSTANT(PHOBOS_DISTANCE, meters(9.518796e6L))
      CONSTANT(PHOBOS_SPEED, meters_per_second(2.105670e3L))
      CONSTANT(PHOBOS_INCLINE, degrees(1.082L))
      CONSTANT(PHOBOS_OFFSET, degrees(0.0L))
      CONSTANT(PHOBOS_PERIOD, seconds(2.758e4L))

      // Horizons
      CONSTANT(DEIMOS_MASS, kilograms(1.44135e15L))
      CONSTANT(DEIMOS_RADIUS, meters(6.2e3L))
      CONSTANT(DEIMOS_DISTANCE, meters(2.347094e7L))
      CONSTANT(DEIMOS_SPEED, meters_per_second(1.350538e3L))
      CONSTANT(DEIMOS_INCLINE, degrees(1.791L))
      CONSTANT(DEIMOS_OFFSET, degrees(0.0L))
      CONSTANT(DEIMOS_PERIOD, seconds(1.096e5L))

    CONSTANT(EUREKA_MASS, kilograms(3.5e15L))
    CONSTANT(EUREKA_RADIUS, meters(6.40e2L))
    CONSTANT(EUREKA_DISTANCE, meters(2.282e11L))
    CONSTANT(EUREKA_SPEED, meters_per_second(2.41e4L))
    CONSTANT(EUREKA_INCLINE, degrees(20.2803507L))
    CONSTANT(EUREKA_OFFSET, degrees(-60.0L))
    CONSTANT(EUREKA_AXIAL, degrees(0.0L)) // unknown

    // The Asteriod Belt
    
    CONSTANT(VESTA_MASS, kilograms(2.59076e20L))
    CONSTANT(VESTA_RADIUS, meters(2.626e5L))
    CONSTANT(VESTA_DISTANCE, meters(3.536e11L))
    CONSTANT(VESTA_SPEED, meters_per_second(1.93e4L))
    CONSTANT(VESTA_INCLINE, degrees(7.14L))
    CONSTANT(VESTA_OFFSET, degrees(0.0L))

    CONSTANT(JUNO_MASS, kilograms(2.82e19L))
    CONSTANT(JUNO_RADIUS, meters(1.17e5L))
    CONSTANT(JUNO_DISTANCE, meters(3.99e11L))
    CONSTANT(JUNO_SPEED, meters_per_second(1.79e4L))
    CONSTANT(JUNO_INCLINE, degrees(12.99L))
    CONSTANT(JUNO_OFFSET, degrees(0.0L))

    CONSTANT(CERES_MASS, kilograms(9.3839e20L))
    CONSTANT(CERES_RADIUS, meters(4.696e5L))
    CONSTANT(CERES_DISTANCE, meters(4.14111e11L))
    CONSTANT(CERES_SPEED, meters_per_second(1.79e4L))
    CONSTANT(CERES_INCLINE, degrees(10.6L))
    CONSTANT(CERES_OFFSET, degrees(0.0L))

    CONSTANT(PALLAS_MASS, kilograms(2.14e20L))
    CONSTANT(PALLAS_RADIUS, meters(2.56e5L))
    CONSTANT(PALLAS_DISTANCE, meters(4.144e11L))
    CONSTANT(PALLAS_SPEED, meters_per_second(1.79e4L))
    CONSTANT(PALLAS_INCLINE, degrees(34.8L))
    CONSTANT(PALLAS_OFFSET, degrees(0.0L))

    CONSTANT(POTATO_MASS, kilograms(5.647034e+13L))
    CONSTANT(POTATO_RADIUS, meters(2.380000e+03L))
    CONSTANT(POTATO_DISTANCE, meters(5.039428e+11L))
    CONSTANT(POTATO_SPEED, meters_per_second(1.557334e+04L))
    CONSTANT(POTATO_INCLINE, degrees(10.02171768028564L))
    CONSTANT(POTATO_OFFSET, degrees(0.0L))

    // Outer System
    
    CONSTANT(JUPITER_MASS, kilograms(1.8982e27L))
    CONSTANT(JUPITER_RADIUS, meters(6.9911e7L))
    CONSTANT(JUPITER_DISTANCE, meters(7.78412027e11L))
    CONSTANT(JUPITER_SPEED, meters_per_second(1.3056e4L))
    CONSTANT(JUPITER_INCLINE, degrees(1.304L))
    CONSTANT(JUPITER_OFFSET, degrees(0.0L))
    CONSTANT(JUPITER_AXIAL, degrees(3.13L))
    CONSTANT(JUPITER_PERIOD, seconds(3.743556e8L))

      // Horizons
      CONSTANT(METIS_MASS, kilograms(3.745711e+16L))
      CONSTANT(METIS_RADIUS, meters(2.150000e+04L))
      CONSTANT(METIS_DISTANCE, meters(1.296734e+08L))
      CONSTANT(METIS_SPEED, meters_per_second(3.117050e+04L))
      CONSTANT(METIS_INCLINE, degrees(0.006L))
      CONSTANT(METIS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ADRASTEA_MASS, kilograms(1.498284e+15L))
      CONSTANT(ADRASTEA_RADIUS, meters(8.200000e+03L))
      CONSTANT(ADRASTEA_DISTANCE, meters(1.309100e+08L))
      CONSTANT(ADRASTEA_SPEED, meters_per_second(3.104471e+04L))
      CONSTANT(ADRASTEA_INCLINE, degrees(0.007L))
      CONSTANT(ADRASTEA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(AMALTHEA_MASS, kilograms(2.466176e18L))
      CONSTANT(AMALTHEA_RADIUS, meters(8.35e4L))
      CONSTANT(AMALTHEA_DISTANCE, meters(1.831157e8L))
      CONSTANT(AMALTHEA_SPEED, meters_per_second(2.625654e4L))
      CONSTANT(AMALTHEA_INCLINE, degrees(0.376L))
      CONSTANT(AMALTHEA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(THEBE_MASS, kilograms(4.509836e+17L))
      CONSTANT(THEBE_RADIUS, meters(4.930000e+04L))
      CONSTANT(THEBE_DISTANCE, meters(2.253300e+08L))
      CONSTANT(THEBE_SPEED, meters_per_second(2.347096e+04L))
      CONSTANT(THEBE_INCLINE, degrees(1.1L))
      CONSTANT(THEBE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(IO_MASS, kilograms(8.929649e+22L))
      CONSTANT(IO_RADIUS, meters(1.821490e+06L))
      CONSTANT(IO_DISTANCE, meters(4.239918e+08L))
      CONSTANT(IO_SPEED, meters_per_second(1.725661e+04L))
      CONSTANT(IO_INCLINE, degrees(0.0375L))
      CONSTANT(IO_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(EUROPA_MASS, kilograms(4.798574e+22L))
      CONSTANT(EUROPA_RADIUS, meters(1.560800e+06L))
      CONSTANT(EUROPA_DISTANCE, meters(6.775825e+08L))
      CONSTANT(EUROPA_SPEED, meters_per_second(1.361130e+04L))
      CONSTANT(EUROPA_INCLINE, degrees(0.462L))
      CONSTANT(EUROPA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(GANYMEDE_MASS, kilograms(1.481479e+23L))
      CONSTANT(GANYMEDE_RADIUS, meters(2.631200e+06L))
      CONSTANT(GANYMEDE_DISTANCE, meters(1.071562e+09L))
      CONSTANT(GANYMEDE_SPEED, meters_per_second(1.085941e+04L))
      CONSTANT(GANYMEDE_INCLINE, degrees(0.207L))
      CONSTANT(GANYMEDE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(CALLISTO_MASS, kilograms(1.075661e+23L))
      CONSTANT(CALLISTO_RADIUS, meters(2.410300e+06L))
      CONSTANT(CALLISTO_DISTANCE, meters(1.897010e+09L))
      CONSTANT(CALLISTO_SPEED, meters_per_second(8.143346e+03L))
      CONSTANT(CALLISTO_INCLINE, degrees(0.2L))
      CONSTANT(CALLISTO_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(THEMISTO_MASS, kilograms(2.696912e+14L))
      CONSTANT(THEMISTO_RADIUS, meters(4.000000e+03L))
      CONSTANT(THEMISTO_DISTANCE, meters(9.298029e+09L))
      CONSTANT(THEMISTO_SPEED, meters_per_second(3.182085e+03L))
      CONSTANT(THEMISTO_INCLINE, degrees(44.3L))
      CONSTANT(THEMISTO_OFFSET, degrees(0.0L))
      
      // Fact sheets
      CONSTANT(ERSA_MASS, kilograms(2.696912e+14L))
      CONSTANT(ERSA_RADIUS, meters(4.000000e+03L))
      CONSTANT(ERSA_DISTANCE, meters(1.273313e+10L))
      CONSTANT(ERSA_SPEED, meters_per_second(2.964654e+03L))
      CONSTANT(ERSA_INCLINE, degrees(29.0L))
      CONSTANT(ERSA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(LEDA_MASS, kilograms(1.093748e+16L))
      CONSTANT(LEDA_RADIUS, meters(5.000000e+03L))
      CONSTANT(LEDA_DISTANCE, meters(1.273591e+10L))
      CONSTANT(LEDA_SPEED, meters_per_second(2.911484e+03L))
      CONSTANT(LEDA_INCLINE, degrees(27.0L))
      CONSTANT(LEDA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(LYSITHEA_MASS, kilograms(5.993138e+16L))
      CONSTANT(LYSITHEA_RADIUS, meters(1.200000e+04L))
      CONSTANT(LYSITHEA_DISTANCE, meters(1.297404e+10L))
      CONSTANT(LYSITHEA_SPEED, meters_per_second(2.953093e+03L))
      CONSTANT(LYSITHEA_INCLINE, degrees(29.0L))
      CONSTANT(LYSITHEA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(HIMALIA_MASS, kilograms(2.270680e+18L))
      CONSTANT(HIMALIA_RADIUS, meters(8.500000e+04L))
      CONSTANT(HIMALIA_DISTANCE, meters(1.325742e+10L))
      CONSTANT(HIMALIA_SPEED, meters_per_second(2.822264e+03L))
      CONSTANT(HIMALIA_INCLINE, degrees(30.18L))
      CONSTANT(HIMALIA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PANDIA_MASS, kilograms(2.696912e+14L))
      CONSTANT(PANDIA_RADIUS, meters(4.000000e+03L))
      CONSTANT(PANDIA_DISTANCE, meters(1.352297e+10L))
      CONSTANT(PANDIA_SPEED, meters_per_second(2.775756e+03L))
      CONSTANT(PANDIA_INCLINE, degrees(28.9L))
      CONSTANT(PANDIA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ELARA_MASS, kilograms(2.247427e+17L))
      CONSTANT(ELARA_RADIUS, meters(4.000000e+04L))
      CONSTANT(ELARA_DISTANCE, meters(1.416656e+10L))
      CONSTANT(ELARA_SPEED, meters_per_second(2.664484e+03L))
      CONSTANT(ELARA_INCLINE, degrees(28.0L))
      CONSTANT(ELARA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(DIA_MASS, kilograms(2.696912e+14L))
      CONSTANT(DIA_RADIUS, meters(4.000000e+03L))
      CONSTANT(DIA_DISTANCE, meters(1.510173e+10L))
      CONSTANT(DIA_SPEED, meters_per_second(2.538577e+03L))
      CONSTANT(DIA_INCLINE, degrees(29.1L))
      CONSTANT(DIA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EUPORIE_MASS, kilograms(2.696912e+14L))
      CONSTANT(EUPORIE_RADIUS, meters(4.000000e+03L))
      CONSTANT(EUPORIE_DISTANCE, meters(2.211266e+10L))
      CONSTANT(EUPORIE_SPEED, meters_per_second(2.209429e+03L))
      CONSTANT(EUPORIE_INCLINE, degrees(145.5L))
      CONSTANT(EUPORIE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(VALETUDO_MASS, kilograms(2.696912e+14L))
      CONSTANT(VALETUDO_RADIUS, meters(4.000000e+03L))
      CONSTANT(VALETUDO_DISTANCE, meters(2.274585e+10L))
      CONSTANT(VALETUDO_SPEED, meters_per_second(2.088243e+03L))
      CONSTANT(VALETUDO_INCLINE, degrees(34.5L))
      CONSTANT(VALETUDO_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(CARPO_MASS, kilograms(2.696912e+14L))
      CONSTANT(CARPO_RADIUS, meters(4.000000e+03L))
      CONSTANT(CARPO_DISTANCE, meters(2.411089e+10L))
      CONSTANT(CARPO_SPEED, meters_per_second(1.753414e+03L))
      CONSTANT(CARPO_INCLINE, degrees(53.3L))
      CONSTANT(CARPO_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HELIKE_MASS, kilograms(2.696912e+14L))
      CONSTANT(HELIKE_RADIUS, meters(4.000000e+03L))
      CONSTANT(HELIKE_DISTANCE, meters(2.415267e+10L))
      CONSTANT(HELIKE_SPEED, meters_per_second(2.105207e+03L))
      CONSTANT(HELIKE_INCLINE, degrees(154.4L))
      CONSTANT(HELIKE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ANANKE_MASS, kilograms(2.996569e+16L))
      CONSTANT(ANANKE_RADIUS, meters(1.000000e+04L))
      CONSTANT(ANANKE_DISTANCE, meters(2.478280e+10L))
      CONSTANT(ANANKE_SPEED, meters_per_second(2.059994e+03L))
      CONSTANT(ANANKE_INCLINE, degrees(147.0L))
      CONSTANT(ANANKE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EUPHEME_MASS, kilograms(2.696912e+14L))
      CONSTANT(EUPHEME_RADIUS, meters(4.000000e+03L))
      CONSTANT(EUPHEME_DISTANCE, meters(2.562204e+10L))
      CONSTANT(EUPHEME_SPEED, meters_per_second(1.946057e+03L))
      CONSTANT(EUPHEME_INCLINE, degrees(147.9L))
      CONSTANT(EUPHEME_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HERMIPPE_MASS, kilograms(2.696912e+14L))
      CONSTANT(HERMIPPE_RADIUS, meters(4.000000e+03L))
      CONSTANT(HERMIPPE_DISTANCE, meters(2.574639e+10L))
      CONSTANT(HERMIPPE_SPEED, meters_per_second(1.959080e+03L))
      CONSTANT(HERMIPPE_INCLINE, degrees(150.2L))
      CONSTANT(HERMIPPE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(IOCASTE_MASS, kilograms(2.696912e+14L))
      CONSTANT(IOCASTE_RADIUS, meters(4.000000e+03L))
      CONSTANT(IOCASTE_DISTANCE, meters(2.575919e+10L))
      CONSTANT(IOCASTE_SPEED, meters_per_second(1.954805e+03L))
      CONSTANT(IOCASTE_INCLINE, degrees(148.7L))
      CONSTANT(IOCASTE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(THELXINOE_MASS, kilograms(2.696912e+14L))
      CONSTANT(THELXINOE_RADIUS, meters(4.000000e+03L))
      CONSTANT(THELXINOE_DISTANCE, meters(2.577496e+10L))
      CONSTANT(THELXINOE_SPEED, meters_per_second(1.946658e+03L))
      CONSTANT(THELXINOE_INCLINE, degrees(150.7L))
      CONSTANT(THELXINOE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(MNEME_MASS, kilograms(2.696912e+14L))
      CONSTANT(MNEME_RADIUS, meters(4.000000e+03L))
      CONSTANT(MNEME_DISTANCE, meters(2.581159e+10L))
      CONSTANT(MNEME_SPEED, meters_per_second(1.931357e+03L))
      CONSTANT(MNEME_INCLINE, degrees(147.8L))
      CONSTANT(MNEME_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HARPALYKE_MASS, kilograms(2.696912e+14L))
      CONSTANT(HARPALYKE_RADIUS, meters(4.000000e+03L))
      CONSTANT(HARPALYKE_DISTANCE, meters(2.587961e+10L))
      CONSTANT(HARPALYKE_SPEED, meters_per_second(1.930086e+03L))
      CONSTANT(HARPALYKE_INCLINE, degrees(147.8L))
      CONSTANT(HARPALYKE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EUANTHE_MASS, kilograms(2.696912e+14L))
      CONSTANT(EUANTHE_RADIUS, meters(4.000000e+03L))
      CONSTANT(EUANTHE_DISTANCE, meters(2.588286e+10L))
      CONSTANT(EUANTHE_SPEED, meters_per_second(1.924874e+03L))
      CONSTANT(EUANTHE_INCLINE, degrees(148.1L))
      CONSTANT(EUANTHE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(THYONE_MASS, kilograms(2.696912e+14L))
      CONSTANT(THYONE_RADIUS, meters(4.000000e+03L))
      CONSTANT(THYONE_DISTANCE, meters(2.590128e+10L))
      CONSTANT(THYONE_SPEED, meters_per_second(1.934259e+03L))
      CONSTANT(THYONE_INCLINE, degrees(147.6L))
      CONSTANT(THYONE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PRAXIDIKE_MASS, kilograms(2.696912e+14L))
      CONSTANT(PRAXIDIKE_RADIUS, meters(4.000000e+03L))
      CONSTANT(PRAXIDIKE_DISTANCE, meters(2.605922e+10L))
      CONSTANT(PRAXIDIKE_SPEED, meters_per_second(1.915803e+03L))
      CONSTANT(PRAXIDIKE_INCLINE, degrees(148.2L))
      CONSTANT(PRAXIDIKE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ORTHOSIE_MASS, kilograms(2.696912e+14L))
      CONSTANT(ORTHOSIE_RADIUS, meters(4.000000e+03L))
      CONSTANT(ORTHOSIE_DISTANCE, meters(2.704175e+10L))
      CONSTANT(ORTHOSIE_SPEED, meters_per_second(1.818660e+03L))
      CONSTANT(ORTHOSIE_INCLINE, degrees(144.2L))
      CONSTANT(ORTHOSIE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(CARME_MASS, kilograms(1.303507e+17L))
      CONSTANT(CARME_RADIUS, meters(1.500000e+04L))
      CONSTANT(CARME_DISTANCE, meters(2.727820e+10L))
      CONSTANT(CARME_SPEED, meters_per_second(1.925092e+03L))
      CONSTANT(CARME_INCLINE, degrees(163.0L))
      CONSTANT(CARME_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PHILOPHROSYNE_MASS, kilograms(2.696912e+14L))
      CONSTANT(PHILOPHROSYNE_RADIUS, meters(4.000000e+03L))
      CONSTANT(PHILOPHROSYNE_DISTANCE, meters(2.759484e+10L))
      CONSTANT(PHILOPHROSYNE_SPEED, meters_per_second(1.891046e+03L))
      CONSTANT(PHILOPHROSYNE_INCLINE, degrees(146.1L))
      CONSTANT(PHILOPHROSYNE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ISONOE_MASS, kilograms(2.696912e+14L))
      CONSTANT(ISONOE_RADIUS, meters(4.000000e+03L))
      CONSTANT(ISONOE_DISTANCE, meters(2.869740e+10L))
      CONSTANT(ISONOE_SPEED, meters_per_second(1.820590e+03L))
      CONSTANT(ISONOE_INCLINE, degrees(164.9L))
      CONSTANT(ISONOE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KALLICHORE_MASS, kilograms(2.696912e+14L))
      CONSTANT(KALLICHORE_RADIUS, meters(4.000000e+03L))
      CONSTANT(KALLICHORE_DISTANCE, meters(2.884043e+10L))
      CONSTANT(KALLICHORE_SPEED, meters_per_second(1.811135e+03L))
      CONSTANT(KALLICHORE_INCLINE, degrees(164.7L))
      CONSTANT(KALLICHORE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(CHALDENE_MASS, kilograms(2.696912e+14L))
      CONSTANT(CHALDENE_RADIUS, meters(4.000000e+03L))
      CONSTANT(CHALDENE_DISTANCE, meters(2.891006e+10L))
      CONSTANT(CHALDENE_SPEED, meters_per_second(1.799271e+03L))
      CONSTANT(CHALDENE_INCLINE, degrees(164.7L))
      CONSTANT(CHALDENE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(TAYGETE_MASS, kilograms(2.696912e+14L))
      CONSTANT(TAYGETE_RADIUS, meters(4.000000e+03L))
      CONSTANT(TAYGETE_DISTANCE, meters(2.904097e+10L))
      CONSTANT(TAYGETE_SPEED, meters_per_second(1.800078e+03L))
      CONSTANT(TAYGETE_INCLINE, degrees(164.7L))
      CONSTANT(TAYGETE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KALE_MASS, kilograms(2.696912e+14L))
      CONSTANT(KALE_RADIUS, meters(4.000000e+03L))
      CONSTANT(KALE_DISTANCE, meters(2.908632e+10L))
      CONSTANT(KALE_SPEED, meters_per_second(1.792579e+03L))
      CONSTANT(KALE_INCLINE, degrees(164.6L))
      CONSTANT(KALE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PASITHEE_MASS, kilograms(2.696912e+14L))
      CONSTANT(PASITHEE_RADIUS, meters(4.000000e+03L))
      CONSTANT(PASITHEE_DISTANCE, meters(2.909918e+10L))
      CONSTANT(PASITHEE_SPEED, meters_per_second(1.777543e+03L))
      CONSTANT(PASITHEE_INCLINE, degrees(164.5L))
      CONSTANT(PASITHEE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EIRENE_MASS, kilograms(2.696912e+14L))
      CONSTANT(EIRENE_RADIUS, meters(4.000000e+03L))
      CONSTANT(EIRENE_DISTANCE, meters(2.911379e+10L))
      CONSTANT(EIRENE_SPEED, meters_per_second(1.790489e+03L))
      CONSTANT(EIRENE_INCLINE, degrees(164.7L))
      CONSTANT(EIRENE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HERSE_MASS, kilograms(2.696912e+14L))
      CONSTANT(HERSE_RADIUS, meters(4.000000e+03L))
      CONSTANT(HERSE_DISTANCE, meters(2.911855e+10L))
      CONSTANT(HERSE_SPEED, meters_per_second(1.796428e+03L))
      CONSTANT(HERSE_INCLINE, degrees(164.4L))
      CONSTANT(HERSE_OFFSET, degrees(0.0L))
      
      // Fact sheets
      CONSTANT(ARCHE_MASS, kilograms(2.696912e+14L))
      CONSTANT(ARCHE_RADIUS, meters(4.000000e+03L))
      CONSTANT(ARCHE_DISTANCE, meters(2.916671e+10L))
      CONSTANT(ARCHE_SPEED, meters_per_second(1.788954e+03L))
      CONSTANT(ARCHE_INCLINE, degrees(164.5L))
      CONSTANT(ARCHE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ERINOME_MASS, kilograms(2.696912e+14L))
      CONSTANT(ERINOME_RADIUS, meters(4.000000e+03L))
      CONSTANT(ERINOME_DISTANCE, meters(2.929060e+10L))
      CONSTANT(ERINOME_SPEED, meters_per_second(1.774182e+03L))
      CONSTANT(ERINOME_INCLINE, degrees(164.3L))
      CONSTANT(ERINOME_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(AITNE_MASS, kilograms(2.696912e+14L))
      CONSTANT(AITNE_RADIUS, meters(4.000000e+03L))
      CONSTANT(AITNE_DISTANCE, meters(2.935462e+10L))
      CONSTANT(AITNE_SPEED, meters_per_second(1.771061e+03L))
      CONSTANT(AITNE_INCLINE, degrees(164.5L))
      CONSTANT(AITNE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KALYKE_MASS, kilograms(2.696912e+14L))
      CONSTANT(KALYKE_RADIUS, meters(4.000000e+03L))
      CONSTANT(KALYKE_DISTANCE, meters(2.937878e+10L))
      CONSTANT(KALYKE_SPEED, meters_per_second(1.784818e+03L))
      CONSTANT(KALYKE_INCLINE, degrees(164.7L))
      CONSTANT(KALYKE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EUKELADE_MASS, kilograms(2.696912e+14L))
      CONSTANT(EUKELADE_RADIUS, meters(4.000000e+03L))
      CONSTANT(EUKELADE_DISTANCE, meters(2.938150e+10L))
      CONSTANT(EUKELADE_SPEED, meters_per_second(1.769014e+03L))
      CONSTANT(EUKELADE_INCLINE, degrees(164.7L))
      CONSTANT(EUKELADE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EURYDOME_MASS, kilograms(2.696912e+14L))
      CONSTANT(EURYDOME_RADIUS, meters(4.000000e+03L))
      CONSTANT(EURYDOME_DISTANCE, meters(2.946522e+10L))
      CONSTANT(EURYDOME_SPEED, meters_per_second(1.750682e+03L))
      CONSTANT(EURYDOME_INCLINE, degrees(148.9L))
      CONSTANT(EURYDOME_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(SINOPE_MASS, kilograms(7.641251e+16L))
      CONSTANT(SINOPE_RADIUS, meters(1.400000e+04L))
      CONSTANT(SINOPE_DISTANCE, meters(3.021750e+10L))
      CONSTANT(SINOPE_SPEED, meters_per_second(1.714586e+03L))
      CONSTANT(SINOPE_INCLINE, degrees(153.0L))
      CONSTANT(SINOPE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SPONDE_MASS, kilograms(2.696912e+14L))
      CONSTANT(SPONDE_RADIUS, meters(4.000000e+03L))
      CONSTANT(SPONDE_DISTANCE, meters(3.114170e+10L))
      CONSTANT(SPONDE_SPEED, meters_per_second(1.659333e+03L))
      CONSTANT(SPONDE_INCLINE, degrees(149.4L))
      CONSTANT(SPONDE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(CALLIRRHOE_MASS, kilograms(8.989707e+14L))
      CONSTANT(CALLIRRHOE_RADIUS, meters(4.800000e+03L))
      CONSTANT(CALLIRRHOE_DISTANCE, meters(3.133260e+10L))
      CONSTANT(CALLIRRHOE_SPEED, meters_per_second(1.694552e+03L))
      CONSTANT(CALLIRRHOE_INCLINE, degrees(132.0L))
      CONSTANT(CALLIRRHOE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(AUTONOE_MASS, kilograms(2.696912e+14L))
      CONSTANT(AUTONOE_RADIUS, meters(4.000000e+03L))
      CONSTANT(AUTONOE_DISTANCE, meters(3.153918e+10L))
      CONSTANT(AUTONOE_SPEED, meters_per_second(1.645114e+03L))
      CONSTANT(AUTONOE_INCLINE, degrees(150.7L))
      CONSTANT(AUTONOE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HEGEMONE_MASS, kilograms(2.696912e+14L))
      CONSTANT(HEGEMONE_RADIUS, meters(4.000000e+03L))
      CONSTANT(HEGEMONE_DISTANCE, meters(3.167591e+10L))
      CONSTANT(HEGEMONE_SPEED, meters_per_second(1.603385e+03L))
      CONSTANT(HEGEMONE_INCLINE, degrees(152.5L))
      CONSTANT(HEGEMONE_OFFSET, degrees(0.0L))
 
      // Horizons
      CONSTANT(PASIPHAE_MASS, kilograms(1.723027e+17L))
      CONSTANT(PASIPHAE_RADIUS, meters(1.800000e+04L))
      CONSTANT(PASIPHAE_DISTANCE, meters(3.238300e+10L))
      CONSTANT(PASIPHAE_SPEED, meters_per_second(1.562130e+03L))
      CONSTANT(PASIPHAE_INCLINE, degrees(148.0L))
      CONSTANT(PASIPHAE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KORE_MASS, kilograms(2.696912e+14L))
      CONSTANT(KORE_RADIUS, meters(4.000000e+03L))
      CONSTANT(KORE_DISTANCE, meters(3.238402e+10L))
      CONSTANT(KORE_SPEED, meters_per_second(1.609076e+03L))
      CONSTANT(KORE_INCLINE, degrees(141.7L))
      CONSTANT(KORE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(MEGACLITE_MASS, kilograms(2.696912e+14L))
      CONSTANT(MEGACLITE_RADIUS, meters(4.000000e+03L))
      CONSTANT(MEGACLITE_DISTANCE, meters(3.359258e+10L))
      CONSTANT(MEGACLITE_SPEED, meters_per_second(1.477415e+03L))
      CONSTANT(MEGACLITE_INCLINE, degrees(149.9L))
      CONSTANT(MEGACLITE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(CYLLENE_MASS, kilograms(2.696912e+14L))
      CONSTANT(CYLLENE_RADIUS, meters(4.000000e+03L))
      CONSTANT(CYLLENE_DISTANCE, meters(3.360665e+10L))
      CONSTANT(CYLLENE_SPEED, meters_per_second(1.477169e+03L))
      CONSTANT(CYLLENE_INCLINE, degrees(146.8L))
      CONSTANT(CYLLENE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(AOEDE_MASS, kilograms(2.696912e+14L))
      CONSTANT(AOEDE_RADIUS, meters(4.000000e+03L))
      CONSTANT(AOEDE_DISTANCE, meters(3.416194e+10L))
      CONSTANT(AOEDE_SPEED, meters_per_second(1.444624e+03L))
      CONSTANT(AOEDE_INCLINE, degrees(155.7L))
      CONSTANT(AOEDE_OFFSET, degrees(0.0L))

    CONSTANT(HEKTOR_MASS, kilograms(2.18e18L))
    CONSTANT(HEKTOR_RADIUS, meters(1.25e5L))
    CONSTANT(HEKTOR_DISTANCE, meters(7.867e11))
    CONSTANT(HEKTOR_SPEED, meters_per_second(1.31e4L))
    CONSTANT(HEKTOR_INCLINE, degrees(18.166L))
    CONSTANT(HEKTOR_OFFSET, degrees(60.0L))
    CONSTANT(HEKTOR_AXIAL, degrees(99.0L))

      // derived from semi major axis and orbital period
      CONSTANT(SKAMANDRIOS_MASS, kilograms(8.9e14L))
      CONSTANT(SKAMANDRIOS_RADIUS, meters(6.0e3L))
      CONSTANT(SKAMANDRIOS_DISTANCE, meters(6.235e5L))
      CONSTANT(SKAMANDRIOS_SPEED, meters_per_second(15.29L))
      CONSTANT(SKAMANDRIOS_INCLINE, degrees(50.0L))
      CONSTANT(SKAMANDRIOS_OFFSET, degrees(0.0L))

    CONSTANT(PATROCLUS_MASS, kilograms(1.35e18L))
    CONSTANT(PATROCLUS_RADIUS, meters(1.0e5L))
    CONSTANT(PATROCLUS_DISTANCE, meters(7.78e11L))
    CONSTANT(PATROCLUS_SPEED, meters_per_second(1.31e4L))
    CONSTANT(PATROCLUS_INCLINE, degrees(22.0L))
    CONSTANT(PATROCLUS_OFFSET, degrees(-60.0L))
    CONSTANT(PATROCLUS_AXIAL, degrees(0.0L)) // unknown

      // data is poor, this is mostly guesswork, but produces qualitatively correct behaviour
      CONSTANT(MENOETIUS_MASS, kilograms(1.0e18L))
      CONSTANT(MENOETIUS_RADIUS, meters(7.0e4L))
      CONSTANT(MENOETIUS_DISTANCE, meters_per_second(6.8e5L))
      CONSTANT(MENOETIUS_SPEED, meters_per_second(15.0L))
      CONSTANT(MENOETIUS_INCLINE, degrees(5.0L)) // approx
      CONSTANT(MENOETIUS_OFFSET, degrees(0.0L))

    CONSTANT(CHIRON_MASS, kilograms(4.80e18L))
    CONSTANT(CHIRON_RADIUS, meters(8.30e4L))
    CONSTANT(CHIRON_DISTANCE, meters(1.26021e12L))
    CONSTANT(CHIRON_SPEED, meters_per_second(1.20610e4L))
    CONSTANT(CHIRON_INCLINE, degrees(6.92L))
    CONSTANT(CHIRON_OFFSET, degrees(0.0L))

    CONSTANT(SATURN_MASS, kilograms(5.6834e26L))
    CONSTANT(SATURN_RADIUS, meters(5.8232e7L))
    CONSTANT(SATURN_DISTANCE, meters(1.43353e12L))
    CONSTANT(SATURN_SPEED, meters_per_second(9.68e3L))
    CONSTANT(SATURN_INCLINE, degrees(2.485L))
    CONSTANT(SATURN_OFFSET, degrees(0.0L))
    CONSTANT(SATURN_AXIAL, degrees(26.73L))
    CONSTANT(SATURN_PERIOD, seconds(2.928e9L))

      // Horizons
      CONSTANT(PAN_MASS, kilograms(4.195197e+15L))
      CONSTANT(PAN_RADIUS, meters(1.433333e+04L))
      CONSTANT(PAN_DISTANCE, meters(1.335840e+08L))
      CONSTANT(PAN_SPEED, meters_per_second(1.689479e+04L))
      CONSTANT(PAN_INCLINE, degrees(0.0L))
      CONSTANT(PAN_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(DAPHNIS_MASS, kilograms(2.696912e+14L))
      CONSTANT(DAPHNIS_RADIUS, meters(3.966667e+03L))
      CONSTANT(DAPHNIS_DISTANCE, meters(1.365000e+08L))
      CONSTANT(DAPHNIS_SPEED, meters_per_second(1.670913e+04L))
      CONSTANT(DAPHNIS_INCLINE, degrees(0.0L))
      CONSTANT(DAPHNIS_OFFSET, degrees(0.0L))
      
      // Horizons
      CONSTANT(ATLAS_MASS, kilograms(5.543653e+15L))
      CONSTANT(ATLAS_RADIUS, meters(1.590000e+04L))
      CONSTANT(ATLAS_DISTANCE, meters(1.376400e+08L))
      CONSTANT(ATLAS_SPEED, meters_per_second(1.662978e+04L))
      CONSTANT(ATLAS_INCLINE, degrees(0.0L))
      CONSTANT(ATLAS_OFFSET, degrees(0.0L))
      
      // Horizons
      CONSTANT(PROMETHEUS_MASS, kilograms(1.604663e+17L))
      CONSTANT(PROMETHEUS_RADIUS, meters(4.600000e+04L))
      CONSTANT(PROMETHEUS_DISTANCE, meters(1.396844e+08L))
      CONSTANT(PROMETHEUS_SPEED, meters_per_second(1.649226e+04L))
      CONSTANT(PROMETHEUS_INCLINE, degrees(0.0L))
      CONSTANT(PROMETHEUS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(PANDORA_MASS, kilograms(1.387411e+17L))
      CONSTANT(PANDORA_RADIUS, meters(4.150000e+04L))
      CONSTANT(PANDORA_DISTANCE, meters(1.422951e+08L))
      CONSTANT(PANDORA_SPEED, meters_per_second(1.631912e+04L))
      CONSTANT(PANDORA_INCLINE, degrees(0.0L))
      CONSTANT(PANDORA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(JANUS_MASS, kilograms(1.897128e+18L))
      CONSTANT(JANUS_RADIUS, meters(8.920000e+04L))
      CONSTANT(JANUS_DISTANCE, meters(1.525323e+08L))
      CONSTANT(JANUS_SPEED, meters_per_second(1.574816e+04L))
      CONSTANT(JANUS_INCLINE, degrees(0.14L))
      CONSTANT(JANUS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(EPIMETHEUS_MASS, kilograms(5.264972e+17L))
      CONSTANT(EPIMETHEUS_RADIUS, meters(5.820000e+04L))
      CONSTANT(EPIMETHEUS_DISTANCE, meters(1.527848e+08L))
      CONSTANT(EPIMETHEUS_SPEED, meters_per_second(1.571151e+04L))
      CONSTANT(EPIMETHEUS_INCLINE, degrees(0.34L))
      CONSTANT(EPIMETHEUS_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(AEGAEON_MASS, kilograms(2.696912e+14L))
      CONSTANT(AEGAEON_RADIUS, meters(3.833333e+02L))
      CONSTANT(AEGAEON_DISTANCE, meters(1.675000e+08L))
      CONSTANT(AEGAEON_SPEED, meters_per_second(1.507328e+04L))
      CONSTANT(AEGAEON_INCLINE, degrees(0.0L))
      CONSTANT(AEGAEON_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(MIMAS_MASS, kilograms(3.750939e+19L))
      CONSTANT(MIMAS_RADIUS, meters(1.988000e+05L))
      CONSTANT(MIMAS_DISTANCE, meters(1.891766e+08L))
      CONSTANT(MIMAS_SPEED, meters_per_second(1.403929e+04L))
      CONSTANT(MIMAS_INCLINE, degrees(1.572L))
      CONSTANT(MIMAS_OFFSET, degrees(0.0L))
      
      // Fact sheets
      CONSTANT(METHONE_MASS, kilograms(2.696912e+14L))
      CONSTANT(METHONE_RADIUS, meters(1.480000e+03L))
      CONSTANT(METHONE_DISTANCE, meters(1.950894e+08L))
      CONSTANT(METHONE_SPEED, meters_per_second(1.399704e+04L))
      CONSTANT(METHONE_INCLINE, degrees(0.0L))
      CONSTANT(METHONE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ANTHE_MASS, kilograms(2.696912e+14L))
      CONSTANT(ANTHE_RADIUS, meters(5.000000e+02L))
      CONSTANT(ANTHE_DISTANCE, meters(1.984962e+08L))
      CONSTANT(ANTHE_SPEED, meters_per_second(1.383914e+04L))
      CONSTANT(ANTHE_INCLINE, degrees(0.0L))
      CONSTANT(ANTHE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PALLENE_MASS, kilograms(2.696912e+14L))
      CONSTANT(PALLENE_RADIUS, meters(2.253333e+03L))
      CONSTANT(PALLENE_DISTANCE, meters(2.131492e+08L))
      CONSTANT(PALLENE_SPEED, meters_per_second(1.330145e+04L))
      CONSTANT(PALLENE_INCLINE, degrees(0.2L))
      CONSTANT(PALLENE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ENCELADUS_MASS, kilograms(1.080318e+20L))
      CONSTANT(ENCELADUS_RADIUS, meters(2.523000e+05L))
      CONSTANT(ENCELADUS_DISTANCE, meters(2.391588e+08L))
      CONSTANT(ENCELADUS_SPEED, meters_per_second(1.257434e+04L))
      CONSTANT(ENCELADUS_INCLINE, degrees(0.009L))
      CONSTANT(ENCELADUS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(TETHYS_MASS, kilograms(6.174430e+20L))
      CONSTANT(TETHYS_RADIUS, meters(5.363000e+05L))
      CONSTANT(TETHYS_DISTANCE, meters(2.952950e+08L))
      CONSTANT(TETHYS_SPEED, meters_per_second(1.135265e+04L))
      CONSTANT(TETHYS_INCLINE, degrees(1.091L))
      CONSTANT(TETHYS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(TELESTO_MASS, kilograms(7.191765e+15L))
      CONSTANT(TELESTO_RADIUS, meters(1.263333e+04L))
      CONSTANT(TELESTO_DISTANCE, meters(2.952950e+08L))
      CONSTANT(TELESTO_SPEED, meters_per_second(1.135265e+04L))
      CONSTANT(TELESTO_INCLINE, degrees(1.2L))
      CONSTANT(TELESTO_OFFSET, degrees(60.0L))
      
      // Horizons
      CONSTANT(CALYPSO_MASS, kilograms(3.595883e+15L))
      CONSTANT(CALYPSO_RADIUS, meters(1.030000e+04L))
      CONSTANT(CALYPSO_DISTANCE, meters(2.952950e+08L))
      CONSTANT(CALYPSO_SPEED, meters_per_second(1.135265e+04L))
      CONSTANT(CALYPSO_INCLINE, degrees(1.5L))
      CONSTANT(CALYPSO_OFFSET, degrees(-60.0L))

      // Horizons
      CONSTANT(DIONE_MASS, kilograms(1.095486e+21L))
      CONSTANT(DIONE_RADIUS, meters(5.625000e+05L))
      CONSTANT(DIONE_DISTANCE, meters(3.782503e+08L))
      CONSTANT(DIONE_SPEED, meters_per_second(1.000632e+04L))
      CONSTANT(DIONE_INCLINE, degrees(0.028L))
      CONSTANT(DIONE_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(HELENE_MASS, kilograms(7.127939e+15L))
      CONSTANT(HELENE_RADIUS, meters(1.600000e+04L))
      CONSTANT(HELENE_DISTANCE, meters(3.782503e+08L))
      CONSTANT(HELENE_SPEED, meters_per_second(1.000632e+04L))
      CONSTANT(HELENE_INCLINE, degrees(0.213L))
      CONSTANT(HELENE_OFFSET, degrees(60.0L))

      // Fact sheets
      CONSTANT(POLYDEUCES_MASS, kilograms(2.696912e+14L))
      CONSTANT(POLYDEUCES_RADIUS, meters(1.233333e+03L))
      CONSTANT(POLYDEUCES_DISTANCE, meters(3.782503e+08L))
      CONSTANT(POLYDEUCES_SPEED, meters_per_second(1.000632e+04L))
      CONSTANT(POLYDEUCES_INCLINE, degrees(0.2L))
      CONSTANT(POLYDEUCES_OFFSET, degrees(-60.0L))

      // Horizons
      CONSTANT(RHEA_MASS, kilograms(2.306459e+21L))
      CONSTANT(RHEA_RADIUS, meters(7.645000e+05L))
      CONSTANT(RHEA_DISTANCE, meters(5.275971e+08L))
      CONSTANT(RHEA_SPEED, meters_per_second(8.475277e+03L))
      CONSTANT(RHEA_INCLINE, degrees(0.331L))
      CONSTANT(RHEA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(TITAN_MASS, kilograms(1.345181e+23L))
      CONSTANT(TITAN_RADIUS, meters(2.575500e+06L))
      CONSTANT(TITAN_DISTANCE, meters(1.257060e+09L))
      CONSTANT(TITAN_SPEED, meters_per_second(5.414321e+03L))
      CONSTANT(TITAN_INCLINE, degrees(0.28L))
      CONSTANT(TITAN_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(HYPERION_MASS, kilograms(5.551144e+18L))
      CONSTANT(HYPERION_RADIUS, meters(1.330000e+05L))
      CONSTANT(HYPERION_DISTANCE, meters(1.535755e+09L))
      CONSTANT(HYPERION_SPEED, meters_per_second(5.011623e+03L))
      CONSTANT(HYPERION_INCLINE, degrees(0.615L))
      CONSTANT(HYPERION_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(IAPETUS_MASS, kilograms(1.805732e+21L))
      CONSTANT(IAPETUS_RADIUS, meters(7.345000e+05L))
      CONSTANT(IAPETUS_DISTANCE, meters(3.661612e+09L))
      CONSTANT(IAPETUS_SPEED, meters_per_second(3.173126e+03L))
      CONSTANT(IAPETUS_INCLINE, degrees(15.47L))
      CONSTANT(IAPETUS_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KIVIUQ_MASS, kilograms(2.696912e+14L))
      CONSTANT(KIVIUQ_RADIUS, meters(4.000000e+03L))
      CONSTANT(KIVIUQ_DISTANCE, meters(1.441693e+10L))
      CONSTANT(KIVIUQ_SPEED, meters_per_second(1.381293e+03L))
      CONSTANT(KIVIUQ_INCLINE, degrees(48.9L))
      CONSTANT(KIVIUQ_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(IJIRAQ_MASS, kilograms(2.696912e+14L))
      CONSTANT(IJIRAQ_RADIUS, meters(4.000000e+03L))
      CONSTANT(IJIRAQ_DISTANCE, meters(1.466870e+10L))
      CONSTANT(IJIRAQ_SPEED, meters_per_second(1.352314e+03L))
      CONSTANT(IJIRAQ_INCLINE, degrees(31.0L))
      CONSTANT(IJIRAQ_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(PHOEBE_MASS, kilograms(8.312482e+18L))
      CONSTANT(PHOEBE_RADIUS, meters(1.066000e+05L))
      CONSTANT(PHOEBE_DISTANCE, meters(1.506474e+10L))
      CONSTANT(PHOEBE_SPEED, meters_per_second(1.450788e+03L))
      CONSTANT(PHOEBE_INCLINE, degrees(175.0L))
      CONSTANT(PHOEBE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SKATHI_MASS, kilograms(2.696912e+14L))
      CONSTANT(SKATHI_RADIUS, meters(4.000000e+03L))
      CONSTANT(SKATHI_DISTANCE, meters(1.995209e+10L))
      CONSTANT(SKATHI_SPEED, meters_per_second(1.169282e+03L))
      CONSTANT(SKATHI_INCLINE, degrees(150.5L))
      CONSTANT(SKATHI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(TARQEQ_MASS, kilograms(2.696912e+14L))
      CONSTANT(TARQEQ_RADIUS, meters(4.000000e+03L))
      CONSTANT(TARQEQ_DISTANCE, meters(2.030714e+10L))
      CONSTANT(TARQEQ_SPEED, meters_per_second(1.264810e+03L))
      CONSTANT(TARQEQ_INCLINE, degrees(49.77L))
      CONSTANT(TARQEQ_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PAALIAQ_MASS, kilograms(2.696912e+14L))
      CONSTANT(PAALIAQ_RADIUS, meters(4.000000e+03L))
      CONSTANT(PAALIAQ_DISTANCE, meters(2.066683e+10L))
      CONSTANT(PAALIAQ_SPEED, meters_per_second(1.068606e+03L))
      CONSTANT(PAALIAQ_INCLINE, degrees(46.0L))
      CONSTANT(PAALIAQ_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SUTTUNGR_MASS, kilograms(2.696912e+14L))
      CONSTANT(SUTTUNGR_RADIUS, meters(4.000000e+03L))
      CONSTANT(SUTTUNGR_DISTANCE, meters(2.164136e+10L))
      CONSTANT(SUTTUNGR_SPEED, meters_per_second(1.244842e+03L))
      CONSTANT(SUTTUNGR_INCLINE, degrees(151.0L))
      CONSTANT(SUTTUNGR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(BERGELMIR_MASS, kilograms(2.696912e+14L))
      CONSTANT(BERGELMIR_RADIUS, meters(4.000000e+03L))
      CONSTANT(BERGELMIR_DISTANCE, meters(2.206197e+10L))
      CONSTANT(BERGELMIR_SPEED, meters_per_second(1.212511e+03L))
      CONSTANT(BERGELMIR_INCLINE, degrees(134.0L))
      CONSTANT(BERGELMIR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(BELI_MASS, kilograms(2.696912e+14L))
      CONSTANT(BELI_RADIUS, meters(4.000000e+03L))
      CONSTANT(BELI_DISTANCE, meters(2.250492e+10L))
      CONSTANT(BELI_SPEED, meters_per_second(1.240581e+03L))
      CONSTANT(BELI_INCLINE, degrees(157.0L))
      CONSTANT(BELI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(MUNDILFARI_MASS, kilograms(2.696912e+14L))
      CONSTANT(MUNDILFARI_RADIUS, meters(4.000000e+03L))
      CONSTANT(MUNDILFARI_DISTANCE, meters(2.251031e+10L))
      CONSTANT(MUNDILFARI_SPEED, meters_per_second(1.153043e+03L))
      CONSTANT(MUNDILFARI_INCLINE, degrees(150.0L))
      CONSTANT(MUNDILFARI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(GRIDR_MASS, kilograms(2.696912e+14L))
      CONSTANT(GRIDR_RADIUS, meters(4.000000e+03L))
      CONSTANT(GRIDR_DISTANCE, meters(2.285046e+10L))
      CONSTANT(GRIDR_SPEED, meters_per_second(1.161691e+03L))
      CONSTANT(GRIDR_INCLINE, degrees(162.0L))
      CONSTANT(GRIDR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(EGGTHER_MASS, kilograms(2.696912e+14L))
      CONSTANT(EGGTHER_RADIUS, meters(4.000000e+03L))
      CONSTANT(EGGTHER_DISTANCE, meters(2.296020e+10L))
      CONSTANT(EGGTHER_SPEED, meters_per_second(1.180149e+03L))
      CONSTANT(EGGTHER_INCLINE, degrees(150.0L))
      CONSTANT(EGGTHER_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SIARNAQ_MASS, kilograms(2.696912e+14L))
      CONSTANT(SIARNAQ_RADIUS, meters(4.000000e+03L))
      CONSTANT(SIARNAQ_DISTANCE, meters(2.338848e+10L))
      CONSTANT(SIARNAQ_SPEED, meters_per_second(1.059531e+03L))
      CONSTANT(SIARNAQ_INCLINE, degrees(60.0L))
      CONSTANT(SIARNAQ_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(JARNSAXA_MASS, kilograms(2.696912e+14L))
      CONSTANT(JARNSAXA_RADIUS, meters(4.000000e+03L))
      CONSTANT(JARNSAXA_DISTANCE, meters(2.347512e+10L))
      CONSTANT(JARNSAXA_SPEED, meters_per_second(1.124050e+03L))
      CONSTANT(JARNSAXA_INCLINE, degrees(164.1L))
      CONSTANT(JARNSAXA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ALBIORIX_MASS, kilograms(2.696912e+14L))
      CONSTANT(ALBIORIX_RADIUS, meters(4.000000e+03L))
      CONSTANT(ALBIORIX_DISTANCE, meters(2.419987e+10L))
      CONSTANT(ALBIORIX_SPEED, meters_per_second(9.011462e+02L))
      CONSTANT(ALBIORIX_INCLINE, degrees(34.0L))
      CONSTANT(ALBIORIX_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(GREIP_MASS, kilograms(2.696912e+14L))
      CONSTANT(GREIP_RADIUS, meters(4.000000e+03L))
      CONSTANT(GREIP_DISTANCE, meters(2.420646e+10L))
      CONSTANT(GREIP_SPEED, meters_per_second(1.034526e+03L))
      CONSTANT(GREIP_INCLINE, degrees(159.2L))
      CONSTANT(GREIP_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HYRROKKIN_MASS, kilograms(2.696912e+14L))
      CONSTANT(HYRROKKIN_RADIUS, meters(4.000000e+03L))
      CONSTANT(HYRROKKIN_DISTANCE, meters(2.450344e+10L))
      CONSTANT(HYRROKKIN_SPEED, meters_per_second(1.013850e+03L))
      CONSTANT(HYRROKKIN_INCLINE, degrees(152.5L))
      CONSTANT(HYRROKKIN_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(BEBHIONN_MASS, kilograms(2.696912e+14L))
      CONSTANT(BEBHIONN_RADIUS, meters(4.000000e+03L))
      CONSTANT(BEBHIONN_DISTANCE, meters(2.484283e+10L))
      CONSTANT(BEBHIONN_SPEED, meters_per_second(9.088481e+02L))
      CONSTANT(BEBHIONN_INCLINE, degrees(35.0L))
      CONSTANT(BEBHIONN_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ANGRBODA_MASS, kilograms(2.696912e+14L))
      CONSTANT(ANGRBODA_RADIUS, meters(4.000000e+03L))
      CONSTANT(ANGRBODA_DISTANCE, meters(2.503926e+10L))
      CONSTANT(ANGRBODA_SPEED, meters_per_second(1.089913e+03L))
      CONSTANT(ANGRBODA_INCLINE, degrees(153.0L))
      CONSTANT(ANGRBODA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(FARBAUTI_MASS, kilograms(2.696912e+14L))
      CONSTANT(FARBAUTI_RADIUS, meters(4.000000e+03L))
      CONSTANT(FARBAUTI_DISTANCE, meters(2.534308e+10L))
      CONSTANT(FARBAUTI_SPEED, meters_per_second(1.060304e+03L))
      CONSTANT(FARBAUTI_INCLINE, degrees(131.0L))
      CONSTANT(FARBAUTI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(FENRIR_MASS, kilograms(2.696912e+14L))
      CONSTANT(FENRIR_RADIUS, meters(4.000000e+03L))
      CONSTANT(FENRIR_DISTANCE, meters(2.539012e+10L))
      CONSTANT(FENRIR_SPEED, meters_per_second(1.135546e+03L))
      CONSTANT(FENRIR_INCLINE, degrees(143.0L))
      CONSTANT(FENRIR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SKOLL_MASS, kilograms(2.696912e+14L))
      CONSTANT(SKOLL_RADIUS, meters(4.000000e+03L))
      CONSTANT(SKOLL_DISTANCE, meters(2.578303e+10L))
      CONSTANT(SKOLL_SPEED, meters_per_second(8.888353e+02L))
      CONSTANT(SKOLL_INCLINE, degrees(160.0L))
      CONSTANT(SKOLL_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ERRIAPUS_MASS, kilograms(2.696912e+14L))
      CONSTANT(ERRIAPUS_RADIUS, meters(4.000000e+03L))
      CONSTANT(ERRIAPUS_DISTANCE, meters(2.582268e+10L))
      CONSTANT(ERRIAPUS_SPEED, meters_per_second(8.781754e+02L))
      CONSTANT(ERRIAPUS_INCLINE, degrees(35.0L))
      CONSTANT(ERRIAPUS_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(AEGIR_MASS, kilograms(2.696912e+14L))
      CONSTANT(AEGIR_RADIUS, meters(4.000000e+03L))
      CONSTANT(AEGIR_DISTANCE, meters(2.593382e+10L))
      CONSTANT(AEGIR_SPEED, meters_per_second(1.043911e+03L))
      CONSTANT(AEGIR_INCLINE, degrees(140.0L))
      CONSTANT(AEGIR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(GUNNLOD_MASS, kilograms(2.696912e+14L))
      CONSTANT(GUNNLOD_RADIUS, meters(4.000000e+03L))
      CONSTANT(GUNNLOD_DISTANCE, meters(2.644839e+10L))
      CONSTANT(GUNNLOD_SPEED, meters_per_second(1.036522e+03L))
      CONSTANT(GUNNLOD_INCLINE, degrees(158.75L))
      CONSTANT(GUNNLOD_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(HATI_MASS, kilograms(2.696912e+14L))
      CONSTANT(HATI_RADIUS, meters(4.000000e+03L))
      CONSTANT(HATI_DISTANCE, meters(2.702154e+10L))
      CONSTANT(HATI_SPEED, meters_per_second(9.389344e+02L))
      CONSTANT(HATI_INCLINE, degrees(165.0L))
      CONSTANT(HATI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(NARVI_MASS, kilograms(2.696912e+14L))
      CONSTANT(NARVI_RADIUS, meters(4.000000e+03L))
      CONSTANT(NARVI_DISTANCE, meters(2.721114e+10L))
      CONSTANT(NARVI_SPEED, meters_per_second(9.061607e+02L))
      CONSTANT(NARVI_INCLINE, degrees(109.0L))
      CONSTANT(NARVI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(ALVALDI_MASS, kilograms(2.696912e+14L))
      CONSTANT(ALVALDI_RADIUS, meters(4.000000e+03L))
      CONSTANT(ALVALDI_DISTANCE, meters(2.722832e+10L))
      CONSTANT(ALVALDI_SPEED, meters_per_second(1.030401e+03L))
      CONSTANT(ALVALDI_INCLINE, degrees(153.0L))
      CONSTANT(ALVALDI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(LOGE_MASS, kilograms(2.696912e+14L))
      CONSTANT(LOGE_RADIUS, meters(4.000000e+03L))
      CONSTANT(LOGE_DISTANCE, meters(2.729677e+10L))
      CONSTANT(LOGE_SPEED, meters_per_second(1.060324e+03L))
      CONSTANT(LOGE_INCLINE, degrees(165.5L))
      CONSTANT(LOGE_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(TARVOS_MASS, kilograms(2.696912e+14L))
      CONSTANT(TARVOS_RADIUS, meters(4.000000e+03L))
      CONSTANT(TARVOS_DISTANCE, meters(2.772567e+10L))
      CONSTANT(TARVOS_SPEED, meters_per_second(8.087326e+02L))
      CONSTANT(TARVOS_INCLINE, degrees(39.0L))
      CONSTANT(TARVOS_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(THRYMR_MASS, kilograms(2.696912e+14L))
      CONSTANT(THRYMR_RADIUS, meters(4.000000e+03L))
      CONSTANT(THRYMR_DISTANCE, meters(2.982484e+10L))
      CONSTANT(THRYMR_SPEED, meters_per_second(8.234619e+02L))
      CONSTANT(THRYMR_INCLINE, degrees(151.0L))
      CONSTANT(THRYMR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(BESTLA_MASS, kilograms(2.696912e+14L))
      CONSTANT(BESTLA_RADIUS, meters(4.000000e+03L))
      CONSTANT(BESTLA_DISTANCE, meters(3.022197e+10L))
      CONSTANT(BESTLA_SPEED, meters_per_second(8.032229e+02L))
      CONSTANT(BESTLA_INCLINE, degrees(142.0L))
      CONSTANT(BESTLA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(FORNJOT_MASS, kilograms(2.696912e+14L))
      CONSTANT(FORNJOT_RADIUS, meters(4.000000e+03L))
      CONSTANT(FORNJOT_DISTANCE, meters(3.024834e+10L))
      CONSTANT(FORNJOT_SPEED, meters_per_second(9.934353e+02L))
      CONSTANT(FORNJOT_INCLINE, degrees(165.0L))
      CONSTANT(FORNJOT_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(YMIR_MASS, kilograms(2.696912e+14L))
      CONSTANT(YMIR_RADIUS, meters(4.000000e+03L))
      CONSTANT(YMIR_DISTANCE, meters(3.071459e+10L))
      CONSTANT(YMIR_SPEED, meters_per_second(9.041759e+02L))
      CONSTANT(YMIR_INCLINE, degrees(154.0L))
      CONSTANT(YMIR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SKRYMIR_MASS, kilograms(2.696912e+14L))
      CONSTANT(SKRYMIR_RADIUS, meters(4.000000e+03L))
      CONSTANT(SKRYMIR_DISTANCE, meters(3.081991e+10L))
      CONSTANT(SKRYMIR_SPEED, meters_per_second(8.324760e+02L))
      CONSTANT(SKRYMIR_INCLINE, degrees(153.0L))
      CONSTANT(SKRYMIR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(GERD_MASS, kilograms(2.696912e+14L))
      CONSTANT(GERD_RADIUS, meters(4.000000e+03L))
      CONSTANT(GERD_DISTANCE, meters(3.177736e+10L))
      CONSTANT(GERD_SPEED, meters_per_second(7.593966e+02L))
      CONSTANT(GERD_INCLINE, degrees(173.0L))
      CONSTANT(GERD_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(KARI_MASS, kilograms(2.696912e+14L))
      CONSTANT(KARI_RADIUS, meters(4.000000e+03L))
      CONSTANT(KARI_DISTANCE, meters(3.236515e+10L))
      CONSTANT(KARI_SPEED, meters_per_second(7.889534e+02L))
      CONSTANT(KARI_INCLINE, degrees(153.5L))
      CONSTANT(KARI_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(SURTUR_MASS, kilograms(2.696912e+14L))
      CONSTANT(SURTUR_RADIUS, meters(4.000000e+03L))
      CONSTANT(SURTUR_DISTANCE, meters(3.293910e+10L))
      CONSTANT(SURTUR_SPEED, meters_per_second(7.972566e+02L))
      CONSTANT(SURTUR_INCLINE, degrees(149.0L))
      CONSTANT(SURTUR_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(GEIRROD_MASS, kilograms(2.696912e+14L))
      CONSTANT(GEIRROD_RADIUS, meters(4.000000e+03L))
      CONSTANT(GEIRROD_DISTANCE, meters(3.425722e+10L))
      CONSTANT(GEIRROD_SPEED, meters_per_second(7.144515e+02L))
      CONSTANT(GEIRROD_INCLINE, degrees(154.7L))
      CONSTANT(GEIRROD_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(THIAZZI_MASS, kilograms(2.696912e+14L))
      CONSTANT(THIAZZI_RADIUS, meters(4.000000e+03L))
      CONSTANT(THIAZZI_DISTANCE, meters(3.562560e+10L))
      CONSTANT(THIAZZI_SPEED, meters_per_second(7.215449e+02L))
      CONSTANT(THIAZZI_INCLINE, degrees(153.5L))
      CONSTANT(THIAZZI_OFFSET, degrees(0.0L))
    
    CONSTANT(CHARIKLO_MASS, kilograms(6.30e18L))
    CONSTANT(CHARIKLO_RADIUS, meters(1.25e5L))
    CONSTANT(CHARIKLO_DISTANCE, meters(1.95563e12L))
    CONSTANT(CHARIKLO_SPEED, meters_per_second(8.90715e3L))
    CONSTANT(CHARIKLO_INCLINE, degrees(23.39L))
    CONSTANT(CHARIKLO_OFFSET, degrees(0.0L))
    
    CONSTANT(TYPHON_MASS, kilograms(8.12e17L))
    CONSTANT(TYPHON_RADIUS, meters(7.60e4L))
    CONSTANT(TYPHON_DISTANCE, meters(2.61e12L))
    CONSTANT(TYPHON_SPEED, meters_per_second(8.82e3L))
    CONSTANT(TYPHON_INCLINE, degrees(2.43L))
    CONSTANT(TYPHON_OFFSET, degrees(0.0L))
    CONSTANT(TYPHON_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(ECHIDNA_MASS, kilograms(1.37e17L))
      CONSTANT(ECHIDNA_RADIUS, meters(4.20e4L))
      CONSTANT(ECHIDNA_DISTANCE, meters(2.48e6))
      CONSTANT(ECHIDNA_SPEED, meters_per_second(3.48L))
      CONSTANT(ECHIDNA_INCLINE, degrees(25.0L))
      CONSTANT(ECHIDNA_OFFSET, degrees(0.0L))
    
    CONSTANT(URANUS_MASS, kilograms(8.6810e25L))
    CONSTANT(URANUS_RADIUS, meters(2.5362e7L))
    CONSTANT(URANUS_DISTANCE, meters(2.87246e12L))
    CONSTANT(URANUS_SPEED, meters_per_second(6.81e3L))
    CONSTANT(URANUS_INCLINE, degrees(0.76989L))
    CONSTANT(URANUS_OFFSET, degrees(0.0L))
    CONSTANT(URANUS_AXIAL, degrees(97.769L))
    CONSTANT(URANUS_PERIOD, seconds(2.651e9L))

      // Horizons
      CONSTANT(CORDELIA_MASS, kilograms(6.053069e+18L))
      CONSTANT(CORDELIA_RADIUS, meters(1.300000e+04L))
      CONSTANT(CORDELIA_DISTANCE, meters(4.975200e+07L))
      CONSTANT(CORDELIA_SPEED, meters_per_second(1.079914e+04L))
      CONSTANT(CORDELIA_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(CORDELIA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(OPHELIA_MASS, kilograms(3.565917e+16L))
      CONSTANT(OPHELIA_RADIUS, meters(1.600000e+04L))
      CONSTANT(OPHELIA_DISTANCE, meters(5.430164e+07L))
      CONSTANT(OPHELIA_SPEED, meters_per_second(1.028382e+04L))
      CONSTANT(OPHELIA_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(OPHELIA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(BIANCA_MASS, kilograms(6.382692e+16L))
      CONSTANT(BIANCA_RADIUS, meters(2.200000e+04L))
      CONSTANT(BIANCA_DISTANCE, meters(5.922416e+07L))
      CONSTANT(BIANCA_SPEED, meters_per_second(9.890767e+03L))
      CONSTANT(BIANCA_INCLINE, degrees(0.19999999999998863L))
      CONSTANT(BIANCA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(CRESSIDA_MASS, kilograms(2.502135e+17L))
      CONSTANT(CRESSIDA_RADIUS, meters(3.300000e+04L))
      CONSTANT(CRESSIDA_DISTANCE, meters(6.177700e+07L))
      CONSTANT(CRESSIDA_SPEED, meters_per_second(9.691201e+03L))
      CONSTANT(CRESSIDA_INCLINE, degrees(0.0L))
      CONSTANT(CRESSIDA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(DESDEMONA_MASS, kilograms(1.498284e+17L))
      CONSTANT(DESDEMONA_RADIUS, meters(2.900000e+04L))
      CONSTANT(DESDEMONA_DISTANCE, meters(6.265900e+07L))
      CONSTANT(DESDEMONA_SPEED, meters_per_second(9.620356e+03L))
      CONSTANT(DESDEMONA_INCLINE, degrees(0.19999999999998863L))
      CONSTANT(DESDEMONA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(JULIET_MASS, kilograms(1.498284e+17L))
      CONSTANT(JULIET_RADIUS, meters(4.200000e+04L))
      CONSTANT(JULIET_DISTANCE, meters(6.442236e+07L))
      CONSTANT(JULIET_SPEED, meters_per_second(9.482641e+03L))
      CONSTANT(JULIET_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(JULIET_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(PORTIA_MASS, kilograms(1.693061e+18L))
      CONSTANT(PORTIA_RADIUS, meters(5.500000e+04L))
      CONSTANT(PORTIA_DISTANCE, meters(6.609700e+07L))
      CONSTANT(PORTIA_SPEED, meters_per_second(9.366226e+03L))
      CONSTANT(PORTIA_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(PORTIA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ROSALIND_MASS, kilograms(1.752993e+17L))
      CONSTANT(ROSALIND_RADIUS, meters(2.900000e+04L))
      CONSTANT(ROSALIND_DISTANCE, meters(6.992700e+07L))
      CONSTANT(ROSALIND_SPEED, meters_per_second(9.105834e+03L))
      CONSTANT(ROSALIND_INCLINE, degrees(0.30000000000001137L))
      CONSTANT(ROSALIND_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(CUPID_MASS, kilograms(3.745711e+15L))
      CONSTANT(CUPID_RADIUS, meters(9.000000e+03L))
      CONSTANT(CUPID_DISTANCE, meters(7.491677e+07L))
      CONSTANT(CUPID_SPEED, meters_per_second(8.771412e+03L))
      CONSTANT(CUPID_INCLINE, degrees(2.0L))
      CONSTANT(CUPID_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(BELINDA_MASS, kilograms(1.603164e+17L))
      CONSTANT(BELINDA_RADIUS, meters(3.400000e+04L))
      CONSTANT(BELINDA_DISTANCE, meters(7.525500e+07L))
      CONSTANT(BELINDA_SPEED, meters_per_second(8.777031e+03L))
      CONSTANT(BELINDA_INCLINE, degrees(0.0L))
      CONSTANT(BELINDA_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(PERDITA_MASS, kilograms(7.491422e+15L))
      CONSTANT(PERDITA_RADIUS, meters(1.500000e+04L))
      CONSTANT(PERDITA_DISTANCE, meters(7.680009e+07L))
      CONSTANT(PERDITA_SPEED, meters_per_second(8.664300e+03L))
      CONSTANT(PERDITA_INCLINE, degrees(1.6L))
      CONSTANT(PERDITA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(PUCK_MASS, kilograms(1.902821e+18L))
      CONSTANT(PUCK_RADIUS, meters(7.700000e+04L))
      CONSTANT(PUCK_DISTANCE, meters(8.600400e+07L))
      CONSTANT(PUCK_SPEED, meters_per_second(8.209667e+03L))
      CONSTANT(PUCK_INCLINE, degrees(0.30000000000001137L))
      CONSTANT(PUCK_OFFSET, degrees(0.0L))

      // Fact sheets
      CONSTANT(MAB_MASS, kilograms(1.003851e+15L))
      CONSTANT(MAB_RADIUS, meters(1.200000e+04L))
      CONSTANT(MAB_DISTANCE, meters(9.832342e+07L))
      CONSTANT(MAB_SPEED, meters_per_second(7.655344e+03L))
      CONSTANT(MAB_INCLINE, degrees(1.8L))
      CONSTANT(MAB_OFFSET, degrees(0.0L))

      // Horizons 
      CONSTANT(MIRANDA_MASS, kilograms(6.442623e+19L))
      CONSTANT(MIRANDA_RADIUS, meters(2.357000e+05L))
      CONSTANT(MIRANDA_DISTANCE, meters(1.301505e+08L))
      CONSTANT(MIRANDA_SPEED, meters_per_second(6.662329e+03L))
      CONSTANT(MIRANDA_INCLINE, degrees(4.219999999999999L))
      CONSTANT(MIRANDA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(ARIEL_MASS, kilograms(1.250019e+21L))
      CONSTANT(ARIEL_RADIUS, meters(5.789000e+05L))
      CONSTANT(ARIEL_DISTANCE, meters(1.918501e+08L))
      CONSTANT(ARIEL_SPEED, meters_per_second(5.498913e+03L))
      CONSTANT(ARIEL_INCLINE, degrees(0.3100000000000023L))
      CONSTANT(ARIEL_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(UMBRIEL_MASS, kilograms(1.279535e+21L))
      CONSTANT(UMBRIEL_RADIUS, meters(5.847000e+05L))
      CONSTANT(UMBRIEL_DISTANCE, meters(2.673300e+08L))
      CONSTANT(UMBRIEL_SPEED, meters_per_second(4.644688e+03L))
      CONSTANT(UMBRIEL_INCLINE, degrees(0.36000000000001364L))
      CONSTANT(UMBRIEL_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(TITANIA_MASS, kilograms(3.338178e+21L))
      CONSTANT(TITANIA_RADIUS, meters(7.889000e+05L))
      CONSTANT(TITANIA_DISTANCE, meters(4.367588e+08L))
      CONSTANT(TITANIA_SPEED, meters_per_second(3.632279e+03L))
      CONSTANT(TITANIA_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(TITANIA_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(OBERON_MASS, kilograms(3.076577e+21L))
      CONSTANT(OBERON_RADIUS, meters(7.614000e+05L))
      CONSTANT(OBERON_DISTANCE, meters(5.830661e+08L))
      CONSTANT(OBERON_SPEED, meters_per_second(3.144469e+03L))
      CONSTANT(OBERON_INCLINE, degrees(0.09999999999999432L))
      CONSTANT(OBERON_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(FRANCISCO_MASS, kilograms(7.191765e+15L))
      CONSTANT(FRANCISCO_RADIUS, meters(1.100000e+04L))
      CONSTANT(FRANCISCO_DISTANCE, meters(4.891401e+09L))
      CONSTANT(FRANCISCO_SPEED, meters_per_second(1.006972e+03L))
      CONSTANT(FRANCISCO_INCLINE, degrees(145.2L))
      CONSTANT(FRANCISCO_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(CALIBAN_MASS, kilograms(7.401525e+17L))
      CONSTANT(CALIBAN_RADIUS, meters(3.000000e+04L))
      CONSTANT(CALIBAN_DISTANCE, meters(8.600400e+09L))
      CONSTANT(CALIBAN_SPEED, meters_per_second(7.340236e+02L))
      CONSTANT(CALIBAN_INCLINE, degrees(120.28L))
      CONSTANT(CALIBAN_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(STEPHANO_MASS, kilograms(2.202478e+16L))
      CONSTANT(STEPHANO_RADIUS, meters(1.600000e+04L))
      CONSTANT(STEPHANO_DISTANCE, meters(9.819979e+09L))
      CONSTANT(STEPHANO_SPEED, meters_per_second(6.716775e+02L))
      CONSTANT(STEPHANO_INCLINE, degrees(99.3L))
      CONSTANT(STEPHANO_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(TRINCULO_MASS, kilograms(3.895540e+15L))
      CONSTANT(TRINCULO_RADIUS, meters(9.000000e+03L))
      CONSTANT(TRINCULO_DISTANCE, meters(1.037317e+10L))
      CONSTANT(TRINCULO_SPEED, meters_per_second(6.597379e+02L))
      CONSTANT(TRINCULO_INCLINE, degrees(166.2L))
      CONSTANT(TRINCULO_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(SYCORAX_MASS, kilograms(2.502135e+18L))
      CONSTANT(SYCORAX_RADIUS, meters(6.000000e+04L))
      CONSTANT(SYCORAX_DISTANCE, meters(1.853366e+10L))
      CONSTANT(SYCORAX_SPEED, meters_per_second(3.867500e+02L))
      CONSTANT(SYCORAX_INCLINE, degrees(124.3L))
      CONSTANT(SYCORAX_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(PROSPERO_MASS, kilograms(1.258559e+16L))
      CONSTANT(PROSPERO_RADIUS, meters(5.000000e+04L))
      CONSTANT(PROSPERO_DISTANCE, meters(2.337446e+10L))
      CONSTANT(PROSPERO_SPEED, meters_per_second(3.711783e+02L))
      CONSTANT(PROSPERO_INCLINE, degrees(68.0L))
      CONSTANT(PROSPERO_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(MARGARET_MASS, kilograms(5.393824e+15L))
      CONSTANT(MARGARET_RADIUS, meters(1.000000e+04L))
      CONSTANT(MARGARET_DISTANCE, meters(2.368585e+10L))
      CONSTANT(MARGARET_SPEED, meters_per_second(2.959348e+02L))
      CONSTANT(MARGARET_INCLINE, degrees(51.3L))
      CONSTANT(MARGARET_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(SETEBOS_MASS, kilograms(7.491422e+15L))
      CONSTANT(SETEBOS_RADIUS, meters(2.400000e+04L))
      CONSTANT(SETEBOS_DISTANCE, meters(2.766376e+10L))
      CONSTANT(SETEBOS_SPEED, meters_per_second(2.956836e+02L))
      CONSTANT(SETEBOS_INCLINE, degrees(74.1L))
      CONSTANT(SETEBOS_OFFSET, degrees(0.0L))

      // Horizons
      CONSTANT(FERDINAND_MASS, kilograms(5.393824e+15L))
      CONSTANT(FERDINAND_RADIUS, meters(1.000000e+04L))
      CONSTANT(FERDINAND_DISTANCE, meters(2.848785e+10L))
      CONSTANT(FERDINAND_SPEED, meters_per_second(3.482065e+02L))
      CONSTANT(FERDINAND_INCLINE, degrees(145.0L))
      CONSTANT(FERDINAND_OFFSET, degrees(0.0L))
      
    CONSTANT(NEPTUNE_MASS, kilograms(1.024e26L))
    CONSTANT(NEPTUNE_RADIUS, meters(2.4622e7L))
    CONSTANT(NEPTUNE_DISTANCE, meters(4.495e12L))
    CONSTANT(NEPTUNE_SPEED, meters_per_second(5.43e3L))
    CONSTANT(NEPTUNE_INCLINE, degrees(1.77L))
    CONSTANT(NEPTUNE_OFFSET, degrees(0.0L))
    CONSTANT(NEPTUNE_AXIAL, degrees(28.32L))
    CONSTANT(NEPTUNE_PERIOD, seconds(5.50e9L))

      CONSTANT(NAIAD_MASS, kilograms(1.9e17L))
      CONSTANT(NAIAD_RADIUS, meters(3.3e4L))
      CONSTANT(NAIAD_DISTANCE, meters(4.82e7L))
      CONSTANT(NAIAD_SPEED, meters_per_second(1.19e4L))
      CONSTANT(NAIAD_INCLINE, degrees(4.7L))
      CONSTANT(NAIAD_OFFSET, degrees(0.0L))

      CONSTANT(THALASSA_MASS, kilograms(3.5e17L))
      CONSTANT(THALASSA_RADIUS, meters(4.05e4L))
      CONSTANT(THALASSA_DISTANCE, meters(5.00e7L))
      CONSTANT(THALASSA_SPEED, meters_per_second(1.16e4L))
      CONSTANT(THALASSA_INCLINE, degrees(0.2L))
      CONSTANT(THALASSA_OFFSET, degrees(0.0L))

      CONSTANT(DESPINA_MASS, kilograms(2.1e18L))
      CONSTANT(DESPINA_RADIUS, meters(7.4e4L))
      CONSTANT(DESPINA_DISTANCE, meters(5.24e7L))
      CONSTANT(DESPINA_SPEED, meters_per_second(1.13e4L))
      CONSTANT(DESPINA_INCLINE, degrees(0.07L))
      CONSTANT(DESPINA_OFFSET, degrees(0.0L))

      CONSTANT(GALATEA_MASS, kilograms(2.12e18L))
      CONSTANT(GALATEA_RADIUS, meters(8.8e4L))
      CONSTANT(GALATEA_DISTANCE, meters(6.20e7L))
      CONSTANT(GALATEA_SPEED, meters_per_second(1.05e4L))
      CONSTANT(GALATEA_INCLINE, degrees(0.05L))
      CONSTANT(GALATEA_OFFSET, degrees(0.0L))

      CONSTANT(LARISSA_MASS, kilograms(4.9e18L))
      CONSTANT(LARISSA_RADIUS, meters(9.7e4L))
      CONSTANT(LARISSA_DISTANCE, meters(7.35e7L))
      CONSTANT(LARISSA_SPEED, meters_per_second(9.60e3L))
      CONSTANT(LARISSA_INCLINE, degrees(0.2L))
      CONSTANT(LARISSA_OFFSET, degrees(0.0L))

      CONSTANT(HIPPOCAMP_MASS, kilograms(2.4695e16L))
      CONSTANT(HIPPOCAMP_RADIUS, meters(1.7000e4L))
      CONSTANT(HIPPOCAMP_DISTANCE, meters(1.0537e8L))
      CONSTANT(HIPPOCAMP_SPEED, meters_per_second(8.0514e3L))
      CONSTANT(HIPPOCAMP_INCLINE, degrees(0.002L))
      CONSTANT(HIPPOCAMP_OFFSET, degrees(0.0L))

      CONSTANT(PROTEUS_MASS, kilograms(5.0e19L))
      CONSTANT(PROTEUS_RADIUS, meters(2.10e5L))
      CONSTANT(PROTEUS_DISTANCE, meters(1.176e8L))
      CONSTANT(PROTEUS_SPEED, meters_per_second(7.60e3L))
      CONSTANT(PROTEUS_INCLINE, degrees(0.1L))
      CONSTANT(PROTEUS_OFFSET, degrees(0.0L))

      CONSTANT(TRITON_MASS, kilograms(2.14e22L))
      CONSTANT(TRITON_RADIUS, meters(1.3534e6L))
      CONSTANT(TRITON_DISTANCE, meters(3.547e8L))
      CONSTANT(TRITON_SPEED, meters_per_second(4.39e3L))
      CONSTANT(TRITON_INCLINE, degrees(156.8L))
      CONSTANT(TRITON_OFFSET, degrees(0.0L))

      CONSTANT(NEREID_MASS, kilograms(2.6000e19L))
      CONSTANT(NEREID_RADIUS, meters(1.7000e5L))
      CONSTANT(NEREID_DISTANCE, meters(9.6523e9L))
      CONSTANT(NEREID_SPEED, meters_per_second(4.2021e2L))
      CONSTANT(NEREID_INCLINE, degrees(27.600L))
      CONSTANT(NEREID_OFFSET, degrees(0.0L))

      CONSTANT(HALIMEDE_MASS, kilograms(1.6000e17L))
      CONSTANT(HALIMEDE_RADIUS, meters(3.1000e4L))
      CONSTANT(HALIMEDE_DISTANCE, meters(2.1006e10L))
      CONSTANT(HALIMEDE_SPEED, meters_per_second(4.8922e2L))
      CONSTANT(HALIMEDE_INCLINE, degrees(112.71L))
      CONSTANT(HALIMEDE_OFFSET, degrees(0.0L))

      CONSTANT(SAO_MASS, kilograms(6.6903e16L))
      CONSTANT(SAO_RADIUS, meters(2.2000e4L))
      CONSTANT(SAO_DISTANCE, meters(2.5262e10L))
      CONSTANT(SAO_SPEED, meters_per_second(4.8341e2L))
      CONSTANT(SAO_INCLINE, degrees(53.483L))
      CONSTANT(SAO_OFFSET, degrees(0.0L))

      CONSTANT(LAOMEDEIA_MASS, kilograms(5.8000e16L))
      CONSTANT(LAOMEDEIA_RADIUS, meters(2.1000e4L))
      CONSTANT(LAOMEDEIA_DISTANCE, meters(3.2985e10L))
      CONSTANT(LAOMEDEIA_SPEED, meters_per_second(3.5355e2L))
      CONSTANT(LAOMEDEIA_INCLINE, degrees(37.874L))
      CONSTANT(LAOMEDEIA_OFFSET, degrees(0.0L))

      CONSTANT(PSAMATHE_MASS, kilograms(4.9000e16L))
      CONSTANT(PSAMATHE_RADIUS, meters(1.9000e4L))
      CONSTANT(PSAMATHE_DISTANCE, meters(6.8254e10L))
      CONSTANT(PSAMATHE_SPEED, meters_per_second(2.3220e2L))
      CONSTANT(PSAMATHE_INCLINE, degrees(137.68L))
      CONSTANT(PSAMATHE_OFFSET, degrees(0.0L))

      CONSTANT(NESO_MASS, kilograms(1.6000e17L))
      CONSTANT(NESO_RADIUS, meters(3.0000e4L))
      CONSTANT(NESO_DISTANCE, meters(7.3647e10L))
      CONSTANT(NESO_SPEED, meters_per_second(2.1666e2L))
      CONSTANT(NESO_INCLINE, degrees(136.40L))
      CONSTANT(NESO_OFFSET, degrees(0.0L))

    // Kuiper Belt

    CONSTANT(ORCUS_MASS, kilograms(5.48e20L))
    CONSTANT(ORCUS_RADIUS, meters(4.59e5L))
    CONSTANT(ORCUS_DISTANCE, meters(5.86e12L))
    CONSTANT(ORCUS_SPEED, meters_per_second(4.68e3L))
    CONSTANT(ORCUS_INCLINE, degrees(20.59L))
    CONSTANT(ORCUS_OFFSET, degrees(0.0L))
    CONSTANT(ORCUS_AXIAL, degrees(10.3L))

      CONSTANT(VANTH_MASS, kilograms(8.70e19L))
      CONSTANT(VANTH_RADIUS, meters(2.22e5L))
      CONSTANT(VANTH_DISTANCE, meters(8.98e6L))
      CONSTANT(VANTH_SPEED, meters_per_second(6.85e1L))
      CONSTANT(VANTH_INCLINE, degrees(0.0L))
      CONSTANT(VANTH_OFFSET, degrees(0.0L))

    CONSTANT(LEMPO_MASS, kilograms(6.68e18L))
    CONSTANT(LEMPO_RADIUS, meters(1.36e5L))
    CONSTANT(LEMPO_DISTANCE, meters(5.905e12L))
    CONSTANT(LEMPO_SPEED, meters_per_second(4.74e3L))
    CONSTANT(LEMPO_INCLINE, degrees(8.41L))
    CONSTANT(LEMPO_OFFSET, degrees(0.0L))
    CONSTANT(LEMPO_AXIAL, degrees(0.0L))

      CONSTANT(HIISI_MASS, kilograms(5.25e18L))
      CONSTANT(HIISI_RADIUS, meters(1.255e5L))
      CONSTANT(HIISI_DISTANCE, meters(8.67e5L))
      CONSTANT(HIISI_SPEED, meters_per_second(3.03e1L))
      CONSTANT(HIISI_INCLINE, degrees(0.0L))
      CONSTANT(HIISI_OFFSET, degrees(0.0L))

      CONSTANT(PAHA_MASS, kilograms(8.20e17L))
      CONSTANT(PAHA_RADIUS, meters(6.6e4L))
      CONSTANT(PAHA_DISTANCE, meters(1.00e7L))
      CONSTANT(PAHA_SPEED, meters_per_second(7.86L))
      CONSTANT(PAHA_INCLINE, degrees(2.40e1L))
      CONSTANT(PAHA_OFFSET, degrees(0.0L))
    
    CONSTANT(PLUTO_MASS, kilograms(1.303e22L))
    CONSTANT(PLUTO_RADIUS, meters(1.1883e6L))
    CONSTANT(PLUTO_DISTANCE, meters(5.90638e12L))
    CONSTANT(PLUTO_SPEED, meters_per_second(4.67e3L))
    CONSTANT(PLUTO_INCLINE, degrees(17.16L))
    CONSTANT(PLUTO_OFFSET, degrees(0.0L))
    CONSTANT(PLUTO_AXIAL, degrees(122.53L))

      CONSTANT(CHARON_MASS, kilograms(1.586e21L))
      CONSTANT(CHARON_RADIUS, meters(6.06e5L))
      CONSTANT(CHARON_DISTANCE, meters(1.9596e7L))
      CONSTANT(CHARON_SPEED, meters_per_second(2.2312e2L))
      CONSTANT(CHARON_INCLINE, degrees(0.0L))
      CONSTANT(CHARON_OFFSET, degrees(0.0L))

      CONSTANT(STYX_MASS, kilograms(7.500e14L))
      CONSTANT(STYX_RADIUS, meters(5.0e3L))
      CONSTANT(STYX_DISTANCE, meters(4.4782e7L))
      CONSTANT(STYX_SPEED, meters_per_second(1.7544e2L))
      CONSTANT(STYX_INCLINE, degrees(8.090e-1L))
      CONSTANT(STYX_OFFSET, degrees(0.0L))

      CONSTANT(NIX_MASS, kilograms(2.700e15L))
      CONSTANT(NIX_RADIUS, meters(1.8500e4L))
      CONSTANT(NIX_DISTANCE, meters(5.0820e7L))
      CONSTANT(NIX_SPEED, meters_per_second(1.6575e2L))
      CONSTANT(NIX_INCLINE, degrees(1.330e-1L))
      CONSTANT(NIX_OFFSET, degrees(0.0L))

      CONSTANT(KERBEROS_MASS, kilograms(1.6500e15L))
      CONSTANT(KERBEROS_RADIUS, meters(6.0e3L))
      CONSTANT(KERBEROS_DISTANCE, meters(5.9909e7L))
      CONSTANT(KERBEROS_SPEED, meters_per_second(1.5414e2L))
      CONSTANT(KERBEROS_INCLINE, degrees(3.890e-1L))
      CONSTANT(KERBEROS_OFFSET, degrees(0.0L))

      CONSTANT(HYDRA_MASS, kilograms(3.0e15L))
      CONSTANT(HYDRA_RADIUS, meters(2.54e4L))
      CONSTANT(HYDRA_DISTANCE, meters(6.6864e7L))
      CONSTANT(HYDRA_SPEED, meters_per_second(1.4697e2L))
      CONSTANT(HYDRA_INCLINE, degrees(2.420e-1L))
      CONSTANT(HYDRA_OFFSET, degrees(0.0L))

    CONSTANT(HAUMEA_MASS, kilograms(4.006e21L))
    CONSTANT(HAUMEA_RADIUS, meters(7.96e5L))
    CONSTANT(HAUMEA_DISTANCE, meters(6.425e12L))
    CONSTANT(HAUMEA_SPEED, meters_per_second(4.53e3L))
    CONSTANT(HAUMEA_INCLINE, degrees(28.19L))
    CONSTANT(HAUMEA_OFFSET, degrees(0.0L))
    CONSTANT(HAUMEA_AXIAL, degrees(126.0L))

      CONSTANT(HI_IAKA_MASS, kilograms(1.8e19L)) // +- 0.5e19 kg
      CONSTANT(HI_IAKA_RADIUS, meters(2.1e5L))
      CONSTANT(HI_IAKA_DISTANCE, meters(4.949e7L))
      CONSTANT(HI_IAKA_SPEED, meters_per_second(7.35e1))
      CONSTANT(HI_IAKA_INCLINE, degrees(1.0L)) // +- 1.0 degree
      CONSTANT(HI_IAKA_OFFSET, degrees(0.0L))

      CONSTANT(NAMAKA_MASS, kilograms(2.0e18L)) // +- 1.0e18 kg
      CONSTANT(NAMAKA_RADIUS, meters(8.5e4L))
      CONSTANT(NAMAKA_DISTANCE, meters(2.573e7L))
      CONSTANT(NAMAKA_SPEED, meters_per_second(1.04e2L))
      CONSTANT(NAMAKA_INCLINE, degrees(13.0L))
      CONSTANT(NAMAKA_OFFSET, degrees(0.0L))

    CONSTANT(QUAOAR_MASS, kilograms(1.212e21L))
    CONSTANT(QUAOAR_RADIUS, meters(5.488e5L))
    CONSTANT(QUAOAR_DISTANCE, meters(6.537e12L))
    CONSTANT(QUAOAR_SPEED, meters_per_second(4.530e3L))
    CONSTANT(QUAOAR_INCLINE, degrees(7.9895L))
    CONSTANT(QUAOAR_OFFSET, degrees(0.0L))
    CONSTANT(QUAOAR_AXIAL, degrees(12.60L))

      CONSTANT(WEYWOT_MASS, kilograms(2.400e18L))
      CONSTANT(WEYWOT_RADIUS, meters(8.250e4L))
      CONSTANT(WEYWOT_DISTANCE, meters(1.3329e7L))
      CONSTANT(WEYWOT_SPEED, meters_per_second(7.800e1L))
      CONSTANT(WEYWOT_INCLINE, degrees(5.000L))
      CONSTANT(WEYWOT_OFFSET, degrees(0.0L))

    CONSTANT(GONGGONG_MASS, kilograms(1.75e21L))
    CONSTANT(GONGGONG_RADIUS, meters(6.15e5L))
    CONSTANT(GONGGONG_DISTANCE, meters(6.65e12L))
    CONSTANT(GONGGONG_SPEED, meters_per_second(4.49e3L))
    CONSTANT(GONGGONG_INCLINE, degrees(30.7L))
    CONSTANT(GONGGONG_OFFSET, degrees(0.0L))
    CONSTANT(GONGGONG_AXIAL, degrees(83.0L)) // +- 20 degrees

      CONSTANT(XIANGLIU_MASS, kilograms(2.0e18L))
      CONSTANT(XIANGLIU_RADIUS, meters(4.0e4L))
      CONSTANT(XIANGLIU_DISTANCE, meters(3.0987e7L))
      CONSTANT(XIANGLIU_SPEED, meters_per_second(51.73L))
      CONSTANT(XIANGLIU_INCLINE, degrees(0.0L)) // += 20 degrees
      CONSTANT(XIANGLIU_OFFSET, degrees(0.0L))

    CONSTANT(MAKEMAKE_MASS, kilograms(3.1e21L))
    CONSTANT(MAKEMAKE_RADIUS, meters(7.15e5L))
    CONSTANT(MAKEMAKE_DISTANCE, meters(6.882e12L))
    CONSTANT(MAKEMAKE_SPEED, meters_per_second(4.30e3L))
    CONSTANT(MAKEMAKE_INCLINE, degrees(29.0L))
    CONSTANT(MAKEMAKE_OFFSET, degrees(0.0L))
    CONSTANT(MAKEMAKE_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(MO_O_MASS, kilograms(1.0e18L)) // magnitude only
      CONSTANT(MO_O_RADIUS, meters(8.0e4L)) // +- 0.5e5 m
      CONSTANT(MO_O_DISTANCE, meters(2.100e7L))
      CONSTANT(MO_O_SPEED, meters_per_second(9.9e1L)) // derived
      CONSTANT(MO_O_INCLINE, degrees(0.0L)) // unknown
      CONSTANT(MO_O_OFFSET, degrees(0.0L))
    
    CONSTANT(ERIS_MASS, kilograms(1.646e22L))
    CONSTANT(ERIS_RADIUS, meters(1.163e6L))
    CONSTANT(ERIS_DISTANCE, meters(1.015e13L))
    CONSTANT(ERIS_SPEED, meters_per_second(3.44e3L))
    CONSTANT(ERIS_INCLINE, degrees(44.04L))
    CONSTANT(ERIS_OFFSET, degrees(0.0L))
    CONSTANT(ERIS_AXIAL, degrees(0.0L)) // unknown

      CONSTANT(DYSNOMIA_MASS, kilograms(4.0e19L)) // +- 1.0e19 kg
      CONSTANT(DYSNOMIA_RADIUS, meters(3.5e5L)) // +- 1.5e5 m
      CONSTANT(DYSNOMIA_DISTANCE, meters(3.737e7L))
      CONSTANT(DYSNOMIA_SPEED, meters_per_second(1.71e2L))
      CONSTANT(DYSNOMIA_INCLINE, degrees(0.0L)) // unknown
      CONSTANT(DYSNOMIA_OFFSET, degrees(0.0L))

    // Comets

    CONSTANT(HALLEY_MASS, kilograms(2.2e14L))
    CONSTANT(HALLEY_RADIUS, meters(5.5e3L))
    CONSTANT(HALLEY_DISTANCE, meters(8.766e10L))
    CONSTANT(HALLEY_SPEED, meters_per_second(5.46e4L))
    CONSTANT(HALLEY_INCLINE, degrees(162.26L))
    CONSTANT(HALLEY_OFFSET, degrees(0.0L))
    CONSTANT(HALLEY_PERIOD, seconds(2.3769e9L))

    CONSTANT(ENCKE_MASS, kilograms(5.79e13L))
    CONSTANT(ENCKE_RADIUS, meters(2.4e3L))
    CONSTANT(ENCKE_DISTANCE, meters(5.0556e10L))
    CONSTANT(ENCKE_SPEED, meters_per_second(6.95e4L))
    CONSTANT(ENCKE_INCLINE, degrees(11.77L))
    CONSTANT(ENCKE_OFFSET, degrees(0.0L))
    CONSTANT(ENCKE_PERIOD, seconds(1.043e8L))
  
  #undef CONSTANT
};
