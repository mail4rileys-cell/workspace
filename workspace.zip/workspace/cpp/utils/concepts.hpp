// since 1.0.0

#pragma once

#include <concepts>
// std::convertible_to

namespace concepts {

  #define ARITHMETIC(NAME, OPERATOR) \
    namespace NAME { \
      template<typename LeftOperand, typename RightOperand, typename Result> \
      concept val = requires (LeftOperand left_operand, RightOperand right_operand) { \
        {left_operand OPERATOR right_operand} -> std::convertible_to<Result>; \
      }; \
      template<typename LeftOperand, typename RightOperand, typename Result> \
      concept mut = requires (LeftOperand left_operand, RightOperand right_operand) { \
        {left_operand OPERATOR##= right_operand} -> std::convertible_to<Result>; \
      }; \
      template<typename LeftOperand, typename RightOperand, typename Result> \
      concept full = val<LeftOperand, RightOperand, Result> && mut<LeftOperand, RightOperand, Result>; \
    }
  // end

  ARITHMETIC(add_c, +)
  ARITHMETIC(sub_c, -)
  ARITHMETIC(mul_c, *)
  ARITHMETIC(div_c, /)
  ARITHMETIC(mod_c, %)
  ARITHMETIC(and_c, &)
  ARITHMETIC(or_c, |)
  ARITHMETIC(xor_c, ^)
  ARITHMETIC(lshift_c, <<)
  ARITHMETIC(rshift_c, >>)

  #undef ARITHMETIC

  #define COMPARATIVE(NAME, OPERATOR) \
    template<typename LeftOperand, typename RightOperand> \
    concept NAME = requires (LeftOperand left_operand, RightOperand right_operand) { \
      {left_operand OPERATOR right_operand} -> std::convertible_to<bool>; \
    };
  // end

  COMPARATIVE(eq_c, ==)
  COMPARATIVE(ne_c, !=)
  COMPARATIVE(lt_c, <)
  COMPARATIVE(le_c, <=)
  COMPARATIVE(gt_c, >)
  COMPARATIVE(ge_c, >=)

  #undef COMPARATIVE

  #define UNARY(NAME, OPERATOR) \
    template<typename Operand> \
    concept NAME = requires (Operand operand) { \
      {OPERATOR operand} -> std::convertible_to<Operand>; \
    };
  // end

  UNARY(pos_c, +)
  UNARY(neg_c, -)
  UNARY(comp_c, ~)
  
  #undef UNARY

  template<typename Operand>
  concept not_c = requires (Operand operand) {
    {!operand} -> std::convertible_to<bool>;
  };

  namespace index_c {

    template<typename Sequence, typename Index, typename Result>
    concept read = requires (Sequence sequence, Index index) {
      {sequence[index]} -> std::convertible_to<Result>;
    };

    template<typename Sequence, typename Index, typename Value>
    concept write = requires (Sequence sequence, Index index, Value value) {
      {sequence[index] = value};
    };

    template<typename Sequence, typename Index, typename Type>
    concept full = read<Sequence, Index, Type> && write<Sequence, Index, Type>;
  }
}
