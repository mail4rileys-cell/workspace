// since 2.0.0

#pragma once

#include <cmath>
// std::sin
// std::cos
// std::atan2
// std::sqrt
// std::cbrt

#include <concepts>
// std::floating_point
// std::same_as

#include <cstdint>
// std::uint8_t

#include <iostream>
// std::istream
// std::ostream

#include <string>
// std::string

namespace physics {

  enum class Axis : std::uint8_t {
    X = 0,
    Y = 1,
    Z = 2,
  };

  inline Axis to_axis(const std::string& str) noexcept {
    if ((str == "1") || (str == "x") || (str == "X")) {
      return physics::Axis::X;
    } else if ((str == "2") || (str == "y") || (str == "Y")) {
      return physics::Axis::Y;
    } else if ((str == "3") || (str == "z") || (str == "z")) {
      return physics::Axis::Z;
    } else {
      return physics::Axis::X;
    }
  }

  template<typename scalar_t>
  requires std::floating_point<scalar_t>
  struct Vector2D {
    scalar_t x = 0.0L;
    scalar_t y = 0.0L;


    inline Vector2D(const scalar_t a, const scalar_t b, const bool cartesian = true) noexcept {
      if (cartesian) {
        this->x = a;
        this->y = b;
      } else {
        this->x = a * std::cos(b);
        this->y = a * std::sin(b);
      }
    }

    inline Vector2D<scalar_t> operator+(const Vector2D<scalar_t>& vector) const noexcept {
      return {this->x + vector.x, this->y + vector.y};
    }

    inline Vector2D<scalar_t> operator+() const noexcept {
      return {+this->x, +this->y};
    }

    inline Vector2D<scalar_t>& operator+=(const Vector2D<scalar_t>& vector) noexcept {
      this->x += vector.x;
      this->y += vector.y;
      return *this;
    }

    inline Vector2D<scalar_t> operator-(const Vector2D<scalar_t>& vector) const noexcept {
      return {this->x - vector.x, this->y - vector.y};
    }

    inline Vector2D<scalar_t> operator-() const noexcept {
      return {-this->x, -this->y};
    }

    inline Vector2D<scalar_t>& operator-=(const Vector2D<scalar_t>& vector) noexcept {
      this->x -= vector.x;
      this->y -= vector.y;
      return *this;
    }

    inline Vector2D<scalar_t> operator*(const scalar_t scalar) const noexcept {
      return {this->x * scalar, this->y * scalar};
    }

    inline Vector2D<scalar_t>& operator*=(const scalar_t scalar) noexcept {
      this->x *= scalar;
      this->y *= scalar;
      return *this;
    }

    inline Vector2D<scalar_t> operator/(const scalar_t scalar) const noexcept {
      return {this->x / scalar, this->y / scalar};
    }

    inline Vector2D<scalar_t>& operator/=(const scalar_t scalar) noexcept {
      this->x /= scalar;
      this->y /= scalar;
      return *this;
    }

    inline Vector2D<scalar_t> rotated(const scalar_t theta) const noexcept {
      const scalar_t sin_theta = std::sin(theta);
      const scalar_t cos_theta = std::cos(theta);
      return {(this->x * cos_theta) - (this->y * sin_theta), (this->x * sin_theta) + (this->y *cos_theta)};
    }

    inline Vector2D<scalar_t>& rotate(const scalar_t theta) noexcept {
      *this = this->rotated(theta);
      return *this;
    }

    inline scalar_t get_magnitude() const noexcept {
      return std::sqrt((this->x * this->x) + (this->y * this->y));
    }
  };

  template<typename scalar_t>
  requires std::floating_point<scalar_t>
  struct Vector3D {
    scalar_t x = 0.0L;
    scalar_t y = 0.0L;
    scalar_t z = 0.0L;

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator+(const Vector3D<scalar_t>& vector) const noexcept {
      return {this->x + vector.x, this->y + vector.y, this->z + vector.z};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator+() const noexcept {
      return {+this->x, +this->y, +this->z};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator+=(const Vector3D<scalar_t>& vector) noexcept {
      this->x += vector.x;
      this->y += vector.y;
      this->z += vector.z;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator-(const Vector3D<scalar_t>& vector) const noexcept {
      return {this->x - vector.x, this->y - vector.y, this->z - vector.z};
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator-() const noexcept {
      return {-this->x, -this->y, -this->z};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator-=(const Vector3D<scalar_t>& vector) noexcept {
      this->x -= vector.x;
      this->y -= vector.y;
      this->z -= vector.z;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator*(const scalar_t scalar) const noexcept {
      return {this->x * scalar, this->y * scalar, this->z * scalar};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator*=(const scalar_t scalar) noexcept {
      this->x *= scalar;
      this->y *= scalar;
      this->z *= scalar;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure, leaf))
    inline Vector3D<scalar_t> operator/(const scalar_t scalar) const noexcept {
      return {this->x / scalar, this->y / scalar, this->z / scalar};
    }

    __attribute__((hot, leaf))
    inline Vector3D<scalar_t>& operator/=(const scalar_t scalar) noexcept {
      this->x /= scalar;
      this->y /= scalar;
      this->z /= scalar;
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure))
    inline Vector3D<scalar_t> rotated(const scalar_t theta, const Axis axis = Axis::Z) const {
      const scalar_t sin_theta = std::sin(theta);
      const scalar_t cos_theta = std::cos(theta);
      switch (axis) {
        case Axis::X: return {this->x, (this->y * cos_theta) - (this->z * sin_theta), (this->y * sin_theta) + (this->z * cos_theta)};
        case Axis::Y: return {(this->x * cos_theta) + (this->z * sin_theta), this->y, (-this->x * sin_theta) + (this->z * cos_theta)};
        case Axis::Z: return {(this->x * cos_theta) - (this->y * sin_theta), (this->x * sin_theta) + (this->y * cos_theta), this->z};
        default: throw std::runtime_error("Unrecognized axis");
      }
    }

    __attribute__((hot))
    inline Vector3D<scalar_t>& rotate(const scalar_t theta, const Axis axis = Axis::Z) noexcept {
      *this = this->rotated(theta, axis);
      return *this;
    }

    [[nodiscard]] __attribute__((hot, pure))
    inline scalar_t get_magnitude() const noexcept {
      return std::sqrt((this->x * this->x) + (this->y * this->y) + (this->z * this->z));
    }
  };


  template<template<typename> class vector_t, typename scalar_t>
  concept Vector = requires (vector_t<scalar_t> a, vector_t<scalar_t> b, scalar_t c) {
    requires std::floating_point<scalar_t>;
    {a + b} -> std::same_as<vector_t<scalar_t>>;
    {+a} -> std::same_as<vector_t<scalar_t>>;
    {a += b} -> std::same_as<vector_t<scalar_t>&>;
    {a - b} -> std::same_as<vector_t<scalar_t>>;
    {-a} -> std::same_as<vector_t<scalar_t>>;
    {a -= b} -> std::same_as<vector_t<scalar_t>&>;
    {a * c} -> std::same_as<vector_t<scalar_t>>;
    {a *= c} -> std::same_as<vector_t<scalar_t>&>;
    {a / c} -> std::same_as<vector_t<scalar_t>>;
    {a /= c} -> std::same_as<vector_t<scalar_t>&>;
    {a.rotated(c)} -> std::same_as<vector_t<scalar_t>>;
    {a.rotate(c)} -> std::same_as<vector_t<scalar_t>&>;
    {a.get_magnitude()} -> std::same_as<scalar_t>;
  };

  template<typename scalar_t>
  __attribute__((hot))
  std::istream& operator>>(std::istream& input, Vector2D<scalar_t>& vector) noexcept {
    char token;
    return input >> token >> vector.x >> vector.y >> token;
    // { x y }
  }

  template<typename scalar_t>
  __attribute__((hot))
  std::istream& operator>>(std::istream& input, Vector3D<scalar_t>& vector) noexcept {
    char token;
    return input >> token >> vector.x >> vector.y >> vector.z >> token;
    // { x y z }
  }

  template<typename scalar_t>
  __attribute__((hot))
  std::ostream& operator<<(std::ostream& output, const Vector2D<scalar_t>& vector) noexcept {
    return output << "{ " << vector.x << " " << vector.y << " }";
  }

  template<typename scalar_t>
  __attribute__((hot))
  std::ostream& operator<<(std::ostream& output, const Vector3D<scalar_t>& vector) noexcept {
    return output << "{ " << vector.x << " " << vector.y << " " << vector.z << " }";
  }

  template<template<typename> class vector_t, typename scalar_t>
  requires Vector<vector_t, scalar_t>
  [[nodiscard]] __attribute__((hot, const))
  inline vector_t<scalar_t> get_delta(const vector_t<scalar_t>& a, const vector_t<scalar_t>& b) noexcept {
    return b - a;
  }

  template<typename scalar_t>
  [[nodiscard]] __attribute__((hot, const, leaf))
  inline scalar_t get_dot(const Vector2D<scalar_t>& a, const Vector2D<scalar_t>& b) noexcept {
    return (a.x * b.x) + (a.y * b.y);
  }
  
  template<typename scalar_t>
  [[nodiscard]] __attribute__((hot, const, leaf))
  inline scalar_t get_dot(const Vector3D<scalar_t>& a, const Vector3D<scalar_t>& b) noexcept {
    return (a.x * b.x) + (a.y * b.y) + (a.z * b.z);
  }
}
