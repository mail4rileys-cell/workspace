// since 1.0.0

#pragma once

#include <concepts>
// std::convertible_to

#include <cstdint>
// std::uint8_t
// std::uintmax_t

namespace math {

  // Note: this only works for natural exponents
  
  template<typename Base, typename Exponent>
  requires
    std::convertible_to<int, Base> &&
    concepts::lt_c<std::uintmax_t, Exponent> &&
    concepts::mul_c::mut<Base, Base, Base>
  inline Base integral_pow(Base base, Exponent exponent) {
    Base result = 1;
    for (std::uintmax_t i = 0; i < exponent; i++) {
      result *= base;
    }
    return result;
  }
}
