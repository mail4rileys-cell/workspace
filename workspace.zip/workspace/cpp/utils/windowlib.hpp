#pragma once

#include <algorithm>
// std::max

#include <cmath>
// std::abs

#include <cstddef>
// std::size_t

#include <iostream>
// std::cout
// std::endl

#include <string>
// std::string

#include <vector>
// std::vector

namespace windowlib {

	const std::string H = reinterpret_cast<const char*>(u8"\u2500");
	const std::string V = reinterpret_cast<const char*>(u8"\u2502");
	const std::string TL = reinterpret_cast<const char*>(u8"\u250c");
	const std::string TR = reinterpret_cast<const char*>(u8"\u2510");
	const std::string BL = reinterpret_cast<const char*>(u8"\u2514");
	const std::string BR = reinterpret_cast<const char*>(u8"\u2518");

  typedef std::vector<std::string> Window;

  __attribute__((hot))
  inline void render(const Window& window) noexcept {
    std::cout << "\033[H";
    std::cout.flush();
    for (std::size_t i = 0; i < window.size(); i++) {
      std::cout << window[i] << std::endl;
    }
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window horizontal(const Window& left, const Window& right) noexcept {
    const Window* shorter = nullptr;
    const Window* taller = nullptr;
    if (left.size() < right.size()) {
      shorter = &left;
      taller = &right;
    } else {
      shorter = &right;
      taller = &left;
    }
    Window result(taller->size());
    for (std::size_t i = 0; i < shorter->size(); i++) {
      result[i] = left[i] + right[i];
    }
    for (std::size_t i = shorter->size(); i < taller->size(); i++) {
      result[i] = (*taller)[i];
    }
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window vertical(const Window& top, const Window& bottom) noexcept {
    Window result(top.size() + bottom.size());
    for (std::size_t i = 0; i < top.size(); i++) {
      result[i] = top[i];
    }
    for (std::size_t i = 0; i < bottom.size(); i++) {
      result[i + top.size()] = bottom[i];
    }
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window border(const Window& window) noexcept {
    Window result(window.size() + 2);
    result[0] = TL;
    for (std::size_t i = 0; i < window[0].size(); i++) {
      result[0] += H;
    }
    result[0] += TR;
    for (std::size_t i = 0; i < window.size(); i++) {
      result[i + 1] = V + window[i] + V;
    }
    result[result.size() - 1] = BL;
    for (std::size_t i = 0; i < window[0].size(); i++) {
      result[result.size() - 1] += H;
    }
    result[result.size() - 1] += BR;
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window title(const Window& window, const std::string& text) noexcept {
    Window result = border(window);
    const std::size_t inner_width =  window[0].size();
    const std::size_t left_fill = (inner_width - text.size()) / 2;
    const std::size_t right_fill = inner_width - text.size() - left_fill; 
    result[0] = TL;
    for (std::size_t i = 0; i < left_fill; i++) {
    	result[0] += H;
    }
    result[0] += text;
    for (std::size_t i = 0; i < right_fill; i++) {
    	result[0] += H;
    }
    result[0] += TR;
    return result;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline Window line(
    const Window& window,
    const std::string& text,
    const int x0,
    const int y0,
    const int x1,
    const int y1
  ) noexcept {
    Window result = window;
    const int dx = x1 - x0;
    const int dy = y1 - y0;
    const int steps = std::max(std::abs(dx), std::abs(dy));
    if (steps == 0) {
      return result;
    }
    for (int i = 0; i <= steps; i++) {
      result[y0 + ((dy * i) / steps)].replace((x0 + ((dx * i) / steps)) * text.size(), text.size(), text);
    }
    return result;
  }
}
