#pragma once

#include <cstddef>
// std::size_t

#include <functional>
// std::function

#include <iostream>
// std::cout

#include <mutex>
// std::mutex
// std::lock_guard

#include <string>
// std::string

#include <termios.h>

#include <unistd.h>

namespace terminal {

  inline termios& saved_state() noexcept {
    static termios state;
    return state;
  }

  inline bool& is_saved() noexcept {
    static bool saved = false;
    return saved;
  }

  inline void disable_echo() noexcept {
    termios current;
    tcgetattr(STDIN_FILENO, &current);
    if (!is_saved()) {
      saved_state() = current;
      is_saved() = true;
    }
    termios modified = current;
    modified.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &modified);
  }

  inline void enable_echo() noexcept {
    if (!is_saved()) {
      return;
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &saved_state());
  }

  static termios oldt;

  inline void enable_raw() noexcept {
    termios newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  }

  inline void disable_raw() noexcept {
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  }

  inline void enable_cursor() noexcept {
    std::cout << "\033[?25h";
  }

  inline void disable_cursor() noexcept {
    std::cout << "\033[?25l";
  }

  inline unsigned char get_key() noexcept {
    unsigned char key;
    ssize_t n = read(STDIN_FILENO, &key, 1);
    if (n == 1) {
      return key;
    }
    return 0;
  }

  class Keyboard final {
    std::string buffer;
    mutable std::mutex mtx;
    std::function<void()> bindings[256];

    inline void clear() noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      this->buffer = "";
    }

    inline void push(const unsigned char key) noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      this->buffer += key;
    }

    inline void newline() noexcept {}

    inline void backspace() noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      if (!this->buffer.empty()) {
        this->buffer.pop_back();
      }
    }

    public:

    inline void bind(const unsigned char key, const std::function<void()>& function) noexcept {
      this->bindings[key] = function;
    }

    inline void unbind(const unsigned char key) noexcept {
      this->bindings[key] = nullptr;
    }

    inline bool bound(const unsigned char key) noexcept {
      return this->bindings[static_cast<std::size_t>(key)] != nullptr;
    }

    inline void call(const unsigned char key) noexcept {
      return this->bindings[static_cast<std::size_t>(key)]();
    }

    Keyboard() noexcept {
      this->bind('\n', [this](){
        this->newline();
      });
      this->bind(127, [this](){
        this->backspace();
      });
      this->bind(8, [this](){
        this->backspace();
      });
    }

    inline std::string read() const noexcept {
      std::lock_guard<std::mutex> lock(this->mtx);
      return this->buffer;
    }

    inline std::string get_line() noexcept {
      this->clear();
      while (true) {
        const unsigned char key = get_key();
        if (key == '\n') {
          return this->read();
        }
        if (this->bound(key)) {
          this->call(key);
          continue;
        } else {
          this->push(key);
        }
      }
    }
  };
}
