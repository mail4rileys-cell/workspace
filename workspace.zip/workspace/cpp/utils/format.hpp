// since 1.1.0

#pragma once

#include <cmath>
// std::pow

#include <cstddef>
// std::size_t

#include <cstdint>
// std::uint8_t

#include <functional>
// std::function

#include <initializer_list>
// std::initializer_list

#include <string>
// std::string
// std::to_string

namespace format {

  #define FORMAT(NAME, CODE) \
    [[nodiscard]] __attribute__((hot, const, leaf)) \
    inline std::string NAME(const std::string& text) noexcept { \
      return CODE + text + "\033[0m"; \
    }

  FORMAT(black, "\033[30m")
  FORMAT(red, "\033[31m")
  FORMAT(green, "\033[32m")
  FORMAT(yellow, "\033[33m")
  FORMAT(blue, "\033[34m")
  FORMAT(magenta, "\033[35m")
  FORMAT(cyan, "\033[36m")
  FORMAT(white, "\033[37m")

  FORMAT(bg_black, "\033[40m")
  FORMAT(bg_red, "\033[41m")
  FORMAT(bg_green, "\033[42m")
  FORMAT(bg_yellow, "\033[43m")
  FORMAT(bg_blue, "\033[44m")
  FORMAT(bg_magenta, "\033[45m")
  FORMAT(bg_cyan, "\033[46m")
  FORMAT(bg_white, "\033[47m")

  FORMAT(bright_black, "\033[90m")
  FORMAT(bright_red, "\033[91m")
  FORMAT(bright_green, "\033[92m")
  FORMAT(bright_yellow, "\033[93m")
  FORMAT(bright_blue, "\033[94m")
  FORMAT(bright_magenta, "\033[95m")
  FORMAT(bright_cyan, "\033[96m")
  FORMAT(bright_white, "\033[97m")

  FORMAT(bg_bright_black, "\033[100m")
  FORMAT(bg_bright_red, "\033[101m")
  FORMAT(bg_bright_green, "\033[102m")
  FORMAT(bg_bright_yellow, "\033[103m")
  FORMAT(bg_bright_blue, "\033[104m")
  FORMAT(bg_bright_magenta, "\033[105m")
  FORMAT(bg_bright_cyan, "\033[106m")
  FORMAT(bg_bright_white, "\033[107m")

  FORMAT(bold, "\033[1m")
  FORMAT(dim, "\033[2m")
  FORMAT(italic, "\033[3m")
  FORMAT(underline, "\033[4m")
  FORMAT(blink, "\033[5m")
  FORMAT(rapid_blink, "\033[6m")
  FORMAT(reverse, "\033[7m")
  FORMAT(hidden, "\033[8m")
  FORMAT(strikethrough, "\033[9m")

  #undef FORMAT

  using func_t = std::function<std::string(const std::string&)>;

  [[nodiscard]] __attribute__((hot))
  inline std::string chain(std::string text, const std::initializer_list<func_t>& funcs) noexcept {
    for (func_t func : funcs) {
      text = func(text);
    }
    return text;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline std::string pad_left(const std::string& text, const std::size_t width, const char ch = ' ') noexcept {
    if (text.size() > width) {
      return text.substr(text.size() - width, width);
    }
    return std::string(width - text.size(), ch) + text;
  }

  [[nodiscard]] __attribute__((hot, const))
  inline std::string pad_right(const std::string& text, const std::size_t width, const char ch = ' ') noexcept {
    if (text.size() > width) {
      return text.substr(0, width);
    }
    return text + std::string(width - text.size(), ch);
  }

  [[nodiscard]] __attribute__((hot, const))
  inline std::string pad_center(const std::string& text, const std::size_t width, const char ch = ' ') noexcept {
    if (text.size() >= width) {
      return text;
    }
    const std::size_t total = width - text.size();
    const std::size_t left = total / 2;
    const std::size_t right = total - left;
    return std::string(left, ch) + text + std::string(right, ch);
  }

  [[nodiscard]] __attribute__((hot, const))
  inline std::string grayscale(const std::string& text, const long double brightness) noexcept {
    const std::string value = std::to_string(static_cast<std::uint8_t>(std::pow(brightness, 0.4L) * 255.0L));
    return "\033[38;2;" + value + ";" + value + ";" + value + "m" + text + "\033[0m";
  }
}