#pragma once

#include <atomic>
// std::atomic

#include <cstddef>
// std::size_t

#include <memory>
// std::unique_ptr

#include <mutex>
// std::mutex

#include <queue>
// std::queue

#include <string>
// std::string

#include <thread>
// std::thread

#include "command.hpp"
// Command
// CommandQueue

#include "config.hpp"
// scalar_t

#include "../../utils/terminal.hpp"
// terminal::

#include "../../utils/windowlib.hpp"
// windowlib::


class Interface final {
  std::string buffer = "";
  mutable std::mutex mtx;
  std::thread thread;
  std::atomic<bool> running = {true};
  std::queue<std::unique_ptr<Command>> command_batch;
  CommandQueue& command_queue;

  __attribute__((hot))
  void clear() noexcept;

  __attribute__((hot))
  void write(const std::string& text) noexcept;

  __attribute__((hot))
  void writeln(const std::string& text) noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_text(const std::string& prompt) noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  scalar_t get_number(const std::string& prompt) noexcept;

  __attribute__((cold, noinline))
  void confirm_command_menu(std::unique_ptr<Command> command) noexcept;

  __attribute__((cold, noinline))
  void command_batch_menu() noexcept;

  __attribute__((cold, noinline))
  void simulate_menu() noexcept;

  __attribute__((cold, noinline))
  void create_body_menu() noexcept;

  __attribute__((cold, noinline))
  void modify_body_menu() noexcept;

  __attribute__((cold, noinline))
  void destroy_body_menu() noexcept;

  __attribute__((cold, noinline))
  void purge_bodies_menu() noexcept;

  __attribute__((cold, noinline))
  void toggle_collisions_menu() noexcept;

  __attribute__((cold, noinline))
  void speed_up_menu() noexcept;

  __attribute__((cold, noinline))
  void focus_view_menu() noexcept;

  __attribute__((cold, noinline))
  void scale_view_menu() noexcept;

  __attribute__((cold, noinline))
  void view_presets_menu() noexcept;

  __attribute__((cold, noinline))
  void save_menu() noexcept;

  __attribute__((cold, noinline))
  void load_menu() noexcept;

  __attribute__((cold, noinline))
  void pause_resume_menu() noexcept;

  __attribute__((cold, noinline))
  void stop_menu() noexcept;

  __attribute__((cold, noinline))
  void main_menu() noexcept;

  public:

  terminal::Keyboard keyboard;

  __attribute__((cold, noinline))
  Interface(CommandQueue& command_queue) noexcept;

  [[nodiscard]] __attribute__((hot))
  std::string read() const noexcept;

  __attribute__((cold, noinline))
  void start() noexcept;

  __attribute__((cold, noinline))
  void stop() noexcept;
};


class InterfaceView final {
  Interface& interface;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept;

  [[nodiscard]] __attribute__((hot))
  windowlib::Window get_window() const noexcept;
};
