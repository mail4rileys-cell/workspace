#pragma once

#include <cmath>
// std::sin
// std::cos

#include <cstddef>
// std::size_t

#include <string>
// std::string

#include "result.hpp"
// Result

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::


struct SolarSystem {
  std::vector<std::string> names = {
    "Sun",
    "Mercury",
    "Venus",
    "Earth", "Moon",
    "Mars", "Phobos", "Deimos",
    "Jupiter", "Io", "Europa", "Ganymede", "Callisto",
    "Saturn", "Titan", "Rhea", "Iapetus", "Dione", "Tethys", "Enceladus", "Mimas", "Hyperion",
    "Uranus", "Titania", "Oberon", "Umbriel", "Ariel", "Miranda",
    "Neptune", "Triton", "Proteus", "Larissa", "Galatea", "Despina", "Thalassa", "Naiad",
    "Pluto", "Charon",
    "1Ceres", "2Vesta", "4Pallas",
    "Encke", "Halley"
  };
  #define PLANET(NAME) \
    { \
      physics:: NAME##_MASS<long double>, \
      physics:: NAME##_RADIUS<long double>, \
      {physics:: NAME##_DISTANCE<long double>, 0.0L, 0.0L}, \
      physics::Vector3D<long double>(0.0L, physics:: NAME##_SPEED<long double>, 0.0L).rotated(physics:: NAME##_INCLINE<long double>, physics::Axis::X), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #define MOON(NAME, PLANET) \
    { \
      physics:: NAME##_MASS<long double>, \
      physics:: NAME##_RADIUS<long double>, \
      {physics:: NAME##_DISTANCE<long double> + physics:: PLANET##_DISTANCE<long double>, 0.0L, 0.0L}, \
      physics::Vector3D<long double>(0.0L, physics:: NAME##_SPEED<long double>, 0.0L).rotated(physics:: NAME##_INCLINE<long double>, physics::Axis::X).rotated(physics:: PLANET##_AXIAL<long double>, physics::Axis::X) + physics::Vector3D<long double>(0.0L, physics:: PLANET##_SPEED<long double>, 0.0L).rotated(physics:: PLANET##_INCLINE<long double>, physics::Axis::X), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  std::vector<physics::RadialBody<physics::Vector3D, long double>> bodies = {
    PLANET(SUN)
      PLANET(MERCURY)
      PLANET(VENUS)
      PLANET(EARTH)
        MOON(MOON, EARTH)
      PLANET(MARS)
        MOON(PHOBOS, MARS)
        MOON(DEIMOS, MARS)
      PLANET(JUPITER)
        MOON(IO, JUPITER)
        MOON(EUROPA, JUPITER)
        MOON(GANYMEDE, JUPITER)
        MOON(CALLISTO, JUPITER)
      PLANET(SATURN)
        MOON(TITAN, SATURN)
        MOON(RHEA, SATURN)
        MOON(IAPETUS, SATURN)
        MOON(DIONE, SATURN)
        MOON(TETHYS, SATURN)
        MOON(ENCELADUS, SATURN)
        MOON(MIMAS, SATURN)
        MOON(HYPERION, SATURN)
      PLANET(URANUS)
        MOON(TITANIA, URANUS)
        MOON(OBERON, URANUS)
        MOON(UMBRIEL, URANUS)
        MOON(ARIEL, URANUS)
        MOON(MIRANDA, URANUS)
      PLANET(NEPTUNE)
        MOON(TRITON, NEPTUNE)
        MOON(PROTEUS, NEPTUNE)
        MOON(LARISSA, NEPTUNE)
        MOON(GALATEA, NEPTUNE)
        MOON(DESPINA, NEPTUNE)
        MOON(THALASSA, NEPTUNE)
        MOON(NAIAD, NEPTUNE)
      PLANET(PLUTO)
        MOON(CHARON, PLUTO)
      PLANET(CERES)
      PLANET(VESTA)
      PLANET(PALLAS)
      PLANET(ENCKE)
      PLANET(HALLEY)
  };
  #undef PLANET
  #undef MOON
  long double time = 0.0L;

  SolarSystem() = default;

  void simulate(const long double batch_time, const long double timestep) noexcept;

  physics::RadialBody<physics::Vector3D, long double>* get_body(const std::string& name) noexcept;

  Result create_body(
    const std::string& name,
    const long double mass,
    const long double radius,
    const physics::Vector3D<long double>& position,
    const physics::Vector3D<long double>& velocity
  ) noexcept;

  Result destroy_body(const std::string& name) noexcept;

  Result purge_bodies() noexcept;
};


class SolarSystemView {
  SolarSystem& solar_system;
  std::string name;
  long double radius;
  std::size_t width;
  std::size_t height;

  public:

  SolarSystemView(
    SolarSystem& solar_system,
    const std::string& name,
    const long double radius,
    const std::size_t width,
    const std::size_t height
  ) noexcept;

  windowlib::Window get_window() const noexcept;

  std::string get_name() const noexcept;

  long double get_radius() const noexcept;

  Result focus(const std::string& name) noexcept;

  Result scale(const long double radius) noexcept;
};


struct Display {
  SolarSystemView views[7];
  
  windowlib::Window get_window(const std::size_t index) const noexcept;
};


struct Simulation {
  SolarSystem& solar_system;
  Display& display;
  bool pause = false;

  Simulation(SolarSystem& solar_system, Display& display, const bool pause) noexcept;

  Result save(const std::string& filename) const noexcept;

  Result load(const std::string& filename) noexcept;
};