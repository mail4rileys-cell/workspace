#include <memory>
// std::unique_ptr

#include <mutex>
// std::lock_guard
// std::mutex

#include <optional>
// std::optional
// std::nullopt

#include <string>
// std::string
// std::to_string

#include <utility>
// std::move

#include "command.hpp"
// Command
// CommandQueue

#include "config.hpp"
// scalar_t
// vector_t
// constants::

#include "result.hpp"
// Result
// Flag

#include "simulation.hpp"
// Simulation
// SystemView

#include "../../utils/physics.hpp"
// physics::


#ifdef GRAPHICS

  
  Result ToggleGuiCommand::execute(Simulation& simulation) noexcept {
    if (simulation.gui) {
      simulation.gui_view.close();
      simulation.gui = false;
      return {Flag::Success, "GUI disabled"};
    } else {
      simulation.gui_view.open();
      simulation.gui = true;
      return {Flag::Success, "GUI enabled"};
    }
  }


#endif


SimulateCommand::SimulateCommand(const scalar_t total_time, const scalar_t timestep) noexcept {
  this->total_time = total_time;
  this->timestep = timestep;
}

Result SimulateCommand::execute(Simulation& simulation) noexcept {
  if (this->total_time <= 0) {
    return {Flag::InvalidInput, "Batch time must be positive"};
  }
  if (this->timestep <= 0) {
    return {Flag::InvalidInput, "Timestep must be positive"};
  }
  if (this->total_time < this->timestep) {
    return {Flag::InvalidInput, "Batch cannot be less than timestep"};
  }
  simulation.system.simulate(this->total_time, this->timestep);
  return {Flag::Success, std::to_string(constants::to_years(this->total_time)) + " yr simulated with " + std::to_string(constants::to_minutes(this->timestep)) + " min timestep"};
}


CreateBodyCommand::CreateBodyCommand(
  const std::string& anchor,
  const std::string& name,
  const scalar_t mass,
  const scalar_t radius,
  const scalar_t luminosity,
  const vector_t<scalar_t>& position,
  const vector_t<scalar_t>& velocity
) noexcept {
  this->anchor = anchor;
  this->name = name;
  this->mass = mass;
  this->radius = radius;
  this->luminosity = luminosity;
  this->position = position;
  this->velocity = velocity;
}

Result CreateBodyCommand::execute(Simulation& simulation) noexcept {
  if (this->anchor != "none") {
    const Body* anchor_ptr = simulation.system.get_body(this->anchor);
    if (anchor_ptr == nullptr) {
      return {Flag::NotFound, anchor + " not found"};
    }
    this->position += anchor_ptr->position;
    this->velocity += anchor_ptr->velocity;
  }
  if (this->name == "none") {
    return {Flag::InvalidInput, "Name cannot be none"};
  }
  if (this->mass == 0.0L) {
    return {Flag::InvalidInput, "Mass cannot be zero"};
  }
  if (this->radius == 0.0L) {
    return {Flag::InvalidInput, "Radius cannot be zero"};
  }
  if (this->luminosity < 0.0L) {
    return {Flag::InvalidInput, "Luminosity cannot be negative"};
  }
  return simulation.system.create_body(this->name, this->mass, this->radius, this->luminosity, this->position, this->velocity);
}


ModifyBodyCommand::ModifyBodyCommand(
  const std::string& name,
  const std::optional<scalar_t> mass,
  const std::optional<scalar_t> radius,
  const std::optional<scalar_t> luminosity,
  const std::optional<scalar_t> pos_x,
  const std::optional<scalar_t> pos_y,
  const std::optional<scalar_t> pos_z,
  const std::optional<scalar_t> vel_x,
  const std::optional<scalar_t> vel_y,
  const std::optional<scalar_t> vel_z
) noexcept {
  this->name = name;
  this->mass = mass;
  this->radius = radius;
  this->luminosity = luminosity;
  this->pos_x = pos_x;
  this->pos_y = pos_y;
  this->pos_z = pos_z;
  this->vel_x = vel_x;
  this->vel_y = vel_y;
  this->vel_z = vel_z;
}

Result ModifyBodyCommand::execute(Simulation& simulation) noexcept {
  Body* body = simulation.system.get_body(this->name);
  if (body == nullptr) {
    return {Flag::NotFound, this->name + " not found"};
  }
  if (this->mass != std::nullopt) {
    body->mass = this->mass.value();
  }
  if (this->radius != std::nullopt) {
    body->radius = this->radius.value();
  }
  if (this->luminosity != std::nullopt) {
    body->luminosity = this->luminosity.value();
  }
  if (this->pos_x != std::nullopt) {
    body->position.x = this->pos_x.value();
  }
  if (this->pos_y != std::nullopt) {
    body->position.y = this->pos_y.value();
  }
  if (this->pos_z != std::nullopt) {
    body->position.z = this->pos_z.value();
  }
  if (this->vel_x != std::nullopt) {
    body->velocity.x = this->vel_x.value();
  }
  if (this->vel_y != std::nullopt) {
    body->velocity.y = this->vel_y.value();
  }
  if (this->vel_z != std::nullopt) {
    body->velocity.z = this->vel_z.value();
  }
  return {Flag::Success, this->name + " modified"};
}


DestroyBodyCommand::DestroyBodyCommand(const std::string& name) noexcept {
  this->name = name;
}

Result DestroyBodyCommand::execute(Simulation& simulation) noexcept {
  if (this->name == "none") {
    return {Flag::InvalidInput, "Name cannot be none"};
  }
  return simulation.system.destroy_body(this->name);
}


Result PurgeBodiesCommand::execute(Simulation& simulation) noexcept {
  simulation.save("purgesave");
  return simulation.system.purge_bodies();
}


Result ToggleCollisionsCommand::execute(Simulation& simulation) noexcept {
  simulation.system.collisions = !simulation.system.collisions;
  return {Flag::Success, "Collisions " + std::string(simulation.system.collisions ? "enabled" : "disabled")};
}


SpeedUpCommand::SpeedUpCommand(const scalar_t factor) noexcept {
  this->factor = factor;
}

Result SpeedUpCommand::execute(Simulation& simulation) noexcept {
  simulation.system.total_time *= this->factor;
  simulation.system.timestep *= this->factor;
  return {Flag::Success, std::string("Total time and timestep multiplied by ") + std::to_string(this->factor)};
}


FocusViewCommand::FocusViewCommand(const std::size_t index, const std::string& name_one, const std::string& name_two) noexcept {
  this->index = index;
  this->name_one = name_one;
  this->name_two = name_two;
}

Result FocusViewCommand::execute(Simulation& simulation) noexcept {
  if ((this->index < 0) || (this->index > 6)) {
    return {Flag::InvalidInput, "Index must be 0, 1, 2, 3, 4, or 5"};
  }
  if (this->name_one == "none") {
    return {Flag::InvalidInput, "Name one cannot be none"};
  }
  return simulation.display.views[this->index].focus(this->name_one, this->name_two);
}


ScaleViewCommand::ScaleViewCommand(const std::size_t index, const scalar_t radius) noexcept {
  this->index = index;
  this->radius = radius;
}

Result ScaleViewCommand::execute(Simulation& simulation) noexcept {
  if ((this->index < 0) || (this->index > 6)) {
    return {Flag::InvalidInput, "Index must be 0, 1, 2, 3, 4, or 5"};
  }
  if (this-> radius <= 0.0) {
    return {Flag::InvalidInput, "Radius must be positive"};
  }
  return simulation.display.views[this->index].scale(this->radius);
}


ViewPresetsCommand::ViewPresetsCommand(const std::size_t index, const std::string& name) noexcept {
  this->index = index;
  this->name = name;
}

Result ViewPresetsCommand::execute(Simulation& simulation) noexcept {
  if ((this->index < 0) || (this->index > 6)) {
    return {Flag::InvalidInput, "Index must be 0, 1, 2, 3, 4, or 5"};
  }
  SystemView& view = simulation.display.views[this->index];

  if (this->name == "Asteroid Belt") {
    view.focus("Sol", "none");
    view.scale(constants::JUPITER_DISTANCE * 1.05L);
  } else if (this->name == "Kuiper Belt") {
    view.focus("Sol", "none");
    view.scale(constants::ERIS_DISTANCE * 1.05L);
  } else if (this->name == "Earth") {
    view.focus("Earth", "none");
    view.scale(constants::LUNA_DISTANCE * 1.05L);
  } else if (this->name == "Mars") {
    view.focus("Mars", "none");
    view.scale(constants::DEIMOS_DISTANCE * 1.05L);
  } else if (this->name == "Jupiter") {
    view.focus("Jupiter", "none");
    view.scale(constants::CALLISTO_DISTANCE * 1.05L);
  } else if (this->name == "Hektor") {
    view.focus("Hektor", "none");
    view.scale(constants::SKAMANDRIOS_DISTANCE * 1.05L);
  } else if (this->name == "Patroclus") {
    view.focus("Patroclus", "Menoetius");
    view.scale(constants::MENOETIUS_DISTANCE * 1.05L);
  } else if (this->name == "Saturn") {
    view.focus("Saturn", "none");
    view.scale(constants::IAPETUS_DISTANCE * 1.05L);
  } else if (this->name == "Uranus") {
    view.focus("Uranus", "none");
    view.scale(constants::OBERON_DISTANCE * 1.05L);
  } else if (this->name == "Neptune") {
    view.focus("Neptune", "none");
    view.scale(constants::TRITON_DISTANCE * 1.05L);
  } else if (this->name == "Orcus") {
    view.focus("Orcus", "Vanth");
    view.scale(constants::VANTH_DISTANCE * 1.05L);
  } else if (this->name == "Lempo") {
    view.focus("Lempo", "Hiisi");
    view.scale(constants::PAHA_DISTANCE * 1.05L);
  } else if (this->name == "Pluto") {
    view.focus("Pluto", "Charon");
    view.scale(constants::HYDRA_DISTANCE * 1.05L);
  } else if (this->name == "Haumea") {
    view.focus("Haumea", "none");
    view.scale(constants::HI_IAKA_DISTANCE * 1.05L);
  } else if (this->name == "Quaoar") {
    view.focus("Quaoar", "none");
    view.scale(constants::WEYWOT_DISTANCE * 1.05L);
  } else if (this->name == "Gonggong") {
    view.focus("Gonggong", "none");
    view.scale(constants::XIANGLIU_DISTANCE * 1.05L);
  } else if (this->name == "Makemake") {
    view.focus("Makemake", "none");
    view.scale(constants::MO_O_DISTANCE * 1.05L);
  } else if (this->name == "Eris") {
    view.focus("Eris", "none");
    view.scale(constants::DYSNOMIA_DISTANCE * 1.05L);
  } else {
    return {Flag::InvalidInput, "View preset name not recognized"};
  }
  return {Flag::Success, "View focused and scaled to " + name};
}


RotatePerspectiveCommand::RotatePerspectiveCommand(const scalar_t angle, const physics::Axis axis) noexcept {
  this->angle = angle;
  this->axis = axis;
}

Result RotatePerspectiveCommand::execute(Simulation& simulation) noexcept {
  simulation.system.right.rotate(this->angle, this->axis);
  simulation.system.upward.rotate(this->angle, this->axis);
  simulation.system.forward.rotate(this->angle, this->axis);
  std::string symbol;
  switch (this->axis) {
    case physics::Axis::X: symbol = "X"; break;
    case physics::Axis::Y: symbol = "Y"; break;
    case physics::Axis::Z: symbol = "Z"; break;
  }
  return {Flag::Success, "Perspective rotated " + std::to_string(constants::to_degrees(this->angle)) + " degrees about " + symbol};
}


ZoomPerspectiveCommand::ZoomPerspectiveCommand(const scalar_t factor) noexcept {
  this->factor = factor;
}

Result ZoomPerspectiveCommand::execute(Simulation& simulation) noexcept {
  simulation.system.zoom *= this->factor;
  return {Flag::Success, "Perspective zoomed by factor of " + std::to_string(this->factor)};
}


PanPerspectiveCommand::PanPerspectiveCommand(const scalar_t increment, const physics::Axis axis) noexcept {
  this->increment = increment;
  this->axis = axis;
}

Result PanPerspectiveCommand::execute(Simulation& simulation) noexcept {
  switch(this->axis) {
    case physics::Axis::X:
      simulation.system.pan_x += this->increment;
      return {Flag::Success, "Perspective panned along X by " + std::to_string(this->increment)};
    case physics::Axis::Y:
      simulation.system.pan_y += this->increment;
      return {Flag::Success, "Perspective panned along Y by " + std::to_string(this->increment)};
    case physics::Axis::Z:
      return {Flag::InvalidInput, "Pan axis cannot be Z"};
  }
}


SaveCommand::SaveCommand(const std::string& filename) noexcept {
  this->filename = filename;
}

Result SaveCommand::execute(Simulation& simulation) noexcept {
  return simulation.save(this->filename);
}


LoadCommand::LoadCommand(const std::string& filename) noexcept {
  this->filename = filename;
}

Result LoadCommand::execute(Simulation& simulation) noexcept {
  return simulation.load(this->filename);
}


Result PauseResumeCommand::execute(Simulation& simulation) noexcept {
  simulation.pause = !simulation.pause;
  return {Flag::Success, "Simulation " + std::string(simulation.pause ? "paused" : "resumed")};
}


Result StopCommand::execute(Simulation& simulation) noexcept {
  simulation.save("stopsave");
  simulation.running = false;
  return {Flag::Success, "Simulation stopped"};
}


// command queue


void CommandQueue::push(std::unique_ptr<Command> command) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->queue.push(std::move(command));
}

std::unique_ptr<Command> CommandQueue::pop() noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  if (this->queue.empty()) {
    return nullptr;
  }
  std::unique_ptr<Command> command = std::move(this->queue.front());
  this->queue.pop();
  return command;
}

bool CommandQueue::empty() const noexcept {
  std::lock_guard<std::mutex> lock (this->mtx);
  return this->queue.empty();
}
