#pragma once

#include "../../utils/constants.hpp"
// Constants

#include "../../utils/geometry.hpp"
// geometry::

typedef double scalar_t;

template<typename S>
using vector_t = geometry::Vector3D<S>;

constexpr scalar_t MASS = 1.0L; // kg * MASS = mass unit
// 1.0L / 1.98847e30L; // Solar mass
constexpr scalar_t DISTANCE = 1.0L; // m * DISTANCE = distance unit
// 1.0L / 1.495978707e11L; // Astronomical unit
constexpr scalar_t TIME = 1.0L; // s * TIME = time unit
// 1.0L / 31557600.0L; // Year

using constants = Constants<scalar_t, MASS, DISTANCE, TIME>;
