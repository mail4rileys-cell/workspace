#pragma once

#include <cstdint>
// std::uint8_t

#include <string>
// std::string

enum class Flag : std::uint8_t {
  Success = 0,
  NotFound = 1,
  AlreadyExists = 2,
  InvalidInput = 3,
  UnsupportedVersion = 4
};

struct Result final {
  Flag flag;
  std::string message;
};
