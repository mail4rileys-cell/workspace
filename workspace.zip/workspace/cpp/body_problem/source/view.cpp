#include <cstddef>
// std::size_t

#include <functional>
// std::function

#include <string>
// std::string

#include "interface.hpp"
// Interface

#include "view.hpp"
// BodyView
// DataView
// InterfaceView

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

DataView::DataView(std::vector<std::function<std::string()>> fields, const std::size_t width, const std::size_t height) noexcept {
  this->fields = fields;
  this->width = width * 2;
  this->height = height;
}

windowlib::Window DataView::get_window() const noexcept {
  windowlib::Window window(this->height);
  for (std::size_t i = 0; i < this->fields.size(); i++) {
    window[i] = this->fields[i]();
  }
  for (std::size_t i = 0; i < this->height; i++) {
    window[i] = format::pad_right(window[i], this->width);
  }
  return window;
}

InterfaceView::InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept 
  : interface(interface) {
  this->width = width * 2;
  this->height = height;
}

windowlib::Window InterfaceView::get_window() const noexcept {
  windowlib::Window window(this->height);
  std::size_t line = 0;
  const std::string buffer = interface.read();
  for (std::size_t i = 0; i < buffer.size(); i++) {
    if (line == this->height) {
      break;
    } else if (buffer[i] == '\n') {
      line++;
      continue;
    }
    window[line] += buffer[i];
  }
  for (std::size_t i = 0; i < this->height; i++) {
    window[i] = format::pad_right(window[i], this->width);
  }
  return window;
}