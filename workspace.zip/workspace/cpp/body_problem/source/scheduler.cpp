#include <chrono>
using namespace std::chrono_literals;

#include <cstddef>
// std::size_t

#include <memory>
// std::make_unique

#include <optional>
// std::optional
// std::nullopt

#include <stdexcept>
// std::runtime_error

#include <string>
// std::string

#include <thread>
// std::this_thread

#include <lua.hpp>
// Lua

#include "command.hpp"
// CommandQueue
// Command

#include "config.hpp"
// scalar_t
// vector_t
// constants::

#include "scheduler.hpp"
// Scheduler

#include "simulation.hpp"
// Simulation
// Body

#include "../../utils/physics.hpp"
// physics::

__attribute__((cold, noinline))
int Scheduler::lua_command(lua_State* L) {

	Scheduler* self = *static_cast<Scheduler**>(lua_getextraspace(L));

	if (!lua_isstring(self->Lua, -2) || (!lua_istable(self->Lua, -1))) {
		lua_pop(self->Lua, 2);
		return 0;
	}
	
	const std::string command = lua_tostring(self->Lua, -2);

	auto get_string = [self](const std::string& name) -> std::string {
		lua_getfield(self->Lua, -1, name.c_str());
		const std::string result = lua_tostring(self->Lua, -1);
		lua_pop(self->Lua, 1);
		return result;
	};

	auto get_number = [self](const std::string& name) -> scalar_t {
		lua_getfield(self->Lua, -1, name.c_str());
		const scalar_t result = lua_tonumber(self->Lua, -1);
		lua_pop(self->Lua, 1);
		return result;
	};

	//auto get_optional_string = [self](const std::string& name) -> std::optional<std::string> {
		//lua_getfield(self->Lua, -1, name.c_str());
		//if (lua_isnil(self->Lua, -1)) {
			//lua_pop(self->Lua, 1);
			//return std::nullopt;
		//}
		//std::optional<std::string> result = lua_tostring(self->Lua, -1);
		//lua_pop(self->Lua, 1);
		//return result;
	//};

	auto get_optional_number = [self](const std::string& name) -> std::optional<scalar_t> {
		lua_getfield(self->Lua, -1, name.c_str());
		if (lua_isnil(self->Lua, -1)) {
			lua_pop(self->Lua, 1);
			return std::nullopt;
		}
		std::optional<scalar_t> result = lua_tonumber(self->Lua, -1);
		lua_pop(self->Lua, 1);
		return result;
	};

	if (command == "simulate") {
		self->command_queue.push(std::make_unique<SimulateCommand>(
			constants::seconds(get_number("total_time")),
			constants::seconds(get_number("timestep"))
		));
	#ifdef GRAPHICS
		} else if (command == "toggle_gui") {
			self->command_queue.push(std::make_unique<ToggleGuiCommand>());
	#endif
	} else if (command == "create_body") {
		self->command_queue.push(std::make_unique<CreateBodyCommand>(
			get_string("anchor"),
			get_string("name"),
			constants::kilograms(get_number("mass")),
			constants::meters(get_number("radius")),
			constants::watts(get_number("luminosity")),
			vector_t<scalar_t>(
				constants::meters(get_number("pos_x")),
				constants::meters(get_number("pos_y")),
				constants::meters(get_number("pos_z"))
			),
			vector_t<scalar_t>(
				constants::meters_per_second(get_number("vel_x")),
				constants::meters_per_second(get_number("vel_y")),
				constants::meters_per_second(get_number("vel_z"))
			)
		));
	} else if (command == "modify_body") {
		std::optional<scalar_t> mass = get_optional_number("mass");
		if (mass.has_value()) {
			mass.value() = constants::kilograms(mass.value());
		}
		std::optional<scalar_t> radius = get_optional_number("radius");
		if (radius.has_value()) {
			radius.value() = constants::meters(radius.value());
		}
		std::optional<scalar_t> luminosity = get_optional_number("luminosity");
		if (luminosity.has_value()) {
			luminosity.value() = constants::watts(luminosity.value());
		}
		std::optional<scalar_t> pos_x = get_optional_number("pos_x");
		if (pos_x.has_value()) {
			pos_x.value() = constants::meters(pos_x.value());
		}
		std::optional<scalar_t> pos_y = get_optional_number("pos_y");
		if (pos_y.has_value()) {
			pos_y.value() = constants::meters(pos_y.value());
		}
		std::optional<scalar_t> pos_z = get_optional_number("pos_z");
		if (pos_z.has_value()) {
			pos_z.value() = constants::meters(pos_z.value());
		}
		std::optional<scalar_t> vel_x = get_optional_number("vel_x");
		if (vel_x.has_value()) {
			vel_x.value() = constants::meters_per_second(vel_x.value());
		}
		std::optional<scalar_t> vel_y = get_optional_number("vel_y");
		if (vel_y.has_value()) {
			vel_y.value() = constants::meters_per_second(vel_y.value());
		}
		std::optional<scalar_t> vel_z = get_optional_number("vel_z");
		if (vel_z.has_value()) {
			vel_z.value() = constants::meters_per_second(vel_z.value());
		}
		self->command_queue.push(std::make_unique<ModifyBodyCommand>(
			get_string("name"),
			mass,
			radius,
			luminosity,
			pos_x,
			pos_y,
			pos_z,
			vel_x,
			vel_y,
			vel_z			
		));
	} else if (command == "destroy_body") {
		self->command_queue.push(std::make_unique<DestroyBodyCommand>(
			get_string("name")
		));
	} else if (command == "purge_bodies") {
		self->command_queue.push(std::make_unique<PurgeBodiesCommand>());
	} else if (command == "toggle_collisions") {
		self->command_queue.push(std::make_unique<ToggleCollisionsCommand>());
	} else if (command == "speed_up") {
		self->command_queue.push(std::make_unique<SpeedUpCommand>(
			get_number("factor")                         	
		));
	} else if (command == "focus_view") {
		self->command_queue.push(std::make_unique<FocusViewCommand>(
			static_cast<std::size_t>(get_number("index")),
			get_string("name_one"),
			get_string("name_two")
		));
	} else if (command == "scale_view") {
		self->command_queue.push(std::make_unique<ScaleViewCommand>(
			static_cast<std::size_t>(get_number("index")),
			constants::meters(get_number("radius"))
		));
	} else if (command == "view_presets") {
		self->command_queue.push(std::make_unique<ViewPresetsCommand>(
			static_cast<std::size_t>(get_number("index")),
			get_string("name")
		));	
	} else if (command == "rotate_perspective") {
		physics::Axis axis;
		const std::string a = get_string("axis");
		if ((a == "1") || (a == "x") || (a == "X")) {
			axis = physics::Axis::X;
		} else if ((a == "2") || (a == "y") || (a == "Y")) {
			axis = physics::Axis::Y;
		} else if ((a == "3") || (a == "z") || (a == "Z")) {
			axis = physics::Axis::Z;
		}
		self->command_queue.push(std::make_unique<RotatePerspectiveCommand>(
			constants::degrees(get_number("angle")),
			axis
		));
	} else if (command == "zoom_in") {
		self->command_queue.push(std::make_unique<ZoomInCommand>(
			get_number("factor")	                      	
		));
	} else if (command == "save") {
		self->command_queue.push(std::make_unique<SaveCommand>(
			get_string("filename")
		));
	} else if (command == "load") {
		self->command_queue.push(std::make_unique<LoadCommand>(
			get_string("filename")
		));
	} else if (command == "pause_resume") {
		self->command_queue.push(std::make_unique<PauseResumeCommand>());
	} else if (command == "stop") {
		self->command_queue.push(std::make_unique<StopCommand>());
		lua_pop(self->Lua, 2);
	}
	return 0;
}

__attribute__((cold, noinline))
int Scheduler::lua_get_body(lua_State* L) {

	Scheduler* self = *static_cast<Scheduler**>(lua_getextraspace(L));

	if (!lua_isstring(self->Lua, -1)) {
		lua_pop(self->Lua, 1);
		lua_pushnil(self->Lua);
		return 1;
	}

	const std::string name = lua_tostring(self->Lua, -1);
	lua_pop(self->Lua, 1);

	Body* body = self->simulation.system.get_body(name);

	if (body == nullptr) {
		lua_pushnil(self->Lua);
		return 1;
	}

	lua_newtable(self->Lua);

	lua_pushnumber(self->Lua, body->mass);
	lua_setfield(self->Lua, -2, "mass");
	
	lua_pushnumber(self->Lua, body->radius);
	lua_setfield(self->Lua, -2, "radius");
	
	lua_pushnumber(self->Lua, body->luminosity);
	lua_setfield(self->Lua, -2, "luminosity");

	lua_pushnumber(self->Lua, body->position.x);
	lua_setfield(self->Lua, -2, "pos_x");

	lua_pushnumber(self->Lua, body->position.y);
	lua_setfield(self->Lua, -2, "pos_y");

	lua_pushnumber(self->Lua, body->position.z);
	lua_setfield(self->Lua, -2, "pos_z");

	lua_pushnumber(self->Lua, body->velocity.x);
	lua_setfield(self->Lua, -2, "vel_x");

	lua_pushnumber(self->Lua, body->velocity.y);
	lua_setfield(self->Lua, -2, "vel_y");

	lua_pushnumber(self->Lua, body->velocity.z);
	lua_setfield(self->Lua, -2, "vel_z");

	return 1;
}

__attribute__((cold, noinline))
int Scheduler::lua_get_names(lua_State* L) {
	Scheduler* self = *static_cast<Scheduler**>(lua_getextraspace(L));
	lua_newtable(self->Lua);
	for (std::size_t i = 0; i < self->simulation.system.bodies.size(); i++) {
		lua_pushstring(self->Lua, self->simulation.system.bodies[i].name.c_str());
		lua_seti(self->Lua, -2, i + 1);
	}
	return 1;
}

__attribute__((cold, noinline))
void Scheduler::loop() const {
  auto autosave = std::chrono::high_resolution_clock::now() + 5min;
  auto lua = std::chrono::high_resolution_clock::now() + 1s;
  while (this->running) {
    const auto now = std::chrono::high_resolution_clock::now();
    if (now >= autosave) {
      this->command_queue.push(std::make_unique<SaveCommand>("autosave"));
      autosave += 5min;
    } else if (now >= lua) {
    	lua_getglobal(this->Lua, "debug");
    	lua_getfield(this->Lua, -1, "traceback");
    	lua_remove(this->Lua, -2);
    	const int errfunc = lua_gettop(this->Lua);
    	lua_getglobal(this->Lua, "TICK");
    	lua_pushnumber(this->Lua, 1);
    	if (lua_pcall(this->Lua, 1, 2, errfunc) != LUA_OK) {
    		const char* msg = lua_tostring(this->Lua, -1);
    		const std::string err = msg ? msg : "unknown Lua error";
    		lua_pop(this->Lua, 1);
    		lua_remove(this->Lua, errfunc);
    		throw std::runtime_error(err);
    	}
    	lua_remove(this->Lua, errfunc);
    	lua += 1s;
    }
  }
}

// public

__attribute__((cold, noinline))
Scheduler::Scheduler(Simulation& simulation, CommandQueue& command_queue)
: simulation(simulation), command_queue(command_queue) {
	this->Lua = luaL_newstate();
	*static_cast<Scheduler**>(lua_getextraspace(this->Lua)) = this;
	luaL_openlibs(this->Lua);
  lua_getglobal(this->Lua, "package");
  lua_getfield(this->Lua, -1, "path");
  std::string path = lua_tostring(this->Lua, -1);
  path = "cpp/body_problem/mods/?.lua;" + path;
  lua_pop(this->Lua, 1);
  lua_pushstring(this->Lua, path.c_str());
  lua_setfield(this->Lua, -2, "path");
  lua_pop(this->Lua, 1);
	luaL_dofile(this->Lua, "cpp/body_problem/mods/main.lua");
	lua_register(this->Lua, "command", Scheduler::lua_command);
	lua_register(this->Lua, "get_body", Scheduler::lua_get_body);
	lua_register(this->Lua, "get_names", Scheduler::lua_get_names);
	lua_getglobal(this->Lua, "debug");
	lua_getfield(this->Lua, -1, "traceback");
	lua_remove(this->Lua, -2);
	const int errfunc = lua_gettop(this->Lua);
	lua_getglobal(this->Lua, "INIT");
	if (lua_pcall(this->Lua, 0, 0, errfunc) != LUA_OK) {
		const char* msg = lua_tostring(this->Lua, -1);
		const std::string err = msg ? msg : "unknown Lua error";
		lua_pop(this->Lua, 1);
		lua_remove(this->Lua, errfunc);
		throw std::runtime_error(err);
	}
	lua_remove(this->Lua, errfunc);
}

__attribute__((cold, noinline))
void Scheduler::start() noexcept {
  this->running = true;
  this->thread = std::thread([this](){
    this->loop();
  });
}

__attribute__((cold, noinline))
void Scheduler::stop() noexcept {
  this->running = false;
  if (this->thread.joinable()) {
    this->thread.join();
  }
}
