#include <cstddef>
// std::size_t

#include <memory>
// std::unique_ptr
// std::make_unique

#include <mutex>
// std::lock_guard
// std::mutex

#include <optional>
// std::optional
// std::nullopt

#include <string>
// std::string
// std::to_string
// std::stold

#include <utility>
// std::move

#include "command.hpp"
// Command
// CommandQueue

#include "interface.hpp"
// Interface
// IntefaceView

#include "types.hpp"
// scalar_t
// vector_t

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::


void Interface::clear() noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer = "";
}

void Interface::write(const std::string& text) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer += text;
}

void Interface::writeln(const std::string& text) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer += text + "\n";
}

std::string Interface::get_text(const std::string& prompt) noexcept {
  this->clear();
  this->write(prompt);
  return this->keyboard.get_line();
}

scalar_t Interface::get_number(const std::string& prompt) noexcept {
  this->clear();
  this->write(prompt);
  scalar_t input;
  try {
    return static_cast<scalar_t>(std::stold(this->keyboard.get_line()));
  } catch (const std::invalid_argument&) {
    return 0.0L;
  } catch (const std::out_of_range&) {
    return 0.0L;
  }
}

void Interface::confirm_command_menu(std::unique_ptr<Command> command) noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Confirm command");
    this->writeln("---------------");
    this->writeln("1. Push to batch");
    this->writeln("2. Push to queue");
    this->writeln("3. Quit");
    this->writeln("---------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "push to batch") || (input == "ptb")) {
      this->command_batch.push(std::move(command));
      return;
    } else if ((input == "2") || (input == "push to queue") || (input == "ptq")) {
      this->command_queue.push(std::move(command));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::command_batch_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Command batch");
    this->writeln("-------------");
    this->writeln("1. Push");
    this->writeln("2. Clear");
    this->writeln("3. Quit");
    this->writeln("-------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "push") || (input == "ptq")) {
      while (!this->command_batch.empty()) {
        this->command_queue.push(std::move(this->command_batch.front()));
        this->command_batch.pop();
      }
      return;
    } else if ((input == "2") || (input == "clear") || (input == "cc")) {
      while (!this->command_batch.empty()) {
        this->command_batch.pop();
      }
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::simulate_menu() noexcept {
  static scalar_t total_time = 0.0L;
  static scalar_t timestep = 0.0L;
  while (this->running) {
    this->clear();
    this->writeln("Simulate");
    this->writeln("--------");
    this->writeln("1. Total time: " + std::to_string(total_time) + " yr");
    this->writeln("2. Timestep: " + std::to_string(timestep) + " min");
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("--------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "total time") || (input == "tt")) {
      total_time = this->get_number("Input total time: ");
    } else if ((input == "2") || (input == "timestep") || (input == "t")) {
      timestep = this->get_number("Input timestep: ");
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<SimulateCommand>(total_time * physics::EARTH_PERIOD<scalar_t>, timestep * 60.0L));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::create_body_menu() noexcept {
  static std::string anchor = "none";
  static std::string name = "default";
  static scalar_t mass = 0.0L;
  static scalar_t radius = 0.0L;
  static vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
  static vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
  while (this->running) {
    this->clear();
    this->writeln("Create body");
    this->writeln("-----------");
    this->writeln("1. Anchor: " + anchor);
    this->writeln("2. Name: " + name);
    this->writeln("3. Mass: " + std::to_string(mass) + " kg");
    this->writeln("4. Radius: " + std::to_string(radius) + " m");
    this->writeln("5. Pos x: " + std::to_string(position.x) + " m");
    this->writeln("6. Pos y: " + std::to_string(position.y) + " m");
    this->writeln("7. Pos z: " + std::to_string(position.z) + " m");
    this->writeln("8. Vel x: " + std::to_string(velocity.x) + " m/s");
    this->writeln("9. Vel y: " + std::to_string(velocity.y) + " m/s");
    this->writeln("10. Vel z: " + std::to_string(velocity.z) + " m/s");
    this->writeln("11. Confirm command");
    this->writeln("12. Quit");
    this->writeln("-----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "anchor") || (input == "a")) {
      anchor = this->get_text("Input anchor: ");
    } else if ((input == "2") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "3") || (input == "mass") || (input == "m")) {
      mass = this->get_number("Input mass: ");
    } else if ((input == "4") || (input == "radius") || (input == "r")) {
      radius = this->get_number("Input radius: ");
    } else if ((input == "5") || (input == "pos x") || (input == "px")) {
      position.x = this->get_number("Input pos x: ");
    } else if ((input == "6") || (input == "pos y") || (input == "py")) {
      position.y = this->get_number("Input pos y: ");
    } else if ((input == "7") || (input == "pos z") || (input == "pz")) {
      position.z = this->get_number("Input pos z: ");
    } else if ((input == "8") || (input == "vel x") || (input == "vx")) {
      velocity.x = this->get_number("Input vel x: ");
    } else if ((input == "9") || (input == "vel y") || (input == "vy")) {
      velocity.y = this->get_number("Input vel y: ");
    } else if ((input == "10") || (input == "vel z") || (input == "vz")) {
      velocity.z = this->get_number("Input vel z: ");
    } else if ((input == "11") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<CreateBodyCommand>(anchor, name, mass, radius, position, velocity));
      return;
    } else if ((input == "12") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::modify_body_menu() noexcept {
  static std::string name = "default";
  static std::optional<scalar_t> mass = std::nullopt;
  static std::optional<scalar_t> radius = std::nullopt;
  static std::optional<scalar_t> pos_x = std::nullopt;
  static std::optional<scalar_t> pos_y = std::nullopt;
  static std::optional<scalar_t> pos_z = std::nullopt;
  static std::optional<scalar_t> vel_x = std::nullopt;
  static std::optional<scalar_t> vel_y = std::nullopt;
  static std::optional<scalar_t> vel_z = std::nullopt;
  while (this->running) {
    this->clear();
    this->writeln("Modify body");
    this->writeln("-----------");
    this->writeln("1. Name: " + name);
    this->writeln("2. Mass: " + (mass ? (std::to_string(mass.value()) + " kg") : "none"));
    this->writeln("3. Radius: " + (radius ? (std::to_string(radius.value()) + " m") : "none"));
    this->writeln("4. Pos x: " + (pos_x ? (std::to_string(pos_x.value()) + " m") : "none"));
    this->writeln("5. Pos y: " + (pos_y ? (std::to_string(pos_y.value()) + " m") : "none"));
    this->writeln("6. Pos z: " + (pos_z ? (std::to_string(pos_z.value()) + " m") : "none"));
    this->writeln("7. Vel x: " + (vel_x ? (std::to_string(vel_x.value()) + " m/s") : "none"));
    this->writeln("8. Vel y: " + (vel_y ? (std::to_string(vel_y.value()) + " m/s") : "none"));
    this->writeln("9. Vel z: " + (vel_z ? (std::to_string(vel_z.value()) + " m/s") : "none"));
    this->writeln("10. Reset");
    this->writeln("11. Confirm command");
    this->writeln("12. Quit");
    this->writeln("-----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "2") || (input == "mass") || (input == "m")) {
      mass = this->get_number("Input mass: ");
    } else if ((input == "3") || (input == "radius") || (input == "r")) {
      radius = this->get_number("Input radius: ");
    } else if ((input == "4") || (input == "pos x") || (input == "px")) {
      pos_x = this->get_number("Input pos x: ");
    } else if ((input == "5") || (input == "pos y") || (input == "py")) {
      pos_y = this->get_number("Input pos y: ");
    } else if ((input == "6") || (input == "pos z") || (input == "pz")) {
      pos_z = this->get_number("Input pos z: ");
    } else if ((input == "7") || (input == "vel x") || (input == "vx")) {
      vel_x = this->get_number("Input vel x: ");
    } else if ((input == "8") || (input == "vel y") || (input == "vy")) {
      vel_y = this->get_number("Input vel y: ");
    } else if ((input == "9") || (input == "vel z") || (input == "vz")) {
      vel_z = this->get_number("Input vel z: ");
    } else if ((input == "10") || (input == "reset") || (input == "r")) {
      mass = std::nullopt;
      radius = std::nullopt;
      pos_x = std::nullopt;
      pos_y = std::nullopt;
      pos_z = std::nullopt;
      vel_x = std::nullopt;
      vel_y = std::nullopt;
      vel_z = std::nullopt;
    } else if ((input == "11") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ModifyBodyCommand>(name, mass, radius, pos_x, pos_y, pos_z, vel_x, vel_y, vel_z));
      return;
    } else if ((input == "12") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::destroy_body_menu() noexcept {
  static std::string name = "default";
  while (this->running) {
    this->clear();
    this->writeln("Destroy body");
    this->writeln("------------");
    this->writeln("1. Name: " + name);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<DestroyBodyCommand>(name));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::purge_bodies_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("WARNING: THIS DESTROYS ALL BODIES");
    this->writeln("Purge bodies");
    this->writeln("------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<PurgeBodiesCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::toggle_collisions_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Toggle collisions");
    this->writeln("-----------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("-----------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ToggleCollisionsCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::focus_view_menu() noexcept {
  static std::size_t index = 0;
  static std::string name_one = "default";
  static std::string name_two = "none";
  while (this->running) {
    this->clear();
    this->writeln("Focus view");
    this->writeln("----------");
    this->writeln("1. Index: " + std::to_string(index));
    this->writeln("2. Name one: " + name_one);
    this->writeln("3. Name two: " + name_two);
    this->writeln("4. Confirm command");
    this->writeln("5. Quit");
    this->writeln("----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "index") || (input == "i")) {
      index = static_cast<std::size_t>(this->get_number("Input index: "));
    } else if ((input == "2") || (input == "name one") || (input == "no")) {
      name_one = this->get_text("Input name one: ");
    } else if ((input == "3") || (input == "name two") || (input == "nt")) {
      name_two = this->get_text("Input name two: ");
    } else if ((input == "4") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<FocusViewCommand>(index, name_one, name_two));
      return;
    } else if ((input == "5") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::scale_view_menu() noexcept {
  static std::size_t index = 0;
  static scalar_t radius = 0.0L;
  while (this->running) {
    this->clear();
    this->writeln("Scale view");
    this->writeln("----------");
    this->writeln("1. Index: " + std::to_string(index));
    this->writeln("2. Radius: " + std::to_string(radius));
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "index") || (input == "i")) {
      index = static_cast<std::size_t>(this->get_number("Input index: "));
    } else if ((input == "2") || (input == "radius") || (input == "r")) {
      radius = this->get_number("Input radius: ");
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ScaleViewCommand>(index, radius));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::save_menu() noexcept {
  static std::string filename = "default";
  while (this->running) {
    this->clear();
    this->writeln("Save");
    this->writeln("----");
    this->writeln("1. Filename: " + filename);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "filename") || (input == "f")) {
      filename = this->get_text("Input filename: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<SaveCommand>(filename));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }  
}

void Interface::load_menu() noexcept {
  static std::string filename = "default";
  while (this->running) {
    this->clear();
    this->writeln("Load");
    this->writeln("----");
    this->writeln("1. Filename: " + filename);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "filename") || (input == "f")) {
      filename = this->get_text("Input filename: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<LoadCommand>(filename));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::pause_resume_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Pause / Resume");
    this->writeln("--------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("--------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "dc")) {
      this->confirm_command_menu(std::make_unique<PauseResumeCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::stop_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Stop");
    this->writeln("----");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<StopCommand>());
      this->running = false;
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

void Interface::main_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Main menu");
    this->writeln("---------");
    this->writeln("1. Command batch");
    this->writeln("2. Simulate");
    this->writeln("3. Create body");
    this->writeln("4. Modify body");
    this->writeln("5. Destroy body");
    this->writeln("6. Purge bodies");
    this->writeln("7. Toggle collisions");
    this->writeln("8. Focus view");
    this->writeln("9. Scale view");
    this->writeln("10. Save");
    this->writeln("11. Load");
    this->writeln("12. Pause / Resume");
    this->writeln("13. Stop");
    this->writeln("---------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "command batch") || (input == "cb")) {
      this->command_batch_menu();
    } else if ((input == "2") || (input == "simulate") || (input == "s")) {
      this->simulate_menu();
    } else if ((input == "3") || (input == "create body") || (input == "cb")) {
      this->create_body_menu();
    } else if ((input == "4") || (input == "modify body") || (input == "mb")) {
      this->modify_body_menu();
    } else if ((input == "5") || (input == "destroy body") || (input == "db")) {
      this->destroy_body_menu();
    } else if ((input == "6") || (input == "purge bodies") || (input == "pb")) {
      this->purge_bodies_menu();
    } else if ((input == "7") || (input == "toggle collisions") || (input == "tg")) {
      this->toggle_collisions_menu();
    } else if ((input == "8") || (input == "focus view") || (input == "fv")) {
      this->focus_view_menu();
    } else if ((input == "9") || (input == "scale view") || (input == "sv")) {
      this->scale_view_menu();
    } else if ((input == "10") || (input == "save") || (input == "s")) {
      this->save_menu();
    } else if ((input == "11") || (input == "load") || (input == "l")) {
      this->load_menu();
    } else if ((input == "12") || (input == "pause resume") || (input == "pr")) {
      this->pause_resume_menu();
    } else if ((input == "13") || (input == "stop") || (input == "s")) {
      this->stop_menu();
    }
  }
}

// public

__attribute__((cold, noinline))
Interface::Interface(CommandQueue& command_queue) noexcept
: command_queue(command_queue) {}

[[nodiscard]] __attribute__((hot))
std::string Interface::read() const noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  return this->buffer;
}

__attribute__((cold, noinline))
void Interface::start() noexcept {

  this->running = true;
  this->input_thread = std::thread([this](){
    this->main_menu();
  });
}

__attribute__((cold, noinline))
void Interface::stop() noexcept {
  this->running = false;
  terminal::enable_echo();
  if (this->input_thread.joinable()) {
    this->input_thread.join();
  }
}


__attribute__((cold, noinline))
InterfaceView::InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept 
  : interface(interface) {
  this->width = width * 2;
  this->height = height;
}

[[nodiscard]] __attribute__((hot))
windowlib::Window InterfaceView::get_window() const noexcept {
  windowlib::Window window(this->height);
  std::size_t line = 0;
  const std::string buffer = this->interface.read();
  for (std::size_t i = 0; i < buffer.size(); i++) {
    if (line == this->height) {
      break;
    } else if (buffer[i] == '\n') {
      line++;
      continue;
    }
    window[line] += buffer[i];
  }
  for (std::size_t i = 0; i < this->height; i++) {
    window[i] = format::pad_right(window[i], this->width);
  }
  window[this->height - 1] = format::pad_right(">: " + this->interface.keyboard.read(), this->width);
  return windowlib::border(window);
}