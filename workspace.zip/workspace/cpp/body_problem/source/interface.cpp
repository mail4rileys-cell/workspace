#include <cstddef>
// std::size_t

#include <memory>
// std::unique_ptr
// std::make_unique

#include <mutex>
// std::lock_guard
// std::mutex

#include <optional>
// std::optional
// std::nullopt

#include <string>
// std::string
// std::to_string
// std::stold

#include <utility>
// std::move

#include "command.hpp"
// Command
// CommandQueue

#include "config.hpp"
// scalar_t
// vector_t
// constants::

#include "interface.hpp"
// Interface
// IntefaceView

#include "../../utils/format.hpp"
// format::

#include "../../utils/geometry.hpp"
// geometry::

#include "../../utils/terminal.hpp"
// terminal::

#include "../../utils/windowlib.hpp"
// windowlib::

__attribute__((hot))
void Interface::clear() noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer = "";
}

__attribute__((hot))
void Interface::write(const std::string& text) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer += text;
}

__attribute__((hot))
void Interface::writeln(const std::string& text) noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  this->buffer += text + "\n";
}

[[nodiscard]] __attribute__((cold, noinline))
std::string Interface::get_text(const std::string& prompt) noexcept {
  this->clear();
  this->write(prompt);
  return this->keyboard.get_line();
}

[[nodiscard]] __attribute__((cold, noinline))
scalar_t Interface::get_number(const std::string& prompt) noexcept {
  this->clear();
  this->write(prompt);
  try {
    return static_cast<scalar_t>(std::stold(this->keyboard.get_line()));
  } catch (const std::invalid_argument&) {
    return 0.0L;
  } catch (const std::out_of_range&) {
    return 0.0L;
  }
}

__attribute__((cold, noinline))
void Interface::confirm_command_menu(std::unique_ptr<Command> command) noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Confirm command");
    this->writeln("---------------");
    this->writeln("1. Push to batch");
    this->writeln("2. Push to queue");
    this->writeln("3. Quit");
    this->writeln("---------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "push to batch") || (input == "ptb")) {
      this->command_batch.push(std::move(command));
      return;
    } else if ((input == "2") || (input == "push to queue") || (input == "ptq")) {
      this->command_queue.push(std::move(command));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::command_batch_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Command batch");
    this->writeln("-------------");
    this->writeln("1. Push");
    this->writeln("2. Clear");
    this->writeln("3. Quit");
    this->writeln("-------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "push") || (input == "ptq")) {
      while (!this->command_batch.empty()) {
        this->command_queue.push(std::move(this->command_batch.front()));
        this->command_batch.pop();
      }
      return;
    } else if ((input == "2") || (input == "clear") || (input == "cc")) {
      while (!this->command_batch.empty()) {
        this->command_batch.pop();
      }
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::simulate_menu() noexcept {
  static scalar_t total_time = 0.0L;
  static scalar_t timestep = 0.0L;
  while (this->running) {
    this->clear();
    this->writeln("Simulate");
    this->writeln("--------");
    this->writeln("1. Total time: " + std::to_string(constants::to_years(total_time)) + " yr");
    this->writeln("2. Timestep: " + std::to_string(constants::to_minutes(timestep)) + " min");
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("--------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "total time") || (input == "tt")) {
      total_time = constants::years(this->get_number("Input total time: "));
    } else if ((input == "2") || (input == "timestep") || (input == "t")) {
      timestep = constants::minutes(this->get_number("Input timestep: "));
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<SimulateCommand>(total_time, timestep));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::create_body_menu() noexcept {
  static std::string anchor = "none";
  static std::string name = "default";
  static scalar_t mass = 0.0L;
  static scalar_t radius = 0.0L;
  static scalar_t luminosity = 0.0L;
  static vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
  static vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
  while (this->running) {
    this->clear();
    this->writeln("Create body");
    this->writeln("-----------");
    this->writeln("1. Anchor: " + anchor);
    this->writeln("2. Name: " + name);
    this->writeln("3. Mass: " + std::to_string(constants::to_earth_masses(mass)) + " EM");
    this->writeln("4. Radius: " + std::to_string(constants::to_kilometers(radius)) + " km");
    this->writeln("5. Luminosity: " + std::to_string(constants::to_solar_luminosities(luminosity)) + " SL");
    this->writeln("6. Pos x: " + std::to_string(constants::to_astronomical_units(position.x)) + " AU");
    this->writeln("7. Pos y: " + std::to_string(constants::to_astronomical_units(position.y)) + " AU");
    this->writeln("8. Pos z: " + std::to_string(constants::to_astronomical_units(position.z)) + " AU");
    this->writeln("9. Vel x: " + std::to_string(constants::to_kilometers_per_second(velocity.x)) + " km/s");
    this->writeln("10. Vel y: " + std::to_string(constants::to_kilometers_per_second(velocity.y)) + " km/s");
    this->writeln("11. Vel z: " + std::to_string(constants::to_kilometers_per_second(velocity.z)) + " km/s");
    this->writeln("12. Confirm command");
    this->writeln("13. Quit");
    this->writeln("-----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "anchor") || (input == "a")) {
      anchor = this->get_text("Input anchor: ");
    } else if ((input == "2") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "3") || (input == "mass") || (input == "m")) {
      mass = constants::earth_masses(this->get_number("Input mass: "));
    } else if ((input == "4") || (input == "radius") || (input == "r")) {
      radius = constants::kilometers(this->get_number("Input radius: "));
    } else if ((input == "5") || (input == "luminosity") || (input == "l")) {
      luminosity = constants::solar_luminosities(this->get_number("Input luminosity: "));
    } else if ((input == "6") || (input == "pos x") || (input == "px")) {
      position.x = constants::astronomical_units(this->get_number("Input pos x: "));
    } else if ((input == "7") || (input == "pos y") || (input == "py")) {
      position.y = constants::astronomical_units(this->get_number("Input pos y: "));
    } else if ((input == "8") || (input == "pos z") || (input == "pz")) {
      position.z = constants::astronomical_units(this->get_number("Input pos z: "));
    } else if ((input == "9") || (input == "vel x") || (input == "vx")) {
      velocity.x = constants::kilometers_per_second(this->get_number("Input vel x: "));
    } else if ((input == "10") || (input == "vel y") || (input == "vy")) {
      velocity.y = constants::kilometers_per_second(this->get_number("Input vel y: "));
    } else if ((input == "11") || (input == "vel z") || (input == "vz")) {
      velocity.z = constants::kilometers_per_second(this->get_number("Input vel z: "));
    } else if ((input == "12") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<CreateBodyCommand>(anchor, name, mass, radius, luminosity, position, velocity));
      return;
    } else if ((input == "13") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::modify_body_menu() noexcept {
  static std::string name = "default";
  static std::optional<scalar_t> mass = std::nullopt;
  static std::optional<scalar_t> radius = std::nullopt;
  static std::optional<scalar_t> luminosity = std::nullopt;
  static std::optional<scalar_t> pos_x = std::nullopt;
  static std::optional<scalar_t> pos_y = std::nullopt;
  static std::optional<scalar_t> pos_z = std::nullopt;
  static std::optional<scalar_t> vel_x = std::nullopt;
  static std::optional<scalar_t> vel_y = std::nullopt;
  static std::optional<scalar_t> vel_z = std::nullopt;
  while (this->running) {
    this->clear();
    this->writeln("Modify body");
    this->writeln("-----------");
    this->writeln("1. Name: " + name);
    this->writeln("2. Mass: " + (mass ? (std::to_string(constants::to_earth_masses(mass.value())) + " EM") : "none"));
    this->writeln("3. Radius: " + (radius ? (std::to_string(constants::to_kilometers(radius.value())) + " km") : "none"));
    this->writeln("4. Luminosity: " + (luminosity ? (std::to_string(constants::to_solar_luminosities(luminosity.value())) + " SL") : "none"));
    this->writeln("5. Pos x: " + (pos_x ? (std::to_string(constants::to_astronomical_units(pos_x.value())) + " AU") : "none"));
    this->writeln("6. Pos y: " + (pos_y ? (std::to_string(constants::to_astronomical_units(pos_y.value())) + " AU") : "none"));
    this->writeln("7. Pos z: " + (pos_z ? (std::to_string(constants::to_astronomical_units(pos_z.value())) + " AU") : "none"));
    this->writeln("8. Vel x: " + (vel_x ? (std::to_string(constants::to_kilometers_per_second(vel_x.value())) + " km/s") : "none"));
    this->writeln("9. Vel y: " + (vel_y ? (std::to_string(constants::to_kilometers_per_second(vel_y.value())) + " km/s") : "none"));
    this->writeln("10. Vel z: " + (vel_z ? (std::to_string(constants::to_kilometers_per_second(vel_z.value())) + " km/s") : "none"));
    this->writeln("11. Reset");
    this->writeln("12. Confirm command");
    this->writeln("13. Quit");
    this->writeln("-----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "2") || (input == "mass") || (input == "m")) {
      mass = constants::earth_masses(this->get_number("Input mass: "));
    } else if ((input == "3") || (input == "radius") || (input == "r")) {
      radius = constants::kilometers(this->get_number("Input radius: "));
    } else if ((input == "4") || (input == "luminosity") || (input == "l")) {
      luminosity = constants::solar_luminosities(this->get_number("Input luminosity: "));
    } else if ((input == "5") || (input == "pos x") || (input == "px")) {
      pos_x = constants::astronomical_units(this->get_number("Input pos x: "));
    } else if ((input == "6") || (input == "pos y") || (input == "py")) {
      pos_y = constants::astronomical_units(this->get_number("Input pos y: "));
    } else if ((input == "7") || (input == "pos z") || (input == "pz")) {
      pos_z = constants::astronomical_units(this->get_number("Input pos z: "));
    } else if ((input == "8") || (input == "vel x") || (input == "vx")) {
      vel_x = constants::kilometers_per_second(this->get_number("Input vel x: "));
    } else if ((input == "9") || (input == "vel y") || (input == "vy")) {
      vel_y = constants::kilometers_per_second(this->get_number("Input vel y: "));
    } else if ((input == "10") || (input == "vel z") || (input == "vz")) {
      vel_z = constants::kilometers_per_second(this->get_number("Input vel z: "));
    } else if ((input == "11") || (input == "reset") || (input == "r")) {
      mass = std::nullopt;
      radius = std::nullopt;
      luminosity = std::nullopt;
      pos_x = std::nullopt;
      pos_y = std::nullopt;
      pos_z = std::nullopt;
      vel_x = std::nullopt;
      vel_y = std::nullopt;
      vel_z = std::nullopt;
    } else if ((input == "12") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ModifyBodyCommand>(name, mass, radius, luminosity, pos_x, pos_y, pos_z, vel_x, vel_y, vel_z));
      return;
    } else if ((input == "13") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::destroy_body_menu() noexcept {
  static std::string name = "default";
  while (this->running) {
    this->clear();
    this->writeln("Destroy body");
    this->writeln("------------");
    this->writeln("1. Name: " + name);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<DestroyBodyCommand>(name));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::purge_bodies_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("WARNING: THIS DESTROYS ALL BODIES");
    this->writeln("Purge bodies");
    this->writeln("------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<PurgeBodiesCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::toggle_collisions_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Toggle collisions");
    this->writeln("-----------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("-----------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ToggleCollisionsCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::speed_up_menu() noexcept {
  static scalar_t factor = 1.0L;
  while (this->running) {
    this->clear();
    this->writeln("Speed up");
    this->writeln("--------");
    this->writeln("1. Factor: " + std::to_string(factor));
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("--------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "factor") || (input == "f")) {
      factor = this->get_number("Input factor: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<SpeedUpCommand>(factor));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::focus_view_menu() noexcept {
  static std::size_t index = 0ULL;
  static std::string name_one = "default";
  static std::string name_two = "none";
  while (this->running) {
    this->clear();
    this->writeln("Focus view");
    this->writeln("----------");
    this->writeln("1. Index: " + std::to_string(index));
    this->writeln("2. Name one: " + name_one);
    this->writeln("3. Name two: " + name_two);
    this->writeln("4. Confirm command");
    this->writeln("5. Quit");
    this->writeln("----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "index") || (input == "i")) {
      index = static_cast<std::size_t>(this->get_number("Input index: "));
    } else if ((input == "2") || (input == "name one") || (input == "no")) {
      name_one = this->get_text("Input name one: ");
    } else if ((input == "3") || (input == "name two") || (input == "nt")) {
      name_two = this->get_text("Input name two: ");
    } else if ((input == "4") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<FocusViewCommand>(index, name_one, name_two));
      return;
    } else if ((input == "5") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::scale_view_menu() noexcept {
  static std::size_t index = 0ULL;
  static scalar_t radius = 0.0L;
  while (this->running) {
    this->clear();
    this->writeln("Scale view");
    this->writeln("----------");
    this->writeln("1. Index: " + std::to_string(index));
    this->writeln("2. Radius: " + std::to_string(constants::to_astronomical_units(radius)) + " AU");
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("----------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "index") || (input == "i")) {
      index = static_cast<std::size_t>(this->get_number("Input index: "));
    } else if ((input == "2") || (input == "radius") || (input == "r")) {
      radius = constants::astronomical_units(this->get_number("Input radius: "));
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ScaleViewCommand>(index, radius));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::view_presets_menu() noexcept {
  static std::size_t index = 0ULL;
  static std::string name = "default";
  while (this->running) {
    this->clear();
    this->writeln("View presets");
    this->writeln("------------");
    this->writeln("1. Index: " + std::to_string(index));
    this->writeln("2. Name: " + name);
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("------------");
    #ifdef SOL
      this->writeln("Asteriod Belt    | Outer Saturn   | Haumea");
      this->writeln("Kuiper Belt      | Typhon         | Quaoar");
      this->writeln("Earth            | Inner Uranus   | Makemake");
      this->writeln("Mars             | Middle Uranus  | Eris");
      this->writeln("Inner Jupiter    | Outer Uranus   |");
      this->writeln("Galilean Jupiter | Inner Neptune  |");
      this->writeln("Outer Jupiter    | Middle Neptune |");
      this->writeln("Hektor           | Outer Neptune  |");
      this->writeln("Patroclus        | Orcus          |");
      this->writeln("Inner Saturn     | Lempo          |");
      this->writeln("Middle Saturn    | Pluto          |");
    #elifdef CENTAURI
      this->writeln("Alpha Centauri | Centauri | Proxima Centauri");
    #elifdef KEPLER_90
      this->writeln("Kepler-90");
    #elifdef LICH
      this->writeln("Lich");
    #elifdef TRAPPIST_1
      this->writeln("TRAPPIST-1");
    #endif
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "index") || (input == "i")) {
      index = static_cast<std::size_t>(this->get_number("Input index: "));
    } else if ((input == "2") || (input == "name") || (input == "n")) {
      name = this->get_text("Input name: ");
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ViewPresetsCommand>(index, name));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::rotate_perspective_menu() noexcept {
  static scalar_t angle = 0.0L;
  static std::string axis_str = "x";
  while (this->running) {
    this->clear();
    this->writeln("Rotate perspective");
    this->writeln("------------------");
    this->writeln("1. Angle: " + std::to_string(constants::to_degrees(angle)));
    this->writeln("2. Axis: " + axis_str);
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("------------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "angle") || (input == "a")) {
      angle = constants::degrees(this->get_number("Input angle: "));
    } else if ((input == "2") || (input == "axis") || (input == "a")) {
      axis_str = this->get_text("Input axis: ");     
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<RotatePerspectiveCommand>(angle, geometry::to_axis(axis_str)));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::zoom_perspective_menu() noexcept {
  static scalar_t factor;
  while (this->running) {
    this->clear();
    this->writeln("Zoom perspective");
    this->writeln("----------------");
    this->writeln("1. Factor: " + std::to_string(factor));
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("----------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "factor") || (input == "f")) {
      factor = this->get_number("Input factor: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<ZoomPerspectiveCommand>(factor));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::pan_perspective_menu() noexcept {
  static scalar_t increment;
  static std::string axis_str = "x";
  while (this->running) {
    this->clear();
    this->writeln("Pan perspective");
    this->writeln("---------------");
    this->writeln("1. Increment: " + std::to_string(increment));
    this->writeln("2. Axis: " + axis_str);
    this->writeln("3. Confirm command");
    this->writeln("4. Quit");
    this->writeln("---------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "increment") || (input == "i")) {
      increment = this->get_number("Input increment: ");
    } else if ((input == "2") || (input == "axis") || (input == "a")) {
      axis_str = this->get_text("Input axis: ");
    } else if ((input == "3") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<PanPerspectiveCommand>(increment, geometry::to_axis(axis_str)));
      return;
    } else if ((input == "4") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::save_menu() noexcept {
  static std::string filename = "default";
  while (this->running) {
    this->clear();
    this->writeln("Save");
    this->writeln("----");
    this->writeln("1. Filename: " + filename);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "filename") || (input == "f")) {
      filename = this->get_text("Input filename: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<SaveCommand>(filename));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }  
}

__attribute__((cold, noinline))
void Interface::load_menu() noexcept {
  static std::string filename = "default";
  while (this->running) {
    this->clear();
    this->writeln("Load");
    this->writeln("----");
    this->writeln("1. Filename: " + filename);
    this->writeln("2. Confirm command");
    this->writeln("3. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "filename") || (input == "f")) {
      filename = this->get_text("Input filename: ");
    } else if ((input == "2") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<LoadCommand>(filename));
      return;
    } else if ((input == "3") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::pause_resume_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Pause / Resume");
    this->writeln("--------------");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("--------------");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "dc")) {
      this->confirm_command_menu(std::make_unique<PauseResumeCommand>());
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::stop_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Stop");
    this->writeln("----");
    this->writeln("1. Confirm command");
    this->writeln("2. Quit");
    this->writeln("----");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "confirm command") || (input == "cc")) {
      this->confirm_command_menu(std::make_unique<StopCommand>());
      this->running = false;
      return;
    } else if ((input == "2") || (input == "quit") || (input == "q")) {
      return;
    }
  }
}

__attribute__((cold, noinline))
void Interface::main_menu() noexcept {
  while (this->running) {
    this->clear();
    this->writeln("Main menu");
    this->writeln("+----------------------------------------------+");
    this->writeln("| 1. Command batch        | 15. Save           |");
    this->writeln("| 2. Simulate             | 16. Load           |");
    this->writeln("| 3. Create body          | 17. Pause / Resume |");
    this->writeln("| 4. Modify body          | 18. Stop           |");
    this->writeln("| 5. Destroy body         |                    |");
    this->writeln("| 6. Purge bodies         |                    |");
    this->writeln("| 7. Toggle collisions    |                    |");
    this->writeln("| 8. Speed up             |                    |");
    this->writeln("| 9. Focus view           |                    |");
    this->writeln("| 10. Scale view          |                    |");
    this->writeln("| 11. View presets        |                    |");
    this->writeln("| 12. Rotate perspective  |                    |");
    this->writeln("| 13. Zoom in perspective |                    |");
    this->writeln("| 14. Pan perspective     |                    |");
    this->writeln("+----------------------------------------------+");
    const std::string input = this->keyboard.get_line();
    if ((input == "1") || (input == "command batch") || (input == "cb")) {
      this->command_batch_menu();
    } else if ((input == "2") || (input == "simulate") || (input == "s")) {
      this->simulate_menu();
    } else if ((input == "3") || (input == "create body") || (input == "cb")) {
      this->create_body_menu();
    } else if ((input == "4") || (input == "modify body") || (input == "mb")) {
      this->modify_body_menu();
    } else if ((input == "5") || (input == "destroy body") || (input == "db")) {
      this->destroy_body_menu();
    } else if ((input == "6") || (input == "purge bodies") || (input == "pb")) {
      this->purge_bodies_menu();
    } else if ((input == "7") || (input == "toggle collisions") || (input == "tg")) {
      this->toggle_collisions_menu();
    } else if ((input == "8") || (input == "speed up") || (input == "sp")) {
      this->speed_up_menu();
    } else if ((input == "9") || (input == "focus view") || (input == "fv")) {
      this->focus_view_menu();
    } else if ((input == "10") || (input == "scale view") || (input == "sv")) {
      this->scale_view_menu();
    } else if ((input == "11") || (input == "view presets") || (input == "vp")) {
      this->view_presets_menu();
    } else if ((input == "12") || (input == "rotate perspective") || (input == "rp")) {
      this->rotate_perspective_menu();
    } else if ((input == "13") || (input == "zoom in") || (input == "zi")) {
      this->zoom_perspective_menu();
    } else if ((input == "14") || (input == "pan perspective") || (input == "pp")) {
      this->pan_perspective_menu();
    } else if ((input == "15") || (input == "save") || (input == "s")) {
      this->save_menu();
    } else if ((input == "16") || (input == "load") || (input == "l")) {
      this->load_menu();
    } else if ((input == "17") || (input == "pause resume") || (input == "pr")) {
      this->pause_resume_menu();
    } else if ((input == "18") || (input == "stop") || (input == "s")) {
      this->stop_menu();
    }
  }
}

// public

__attribute__((cold, noinline))
Interface::Interface(CommandQueue& command_queue) noexcept
: command_queue(command_queue) {

  #ifdef GRAPHICS
    this->keyboard.bind('|', [this]() -> void {
      this->command_queue.push(std::make_unique<ToggleGuiCommand>());             
    });
  #endif

  this->keyboard.bind('+', [this]() -> void {
    this->command_queue.push(std::make_unique<SpeedUpCommand>(2.0L));
  });
  this->keyboard.bind('_', [this]() -> void {
    this->command_queue.push(std::make_unique<SpeedUpCommand>(0.5L));
  });

  static std::size_t index = 0ULL;
  #ifdef SOL
    constexpr std::size_t N = 26;
  #elifdef CENTAURI
    constexpr std::size_t N = 2;
  #elifdef KEPLER_90
    constexpr std::size_t N = 0;
  #elifdef LICH
    constexpr std::size_t N = 0;
  #elifdef TRAPPIST_1
    constexpr std::size_t N = 0;
  #else
    constexpr std::size_t N = 0;
  #endif
  auto cycle = [this]() -> void {
    switch (index) {
      #ifdef SOL
        case 0: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Asteroid Belt")); break;
        case 1: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Kuiper Belt")); break;
        case 2: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Earth")); break;
        case 3: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Mars")); break;
        case 4: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Inner Jupiter")); break;
        case 5: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Galilean Jupiter")); break;
        case 6: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Outer Jupiter")); break;
        case 7: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Hektor")); break;
        case 8: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Patroclus")); break;
        case 9: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Inner Saturn")); break;
        case 10: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Middle Saturn")); break;
        case 11: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Outer Saturn")); break;
        case 12: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Typhon")); break;
        case 13: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Inner Uranus")); break;
        case 14: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Middle Uranus")); break;
        case 15: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Outer Uranus")); break;
        case 16: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Inner Neptune")); break;
        case 17: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Middle Neptune")); break;
        case 18: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Outer Neptune")); break;
        case 19: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Orcus")); break;
        case 20: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Lempo")); break;
        case 21: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Pluto")); break;
        case 22: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Haumea")); break;
        case 23: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Quaoar")); break;
        case 24: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Gonggong")); break;
        case 25: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Makemake")); break;
        case 26: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Eris")); break;
      #elifdef CENTAURI
        case 0: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Alpha Centauri")); break;
        case 1: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Centauri")); break;
        case 2: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Proxima Centauri")); break;
      #elifdef KEPLER_90
        case 0: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Kepler-90")); break;
      #elifdef LICH
        case 0: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "Lich")); break;
      #elifdef TRAPPIST_1
        case 0: this->command_queue.push(std::make_unique<ViewPresetsCommand>(0, "TRAPPIST-1")); break;
      #endif
    }
  };
  this->keyboard.bind('>', [cycle]() -> void {
    if (index == N) {
      index = 0;
    } else {
      index++;
    }
    cycle();
  });
  this->keyboard.bind('<', [cycle]() -> void {
    if (index == 0) {
      index = N;
    } else {
      index--;
    }
    cycle();
  });

  this->keyboard.bind('!', [this]() -> void {
    this->command_queue.push(std::make_unique<RotatePerspectiveCommand>(constants::degrees(5), geometry::Axis::X));
  });
  this->keyboard.bind('@', [this]() -> void {
    this->command_queue.push(std::make_unique<RotatePerspectiveCommand>(constants::degrees(5), geometry::Axis::Y));
  });
  this->keyboard.bind('#', [this]() -> void {
    this->command_queue.push(std::make_unique<RotatePerspectiveCommand>(constants::degrees(5), geometry::Axis::Z));
  });

  this->keyboard.bind('$', [this]() -> void {
    this->command_queue.push(std::make_unique<PanPerspectiveCommand>(-0.01, geometry::Axis::X));
  });
  this->keyboard.bind('%', [this]() -> void {
    this->command_queue.push(std::make_unique<PanPerspectiveCommand>(0.01, geometry::Axis::X));
  });
  this->keyboard.bind('^', [this]() ->void {
    this->command_queue.push(std::make_unique<PanPerspectiveCommand>(-0.01, geometry::Axis::Y));
  });
  this->keyboard.bind('&', [this]() -> void {
    this->command_queue.push(std::make_unique<PanPerspectiveCommand>(0.01, geometry::Axis::Y));  
  });

  this->keyboard.bind('}', [this]() -> void {
    this->command_queue.push(std::make_unique<ZoomPerspectiveCommand>(1.1L));    
  });
  this->keyboard.bind('{', [this]() -> void {
    this->command_queue.push(std::make_unique<ZoomPerspectiveCommand>(1.0L / 1.1L));    
  });

  this->keyboard.bind('~', [this]() -> void {
    this->command_queue.push(std::make_unique<StopCommand>());
  });
  this->keyboard.bind('/', [this]() -> void {
    this->command_queue.push(std::make_unique<PauseResumeCommand>());
  });
}

[[nodiscard]] __attribute__((hot))
std::string Interface::read() const noexcept {
  std::lock_guard<std::mutex> lock(this->mtx);
  return this->buffer;
}

__attribute__((cold, noinline))
void Interface::start() noexcept {
  terminal::enable_raw();
  terminal::disable_cursor();
  this->running = true;
  this->thread = std::thread([this](){
    this->main_menu();
  });
}

__attribute__((cold, noinline))
void Interface::stop() noexcept {
  terminal::disable_raw();
  terminal::enable_cursor();
  this->running = false;
  if (this->thread.joinable()) {
    this->thread.join();
  }
}


__attribute__((cold, noinline))
InterfaceView::InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept 
  : interface(interface) {
  this->width = width * 2;
  this->height = height;
}

[[nodiscard]] __attribute__((hot))
windowlib::Window InterfaceView::get_window() const noexcept {
  windowlib::Window window(this->height);
  std::size_t line = 0;
  const std::string buffer = this->interface.read();
  for (std::size_t i = 0; i < buffer.size(); i++) {
    if (line == this->height) {
      break;
    } else if (buffer[i] == '\n') {
      line++;
      continue;
    }
    window[line] += buffer[i];
  }
  for (std::size_t i = 0; i < this->height; i++) {
    window[i] = format::pad_right(window[i], this->width);
  }
  window[this->height - 1] = format::pad_right(">: " + this->interface.keyboard.read(), this->width);
  return windowlib::border(window);
}
