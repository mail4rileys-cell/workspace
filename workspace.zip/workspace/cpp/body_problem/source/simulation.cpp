#include <cstddef>
// std::size_t

#include <cstdint>
// std::uintmax_t

#include <filesystem>
// std::filesystem::

#include <fstream>
// std::ifstream
// std::ofstream

#include <iomanip>
// std::scientific
// std::setprecision

#include <iostream>
// std::endl

#include <limits>
// std::numerical_limit

#include <string>
// std::string
// std::to_string
// std::stoull

#include "result.hpp"
// Flag
// Result

#include "types.hpp"
// scalar_t
// vector_t
// object_t

#include "simulation.hpp"
// SolarSystem
// SolarSystemView
// Display
// Simulation

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

__attribute__((cold, noinline))
SolarSystem::SolarSystem() noexcept {
  for (std::size_t i = 0; i < this->bodies.size(); i++) {
    for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
      const physics::GetGravityResult gravity = physics::get_gravity<object_t, vector_t, scalar_t>(
        this->bodies[i],
        this->bodies[j]
      );
      this->original_energy -= gravity.potential_energy;
    }
    this->original_energy += physics::get_kinetic_energy<object_t, vector_t, scalar_t>(this->bodies[i]);
  }
}

__attribute__((hot))
void SolarSystem::simulate(const scalar_t total_time, const scalar_t timestep) noexcept {
  [[assume(total_time > 0)]];
  [[assume(timestep > 0)]];
  [[assume(total_time >= timestep)]];
  const std::uintmax_t steps = static_cast<std::uintmax_t>(total_time / timestep);
  this->energy = 0.0L;
  for (std::uintmax_t step = 0; step < steps; step++) {
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      this->bodies[i].acceleration = {0, 0, 0};
    }
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
        const physics::GetGravityResult gravity = physics::get_gravity<object_t, vector_t, scalar_t>(
          this->bodies[i],
          this->bodies[j]
        );
        if (this->collisions && (gravity.distance < (this->bodies[i].radius + this->bodies[j].radius))) {
          const object_t<vector_t, scalar_t> merged = {
            this->bodies[i].mass + this->bodies[j].mass,
            physics::get_combined_radius(this->bodies[i], this->bodies[j]),
            physics::get_barycenter(this->bodies[i], this->bodies[j]),
            physics::get_combined_velocity(this->bodies[i], this->bodies[j]),
            physics::get_combined_acceleration(this->bodies[i], this->bodies[j])
          };
          if (this->bodies[i].mass > this->bodies[j].mass) {
            this->bodies[i] = merged;
            this->destroy_body(this->names[j]);
          } else {
            this->bodies[j] = merged;
            this->destroy_body(this->names[i]);
          }
        } else {
          this->bodies[i].apply(gravity.force);
          this->bodies[j].apply(-gravity.force);
          if (step == (steps - 1)) {
            this->energy -= gravity.potential_energy;
          }
        }
      }
    }
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      this->bodies[i].integrate(timestep);
      if (step == (steps - 1)) {
        this->energy += physics::get_kinetic_energy<object_t, vector_t, scalar_t>(this->bodies[i]);
      }
    }
  }
  this->time += total_time;
}

[[nodiscard]] __attribute__((hot, pure))
object_t<vector_t, scalar_t>* SolarSystem::get_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      return &this->bodies[i];
    }
  }
  return nullptr;
}

__attribute__((cold, noinline))
Result SolarSystem::create_body(
  const std::string& name,
  const scalar_t mass,
  const scalar_t radius,
  const vector_t<scalar_t>& position,
  const vector_t<scalar_t>& velocity
) noexcept {
  if (this->get_body(name) != nullptr) {
    return {Flag::AlreadyExists, name + " already exists"};
  }
  this->names.push_back(name);
  this->bodies.push_back(object_t<vector_t, scalar_t>(mass, radius, position, velocity, {0, 0, 0}));
  return {Flag::Success, name + " created"};
}

__attribute__((cold, noinline))
Result SolarSystem::destroy_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      this->names.erase(this->names.begin() + i);
      this->bodies.erase(this->bodies.begin() + i);
      return {Flag::Success, name + " destroyed"};
    }
  }
  return {Flag::NotFound, name + " not found"};
}

__attribute__((cold, noinline))
Result SolarSystem::purge_bodies() noexcept {
  this->names.clear();
  this->bodies.clear();
  return {Flag::Success, "Bodies purged"};
}


__attribute__((cold, noinline))
SolarSystemView::SolarSystemView(
  SolarSystem& solar_system,
  const std::string& name_one,
  const std::string& name_two,
  const scalar_t radius,
  const std::size_t width,
  const std::size_t height
) noexcept : solar_system(solar_system) {
  this->name_one = name_one;
  this->name_two = name_two;
  this->radius = radius;
  this->width = width;
  this->height = height;
}

[[nodiscard]] __attribute__((hot, pure))
windowlib::Window SolarSystemView::get_window() const noexcept {
  windowlib::Window window(this->height);
  vector_t<scalar_t> focus;
  if (this->name_two == "none") {
    const object_t<vector_t, scalar_t>* body = this->solar_system.get_body(this->name_one);
    if (body == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
    }
    focus = body->position;
  } else {
    const object_t<vector_t, scalar_t>* body_one = this->solar_system.get_body(this->name_one);
    if (body_one == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
    }
    const object_t<vector_t, scalar_t>* body_two = this->solar_system.get_body(this->name_two);
    if (body_two == nullptr) {
      window[0] = this->name_two + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return window;
    }
    focus = physics::get_barycenter(*body_one, *body_two);
  }
  std::vector<std::vector<std::string>> grid(this->height, std::vector<std::string>(this->width, "  "));
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      grid[y][x] = "  ";
    }
  }
  for (std::size_t i = 0; i < this->solar_system.bodies.size(); i++) {
    const vector_t<scalar_t> normal = physics::get_delta<vector_t, scalar_t>(focus, this->solar_system.bodies[i].position) / this->radius;
    if ((normal.x < -1.0L) || (normal.x > 1.0L) || (normal.y < -1.0L) || (normal.y > 1.0L) || (normal.z < -1.0L) || (normal.z > 1.0L)) {
      continue;
    }
    const std::size_t x = static_cast<std::size_t>(((normal.x + 1.0L) * 0.5L * this->width));
    const std::size_t y = (this->height - 1) - static_cast<std::size_t>((normal.y + 1.0L) * 0.5L * this->height);
    if (grid[y][x] != "  ") {
      continue;
    }
    grid[y][x] = format::grayscale(format::pad_right(solar_system.names[i], 2), (normal.z + 1.0L) * 0.5L);
  }
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      window[y] += grid[y][x];
    }
  }
  return windowlib::title(window, ((this->name_two == "none") ? this->name_one : (this->name_one + "-and-" + this->name_two)));
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SolarSystemView::get_name_one() const noexcept {
  return this->name_one;
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SolarSystemView::get_name_two() const noexcept {
  return this->name_two;
}

[[nodiscard]] __attribute__((cold, noinline))
scalar_t SolarSystemView::get_radius() const noexcept {
  return this->radius;
}

__attribute__((cold, noinline))
Result SolarSystemView::focus(const std::string& name_one, const std::string& name_two) noexcept {
  this->name_one = name_one;
  this->name_two = name_two;
  return {Flag::Success, "View focused on " + this->name_one + " and " + this->name_two};
}

__attribute__((cold, noinline))
Result SolarSystemView::scale(const scalar_t radius) noexcept {
  this->radius = radius;
  return {Flag::Success, "View scaled to " + std::to_string(this->radius) + " m"};
}


[[nodiscard]] __attribute__((hot, pure))
windowlib::Window Display::get_window(const std::size_t index) const noexcept {
  return this->views[index].get_window();
}


__attribute__((cold, noinline))
Simulation::Simulation(SolarSystem& solar_system, Display& display, const bool pause) noexcept
: solar_system(solar_system), display(display) {
  this->pause = pause;
}

__attribute__((cold, noinline))
Result Simulation::save(const std::string& filename) const noexcept {
  std::ifstream version_file("cpp/body_problem/version.txt");
  std::string version;
  version_file >> version;
  version_file.close();
  std::ofstream file("cpp/body_problem/saves/" + filename + ".sim");
  file << std::scientific << std::setprecision(std::numeric_limits<scalar_t>::max_digits10);
  file << "version = " << version << std::endl;
  file << std::endl;
  file << "solar_system = {" << std::endl;
  for (std::size_t i = 0; i < this->solar_system.bodies.size(); i++) {
    file << std::endl;
    file << "  " << this->solar_system.names[i] << " = {" << std::endl;
    file << "    mass = " << this->solar_system.bodies[i].mass << std::endl;
    file << "    radius = " << this->solar_system.bodies[i].radius << std::endl;
    file << "    position = {" << std::endl;
    file << "      x = " << this->solar_system.bodies[i].position.x << std::endl;
    file << "      y = " << this->solar_system.bodies[i].position.y << std::endl;
    file << "      z = " << this->solar_system.bodies[i].position.z << std::endl;
    file << "    }" << std::endl;
    file << "    velocity = {" << std::endl;
    file << "      x = " << this->solar_system.bodies[i].velocity.x << std::endl;
    file << "      y = " << this->solar_system.bodies[i].velocity.y << std::endl;
    file << "      z = " << this->solar_system.bodies[i].velocity.z << std::endl;
    file << "    }" << std::endl;
    file << "  }" << std::endl;
  }
  file << std::endl;
  file << "  time = " << this->solar_system.time << std::endl;
  file << std::endl;
  file << "  collisions = " << this->solar_system.collisions << std::endl;
  file << "}" << std::endl;
  file << std::endl;
  file << std::endl;
  file << "display = {" << std::endl;
  for (std::size_t i = 0; i < 7; i++) {
    file << std::endl;
    file << "  " << i << " = {" << std::endl;
    file << "    name_one = " << this->display.views[i].get_name_one() << std::endl;
    file << "    name_two = " << this->display.views[i].get_name_two() << std::endl;
    file << "    radius = " << this->display.views[i].get_radius() << std::endl;
    file << "  }" << std::endl;
  }
  file << "}" << std::endl;
  file.close();
  return {Flag::Success, "Simulation saved to " + filename};
}

__attribute__((cold, noinline))
Result Simulation::load(const std::string& filename) noexcept {
  if (!std::filesystem::exists("cpp/body_problem/saves/" + filename + ".sim")) {
    return {Flag::NotFound, filename + " not found"};
  }
  std::ifstream file("cpp/body_problem/saves/" + filename + ".sim");
  std::string token;
  while (file >> token) {
    if (token == "version") {
      file >> token; // "="
      std::ifstream version_file("cpp/body_problem/version.txt");
      std::string program_version;
      version_file >> program_version;
      version_file.close();
      std::string save_version;
      file >> save_version;
      if (save_version != program_version) {
        return {Flag::UnsupportedVersion, "Save file and program versions do not match"};
      }
    } else if (token == "solar_system") {
      this->solar_system.purge_bodies();
      this->solar_system.time = 0.0L;
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        } else if (token == "time") {
          file >> token; // "="
          file >> this->solar_system.time;
          continue;
        } else if (token == "collisions") {
          file >> token; // "="
          file >> this->solar_system.collisions;
          continue;
        }
        std::string name = token;
        file >> token; // "="
        file >> token; // "{"
        scalar_t mass = 0.0L;
        scalar_t radius = 0.0L;
        vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
        vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "mass") {
            file >> token; // "="
            file >> mass;
          } else if (token == "radius") {
            file >> token; // "="
            file >> radius;
          } else if (token == "position") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> position.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> position.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> position.z;
              }
            }
          } else if (token == "velocity") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> velocity.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> velocity.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> velocity.z;
              }
            }
          }
        }
        this->solar_system.create_body(name, mass, radius, position, velocity);
      }
    }
    else if (token == "display") {
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        }
        std::size_t index = std::stoull(token);
        file >> token; // "="
        file >> token; // "{"
        std::string name_one;
        std::string name_two;
        scalar_t radius;
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "name_one") {
            file >> token; // "="
            file >> name_one; // name_one
          } else if (token == "name_two") {
            file >> token; // "="
            file >> name_two; // name_two
          } else if (token == "radius") {
            file >> token; // "="
            file >> radius;
          }
        }
        this->display.views[index].focus(name_one, name_two);
        this->display.views[index].scale(radius);
      }
    }
  }
  file.close();
  return {Flag::Success, "Simulation loaded from " + filename};
}