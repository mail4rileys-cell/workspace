#include <algorithm>
// std::min

#include <cmath>
// cbrt

#include <cstddef>
// std::size_t

#include <cstdint>
// std::uintmax_t

#include <filesystem>
// std::filesystem::

#include <fstream>
// std::ifstream
// std::ofstream

#include <iomanip>
// std::scientific
// std::setprecision

#include <iostream>
// std::endl

#include <limits>
// std::numerical_limit

#include <string>
// std::string
// std::to_string
// std::stoull

#include "config.hpp"
// MASS
// DISTANCE
// TIME
// scalar_t
// vector_t
// constants::

#include "result.hpp"
// Flag
// Result

#include "simulation.hpp"
// Body
// System
// SystemView
// AxesView
// Display
// Simulation

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

__attribute__((cold, noinline))
System::System() noexcept {
  for (std::size_t i = 0; i < this->bodies.size(); i++) {
    Body& a = this->bodies[i];
    for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
      Body& b = this->bodies[j];
      this->original_energy -= (constants::GRAVITATIONAL_CONSTANT * a.mass * b.mass) / ((b.position - a.position)).get_magnitude();
    }
    const scalar_t speed = a.velocity.get_magnitude();
    this->original_energy += (a.mass * speed * speed) / 2;
  }
}

__attribute__((hot))
void System::simulate(const scalar_t total_time, const scalar_t timestep) noexcept {
  [[assume(total_time > 0)]];
  [[assume(timestep > 0)]];
  [[assume(total_time >= timestep)]];
  const std::uintmax_t steps = static_cast<std::uintmax_t>(total_time / timestep);
  this->energy = 0.0L;
  for (std::uintmax_t step = 0; step < steps; step++) {
    std::vector<std::string> destroyed;
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      Body& a = this->bodies[i];
      for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
        Body& b = this->bodies[j];
        const vector_t<scalar_t> displacement = b.position - a.position;
        const scalar_t distance = displacement.get_magnitude();
        const vector_t<scalar_t> direction = displacement / distance;
        const scalar_t potential_energy = (constants::GRAVITATIONAL_CONSTANT * a.mass * b.mass) / distance;
        // gravity
        const vector_t<scalar_t> gravity = (direction * potential_energy) / distance;
        a.net_force += gravity;
        b.net_force -= gravity;
        // radiation pressure
        if (a.luminosity > 0.0L) { // a -> b
        	b.net_force += (direction * a.luminosity * a.radius * b.radius) / (4.0L * constants::LIGHTSPEED * distance * distance);
        }
        if (b.luminosity > 0.0L) { // b -> a
        	a.net_force -= (direction * b.luminosity * a.radius * b.radius) / (4.0L * constants::LIGHTSPEED * distance * distance);
        }
        if (step == (steps - 1)) { // gravitational potential energy
          this->energy -= potential_energy;
        }
      }
      // integration
      a.velocity += (a.net_force / a.mass) * timestep;
      a.position += a.velocity * timestep;
      a.net_force = {0.0L, 0.0L, 0.0L};
      if (a.luminosity > 0.0L) { // radiative mass loss
      	a.mass -= (a.luminosity / (constants::LIGHTSPEED * constants::LIGHTSPEED)) * timestep;
      }
      if (a.mass <= 0.0L) { // disintegrated body
        destroyed.push_back(a.name);
      }
      if (step == (steps - 1)) { // kinetic energy
        const scalar_t speed = a.velocity.get_magnitude();
        this->energy += (a.mass * speed * speed) / 2;
      }
    }
    if (this->collisions) { // inelastic
      for (std::size_t i = 0; i < this->bodies.size(); i++) {
        Body& a = this->bodies[i];
        for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
          Body& b = this->bodies[j];
          if ((b.position - a.position).get_magnitude() < (a.radius + b.radius)) {
            const Body merged = {
              (a.mass > b.mass) ? a.name : b.name,
              a.mass + b.mass,
              std::cbrt((a.radius * a.radius * a.radius) + (b.radius * b.radius * b.radius)),
              a.luminosity + b.luminosity,
              ((a.position * a.mass) + (b.position * b.mass)) / (a.mass + b.mass),
              ((a.velocity * a.mass) + (b.velocity * b.mass)) / (a.mass + b.mass),
              {0.0L, 0.0L, 0.0L}
            };
            if (a.mass > b.mass) {
              this->bodies[i] = merged;
              destroyed.push_back(b.name);
            } else {
              this->bodies[j] = merged;
              destroyed.push_back(a.name);
            }
          }
        }
      }
    }
    for (const std::string& name : destroyed) {
      this->destroy_body(name);
    }
  }
  this->time += total_time;
}

[[nodiscard]] __attribute__((hot, pure))
Body* System::get_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->bodies.size(); i++) {
    if (this->bodies[i].name == name) {
      return &this->bodies[i];
    }
  }
  return nullptr;
}

__attribute__((cold, noinline))
Result System::create_body(
  const std::string& name,
  const scalar_t mass,
  const scalar_t radius,
  const scalar_t luminosity,
  const vector_t<scalar_t>& position,
  const vector_t<scalar_t>& velocity
) noexcept {
  if (this->get_body(name) != nullptr) {
    return {Flag::AlreadyExists, name + " already exists"};
  }
  this->bodies.push_back(Body(name, mass, radius, luminosity, position, velocity, {0, 0, 0}));
  return {Flag::Success, name + " created"};
}

__attribute__((cold, noinline))
Result System::destroy_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->bodies.size(); i++) {
    if (this->bodies[i].name == name) {
      this->bodies.erase(this->bodies.begin() + i);
      return {Flag::Success, name + " destroyed"};
    }
  }
  return {Flag::NotFound, name + " not found"};
}

__attribute__((cold, noinline))
Result System::purge_bodies() noexcept {
  this->bodies.clear();
  return {Flag::Success, "Bodies purged"};
}

__attribute__((cold, noinline))
Result System::rotate(const scalar_t angle, const physics::Axis axis) noexcept {
  this->right.rotate(angle, axis);
  this->upward.rotate(angle, axis);
  this->forward.rotate(angle, axis);
  std::string text;
  switch (axis) {
    case physics::Axis::X: text = "X"; break;
    case physics::Axis::Y: text = "Y"; break;
    case physics::Axis::Z: text = "Z"; break;
  }
  return {Flag::Success, "Views rotated " + std::to_string(constants::to_degrees(angle)) + " degrees about " + text};
}


__attribute__((cold, noinline))
SystemView::SystemView(
  System& system,
  const std::string& name_one,
  const std::string& name_two,
  const scalar_t radius,
  const std::size_t width,
  const std::size_t height
) noexcept : system(system) {
  this->name_one = name_one;
  this->name_two = name_two;
  this->radius = radius;
  this->width = width;
  this->height = height;
}

[[nodiscard]] __attribute__((hot, pure))
windowlib::Window SystemView::get_window() const noexcept {
  windowlib::Window window(this->height);
  vector_t<scalar_t> focus;
  if (this->name_two == "none") {
    const Body* body = this->system.get_body(this->name_one);
    if (body == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, this->name_one);
    }
    focus = body->position;
  } else {
    const Body* body_one = this->system.get_body(this->name_one);
    if (body_one == nullptr) {
      window[0] = this->name_one + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, std::string(this->name_one) + std::string("-and-") + std::string(this->name_two));
    }
    const Body* body_two = this->system.get_body(this->name_two);
    if (body_two == nullptr) {
      window[0] = this->name_two + " not found";
      for (std::size_t i = 0; i < this->height; i++) {
        window[i] = format::pad_right(window[i], this->width * 2);
      }
      return windowlib::title(window, std::string(this->name_one) + std::string("-and-") + std::string(this->name_two));
    }
    focus = ((body_one->position * body_one->mass) + (body_two->position * body_two->mass)) / (body_one->mass + body_two->mass);
  }
  std::vector<std::vector<std::string>> grid(this->height, std::vector<std::string>(this->width, "  "));
  for (const Body& body : this->system.bodies) {
    const vector_t<scalar_t> relative = body.position - focus;
    const vector_t<scalar_t> perspective = vector_t<scalar_t>(
      physics::get_dot<scalar_t>(relative, this->system.right),
      physics::get_dot<scalar_t>(relative, this->system.upward),
      physics::get_dot<scalar_t>(relative, this->system.forward)
    ) / this->radius;
    if ((perspective.x <= -1.0L) || (perspective.x >= 1.0L) || (perspective.y <= -1.0L) || (perspective.y >= 1.0L) || (perspective.z <= -1.0L) || (perspective.z >= 1.0L)) {
      continue;
    }
    const std::size_t x = static_cast<std::size_t>(((perspective.x + 1.0L) * 0.5L * (this->width - 1)));
    const std::size_t y = (this->height - 1) - static_cast<std::size_t>((perspective.y + 1.0L) * 0.5L * (this->height - 1));
    if (grid[y][x] == "  ") {
    	grid[y][x] = format::grayscale(format::pad_right(body.name, 2), (perspective.z + 1.0L) * 0.5L);
    }
  }
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      window[y] += grid[y][x];
    }
  }
  return windowlib::title(window, (this->name_two == "none") ? this->name_one : (std::string(this->name_one) + std::string("-and-") + std::string(this->name_two)));
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SystemView::get_name_one() const noexcept {
  return this->name_one;
}

[[nodiscard]] __attribute__((cold, noinline))
std::string SystemView::get_name_two() const noexcept {
  return this->name_two;
}

[[nodiscard]] __attribute__((cold, noinline))
scalar_t SystemView::get_radius() const noexcept {
  return this->radius;
}

__attribute__((cold, noinline))
Result SystemView::focus(const std::string& name_one, const std::string& name_two) noexcept {
  this->name_one = name_one;
  this->name_two = name_two;
  return {Flag::Success, "View focused on " + this->name_one + " and " + this->name_two};
}

__attribute__((cold, noinline))
Result SystemView::scale(const scalar_t radius) noexcept {
  this->radius = radius;
  return {Flag::Success, "View scaled to " + std::to_string(this->radius) + " m"};
}


__attribute__((cold, noinline))
AxesView::AxesView(System& system, const std::size_t width, const std::size_t height) noexcept
: system(system) {
  this->width = width;
  this->height = height;
}

__attribute__((hot, pure))
windowlib::Window AxesView::get_window() const noexcept {
  windowlib::Window window(this->height, std::string(this->width * 2, ' '));
  const scalar_t scale = std::min(this->width, this->height) * 0.4L;
  const int x0 = this->width / 2;
  const int y0 = this->height / 2;
  auto draw_axis = [&](const vector_t<scalar_t>& axis, const std::string& text) {
    const int x1 = x0 + (axis.x * scale);
    const int y1 = y0 - (axis.y * scale);
    window = windowlib::line(window, text, x0, y0, x1, y1);
  };
  draw_axis(this->system.right, "XX");
  draw_axis(-this->system.right, "::");
  draw_axis(this->system.upward, "YY");
  draw_axis(-this->system.upward, "::");
  draw_axis(this->system.forward, "ZZ");
  draw_axis(-this->system.forward, "::");
  window[y0].replace(x0 * 2, 2, "[]");
  return windowlib::border(window);
}


[[nodiscard]] __attribute__((hot, pure))
windowlib::Window Display::get_window(const std::size_t index) const noexcept {
  return this->views[index].get_window();
}


__attribute__((cold, noinline))
Simulation::Simulation(System& system, Display& display, const bool pause) noexcept
: system(system), display(display) {
  this->pause = pause;
}

__attribute__((cold, noinline))
Result Simulation::save(const std::string& filename) const noexcept {
  std::ifstream version_file("cpp/body_problem/version.txt");
  std::string version;
  version_file >> version;
  version_file.close();
  std::ofstream file("cpp/body_problem/saves/" + filename + ".sim");
  file << std::scientific << std::setprecision(std::numeric_limits<scalar_t>::max_digits10);
  file << "version " << version << std::endl;
  file << std::endl;
  file << "MASS " << MASS << std::endl;
  file << "DISTANCE " << DISTANCE << std::endl;
  file << "TIME " << TIME << std::endl;
  file << std::endl;
  file << "system {" << std::endl;
  file << std::endl;
  file << "  collisions " << this->system.collisions << std::endl;
  file << "  time " << this->system.time << std::endl;
  file << "  total_time " << this->system.total_time << std::endl;
  file << "  timestep " << this->system.timestep << std::endl;
  file << "  original_energy " << this->system.original_energy << std::endl;
  file << "  right " << this->system.right << std::endl;
  file << "  upward " << this->system.upward << std::endl;
  file << "  forward " << this->system.forward << std::endl;
  for (const Body& body : this->system.bodies) {
    file << std::endl;
    file << "  " << body.name << " {" << std::endl;
    file << "    mass " << body.mass << std::endl;
    file << "    radius " << body.radius << std::endl;
    file << "    luminosity " << body.luminosity << std::endl;
    file << "    position " << body.position << std::endl;
    file << "    velocity " << body.velocity << std::endl;
    file << "  }" << std::endl;
  }
  file << "}" << std::endl;
  file << std::endl;
  file << "display {" << std::endl;
  for (std::size_t i = 0; i < 6; i++) {
    file << std::endl;
    file << "  " << i << " {" << std::endl;
    file << "    name_one " << this->display.views[i].get_name_one() << std::endl;
    file << "    name_two " << this->display.views[i].get_name_two() << std::endl;
    file << "    radius " << this->display.views[i].get_radius() << std::endl;
    file << "  }" << std::endl;
  }
  file << "}" << std::endl;
  file.close();
  return {Flag::Success, "Simulation saved to " + filename};
}

__attribute__((cold, noinline))
Result Simulation::load(const std::string& filename) noexcept {
  if (!std::filesystem::exists("cpp/body_problem/saves/" + filename + ".sim")) {
    return {Flag::NotFound, filename + " not found"};
  }
  std::ifstream file("cpp/body_problem/saves/" + filename + ".sim");
  std::string token;
  scalar_t save_MASS = 1.0L;
  scalar_t save_DISTANCE = 1.0L;
  scalar_t save_TIME = 1.0L;
  while (file >> token) {
    if (token == "version") {
      std::string save_version;
      file >> save_version;
      std::ifstream version_file("cpp/body_problem/version.txt");
      std::string program_version;
      version_file >> program_version;
      version_file.close();
      if (save_version != program_version) {
        return {Flag::UnsupportedVersion, "Save file and program versions do not match"};
      }
    } else if (token == "MASS") {
      file >> save_MASS;
    } else if (token == "DISTANCE") {
      file >> save_DISTANCE;
    } else if (token == "TIME") {
      file >> save_TIME;
    } else if (token == "system") {
      this->system.purge_bodies();
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        } else if (token == "collisions") {
          file >> this->system.collisions;
        } else if (token == "time") {
          file >> this->system.time;
          this->system.time = constants::seconds(this->system.time / save_TIME);
        } else if (token == "total_time") {
          file >> this->system.total_time;
          this->system.total_time = constants::seconds(this->system.total_time / save_TIME);
        } else if (token == "timestep") {
          file >> this->system.timestep;
          this->system.timestep = constants::seconds(this->system.timestep / save_TIME);
        } else if (token == "original_energy") {
          file >> this->system.original_energy;
          this->system.original_energy = constants::watts(this->system.original_energy / ((save_MASS * save_DISTANCE * save_DISTANCE) / (save_TIME * save_TIME * save_TIME)));
        } else if (token == "right") {
          file >> this->system.right;
        } else if (token == "upward") {
          file >> this->system.upward;
        } else if (token == "forward") {
          file >> this->system.forward;
        } else {
          std::string name = token;
          file >> token; // "{"
          scalar_t mass = 0.0L;
          scalar_t radius = 0.0L;
          scalar_t luminosity = 0.0L;
          vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
          vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
          while (file >> token) {
            if (token == "}") {
              break;
            } else if (token == "mass") {
              file >> mass;
              mass = constants::kilograms(mass / save_MASS);
            } else if (token == "radius") {
              file >> radius;
              radius = constants::meters(radius / save_DISTANCE);
            } else if (token == "luminosity") {
              file >> luminosity;
              luminosity = constants::watts(luminosity / ((save_MASS * save_DISTANCE * save_DISTANCE) / (save_TIME * save_TIME * save_TIME)));
            } else if (token == "position") {
              file >> position;
              position.x = constants::meters(position.x / save_DISTANCE);
              position.y = constants::meters(position.y / save_DISTANCE);
              position.z = constants::meters(position.z / save_DISTANCE);
            } else if (token == "velocity") {
              file >> velocity;
              velocity.x = constants::meters_per_second(velocity.x / (save_DISTANCE / save_TIME));
              velocity.y = constants::meters_per_second(velocity.y / (save_DISTANCE / save_TIME));
              velocity.z = constants::meters_per_second(velocity.z / (save_DISTANCE / save_TIME));
            }
          }
          this->system.create_body(name, mass, radius, luminosity, position, velocity);
        }
      }
    }
    else if (token == "display") {
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        }
        std::size_t index = std::stoull(token);
        file >> token; // "{"
        std::string name_one;
        std::string name_two;
        scalar_t radius;
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "name_one") {
            file >> name_one; // name_one
          } else if (token == "name_two") {
            file >> name_two; // name_two
          } else if (token == "radius") {
            file >> radius;
            radius = constants::meters(radius / save_DISTANCE);
          }
        }
        this->display.views[index].focus(name_one, name_two);
        this->display.views[index].scale(radius);
      }
    }
  }
  file.close();
  return {Flag::Success, "Simulation loaded from " + filename};
}
