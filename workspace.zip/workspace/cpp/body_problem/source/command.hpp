#pragma once

#include <cstddef>
// std::size_t

#include <memory>
// std::unique_ptr

#include <mutex>
// std::mutex

#include <optional>
// std::optional

#include <queue>
// std::queue

#include <string>
// std::string

#include "config.hpp"
// scalar_t
// vector_t

#include "result.hpp"
// Result

#include "simulation.hpp"
// Simulation

#include "../../utils/physics.hpp"
// physics::


class Command {
  public:
  virtual ~Command() = default;
  virtual Result execute(Simulation& simulation) noexcept = 0;
};


class SimulateCommand final : public Command {
  scalar_t total_time;
  scalar_t timestep;

  public:

  SimulateCommand(const scalar_t total_time, const scalar_t timestep) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class CreateBodyCommand final : public Command {
  std::string anchor;
  std::string name;
  scalar_t mass;
  scalar_t radius;
  scalar_t luminosity;
  vector_t<scalar_t> position;
  vector_t<scalar_t> velocity;

  public:

  CreateBodyCommand(
    const std::string& anchor,
    const std::string& name,
    const scalar_t mass,
    const scalar_t radius,
    const scalar_t luminosity,
    const vector_t<scalar_t>& position,
    const vector_t<scalar_t>& velocity
  ) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class ModifyBodyCommand final : public Command {
  std::string name;
  std::optional<scalar_t> mass;
  std::optional<scalar_t> radius;
  std::optional<scalar_t> luminosity;
  std::optional<scalar_t> pos_x;
  std::optional<scalar_t> pos_y;
  std::optional<scalar_t> pos_z;
  std::optional<scalar_t> vel_x;
  std::optional<scalar_t> vel_y;
  std::optional<scalar_t> vel_z;

  public:

  ModifyBodyCommand(
    const std::string& name,
    const std::optional<scalar_t> mass,
    const std::optional<scalar_t> radius,
    const std::optional<scalar_t> luminosity,
    const std::optional<scalar_t> pos_x,
    const std::optional<scalar_t> pos_y,
    const std::optional<scalar_t> pos_z,
    const std::optional<scalar_t> vel_x,
    const std::optional<scalar_t> vel_y,
    const std::optional<scalar_t> vel_z
  ) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class DestroyBodyCommand final : public Command {
  std::string name;

  public:

  DestroyBodyCommand(const std::string& name) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};

struct PurgeBodiesCommand final : public Command {

  PurgeBodiesCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


struct ToggleCollisionsCommand final : public Command {

  ToggleCollisionsCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


class FocusViewCommand final : public Command {
  std::size_t index;
  std::string name_one;
  std::string name_two;

  public:

  FocusViewCommand(const std::size_t index, const std::string& name_one, const std::string& name_two) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class ScaleViewCommand final : public Command {
  std::size_t index;
  scalar_t radius;

  public:

  ScaleViewCommand(const std::size_t index, const scalar_t radius) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class ViewPresetsCommand final : public Command {
  std::size_t index;
  std::string name;

  public:

  ViewPresetsCommand(const std::size_t index, const std::string& name) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class SaveCommand final : public Command {
  std::string filename;

  public:

  SaveCommand(const std::string& filename) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


class LoadCommand final : public Command {
  std::string filename;

  public:

  LoadCommand(const std::string& filename) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


struct PauseResumeCommand final : public Command {

  PauseResumeCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


struct StopCommand final : public Command {

  StopCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


// keybind only commands


struct SpeedUpCommand final : public Command {

  SpeedUpCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


struct SlowDownCommand final : public Command {

  SlowDownCommand() = default;

  Result execute(Simulation& simulation) noexcept override;
};


class RotatePerspectiveCommand final : public Command {
  scalar_t angle;
  physics::Axis axis;

  public:

  RotatePerspectiveCommand(const scalar_t angle, const physics::Axis axis) noexcept;

  Result execute(Simulation& simulation) noexcept override;
};


// command queue


class CommandQueue final {
  std::queue<std::unique_ptr<Command>> queue;
  mutable std::mutex mtx;

  public:
  
  void push(std::unique_ptr<Command> command) noexcept;

  std::unique_ptr<Command> pop() noexcept;

  bool empty() const noexcept;
};
