#pragma once

#include "../../utils/physics.hpp"
// physics::

typedef long double scalar_t;

template<typename S>
using vector_t = physics::Vector3D<S>;

template<template<typename> class V, typename S>
using object_t = physics::RadialBody<V, S>;