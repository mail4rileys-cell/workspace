#include <cstddef>
// std::size_t

#include <cstdint>
// std::uintmax_t

#include <fstream>
// std::ifstream
// std::ofstream

#include <iostream>
// std::endl

#include <string>
// std::string
// std::to_string
// std::stold
// std::stoull

#include "result.hpp"
// Flag
// Result

#include "solar_system.hpp"
// SolarSystem
// SolarSystemView
// Display
// Simulation

#include "../../utils/format.hpp"
// format::

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

void SolarSystem::simulate(const long double batch_time, const long double timestep) noexcept {
  const std::uintmax_t steps = static_cast<std::uintmax_t>(batch_time / timestep);
  for (std::uintmax_t step = 0; step < steps; step++) {
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      this->bodies[i].acceleration = {0, 0, 0};
    }
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      for (std::size_t j = i + 1; j < this->bodies.size(); j++) {
        const physics::GetGravityResult result = physics::get_gravity<physics::RadialBody, physics::Vector3D, long double>(
          this->bodies[i],
          this->bodies[j]
        );
        if (result.distance < (this->bodies[i].radius + this->bodies[j].radius)) {
          const physics::RadialBody<physics::Vector3D, long double> merged = {
            this->bodies[i].mass + this->bodies[j].mass,
            physics::get_combined_radius(this->bodies[i], this->bodies[j]),
            physics::get_barycenter(this->bodies[i], this->bodies[j]),
            physics::get_combined_velocity(this->bodies[i], this->bodies[j]),
            physics::get_combined_acceleration(this->bodies[i], this->bodies[j])
          };
          if (this->bodies[i].mass > this->bodies[j].mass) {
            this->bodies[i] = merged;
            this->destroy_body(this->names[j]);
          } else {
            this->bodies[j] = merged;
            this->destroy_body(this->names[i]);
          }
        } else {
          this->bodies[i].apply(result.gravity);
          this->bodies[j].apply(-result.gravity);
        }
      }
    }
    for (std::size_t i = 0; i < this->bodies.size(); i++) {
      this->bodies[i].integrate(timestep);
    }
  }
  this->time += batch_time;
}

physics::RadialBody<physics::Vector3D, long double>* SolarSystem::get_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      return &this->bodies[i];
    }
  }
  return nullptr;
}

Result SolarSystem::create_body(
  const std::string& name,
  const long double mass,
  const long double radius,
  const physics::Vector3D<long double>& position,
  const physics::Vector3D<long double>& velocity
) noexcept {
  if (this->get_body(name) != nullptr) {
    return {Flag::AlreadyExists, name + " already exists"};
  }
  this->names.push_back(name);
  this->bodies.push_back(physics::RadialBody<physics::Vector3D, long double>(mass, radius, position, velocity, {0, 0, 0}));
  return {Flag::Success, name + " created"};
}

Result SolarSystem::destroy_body(const std::string& name) noexcept {
  for (std::size_t i = 0; i < this->names.size(); i++) {
    if (this->names[i] == name) {
      this->names.erase(this->names.begin() + i);
      this->bodies.erase(this->bodies.begin() + i);
      return {Flag::Success, name + " destroyed"};
    }
  }
  return {Flag::NotFound, name + " not found"};
}

Result SolarSystem::purge_bodies() noexcept {
  this->names.clear();
  this->bodies.clear();
  return {Flag::Success, "Bodies purged"};
}


SolarSystemView::SolarSystemView(
  SolarSystem& solar_system,
  const std::string& name,
  const long double radius,
  const std::size_t width,
  const std::size_t height
) noexcept : solar_system(solar_system) {
  this->name = name;
  this->radius = radius;
  this->width = width;
  this->height = height;
}

windowlib::Window SolarSystemView::get_window() const noexcept {
  windowlib::Window window(this->height);
  const physics::RadialBody<physics::Vector3D, long double>* focus = this->solar_system.get_body(this->name);
  if (focus == nullptr) {
    window[0] = this->name + " not found";
    for (std::size_t i = 0; i < this->height; i++) {
      window[i] = format::pad_right(window[i], this->width * 2);
    }
    return window;
  }
  std::vector<std::vector<std::string>> grid(this->height, std::vector<std::string>(this->width, "  "));
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      grid[y][x] = "  ";
    }
  }
  for (std::size_t i = 0; i < this->solar_system.bodies.size(); i++) {
    const physics::Vector3D<long double> normalized = physics::get_delta<physics::Vector3D, long double>(focus->position, this->solar_system.bodies[i].position) / this->radius;
    if ((normalized.x < -1.0L) || (normalized.x > 1.0L) || (normalized.y < -1.0L) || (normalized.y > 1.0L)) {
      continue;
    }
    const std::size_t x = static_cast<std::size_t>(((normalized.x + 1.0L) * 0.5L * this->width));
    const std::size_t y = (this->height - 1) - static_cast<std::size_t>((normalized.y + 1.0L) * 0.5L * this->height);
    if (grid[y][x] != "  ") {
      continue;
    }
    grid[y][x] = format::pad_right(solar_system.names[i], 2);
  }
  for (std::size_t y = 0; y < this->height; y++) {
    for (std::size_t x = 0; x < this->width; x++) {
      window[y] += grid[y][x];
    }
  }
  return window;
}

std::string SolarSystemView::get_name() const noexcept {
  return this->name;
}

long double SolarSystemView::get_radius() const noexcept {
  return this->radius;
}


Result SolarSystemView::focus(const std::string& name) noexcept {
  this->name = name;
  return {Flag::Success, "View focused on " + name};
}

Result SolarSystemView::scale(const long double radius) noexcept {
  this->radius = radius;
  return {Flag::Success, "View scaled to " + std::to_string(radius) + " m"};
}


windowlib::Window Display::get_window(const std::size_t index) const noexcept {
  return this->views[index].get_window();
}


Simulation::Simulation(SolarSystem& solar_system, Display& display, const bool pause) noexcept
: solar_system(solar_system), display(display) {
  this->pause = pause;
}

Result Simulation::save(const std::string& filename) const noexcept {
  std::ifstream version_file("cpp/body_problem/version.txt");
  std::string version;
  version_file >> version;
  version_file.close();
  std::ofstream file("cpp/body_problem/saves/" + filename + ".sim");
  file << "version = " << version << std::endl;
  file << std::endl;
  file << "solar_system = {" << std::endl;
  for (std::size_t i = 0; i < this->solar_system.bodies.size(); i++) {
    file << std::endl;
    file << "  " << this->solar_system.names[i] << " = {" << std::endl;
    file << "    mass = " << this->solar_system.bodies[i].mass << std::endl;
    file << "    radius = " << this->solar_system.bodies[i].radius << std::endl;
    file << "    position = {" << std::endl;
    file << "      x = " << this->solar_system.bodies[i].position.x << std::endl;
    file << "      y = " << this->solar_system.bodies[i].position.y << std::endl;
    file << "      z = " << this->solar_system.bodies[i].position.z << std::endl;
    file << "    }" << std::endl;
    file << "    velocity = {" << std::endl;
    file << "      x = " << this->solar_system.bodies[i].velocity.x << std::endl;
    file << "      y = " << this->solar_system.bodies[i].velocity.y << std::endl;
    file << "      z = " << this->solar_system.bodies[i].velocity.z << std::endl;
    file << "    }" << std::endl;
    file << "  }" << std::endl;
  }
  file << std::endl;
  file << "  time = " << this->solar_system.time << std::endl;
  file << "}" << std::endl;
  file << std::endl;
  file << std::endl;
  file << "display = {" << std::endl;
  for (std::size_t i = 0; i < 7; i++) {
    file << std::endl;
    file << "  " << i << " = {" << std::endl;
    file << "    name = " << this->display.views[i].get_name() << std::endl;
    file << "    radius = " << this->display.views[i].get_radius() << std::endl;
    file << "  }" << std::endl;
  }
  file << "}" << std::endl;
  file.close();
  return {Flag::Success, "Simulation saved to " + filename};
}

Result Simulation::load(const std::string& filename) noexcept {
  std::ifstream file("cpp/body_problem/saves/" + filename + ".sim");
  std::string token;
  while (file >> token) {
    if (token == "version") {
      file >> token; // "="
      std::ifstream version_file("cpp/body_problem/version.txt");
      std::string program_version;
      version_file >> program_version;
      version_file.close();
      std::string save_version;
      file >> save_version;
      if (save_version != program_version) {
        return {Flag::UnsupportedVersion, "Save file and program versions do not match"};
      }
    } else if (token == "solar_system") {
      this->solar_system.purge_bodies();
      this->solar_system.time = 0.0L;
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        } else if (token == "time") {
          file >> token; // "="
          file >> this->solar_system.time;
          continue;
        }
        std::string name = token;
        file >> token; // "="
        file >> token; // "{"
        long double mass = 0.0L;
        long double radius = 0.0L;
        physics::Vector3D<long double> position = {0.0L, 0.0L, 0.0L};
        physics::Vector3D<long double> velocity = {0.0L, 0.0L, 0.0L};
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "mass") {
            file >> token; // "="
            file >> mass;
          } else if (token == "radius") {
            file >> token; // "="
            file >> radius;
          } else if (token == "position") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> position.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> position.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> position.z;
              }
            }
          } else if (token == "velocity") {
            file >> token; // "="
            file >> token; // "{"
            while (file >> token) {
              if (token == "}") {
                break;
              } else if (token == "x") {
                file >> token; // "="
                file >> velocity.x;
              } else if (token == "y") {
                file >> token; // "="
                file >> velocity.y;
              } else if (token == "z") {
                file >> token; // "="
                file >> velocity.z;
              }
            }
          }
        }
        this->solar_system.create_body(name, mass, radius, position, velocity);
      }
    }
    else if (token == "display") {
      file >> token; // "="
      file >> token; // "{"
      while (file >> token) {
        if (token == "}") {
          break;
        }
        std::size_t index = std::stoull(token);
        file >> token; // "="
        file >> token; // "{"
        std::string name;
        long double radius;
        while (file >> token) {
          if (token == "}") {
            break;
          } else if (token == "name") {
            file >> token; // "="
            file >> name;
          } else if (token == "radius") {
            file >> token; // "="
            file >> token; // radius
            radius = std::stold(token);
          }
        }
        this->display.views[index].focus(name);
        this->display.views[index].scale(radius);
      }
    }
  }
  file.close();
  return {Flag::Success, "Simulation loaded from " + filename};
}