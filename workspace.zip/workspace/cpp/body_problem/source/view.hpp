#pragma once

#include <cstddef>
// std::size_t

#include <functional>
// std::function

#include "interface.hpp"
// Interface

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::

class DataView {
  std::vector<std::function<std::string()>> fields;
  std::size_t width;
  std::size_t height;

  public:

  DataView(std::vector<std::function<std::string()>> fields, const std::size_t width, const std::size_t height) noexcept;

  windowlib::Window get_window() const noexcept;
};

class InterfaceView {
  Interface& interface;
  std::size_t width;
  std::size_t height;

  public:

  InterfaceView(Interface& interface, const std::size_t width, const std::size_t height) noexcept;

  windowlib::Window get_window() const noexcept;
};