#if !defined(SOL) && !defined(CENTAURI) && !defined(TRAPPIST_1)
  #error Star system is invalid or not defined
#endif

#include <chrono>
// std::chrono::

#include <cmath>
// std::abs

#include <cstdint>
// std::uintmax_t
// std::intmax_t

#include <cstdlib>
// std::system

#include <format>
// std::format

#include <memory>
// std::unique_ptr

#include <string>
// std::string
// std::to_string
// std::stold

#include <thread>
// std::this_thread

#include "command.hpp"
// Command
// CommandQueue

#include "config.hpp"
// scalar_t
// constants::

#include "console.hpp"
// ConsoleView

#include "interface.hpp"
// Interface
// InterfaceView

#include "result.hpp"
// Result

#include "scheduler.hpp"
// Scheduler

#include "simulation.hpp"
// System
// AxesView
// Display
// Simulation
// GuiView

#include "../../utils/windowlib.hpp"
// windowlib::

constexpr scalar_t FPS = 60.0L;

int main(const int argc, const char* argv[]) {
  
  std::system("clear");
  scalar_t fps;
  Result result = {Flag::Success, ""};
  
  System system;
  #ifdef GRAPHICS
    GuiView gui_view = {
      system,
      "default",
      "none",
      0.0L
    };
  #endif
  #ifdef SOL
    Display display = {{
      {system, "Sol", "none", constants::JUPITER_DISTANCE * 1.05L, 25, 25},
      {system, "Sol", "none", constants::ERIS_DISTANCE * 1.05L, 25, 25},
      {system, "Jupiter", "none", constants::CALLISTO_DISTANCE * 1.05L, 25, 25},
      {system, "Saturn", "none", constants::IAPETUS_DISTANCE * 1.05L, 25, 25},
      {system, "Uranus", "none", constants::OBERON_DISTANCE * 1.05L, 25, 25},
      {system, "Neptune", "none", constants::TRITON_DISTANCE * 1.05L, 25, 25}
    }};
  #elifdef CENTAURI
    Display display = {{
      {system, "Rigil Kentaurus", "Toliman", constants::TOLIMAN_DISTANCE * 1.05L, 25, 25},
      {system, "Rigil Kentaurus", "Toliman", constants::PROXIMA_CENTAURI_DISTANCE * 1.05L, 25, 25},
      {system, "Proxima Centauri", "none", constants::PROXIMA_CENTAURI_D_DISTANCE * 1.05L, 25, 25},
      {system, "Rigil Kentaurus", "Toliman", constants::TOLIMAN_DISTANCE * 1.05L, 25, 25},
      {system, "Rigil Kentaurus", "Toliman", constants::PROXIMA_CENTAURI_DISTANCE * 1.05L, 25, 25},
      {system, "Proxima Centauri", "none", constants::PROXIMA_CENTAURI_D_DISTANCE * 1.05L, 25, 25}
    }};
  #elifdef TRAPPIST_1
    Display display = {{
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25},
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25},
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25},
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25},
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25},
      {system, "TRAPPIST-1", "none", constants::TRAPPIST_1H_DISTANCE * 1.05L, 25, 25}
    }};
  #endif
  #ifdef GRAPHICS
    Simulation simulation = {system, gui_view, display};
  #else
    Simulation simulation = {system, display};
  #endif
  if (argc == 2) {
    result = simulation.load(std::string(argv[1]));
  }
  
  const AxesView axes_view = {system, 25, 25};
  ConsoleView console_view = {{
    [&] -> std::string {
      return
        std::string("Simulation time: ")
        + std::to_string(constants::to_days(system.time))
        + std::string(" d / ")
        + std::to_string(constants::to_years(system.time))
        + std::string (" yr");
    },
    [&] -> std::string {
      return
        std::string("Bodies: ")
        + std::to_string(system.bodies.size())
        + std::string(" | FPS: ")
        + std::to_string(static_cast<std::uintmax_t>((fps > FPS) ? FPS : fps))
        + std::string(" | TPS: ")
        + std::to_string(constants::to_days(system.total_time) * ((fps > FPS) ? FPS : fps))
        + std::string(" d");
    },
    [&] -> std::string {
      return
        std::string("Energy: ")
        + std::format("{:.35f}", (std::abs((system.energy - system.original_energy) / system.original_energy)) * 100.0L)
        + std::string (" %");
    },
    [&] -> std::string {
      return
        std::string("Zoom: ") + std::to_string(system.zoom)
        + std::string(" | Pan x: ") + std::to_string(system.pan_x)
        + std::string(" | Pan y: ") + std::to_string(system.pan_y);
    },
    [&] -> std::string {
      return ((result.flag == Flag::Success) ? "" : "Error: ") + result.message;
    }
  }, 25, 5};
  CommandQueue command_queue;
  Interface interface = {command_queue};
  const InterfaceView interface_view = {interface, 25, 18};
  Scheduler scheduler = {simulation, command_queue};
  interface.start();
  scheduler.start();

  while (simulation.running) {
    const auto start = std::chrono::high_resolution_clock::now();
    while (!command_queue.empty()) {
      result = command_queue.pop()->execute(simulation);
      std::system("clear");
    }
    if (!simulation.pause) {
      system.simulate(system.total_time, system.timestep);
    }
    #ifdef GRAPHICS
      if (simulation.gui) {
        gui_view.focus(display.views[0].get_name_one(), display.views[0].get_name_two());
        gui_view.scale(display.views[0].get_radius());
        gui_view.render();
        const windowlib::Window console_window = console_view.get_window();
        const windowlib::Window interface_window = interface_view.get_window();
        windowlib::render(windowlib::vertical(console_window, interface_window));
      } else {
    #endif
        const windowlib::Window top_left_window = display.get_window(0);
        const windowlib::Window top_middle_window = display.get_window(1);
        const windowlib::Window top_right_window = display.get_window(2);
        const windowlib::Window axes_window = axes_view.get_window();
        const windowlib::Window top = windowlib::horizontal(top_left_window, windowlib::horizontal(top_middle_window, windowlib::horizontal(top_right_window, axes_window)));
        const windowlib::Window bottom_left_window = display.get_window(3);
        const windowlib::Window bottom_middle_window = display.get_window(4);
        const windowlib::Window bottom_right_window = display.get_window(5);
        const windowlib::Window console_window = console_view.get_window();
        const windowlib::Window interface_window = interface_view.get_window();
        const windowlib::Window ui_window = windowlib::vertical(console_window, interface_window);
        const windowlib::Window bottom = windowlib::horizontal(bottom_left_window, windowlib::horizontal(bottom_middle_window, windowlib::horizontal(bottom_right_window, ui_window)));
        windowlib::render(windowlib::vertical(top, bottom));
    #ifdef GRAPHICS
      }
    #endif
    const auto end = std::chrono::high_resolution_clock::now();
    const std::chrono::duration<scalar_t> elapsed = end - start;
    fps = 1.0L / elapsed.count();
    if (elapsed.count() < (1.0L / FPS)) {
      std::this_thread::sleep_for(std::chrono::duration<scalar_t>((1.0L / FPS) - elapsed.count()));
    }
  }
  
  interface.stop();
  scheduler.stop();
  std::system("clear");
  return 0;
}
