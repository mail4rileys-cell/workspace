#pragma GCC diagnostic error "-Wall"

#include <chrono>
// std::chrono::

#include <cmath>
// std::abs

#include <cstdint>
// std::uintmax_t
// std::intmax_t

#include <cstdlib>
// std::system

#include <format>
// std::format

#include <iostream>
// std::cin
// std::cout
// std::endl

#include <memory>
// std::unique_ptr

#include <string>
// std::string
// std::to_string

#include <thread>
// std::this_thread

#include "command.hpp"
// Command
// CommandQueue

#include "console.hpp"
// ConsoleView

#include "interface.hpp"
// Interface
// InterfaceView

#include "result.hpp"
// Result

#include "types.hpp"
// scalar_t

#include "simulation.hpp"
// SolarSystem
// Display
// Simulation

#include "../../utils/physics.hpp"
using namespace physics::units;
// physics::

#include "../../utils/terminal.hpp"
// terminal::

#include "../../utils/windowlib.hpp"
// windowlib::

constexpr scalar_t FRAME_TIME = 1.0_h;
constexpr scalar_t FPS = 24.0L;
constexpr scalar_t TIMESTEP = 4.0_s;

int main(const int argc, const char* argv[]) {
  std::system("clear");
  terminal::enable_raw();
  Result result = {Flag::Success, ""};
  SolarSystem solar_system;
  Display display = {{
    {solar_system, "Sun", "none", physics::PLUTO_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Sun", "none", physics::CERES_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Jupiter", "none", physics::CALLISTO_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Saturn", "none", physics::IAPETUS_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Uranus", "none", physics::OBERON_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Neptune", "none", physics::TRITON_DISTANCE<scalar_t> * 1.1L, 25, 25},
    {solar_system, "Pluto", "Charon", physics::CHARON_DISTANCE<scalar_t> * 1.0L, 25, 25},
  }};
  scalar_t fps;
  ConsoleView console_view = {{
    [&] {
      return
        std::string("Simulation time: ")
        + std::to_string(static_cast<std::uintmax_t>(solar_system.time / 24.0_h))
        + std::string(" days / ")
        + std::to_string(solar_system.time / physics::EARTH_PERIOD<scalar_t>)
        + std::string (" years");
    },
    [&] {
      return
        std::string("Bodies: ")
        + std::to_string(solar_system.bodies.size())
        + std::string(" | FPS: ")
        + std::to_string(static_cast<std::uintmax_t>((fps > FPS) ? FPS : fps));
    },
    [&] {
      return
        std::string("Energy drift: ")
        + std::format("{:.20f}", (std::abs((solar_system.energy - solar_system.original_energy) / solar_system.original_energy)) * 100.0L)
        + std::string (" %");
    },
    [&] {
      return ((result.flag == Flag::Success) ? "" : "Error: ") + result.message;
    }
  }, 25, 4};
  Simulation simulation = {solar_system, display, false};
  if (argc == 2) {
    result = simulation.load(std::string(argv[1]));
  }
  CommandQueue command_queue;
  Interface interface = {command_queue};
  const InterfaceView interface_view = {interface, 25, 19};
  interface.start();
  while (!simulation.stop) {
    const auto start = std::chrono::high_resolution_clock::now();
    while (!command_queue.empty()) {
      result = command_queue.pop()->execute(simulation);
      std::system("clear");
    }
    const windowlib::Window top_left_window = display.get_window(0);
    const windowlib::Window top_middle_window = display.get_window(1);
    const windowlib::Window top_right_window = display.get_window(2);
    const windowlib::Window extra_window = display.get_window(3);
    const windowlib::Window top = windowlib::horizontal(top_left_window, windowlib::horizontal(top_middle_window, windowlib::horizontal(top_right_window, extra_window)));
    const windowlib::Window bottom_left_window = display.get_window(4);
    const windowlib::Window bottom_middle_window = display.get_window(5);
    const windowlib::Window bottom_right_window = display.get_window(6);
    const windowlib::Window console_window = console_view.get_window();
    const windowlib::Window interface_window = interface_view.get_window();
    const windowlib::Window ui_window = windowlib::vertical(console_window, interface_window);
    const windowlib::Window bottom = windowlib::horizontal(bottom_left_window, windowlib::horizontal(bottom_middle_window, windowlib::horizontal(bottom_right_window, ui_window)));
    windowlib::render(windowlib::vertical(top, bottom));
    if (!simulation.pause) {
      solar_system.simulate(FRAME_TIME, TIMESTEP);
    }
    const auto end = std::chrono::high_resolution_clock::now();
    const std::chrono::duration<scalar_t> elapsed = end - start;
    fps = 1.0_s / elapsed.count();
    if (elapsed.count() < (1.0_s / FPS)) {
      std::this_thread::sleep_for(std::chrono::duration<scalar_t>((1.0_s / FPS) - elapsed.count()));
    }
  }
  interface.stop();
  terminal::disable_raw();
  std::system("clear");
  return 0;
}