#pragma once

#include <atomic>
// std::atomic

#include <thread>
// std::thread

#include <lua.hpp>
// Lua

#include "command.hpp"
// CommandQueue

#include "simulation.hpp"
// Simulation

class Scheduler final {
	Simulation& simulation;
	CommandQueue& command_queue;
  std::thread thread;
  std::atomic<bool> running = {true};
  lua_State* Lua;

  __attribute__((cold, noinline))
  static int lua_command(lua_State* L); 

  __attribute__((cold, noinline))
  static int lua_get_body(lua_State* L);

  __attribute__((cold, noinline))
  static int lua_get_names(lua_State* L);

  __attribute__((cold, noinline))
  void loop() const;

  public:

  __attribute__((cold, noinline))
  Scheduler(Simulation& simulation, CommandQueue& command_queue);

  __attribute__((cold, noinline))
  void start() noexcept;

  __attribute__((cold, noinline))
  void stop() noexcept;
};
