#pragma once

#include <cstddef>
// std::size_t

#include <functional>
// std::function

#include "../../utils/windowlib.hpp"
// windowlib::


class ConsoleView final {
  std::vector<std::function<std::string()>> fields;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  ConsoleView(std::vector<std::function<std::string()>> fields, const std::size_t width, const std::size_t height) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;
};