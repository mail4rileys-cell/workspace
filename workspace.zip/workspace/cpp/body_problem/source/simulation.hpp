#pragma once

#ifdef GRAPHICS
  #include <SFML/Graphics.hpp>
#endif

#include <cstddef>
// std::size_t

#include <string>
// std::string

#include "config.hpp"
// scalar_t
// vector_t
// constants::

#include "result.hpp"
// Result

#include "../../utils/physics.hpp"
// physics::

#include "../../utils/windowlib.hpp"
// windowlib::


struct Body final {
  std::string name = "default";
  scalar_t mass = 0.0L;
  scalar_t radius = 0.0L;
  scalar_t luminosity = 0.0L;
  vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> net_force = {0.0L, 0.0L, 0.0L};
};


struct System final {
  bool collisions = false;
  scalar_t time = 0.0L;
  scalar_t total_time = constants::minutes(24.0L);
  scalar_t timestep = constants::seconds(3.0L);
  scalar_t original_energy = 0.0L;
  scalar_t energy = 0.0L;
  vector_t<scalar_t> right = {1, 0, 0};
  vector_t<scalar_t> upward = {0, 1, 0};
  vector_t<scalar_t> forward = {0, 0, 1};
  scalar_t zoom = 1.0L;
  scalar_t pan_x = 0.0L;
  scalar_t pan_y = 0.0L;
  #define PLANET(STR_NAME, NAME) \
    { \
      STR_NAME, \
      constants:: NAME##_MASS, \
      constants:: NAME##_RADIUS, \
      0.0L, \
      vector_t<scalar_t>(constants:: NAME##_DISTANCE, 0.0L, 0.0L).rotated(constants:: NAME##_OFFSET, physics::Axis::Z), \
      vector_t<scalar_t>(0.0L, constants:: NAME##_SPEED, 0.0L).rotated(constants:: NAME##_INCLINE, physics::Axis::X).rotated(constants:: NAME##_OFFSET, physics::Axis::Z), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #define MOON(STR_NAME, NAME, PLANET) \
    { \
      STR_NAME, \
      constants:: NAME##_MASS, \
      constants:: NAME##_RADIUS, \
      0.0L, \
      vector_t<scalar_t>(constants:: NAME##_DISTANCE, 0.0L, 0.0L) \
      + vector_t<scalar_t>(constants:: PLANET##_DISTANCE, 0.0L, 0.0L).rotated(constants:: PLANET##_OFFSET, physics::Axis::Z), \
      vector_t<scalar_t>(0.0L, constants:: NAME##_SPEED, 0.0L).rotated(constants:: NAME##_INCLINE, physics::Axis::X).rotated(constants:: PLANET##_AXIAL, physics::Axis::X) \
      + vector_t<scalar_t>(0.0L, constants:: PLANET##_SPEED, 0.0L).rotated(constants:: PLANET##_INCLINE, physics::Axis::X).rotated(constants:: PLANET##_OFFSET, physics::Axis::Z), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  std::vector<Body> bodies = {
    {
      "Sol",
      constants::SOL_MASS,
      constants::SOL_RADIUS,
      constants::SOL_LUMINOSITY,
      {0.0L, 0.0L, 0.0L},
      {0.0L, 0.0L, 0.0L},
      {0.0L, 0.0L, 0.0L}
    },

      PLANET("Mercury", MERCURY)

      PLANET("Venus", VENUS)

      PLANET("Earth", EARTH)
        MOON("Luna", LUNA, EARTH)

      PLANET("Mars", MARS)
        MOON("Phobos", PHOBOS, MARS)
        MOON("Deimos", DEIMOS, MARS)

      PLANET("Eureka", EUREKA)

      PLANET("1Ceres", CERES)
      PLANET("2Vesta", VESTA)
      PLANET("3Juno", JUNO)
      PLANET("4Pallas", PALLAS)

      PLANET("Jupiter", JUPITER)
        MOON("Io", IO, JUPITER)
        MOON("Europa", EUROPA, JUPITER)
        MOON("Ganymede", GANYMEDE, JUPITER)
        MOON("Callisto", CALLISTO, JUPITER)

      PLANET("Hektor", HEKTOR)
        MOON("Skamandrios", SKAMANDRIOS, HEKTOR)

      PLANET("Patroclus", PATROCLUS)
        MOON("Menoetius", MENOETIUS, PATROCLUS)

      PLANET("Saturn", SATURN)
        MOON("Titan", TITAN, SATURN)
        MOON("Rhea", RHEA, SATURN)
        MOON("Iapetus", IAPETUS, SATURN)
        MOON("Dione", DIONE, SATURN)
        MOON("Tethys", TETHYS, SATURN)
        MOON("Enceladus", ENCELADUS, SATURN)
        MOON("Mimas", MIMAS, SATURN)
        MOON("Hyperion", HYPERION, SATURN)

      PLANET("Uranus", URANUS)
        MOON("Titania", TITANIA, URANUS)
        MOON("Oberon", OBERON, URANUS)
        MOON("Umbriel", UMBRIEL, URANUS)
        MOON("Ariel", ARIEL, URANUS)
        MOON("Miranda", MIRANDA, URANUS)
        //MOON("Sycorax", SYCORAX, URANUS)

      PLANET("Neptune", NEPTUNE)
        MOON("Triton", TRITON, NEPTUNE)
        MOON("Proteus", PROTEUS, NEPTUNE)
        MOON("Larissa", LARISSA, NEPTUNE)
        MOON("Galatea", GALATEA, NEPTUNE)
        MOON("Despina", DESPINA, NEPTUNE)
        MOON("Thalassa", THALASSA, NEPTUNE)
        MOON("Naiad", NAIAD, NEPTUNE)

      PLANET("Orcus", ORCUS)
        MOON("Vanth", VANTH, ORCUS)

      PLANET("Lempo", LEMPO)
        MOON("Hiisi", HIISI, LEMPO)
        MOON("Paha", PAHA, LEMPO)
      
      PLANET("Pluto", PLUTO)
        MOON("Charon", CHARON, PLUTO)
        MOON("Styx", STYX, PLUTO)
        MOON("Nix", NIX, PLUTO)
        MOON("Kerberos", KERBEROS, PLUTO)
        MOON("Hydra", HYDRA, PLUTO)

      PLANET("Haumea", HAUMEA)
        MOON("Hi'iaka", HI_IAKA, HAUMEA)
        MOON("Namaka", NAMAKA, HAUMEA)

      PLANET("Quaoar", QUAOAR)
        MOON("Weywot", WEYWOT, QUAOAR)

      PLANET("Gonggong", GONGGONG)
        MOON("Xiangliu", XIANGLIU, GONGGONG)

      PLANET("Makemake", MAKEMAKE)
        MOON("Mo'o", MO_O, MAKEMAKE)

      PLANET("Eris", ERIS)
        MOON("Dysnomia", DYSNOMIA, ERIS)

      PLANET("Encke", ENCKE)
      PLANET("Halley", HALLEY)
  };
  #undef PLANET
  #undef MOON
  
  __attribute__((cold, noinline))
  System() noexcept;

  __attribute__((hot))
  void simulate(const scalar_t batch_time, const scalar_t timestep) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  Body* get_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result create_body(
    const std::string& name,
    const scalar_t mass,
    const scalar_t radius,
    const scalar_t luminosity,
    const vector_t<scalar_t>& position,
    const vector_t<scalar_t>& velocity
  ) noexcept;

  __attribute__((cold, noinline))
  Result destroy_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result purge_bodies() noexcept;
};


#ifdef GRAPHICS


  class GuiView final {
    System& system;
    std::string name_one;
    std::string name_two;
    scalar_t radius;
    sf::RenderWindow window;
    sf::Font font; 
    sf::Color grey = sf::Color(128, 128, 128);

    public:

    GuiView(System& system, const std::string& name_one, const std::string& name_two, const scalar_t radius) noexcept;

    void open() noexcept;

    void close() noexcept;

    void render() noexcept;

    Result focus(const std::string& name_one, const std::string& name_two) noexcept;

    Result scale(const scalar_t radius) noexcept;
  };


#endif


class SystemView final {
  System& system;
  std::string name_one;
  std::string name_two;
  scalar_t radius;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  SystemView(
    System& system,
    const std::string& name_one,
    const std::string& name_two,
    const scalar_t radius,
    const std::size_t width,
    const std::size_t height
  ) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_one() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_two() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  scalar_t get_radius() const noexcept;

  __attribute__((cold, noinline))
  Result focus(const std::string& name_one, const std::string& name_two) noexcept;

  __attribute__((cold, noinline))
  Result scale(const scalar_t radius) noexcept;
};


class AxesView final {
  System& system;
  std::size_t width;
  std::size_t height;

  public: 

  __attribute__((cold, noinline))
  AxesView(System& system, const std::size_t width, const std::size_t height) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;
};


struct Display final {
  SystemView views[6];
  
  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window(const std::size_t index) const noexcept;
};


struct Simulation final {
  System& system;
  #ifdef GRAPHICS
    GuiView& gui_view;
  #endif
  Display& display;
  bool gui = false;
  bool pause = false;
  bool running = true;

  __attribute__((cold, noinline))
  #ifdef GRAPHICS
    Simulation(System& system, GuiView& gui_view, Display& display) noexcept;
  #else
    Simulation(System& system, Display& display) noexcept;
  #endif

  __attribute__((cold, noinline))
  Result save(const std::string& filename) const noexcept;

  __attribute__((cold, noinline))
  Result load(const std::string& filename) noexcept;
};
