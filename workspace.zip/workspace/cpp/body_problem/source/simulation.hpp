#pragma once

#ifdef GRAPHICS
  #include <SFML/Graphics.hpp>
#endif

#include <cstddef>
// std::size_t

#include <string>
// std::string

#include "config.hpp"
// scalar_t
// vector_t
// constants::

#include "result.hpp"
// Result

#include "../../utils/constants.hpp"
// constants::

#include "../../utils/geometry.hpp"
// geometry::

#include "../../utils/windowlib.hpp"
// windowlib::


struct Body final {
  std::string name = "default";
  scalar_t mass = 0.0L;
  scalar_t radius = 0.0L;
  scalar_t luminosity = 0.0L;
  vector_t<scalar_t> position = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> velocity = {0.0L, 0.0L, 0.0L};
  vector_t<scalar_t> net_force = {0.0L, 0.0L, 0.0L};
};


struct System final {
  bool collisions = false;
  scalar_t time = 0.0L;
  scalar_t total_time = constants::days(1.0L / 60.0L);
  #ifdef SOL
    scalar_t timestep = constants::seconds(6.0L);
  #elifdef CENTAURI
    scalar_t timestep = constants::seconds(0.006L);
  #elifdef KEPLER_47
    scalar_t timestep = constants::seconds(0.005L);
  #elifdef KEPLER_90
    scalar_t timestep = constants::seconds(0.02L);
  #elifdef LICH
    scalar_t timestep = constants::seconds(0.004L);
  #elifdef TRAPPIST_1
    scalar_t timestep = constants::seconds(0.01L);
  #else
    scalar_t timestep = constants::seconds(1.0L);
  #endif
  scalar_t original_energy = 0.0L;
  scalar_t energy = 0.0L;
  vector_t<scalar_t> right = {1, 0, 0};
  vector_t<scalar_t> upward = {0, 1, 0};
  vector_t<scalar_t> forward = {0, 0, 1};
  scalar_t zoom = 1.0L;
  scalar_t pan_x = 0.0L;
  scalar_t pan_y = 0.0L;
  #define STAR(STR_NAME, NAME) \
    { \
      STR_NAME, \
      constants:: NAME##_MASS, \
      constants:: NAME##_RADIUS, \
      constants:: NAME##_LUMINOSITY, \
      vector_t<scalar_t>(constants:: NAME##_DISTANCE, 0.0L, 0.0L).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z), \
      vector_t<scalar_t>(0.0L, constants:: NAME##_SPEED, 0.0L).rotated(constants:: NAME##_INCLINE, geometry::Axis::X).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #define PLANET(STR_NAME, NAME) \
    { \
      STR_NAME, \
      constants:: NAME##_MASS, \
      constants:: NAME##_RADIUS, \
      0.0L, \
      vector_t<scalar_t>(constants:: NAME##_DISTANCE, 0.0L, 0.0L).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z), \
      vector_t<scalar_t>(0.0L, constants:: NAME##_SPEED, 0.0L).rotated(constants:: NAME##_INCLINE, geometry::Axis::X).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #define MOON(STR_NAME, NAME, PLANET) \
    { \
      STR_NAME, \
      constants:: NAME##_MASS, \
      constants:: NAME##_RADIUS, \
      0.0L, \
      vector_t<scalar_t>(constants:: NAME##_DISTANCE, 0.0L, 0.0L).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z) \
      + vector_t<scalar_t>(constants:: PLANET##_DISTANCE, 0.0L, 0.0L).rotated(constants:: PLANET##_OFFSET, geometry::Axis::Z), \
      vector_t<scalar_t>(0.0L, constants:: NAME##_SPEED, 0.0L).rotated(constants:: NAME##_INCLINE, geometry::Axis::X).rotated(constants:: PLANET##_AXIAL, geometry::Axis::X).rotated(constants:: NAME##_OFFSET, geometry::Axis::Z) \
      + vector_t<scalar_t>(0.0L, constants:: PLANET##_SPEED, 0.0L).rotated(constants:: PLANET##_INCLINE, geometry::Axis::X).rotated(constants:: PLANET##_OFFSET, geometry::Axis::Z), \
      {0.0L, 0.0L, 0.0L} \
    },
  // end
  #ifdef SOL
    std::vector<Body> bodies = {
      STAR("Sol", SOL)

        PLANET("Mercury", MERCURY)

        PLANET("Venus", VENUS)

        PLANET("Earth", EARTH)
          MOON("Luna", LUNA, EARTH)

        PLANET("Mars", MARS)
          MOON("Phobos", PHOBOS, MARS)
          MOON("Deimos", DEIMOS, MARS)

        PLANET("Eureka", EUREKA)

        PLANET("Vesta", VESTA)
        PLANET("Juno", JUNO)
        PLANET("Ceres", CERES)
        PLANET("Pallas", PALLAS)
        PLANET("Potato", POTATO)

        PLANET("Jupiter", JUPITER)
          MOON("Metis", METIS, JUPITER)
          MOON("Adrastea", ADRASTEA, JUPITER)
          MOON("Amalthea", AMALTHEA, JUPITER)
          MOON("Thebe", THEBE, JUPITER)
          MOON("Io", IO, JUPITER)
          MOON("Europa", EUROPA, JUPITER)
          MOON("Ganymede", GANYMEDE, JUPITER)
          MOON("Callisto", CALLISTO, JUPITER)
          MOON("Themisto", THEMISTO, JUPITER)
          MOON("Ersa", ERSA, JUPITER)
          MOON("Leda", LEDA, JUPITER)
          MOON("Lysithea", LYSITHEA, JUPITER)
          MOON("Himalia", HIMALIA, JUPITER)
          MOON("Pandia", PANDIA, JUPITER)
          MOON("Elara", ELARA, JUPITER)
          MOON("Dia", DIA, JUPITER)
          MOON("Euporie", EUPORIE, JUPITER)
          MOON("Valetudo", VALETUDO, JUPITER)
          MOON("Carpo", CARPO, JUPITER)
          MOON("Helike", HELIKE, JUPITER)
          MOON("Ananke", ANANKE, JUPITER)
          MOON("Eupheme", EUPHEME, JUPITER)
          MOON("Hermippe", HERMIPPE, JUPITER)
          MOON("Iocaste", IOCASTE, JUPITER)
          MOON("Thelxinoe", THELXINOE, JUPITER)
          MOON("Mneme", MNEME, JUPITER)
          MOON("Harpalyke", HARPALYKE, JUPITER)
          MOON("Euanthe", EUANTHE, JUPITER)
          MOON("Thyone", THYONE, JUPITER)
          MOON("Praxidike", PRAXIDIKE, JUPITER)
          MOON("Orthosie", ORTHOSIE, JUPITER)
          MOON("Carme", CARME, JUPITER)
          MOON("Philophrosyne", PHILOPHROSYNE, JUPITER)
          MOON("Isonoe", ISONOE, JUPITER)
          MOON("Kallichore", KALLICHORE, JUPITER)
          MOON("Chaldene", CHALDENE, JUPITER)
          MOON("Taygete", TAYGETE, JUPITER)
          MOON("Kale", KALE, JUPITER)
          MOON("Pasithee", PASITHEE, JUPITER)
          MOON("Eirene", EIRENE, JUPITER)
          MOON("Herse", HERSE, JUPITER)
          MOON("Arche", ARCHE, JUPITER)
          MOON("Erinome", ERINOME, JUPITER)
          MOON("Aitne", AITNE, JUPITER)
          MOON("Kalyke", KALYKE, JUPITER)
          MOON("Eukelade", EUKELADE, JUPITER)
          MOON("Eurydome", EURYDOME, JUPITER)
          MOON("Sinope", SINOPE, JUPITER)
          MOON("Sponde", SPONDE, JUPITER)
          MOON("Callirrhoe", CALLIRRHOE, JUPITER)
          MOON("Autonoe", AUTONOE, JUPITER)
          MOON("Hegemone", HEGEMONE, JUPITER)
          MOON("Pasiphae", PASIPHAE, JUPITER)
          MOON("Kore", KORE, JUPITER)
          MOON("Megaclite", MEGACLITE, JUPITER)
          MOON("Cyllene", CYLLENE, JUPITER)
          MOON("Aoede", AOEDE, JUPITER)

        PLANET("Hektor", HEKTOR)
          MOON("Skamandrios", SKAMANDRIOS, HEKTOR)

        PLANET("Patroclus", PATROCLUS)
          MOON("Menoetius", MENOETIUS, PATROCLUS)

        PLANET("Chiron", CHIRON)

        PLANET("Saturn", SATURN)
          MOON("Pan", PAN, SATURN)
          MOON("Daphnis", DAPHNIS, SATURN)
          MOON("Atlas", ATLAS, SATURN)
          MOON("Prometheus", PROMETHEUS, SATURN)
          MOON("Pandora", PANDORA, SATURN)
          MOON("Janus", JANUS, SATURN)
          MOON("Epimetheus", EPIMETHEUS, SATURN)
          MOON("Aegaeon", AEGAEON, SATURN)
          MOON("Mimas", MIMAS, SATURN)
          MOON("Methone", METHONE, SATURN)
          MOON("Anthe", ANTHE, SATURN)
          MOON("Pallene", PALLENE, SATURN)
          MOON("Enceladus", ENCELADUS, SATURN)
          MOON("Tethys", TETHYS, SATURN)
          MOON("Telesto", TELESTO, SATURN)
          MOON("Calypso", CALYPSO, SATURN)
          MOON("Dione", DIONE, SATURN)
          MOON("Helene", HELENE, SATURN)
          MOON("Polydeuces", POLYDEUCES, SATURN)
          MOON("Rhea", RHEA, SATURN)
          MOON("Titan", TITAN, SATURN)
          MOON("Hyperion", HYPERION, SATURN)
          MOON("Iapetus", IAPETUS, SATURN)
          MOON("Kiviuq", KIVIUQ, SATURN)
          MOON("Ijiraq", IJIRAQ, SATURN)
          MOON("Phoebe", PHOEBE, SATURN)
          MOON("Skathi", SKATHI, SATURN)
          MOON("Tarqeq", TARQEQ, SATURN)
          MOON("Paaliaq", PAALIAQ, SATURN)
          MOON("Suttungr", SUTTUNGR, SATURN)
          MOON("Bergelmir", BERGELMIR, SATURN)
          MOON("Beli", BELI, SATURN)
          MOON("Mundilfari", MUNDILFARI, SATURN)
          MOON("Gridr", GRIDR, SATURN)
          MOON("Eggther", EGGTHER, SATURN)
          MOON("Siarnaq", SIARNAQ, SATURN)
          MOON("Jarnsaxa", JARNSAXA, SATURN)
          MOON("Albiorix", ALBIORIX, SATURN)
          MOON("Greip", GREIP, SATURN)
          MOON("Hyrrokkin", HYRROKKIN, SATURN)
          MOON("Bebhionn", BEBHIONN, SATURN)
          MOON("Angrboda", ANGRBODA, SATURN)
          MOON("Farbauti", FARBAUTI, SATURN)
          MOON("Fenrir", FENRIR, SATURN)
          MOON("Skoll", SKOLL, SATURN)
          MOON("Erriapus", ERRIAPUS, SATURN)
          MOON("Aegir", AEGIR, SATURN)
          MOON("Gunnlod", GUNNLOD, SATURN)
          MOON("Hati", HATI, SATURN)
          MOON("Narvi", NARVI, SATURN)
          MOON("Alvaldi", ALVALDI, SATURN)
          MOON("Loge", LOGE, SATURN)
          MOON("Tarvos", TARVOS, SATURN)
          MOON("Thrymr", THRYMR, SATURN)
          MOON("Bestla", BESTLA, SATURN)
          MOON("Fornjot", FORNJOT, SATURN)
          MOON("Ymir", YMIR, SATURN)
          MOON("Skrymir", SKRYMIR, SATURN)
          MOON("Gerd", GERD, SATURN)
          MOON("Kari", KARI, SATURN)
          MOON("Surtur", SURTUR, SATURN)
          MOON("Geirrod", GEIRROD, SATURN)
          MOON("Thiazzi", THIAZZI, SATURN)

        PLANET("Chariklo", CHARIKLO)

        PLANET("Typhon", TYPHON)
          MOON("Echidna", ECHIDNA, TYPHON)

        PLANET("Uranus", URANUS)
          MOON("Cordelia", CORDELIA, URANUS)
          MOON("Ophelia", OPHELIA, URANUS)
          MOON("Bianca", BIANCA, URANUS)
          MOON("Cressida", CRESSIDA, URANUS)
          MOON("Desdemona", DESDEMONA, URANUS)
          MOON("Juliet", JULIET, URANUS)
          MOON("Portia", PORTIA, URANUS)
          MOON("Rosalind", ROSALIND, URANUS)
          MOON("Cupid", CUPID, URANUS)
          MOON("Belinda", BELINDA, URANUS)
          MOON("Perdita", PERDITA, URANUS)
          MOON("Puck", PUCK, URANUS)
          MOON("Mab", MAB, URANUS)
          MOON("Miranda", MIRANDA, URANUS)
          MOON("Ariel", ARIEL, URANUS)
          MOON("Umbriel", UMBRIEL, URANUS)
          MOON("Titania", TITANIA, URANUS)
          MOON("Oberon", OBERON, URANUS)
          MOON("Francisco", FRANCISCO, URANUS)
          MOON("Caliban", CALIBAN, URANUS)
          MOON("Stephano", STEPHANO, URANUS)
          MOON("Trinculo", TRINCULO, URANUS)
          MOON("Sycorax", SYCORAX, URANUS)
          MOON("Prospero", PROSPERO, URANUS)
          MOON("Margaret", MARGARET, URANUS)
          MOON("Setebos", SETEBOS, URANUS)
          MOON("Ferdinand", FERDINAND, URANUS)

        PLANET("Neptune", NEPTUNE)
          MOON("Naiad", NAIAD, NEPTUNE)
          MOON("Thalassa", THALASSA, NEPTUNE)
          MOON("Despina", DESPINA, NEPTUNE)
          MOON("Galatea", GALATEA, NEPTUNE)
          MOON("Larissa", LARISSA, NEPTUNE)
          MOON("Hippocamp", HIPPOCAMP, NEPTUNE)
          MOON("Proteus", PROTEUS, NEPTUNE)
          MOON("Triton", TRITON, NEPTUNE)
          MOON("Nereid", NEREID, NEPTUNE)
          MOON("Halimede", HALIMEDE, NEPTUNE)
          MOON("Sao", SAO, NEPTUNE)
          MOON("Laomedeia", LAOMEDEIA, NEPTUNE)
          MOON("Psamathe", PSAMATHE, NEPTUNE)
          MOON("Neso", NESO, NEPTUNE)

        PLANET("Orcus", ORCUS)
          MOON("Vanth", VANTH, ORCUS)

        PLANET("Lempo", LEMPO)
          MOON("Hiisi", HIISI, LEMPO)
          MOON("Paha", PAHA, LEMPO)
        
        PLANET("Pluto", PLUTO)
          MOON("Charon", CHARON, PLUTO)
          MOON("Styx", STYX, PLUTO)
          MOON("Nix", NIX, PLUTO)
          MOON("Kerberos", KERBEROS, PLUTO)
          MOON("Hydra", HYDRA, PLUTO)

        PLANET("Haumea", HAUMEA)
          MOON("Hi'iaka", HI_IAKA, HAUMEA)
          MOON("Namaka", NAMAKA, HAUMEA)

        PLANET("Quaoar", QUAOAR)
          MOON("Weywot", WEYWOT, QUAOAR)

        PLANET("Gonggong", GONGGONG)
          MOON("Xiangliu", XIANGLIU, GONGGONG)

        PLANET("Makemake", MAKEMAKE)
          MOON("Mo'o", MO_O, MAKEMAKE)

        PLANET("Eris", ERIS)
          MOON("Dysnomia", DYSNOMIA, ERIS)

        PLANET("Encke", ENCKE)
        PLANET("Halley", HALLEY)
    };
  #elifdef CENTAURI
    std::vector<Body> bodies = {
      STAR("Rigil Kentaurus", RIGIL_KENTAURUS)
      STAR("Toliman", TOLIMAN)

        STAR("Proxima Centauri", PROXIMA_CENTAURI)
          MOON("Proxima Centauri d", PROXIMA_CENTAURI_D, PROXIMA_CENTAURI)
          MOON("Proxima Centauri b", PROXIMA_CENTAURI_B, PROXIMA_CENTAURI)
    };
  #elifdef KEPLER_47
    std::vector<Body> bodies = {
      STAR("Kepler-47A", KEPLER_47_A)
      STAR("Kepler-47B", KEPLER_47_B)
        PLANET("Kepler-47b", KEPLER_47B)
        PLANET("Kepler-47d", KEPLER_47D)
        PLANET("Kepler-47c", KEPLER_47C)
    };
  #elifdef KEPLER_90
    std::vector<Body> bodies = {
      STAR("Kepler-90", KEPLER_90)
        PLANET("Kepler-90b", KEPLER_90B)
        PLANET("Kepler-90c", KEPLER_90C)
        PLANET("Kepler-90i", KEPLER_90I)
        PLANET("Kepler-90d", KEPLER_90D)
        PLANET("Kepler-90e", KEPLER_90E)
        PLANET("Kepler-90f", KEPLER_90F)
        PLANET("Kepler-90g", KEPLER_90G)
        PLANET("Kepler-90h", KEPLER_90H)
    };
  #elifdef LICH
    std::vector<Body> bodies = {
      STAR("Lich", LICH)
        PLANET("Draugr", DRAUGR)
        PLANET("Poltergeist", POLTERGEIST)
        PLANET("Phobetor", PHOBETOR)
    };
  #elifdef TRAPPIST_1
    std::vector<Body> bodies = {
      STAR("TRAPPIST-1", TRAPPIST_1)
        PLANET("TRAPPIST-1b", TRAPPIST_1B)
        PLANET("TRAPPIST-1c", TRAPPIST_1C)
        PLANET("TRAPPIST-1d", TRAPPIST_1D)
        PLANET("TRAPPIST-1e", TRAPPIST_1E)
        PLANET("TRAPPIST-1f", TRAPPIST_1F)
        PLANET("TRAPPIST-1g", TRAPPIST_1G)
        PLANET("TRAPPIST-1h", TRAPPIST_1H)
    };
  #else
    std::vector<Body> bodies;
  #endif
  #undef PLANET
  #undef MOON
  
  __attribute__((cold, noinline))
  System() noexcept;

  __attribute__((hot))
  void simulate(const scalar_t batch_time, const scalar_t timestep) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  Body* get_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result create_body(
    const std::string& name,
    const scalar_t mass,
    const scalar_t radius,
    const scalar_t luminosity,
    const vector_t<scalar_t>& position,
    const vector_t<scalar_t>& velocity
  ) noexcept;

  __attribute__((cold, noinline))
  Result destroy_body(const std::string& name) noexcept;

  __attribute__((cold, noinline))
  Result purge_bodies() noexcept;
};


#ifdef GRAPHICS


  class GuiView final {
    System& system;
    std::string name_one;
    std::string name_two;
    scalar_t radius;
    sf::RenderWindow window;
    sf::Font font; 
    sf::Color grey = sf::Color(128, 128, 128);

    public:

    GuiView(System& system, const std::string& name_one, const std::string& name_two, const scalar_t radius) noexcept;

    void open() noexcept;

    void close() noexcept;

    void render() noexcept;

    Result focus(const std::string& name_one, const std::string& name_two) noexcept;

    Result scale(const scalar_t radius) noexcept;
  };


#endif


class SystemView final {
  System& system;
  std::string name_one;
  std::string name_two;
  scalar_t radius;
  std::size_t width;
  std::size_t height;

  public:

  __attribute__((cold, noinline))
  SystemView(
    System& system,
    const std::string& name_one,
    const std::string& name_two,
    const scalar_t radius,
    const std::size_t width,
    const std::size_t height
  ) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_one() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  std::string get_name_two() const noexcept;

  [[nodiscard]] __attribute__((cold, noinline))
  scalar_t get_radius() const noexcept;

  __attribute__((cold, noinline))
  Result focus(const std::string& name_one, const std::string& name_two) noexcept;

  __attribute__((cold, noinline))
  Result scale(const scalar_t radius) noexcept;
};


class AxesView final {
  System& system;
  std::size_t width;
  std::size_t height;

  public: 

  __attribute__((cold, noinline))
  AxesView(System& system, const std::size_t width, const std::size_t height) noexcept;

  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window() const noexcept;
};


struct Display final {
  SystemView views[6];
  
  [[nodiscard]] __attribute__((hot, pure))
  windowlib::Window get_window(const std::size_t index) const noexcept;
};


struct Simulation final {
  System& system;
  #ifdef GRAPHICS
    GuiView& gui_view;
  #endif
  Display& display;
  bool gui = false;
  bool pause = false;
  bool running = true;

  __attribute__((cold, noinline))
  #ifdef GRAPHICS
    Simulation(System& system, GuiView& gui_view, Display& display) noexcept;
  #else
    Simulation(System& system, Display& display) noexcept;
  #endif

  __attribute__((cold, noinline))
  Result save(const std::string& filename) const noexcept;

  __attribute__((cold, noinline))
  Result load(const std::string& filename) noexcept;
};
