#include <cstddef>
// std::size_t

#include <functional>
// std::function

#include <string>
// std::string

#include "console.hpp"
// ConsoleView

#include "../../utils/format.hpp"
// format::

#include "../../utils/windowlib.hpp"
// windowlib::


__attribute__((cold, noinline))
ConsoleView::ConsoleView(std::vector<std::function<std::string()>> fields, const std::size_t width, const std::size_t height) noexcept {
  this->fields = fields;
  this->width = width * 2;
  this->height = height;
}

[[nodiscard]] __attribute__((hot, pure))
windowlib::Window ConsoleView::get_window() const noexcept {
  windowlib::Window window(this->height);
  for (std::size_t i = 0; i < this->fields.size(); i++) {
    window[i] = this->fields[i]();
  }
  for (std::size_t i = 0; i < this->height; i++) {
    window[i] = format::pad_right(window[i], this->width);
  }
  return windowlib::border(window);
}