# Body Problem
  - A sandboxed runtime model of astrophysics

# Physics
  - Pairwise Newtonian gravity
  - Pairwise inelastic collisions (optional)
  - Pairwise radiation pressure
  - Elementwise radiative mass loss

# Units
  - All units match what is listed below, unless otherwise stated
  - Mass: kilograms (kg)
  - Distance: meters (m)
  - Time: seconds (s)
  - Everything else: derived from the above

# User Interface
  - Simple textual graphics via seven views with configurable reference frame
  - Simulation is concurrent, every real second is one day for the simulation
  - While the simulation runs, users can push commands which range from manipulating bodies to time skipping to saving and loading simulations

# Lua scripting API
  - cpp/body_problem/mods is prepended to package.path automatically
  - Two functions must be defined in cpp/body_problem/mods/main.lua: tick(dt) and init().
  - Neither function returns anything
  - tick runs periodically, many times per minute
  - init runs once during simulation initialization
  - Three functions are provided: command(name, args), get_body(name), and get_names()
  - command(name, args) takes the name of a command and an argument table and executes a command
  - get_body(name) takes the name of a body and returns a table describing it, returns nil on failure
  - get_names() returns an array of all valid body names
  - Failure to comply with this API may result in UB

# Run and Build
  - Ensure that the current working directory is workspace
  - Run the following command: python cpp/body_problem/launch.py
  - Or: bodies

# Supported Operating Systems
  - Linux (tested)
  - Windows (untested)

# System Requirements
  - 3 processors

# Compiler Requirements
  - C++23 or later

# Interpreter Requirements
  - Python 3 or later
  - Lua 5.1, 5.2, 5.3, 5.4, or 5.5

# Dependencies
  - cpp/utils 5.7.0 or later

# Known Issues
  - Z axis symbol appears in first line of AxesView window if windowlib::title is used instead of windowlib::border