# Body Problem
  - A sandboxed runtime model of astrophysics

# Physics
  - Pairwise Newtonian gravity
  - Pairwise inelastic collisions (optional)
  - Pairwise radiation pressure
  - Elementwise radiative mass loss

# Units
  - All units match what is listed below, unless otherwise stated
  - Mass: kilograms (kg)
  - Distance: meters (m)
  - Time: seconds (s)
  - Everything else: derived from the above

# User Interface
  - Simple textual graphics via seven views with configurable reference frame
  - Simulation is concurrent, every real second is one day for the simulation
  - While the simulation runs, users can push commands which range from manipulating bodies to time skipping to saving and loading simulations
  - SFML GUI is also available if your hardware can support it and you have SFML downloaded
  - Use the --headless flag to force SFML to be disabled

# Lua scripting API
  - cpp/body_problem/mods is prepended to package.path automatically
  - Two global functions must be defined in cpp/body_problem/mods/main.lua: TICK(dt) and INIT().
  - Neither function returns anything
  - TICK runs periodically, many times per minute
  - INIT runs once during simulation initialization
  - Three functions are provided: command(name, args), get_body(name), and get_names()
  - command(name, args) takes the name of a command and an argument table and executes a command
  - get_body(name) takes the name of a body and returns a table describing it, returns nil on failure
  - get_names() returns an array of all valid body names
  - Failure to comply with this API may result in UB

# Star systems
  - The currently supported star system are listed below
  - Sol
  - Centauri

# Run and Build
  - Ensure that the current working directory is workspace
  - Run the following command: bash cpp/body_problem/scripts/run.sh
  - Or: bodies

# Supported Operating Systems
  - Linux (tested)
  - Windows (untested)

# System Requirements
  - 3 threads

# Compiler Requirements
  - C++23 or later

# Interpreter Requirements
  - Python 3 or later
  - Lua 5.1, 5.2, 5.3, 5.4, or 5.5

# Dependencies
  - cpp/utils 6.8.0 or later

# Known Issues
  - Z axis symbol appears in first line of AxesView window if windowlib::title is used instead of windowlib::border
