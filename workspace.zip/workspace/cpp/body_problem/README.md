# Body Problem
  - A sandboxed runtime for a model of the Solar System
  - Supports full pairwise Newtonian gravity and simple merging spherical collisions
  - Simulation can be changed on the fly via the command system
  - DSL allows for saving and loading simulations

# Run and Build
  - Ensure that the current working directory is workspace
  - Run the following command: bodies

# Supported Operating Systems
  - Linux (tested)
  - Windows (untested)

# System Requirements
  - 2 processors

# Compiler Requirements
  - C++23 or later

# Interpreter Requirements
  - Python 3 or later

# Dependencies
  - cpp/utils 3.1.0 or later