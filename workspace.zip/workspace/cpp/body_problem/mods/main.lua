local Body = require("body")
local Vector = require("vector")

function tick(dt)
end

function init()
end
