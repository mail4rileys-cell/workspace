local Body = require("body")
local Vector = require("vector")

function TICK(dt)
  --local names = get_names()
  --local name_one = names[math.random(1, #names)]
  --local name_two = names[math.random(1, #names)]
  --local body_one = get_body(name_one)
  --local body_two = get_body(name_two)
  --command("modify_body", {
    --name = name_one,
    --pos_x = body_two.pos_x,
    --pos_y = body_two.pos_y,
    --pos_z = body_two.pos_z
  --})
  --command("modify_body", {
    --name = name_two,
    --pos_x = body_one.pos_x,
    --pos_y = body_one.pos_y,
    --pos_z = body_one.pos_z
  --})
end

function INIT()
end
