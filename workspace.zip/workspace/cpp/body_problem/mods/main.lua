local Body = require("body")
local Vector = require("vector")

local gravitational_constant = 6.67430e-11
local day = 86400

function TICK(dt)
end

local elapsed = 0
function TICK_(dt)
  elapsed = elapsed + dt
  if elapsed < 30 then
    return
  end
  elapsed = 0
  local names = get_names()
  local host = Body.get(names[math.random(1, #names)])
  local period = day * 5
  local distance = ((gravitational_constant * host.mass * period * period) / (4 * math.pi * math.pi)) ^ (1 / 3)
  local speed = ((gravitational_constant * host.mass) / distance) ^ (1 / 2)
  local sat_name = host.name .. "-sat"
  while true do
    local collision = false
    for i, name in ipairs(names) do
      if name == sat_name then
        sat_name = sat_name .. "-sat"
        collision = true
        break
      end
    end
    if not collision then
      break
    end
  end
  command("create_body", {
    anchor = host.name,
    name = sat_name,
    mass = host.mass * 0.01,
    radius = host.radius * 0.01,
    luminosity = host.luminosity * 0.01,
    pos_x = distance,
    pos_y = 0,
    pos_z = 0,
    vel_x = 0,
    vel_y = speed,
    vel_z = 0
  })
  command("focus_view", {
    index = 0,
    name_one = host.name,
    name_two = "none"
  })
  command("scale_view", {
    index = 0,
    radius = distance * 1.1
  })
end

function INIT()
end
