local Body = require("body")
local Vector = require("vector")

function TICK(dt)
end

function INIT()
end
