local Body = require("body")
local Vector = require("vector")

function TICK(dt)
  --local oberon_mass = get_body("Oberon").mass
  --for _, name in ipairs(get_names()) do
    --command("modify_body", {
      --name = name,
      --mass = get_body(name).mass + oberon_mass
    --})
  --end
end

function INIT()
end
