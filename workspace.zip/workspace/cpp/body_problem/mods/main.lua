local Body = require("body")
local Vector = require("vector")

function TICK(dt)
end

function INIT()
  local charon = get_body("Charon")
end
