local Vector = require("vector")

local Body = {}
Body.__index = Body

function Body.get(name)
	local body = get_body(name)
	return setmetatable({
		name = name,
		mass = body.mass,
		radius = body.radius,
		luminosity = body.luminosity,
		position = Vector.new(
			body.pos_x,
			body.pos_y,
			body.pos_z
		),
		velocity = Vector.new(
			body.vel_x,
			body.vel_y,
			body.vel_z
		)
	}, Body)
end

function Body.new(name, mass, radius, luminosity, position, velocity)
	return setmetatable({
		name = name,
		mass = mass,
		radius = radius,
		luminosity = luminosity,
		position = position,
		velocity = velocity
	}, Body)
end

return Body
