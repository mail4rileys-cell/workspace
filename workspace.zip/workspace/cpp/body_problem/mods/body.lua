Body = {}
Body.__index = Body

function Body.new(name)
	local body = get_body(name)
	return setmetatable({
		name = name,
		mass = body.mass,
		radius = body.radius,
		luminosity = body.luminosity,
		position = Vector.new(
			body.pos_x,
			body.pos_y,
			body.pos_z
		),
		velocity = Vector.new(
			body.vel_x,
			body.vel_y,
			body.vel_z
		)
	}, Body)
end

return Body