local Vector = require("../../../lua/utils/vector")

Body = {}
Body.__index = Body

function Body.new(name)
	local body = get_body(name)
	return setmetatable({
		name = name,
		mass = body.mass,
		radius = body.radius,
		luminosity = body.luminosity,
		position = Vector.new(
			body.pos_x,
			body.pos_y,
			body.pos_z
		),
		velocity = Vector.new(
			body.vel_x,
			body.vel_y,
			body.vel_z
		)
	}, Body)
end


local counter = 0
function tick(dt)
	counter = counter + dt
	if counter < 10 then
		return
	end
	counter = 0
	for i, name in ipairs(get_names()) do
		command("modify_body", {
			name = name,
			mass = get_body(name).mass * 2
		})
	end
end

function init()
	command("toggle_collisions", {})
end
