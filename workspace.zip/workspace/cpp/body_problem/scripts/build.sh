#!/bin/bash
set -euo pipefail

if [ $1 == "-c" ]; then

  clear
  
	echo "Searching for Lua package..."
	LUA_PACKAGE="none"
	for name in "lua5.5" "lua5.4" "lua5.3" "lua5.2" "lua5.1" "lua"; do
		if pkg-config --exists $name; then
			LUA_PACKAGE=$name
			break
		fi
	done
	if [ LUA_PACKAGE == "none" ]; then
		echo "Error: Lua package not found"
		exit 1
	fi
	echo "Lua package found: $LUA_PACKAGE"

	echo "Compiling Body Problem..."
  g++ \
  $(find cpp/body_problem/source -name "*.cpp") \
  $(pkg-config --cflags --libs $LUA_PACKAGE) \
  -o cpp/body_problem/body_problem.exe \
  -std=c++23 \
  -O3 \
  -march=native \
  -ffast-math \
  -flto \
  -Wno-unused-result \
  -Wno-multichar \
  -Wno-overflow \
  -Wno-constant-conversion
  echo "Body Problem compiled as cpp/body_problem/body_problem.exe"
  
elif [ $1 != "-nc" ]; then
  echo "Invalid flag: $1"
  exit 1
fi

if [ $# -eq 2 ]; then
  ./cpp/body_problem/body_problem.exe $2
else
  ./cpp/body_problem/body_problem.exe
fi

exit 0