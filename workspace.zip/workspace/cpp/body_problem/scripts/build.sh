#!/bin/bash
set -euo pipefail


clear
  
echo "Searching for Lua interpreter..."
LUA="none"
for name in "lua5.5" "lua5.4" "lua5.3" "lua5.2" "lua5.1" "lua"; do
	if pkg-config --exists $name; then
		LUA=$name
		break
	fi
done
	if [ $LUA == "none" ]; then
	  echo "Error: Lua interpreter not found"
	  exit 1
	fi
echo "Lua interpreter found: $LUA"

SFML="none"
FLAG="none"
echo "Searching for SMFL graphics..."
if pkg-config --exists sfml-graphics; then
	echo "SFML graphics found"
	SFML="$(pkg-config --cflags --libs sfml-graphics)"
	FLAG="-DGRAPHICS"
else
	echo "SFML graphics not found"
	SFML=""
	FLAG="-DNO_GRAPHICS"
fi

star_system="SOL"
if [ "$1" == "-n" ]; then
  star_system="$2"
  echo "Compiling Body Problem ($2)"
elif [ "$1" == "-l" ]; then
	echo "Compiling Body Problem (SOL) and loading $2"
fi

clang++ \
  $(find cpp/body_problem/source -name "*.cpp") \
  $(pkg-config --cflags --libs $LUA) \
  $SFML \
  $FLAG \
	-D"$star_system" \
  -o cpp/body_problem/body_problem \
  -std=c++23 \
  -O3 \
  -march=native \
  -ffast-math \
  -flto \
  -Werror \
  -Wall \
  -Wextra \
  -Wpedantic
echo "Body Problem compiled"

if [ "$1" == "-l" ]; then
  ./cpp/body_problem/body_problem "$2"
else
  ./cpp/body_problem/body_problem
fi

exit 0
