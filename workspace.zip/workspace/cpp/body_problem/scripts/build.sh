#!/bin/bash
set -euo pipefail

if [ "$1" == "-c" ]; then

  clear
  
	echo "Searching for Lua interpreter..."
	LUA="none"
	for name in "lua5.5" "lua5.4" "lua5.3" "lua5.2" "lua5.1" "lua"; do
		if pkg-config --exists $name; then
			LUA=$name
			break
		fi
	done
	if [ $LUA == "none" ]; then
		echo "Error: Lua interpreter not found"
		exit 1
	fi
	echo "Lua interpreter found: $LUA"

	echo "Compiling Body Problem..."
  clang++ \
    $(find cpp/body_problem/source -name "*.cpp") \
    $(pkg-config --cflags --libs $LUA) \
    $(pkg-config --cflags --libs sfml-graphics) \
    -o cpp/body_problem/body_problem \
    -std=c++23 \
    -O3 \
    -march=native \
    -ffast-math \
    -flto \
    -Werror \
    -Wall \
    -Wextra \
    -Wpedantic
  echo "Body Problem compiled"
  
elif [ $1 != "-nc" ]; then
  echo "Invalid flag: $1"
  exit 1
fi

if [ $# -eq 2 ]; then
  ./cpp/body_problem/body_problem $2
else
  ./cpp/body_problem/body_problem
fi

exit 0
