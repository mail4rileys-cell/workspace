#!/bin/bash
set -euo pipefail

if [ "$1" == "-c" ]; then

  clear
  
  echo "Searching for Lua interpreter..."
  LUA="none"
  for name in "lua5.5" "lua5.4" "lua5.3" "lua5.2" "lua5.1" "lua"; do
	if pkg-config --exists $name; then
		LUA=$name
		break
	fi
  done
	if [ $LUA == "none" ]; then
	  echo "Error: Lua interpreter not found"
	  exit 1
	fi
  echo "Lua interpreter found: $LUA"

  SFML="none"
  FLAG="none"
  echo "Searching for SMFL graphics..."
  if pkg-config --exists sfml-graphics; then
	echo "SFML graphics found"
	SFML="$(pkg-config --cflags --libs sfml-graphics)"
	FLAG="-DGRAPHICS"
  else
	echo "SFML graphics not found"
	SFML=""
	FLAG="-DNO_GRAPHICS"
  fi

  declare -u star_system
  read -p "Select star system (Sol, Centauri, Lich, TRAPPIST_1): " star_system
  if [ $star_system != "SOL" ] && [ $star_system != "CENTAURI" ] && [ $star_system != "LICH" ] && [ $star_system != "TRAPPIST_1" ]; then
	  echo "Error: $star_system is not a valid star system"
	  exit 1
  fi
  
  echo "Compiling Body Problem..."
  clang++ \
    $(find cpp/body_problem/source -name "*.cpp") \
    $(pkg-config --cflags --libs $LUA) \
    $SFML \
    $FLAG \
	-D$star_system \
    -o cpp/body_problem/body_problem \
    -std=c++23 \
    -O3 \
    -march=native \
    -ffast-math \
    -flto \
    -Werror \
    -Wall \
    -Wextra \
    -Wpedantic
  echo "Body Problem compiled"
  
elif [ $1 != "-nc" ]; then
  echo "Invalid flag: $1"
  exit 1
fi

if [ $# -eq 2 ]; then
  ./cpp/body_problem/body_problem $2
else
  ./cpp/body_problem/body_problem
fi

exit 0
