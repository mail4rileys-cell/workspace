#!/bin/bash
set -euo pipefail

clear
echo "Launching Body Problem..."

echo "Searching for Python interpreter..."
PYTHON="none"
for name in python3 python; do
  if command -v $name >/dev/null 2>&1; then
    PYTHON=$name
    break
  fi
done
if [ $PYTHON == "none" ]; then
  echo "Error: Python interpreter not found"
  exit 1
fi
echo "Python interpreter found: $PYTHON"
$PYTHON cpp/body_problem/scripts/launch.py

echo "Body Problem terminated"
exit 0
