#!/bin/bash
set -euo pipefail

clear
echo "Launching Body Problem..."
if [ ! -f cpp/body_problem/scripts/launch.py ]; then
	echo "Error: launcher not found"
	exit 1
fi
python cpp/body_problem/scripts/launch.py
echo "Body Problem terminated"
exit 0