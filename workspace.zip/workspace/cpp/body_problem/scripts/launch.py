import os
import subprocess
import sys

from utils import formatlib

def search(path, target, tokens = ("\n", " ")):
  with open(path, "r") as file:
    data = file.read()
  start = data.find(target)
  if start == -1:
    return None
  start += len(target)
  end = len(data)
  for token in tokens:
    pos = data.find(token, start)
    if pos != -1:
      end = min(end, pos)
  return data[start:end]


class Files(list):

  def __init__(self, path, suffix):
    self.path = path
    self.suffix = suffix
    with os.scandir(path) as directory:
      for file in directory:
        if file.is_file() and file.name.endswith(self.suffix):
          self.append(file)
    self.sort(key = lambda file: file.name)

  def get_contents(self):
    if len(self) == 0:
      return ["No files found"]
    contents = []
    for i, file in enumerate(self):
      line = str(i + 1) + ". " + file.name.split(self.suffix)[0]
      line += " | version " + search(file.path, "version ")
      contents.append(line)
    return contents

  def has(self, name):
    for file in self:
      if file.name == name + self.suffix:
        return True
    return False

  def get(self, name):
    for i, file in enumerate(self):
      if file.name == name + self.suffix:
        return file.name.split(self.suffix)[0]

  def delete(self, name):
    for i, file in enumerate(self):
      if file.name == name + self.suffix:
        os.remove(file.path)
        del self[i]
        return


class LaunchError(Exception):
  def __init__(self, message):
    super().__init__(message)


def run(filename = None):
  cmd = ["bash", "cpp/body_problem/scripts/build.sh"]
  if hasattr(run, "compiled"):
    cmd.append("-nc")
  else:
    cmd.append("-c")
    run.compiled = True
  if filename is not None:
    cmd.append(filename)
  result = subprocess.run(cmd)
  if result.returncode != 0:
    raise LaunchError(repr(result) + " failed")

def load_menu(files):
  while True:
    os.system("clear")
    if files:
      print(formatlib.title_box("Load", [*files.get_contents(), str(len(files) + 1) + ". Quit"]))
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      run(files[int(choice) - 1].name.split(files.suffix)[0])
      files = Files(files.path, files.suffix)
    elif files.has(choice):
      run(files.get(choice))
      files = Files(files.path, files.suffix)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

def delete_menu(files):
  while True:
    os.system("clear")
    print(formatlib.title_box("Delete", [*files.get_contents(), str(len(files) + 1) + ". Quit"]))
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      files.delete(files[int(choice) - 1].name.split(files.suffix)[0])
    elif files.has(choice):
      files.delete(choice)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

def main():
  files = Files("cpp/body_problem/saves", ".sim")
  while True:
    os.system("clear")
    print(formatlib.title_box("Body Problem " + search("cpp/body_problem/version.txt", ""), [
      "1. New",
      "2. Load",
      "3. Delete",
      "4. Modify",
      "5. About",
      "6. Changelog",
      "7. Quit"
    ]))
    choice = input(">: ").lower().strip()
    if choice == "1" or choice == "new" or choice == "n":
      run()
      files = Files(files.path, files.suffix)
    elif choice == "2" or choice == "load" or choice == "l":
      load_menu(files)
    elif choice == "3" or choice == "delete" or choice == "d":
      delete_menu(files)
    elif choice == "4" or choice == "modify" or choice == "m":
      with open("cpp/body_problem/scripts/modify.lua", "a"): pass # ensure modify.lua exists
      subprocess.run([os.environ.get("EDITOR", "nano"), "cpp/body_problem/scripts/modify.lua"])
    elif choice == "5" or choice == "about" or choice == "a":
      os.system("clear")
      subprocess.run([os.environ.get("PAGER", "less"), "cpp/body_problem/README.md"])
    elif choice == "6" or choice == "changelog" or choice == "c":
      os.system("clear")
      subprocess.run([os.environ.get("PAGER", "less"), "archive/cpp/body_problem/changelog.md"])
    elif choice == "7" or choice == "quit" or choice == "q":
      os.system("clear")
      return 0

if __name__ == "__main__":
  sys.exit(main())