from __future__ import annotations

import os
import subprocess
import sys

from typeguard import typechecked

from utils import formatlib

@typechecked
def search(path: str, target: str, tokens: list[str] = ["\n", " "]) -> str | None:
  with open(path, "r") as file:
    data = file.read()
  start = data.find(target)
  if start == -1:
    return None
  start += len(target)
  end = len(data)
  for token in tokens:
    pos = data.find(token, start)
    if pos != -1:
      end = min(end, pos)
  return data[start:end]


class Files(list):
  
  @typechecked
  def __init__(self: Files, path: str, suffix: str) -> None:
    self.path = path
    self.suffix = suffix
    with os.scandir(path) as directory:
      for file in directory:
        if file.is_file() and file.name.endswith(self.suffix):
          self.append(file)
    self.sort(key = lambda file: file.name)

  @typechecked
  def get_contents(self: Files) -> list[str]:
    contents = []
    for i, file in enumerate(self):
      line = str(i + 1) + ". " + file.name.split(self.suffix)[0]
      line += " | version " + str(search(file.path, "version "))
      contents.append(line)
    return ["No files found"] if len(contents) == 0 else contents

  @typechecked
  def has(self: Files, name: str) -> bool:
    for file in self:
      if file.name == name + self.suffix:
        return True
    return False

  @typechecked
  def delete(self: Files, name: str) -> None:
    for i, file in enumerate(self):
      if file.name == name + self.suffix:
        os.remove(file.path)
        del self[i]
        return


class LaunchError(Exception):
  
  @typechecked
  def __init__(self: LaunchError, message: str) -> None:
    super().__init__(message)


@typechecked
def run(*args: str) -> None:
  result = subprocess.run([
    "bash",
    "cpp/body_problem/scripts/build.sh",
    *args
  ])
  if result.returncode != 0:
    raise LaunchError(repr(result) + " failed")

@typechecked
def new_menu() -> None:
  while True:
    subprocess.run("clear")
    print(formatlib.title_box("New", [
      "1. Empty",
      "2. Sol",
      "3. Centauri",
      "4. Kepler-47",
      "5. Kepler-90",
      "6. Lich",
      "7. TRAPPIST-1",
      "8. Butterfly-I",
      "9. Chenciner-Montgomery figure-eight",
      "10. Sitnikov pendulum",
      "11. Quit"
    ]))
    match input(">: ").lower().strip():
      case "1" | "empty" | "e":
        run("-n", "EMPTY")
      case "2" | "sol" | "s":
        run("-n", "SOL")
      case "3" | "centauri" | "c":
        run("-n", "CENTAURI")
      case "4" | "kepler-47" | "k":
        run("-n", "KEPLER_47")
      case "5" | "kepler-90" | "k":
        run("-n", "KEPLER_90")
      case "6" | "lich" | "l":
        run("-n", "LICH")
      case "7" | "trappist-1" | "t":
        run("-n", "TRAPPIST_1")
      case "8" | "butterfly-i" | "b":
        run("-n", "BUTTERFLY_I")
      case "9" | "chenciner-montgomery figure-eight" | "cf":
        run("-n", "CHENCINER_MONTGOMERY_FIGURE_EIGHT")
      case "10" | "sitnikov pendulum" | "sp":
        run("-n", "SITNIKOV_PENDULUM")
      case "11" | "quit" | "q":
        return

@typechecked
def load_menu(files: Files) -> None:
  while True:
    subprocess.run("clear")
    print(formatlib.title_box("Load", [*files.get_contents(), str(len(files) + 1) + ". Quit"]))
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      run("-l", files[int(choice) - 1].name.split(files.suffix)[0])
      files = Files(files.path, files.suffix)
    elif files.has(choice):
      run("-l", choice)
      files = Files(files.path, files.suffix)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

@typechecked
def delete_menu(files: Files) -> None:
  while True:
    subprocess.run("clear")
    print(formatlib.title_box("Delete", [*files.get_contents(), str(len(files) + 1) + ". Quit"]))
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      files.delete(files[int(choice) - 1].name.split(files.suffix)[0])
    elif files.has(choice):
      files.delete(choice)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

@typechecked
def main() -> int:
  files = Files("cpp/body_problem/saves", ".bps")
  while True:
    subprocess.run("clear")
    print(formatlib.title_box("Body Problem " + str(search("cpp/body_problem/version.txt", "")), [
      "1. New",
      "2. Load",
      "3. Delete",
      "4. Mods",
      "5. About",
      "6. Changelog",
      "7. Quit"
    ]))
    choice = input(">: ").lower().strip()
    if choice == "1" or choice == "new" or choice == "n":
      new_menu()
      files = Files(files.path, files.suffix)
    elif choice == "2" or choice == "load" or choice == "l":
      load_menu(files)
    elif choice == "3" or choice == "delete" or choice == "d":
      delete_menu(files)
    elif choice == "4" or choice == "mods" or choice == "m":
      with open("cpp/body_problem/mods/main.lua", "a"): pass # ensure main.lua exists
      subprocess.run([os.environ.get("EDITOR", "nano"), "cpp/body_problem/mods/main.lua"])
    elif choice == "5" or choice == "about" or choice == "a":
      subprocess.run("clear")
      subprocess.run([os.environ.get("PAGER", "less"), "cpp/body_problem/README.md"])
    elif choice == "6" or choice == "changelog" or choice == "c":
      subprocess.run("clear")
      subprocess.run([os.environ.get("PAGER", "less"), "archive/cpp/body_problem/changelog.md"])
    elif choice == "7" or choice == "quit" or choice == "q":
      subprocess.run("clear")
      return 0

if __name__ == "__main__":
  sys.exit(main())
