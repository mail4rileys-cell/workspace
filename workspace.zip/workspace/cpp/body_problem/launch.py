import os
import sys
import subprocess

def display(path):
  with open(path, "r") as file:
    for line in file:
      print(line)

def search(path, target, tokens = ("\n", " ")):
  with open(path, "r") as file:
    data = file.read()
  start = data.find(target)
  if start == -1:
    return None
  start += len(target)
  end = len(data)
  for token in tokens:
    pos = data.find(token, start)
    if pos != -1:
      end = min(end, pos)
  return data[start:end]


class Files(list):

  def __init__(self, path, suffix):
    self.path = path
    self.suffix = suffix
    with os.scandir(path) as directory:
      for file in directory:
        if file.is_file() and file.name.endswith(self.suffix):
          self.append(file)
    self.sort(key = lambda file: file.name)

  def __str__(self):
    result = ""
    for i, file in enumerate(self):
      result += str(i + 1) + ". name: " + file.name.strip(self.suffix)
      result += " | version: " + str(search(file.path, "version = "))
      result += " | time: " + str(round(float(search(file.path, "time = ")) / 31536000, 2)) + " yr"
      result += " | collisions: " + str(search(file.path, "collisions = "))
      if i != len(self) - 1:
        result += "\n"
    return result

  def has(self, name):
    for file in self:
      if file.name == name + self.suffix:
        return True
    return False

  def get(self, name):
    for i, file in enumerate(self):
      if file.name == name + self.suffix:
        return file.name.strip(self.suffix)

  def delete(self, name):
    for i, file in enumerate(self):
      if file.name == name + self.suffix:
        os.remove(file.path)
        del self[i]
        return


def run(filename = None):
  cmd = ["bash", "cpp/body_problem/build.sh"]
  if hasattr(run, "compiled"):
    cmd.append("-nc")
  else:
    cmd.append("-c")
    run.compiled = True
  if filename is not None:
    cmd.append(filename)
  subprocess.run(cmd)

def load_menu(files):
  while True:
    os.system("clear")
    print("Load")
    print("----")
    if files:
      print(files)
    print(str(len(files) + 1) + ". Quit")
    print("----")
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      run(files[int(choice) - 1].name.strip(files.suffix))
      files = Files(files.path, files.suffix)
    elif files.has(choice):
      run(files.get(choice))
      files = Files(files.path, files.suffix)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

def delete_menu(files):
  while True:
    os.system("clear")
    print("Delete")
    print("------")
    if files:
      print(files)
    print(str(len(files) + 1) + ". Quit")
    print("------")
    choice = input(">: ").strip()
    if choice.isnumeric() and int(choice) >= 1 and int(choice) <= len(files):
      files.delete(files[int(choice) - 1].name.strip(files.suffix))
    elif files.has(choice):
      files.delete(choice)
    elif choice == str(len(files) + 1) or choice == "quit" or choice == "q":
      return

def main():
  files = Files("cpp/body_problem/saves", ".sim")
  while True:
    os.system("clear")
    print("version: " + search("cpp/body_problem/version.txt", ""))
    print("Body Problem")
    print("------------")
    print("1. New")
    print("2. Load")
    print("3. Delete")
    print("4. About")
    print("5. Changelog")
    print("6. Quit")
    print("------------")
    choice = input(">: ").lower().strip()
    if choice == "1" or choice == "new" or choice == "n":
      run()
      files = Files(files.path, files.suffix)
    elif choice == "2" or choice == "load" or choice == "l":
      load_menu(files)
    elif choice == "3" or choice == "delete" or choice == "d":
      delete_menu(files)
    elif choice == "4" or choice == "about" or choice == "a":
      os.system("clear")
      display("cpp/body_problem/README.md")
      input("Input anything to continue: ")
    elif choice == "5" or choice == "changelog" or choice == "c":
      os.system("clear")
      display("archive/cpp/body_problem/changelog.md")
      input("Input anything to continue: ")
    elif choice == "6" or choice == "quit" or choice == "q":
      os.system("clear")
      return 0

if __name__ == "__main__":
  sys.exit(main())