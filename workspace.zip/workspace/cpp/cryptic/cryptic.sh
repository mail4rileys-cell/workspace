#!/bin/bash
set -euo pipefail

if [ ! -f cryptic.exe ] || [ cryptic.cpp -nt cryptic.exe ]; then
  echo "Compiling cryptic.cpp..."
  g++ -std=c++23 cryptic.cpp -o cryptic.exe -DMAIN -march=native -Ofast -Wno-psabi -Wno-unused-result
fi