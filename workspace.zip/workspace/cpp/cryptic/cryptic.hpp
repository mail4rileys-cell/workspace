#pragma once

#include <string>
// std::string

void cryptic(const std::string directive, const std::string input_filename, const std::string output_filename) noexcept;