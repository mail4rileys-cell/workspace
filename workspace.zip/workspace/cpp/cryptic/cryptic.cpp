#pragma GCC diagnostic error "-Wall"

#include <algorithm>
// std::shuffle

#include <cstdint>
// std::intmax_t
// std::uintmax_t
// std::uint8_t
// std::uint32_t
// std::uint64_t

#include <cstdlib>
// std::system

#include <fstream>
// std::ifstream
// std::ofstream

#include <iterator>
// std::begin
// std::end

#include <ios>
// std::ios
// std::streampos

#include <iostream>
// std::cin
// std::cout
// std::endl

#include <random>
// std::random_device
// std::mt19937

#include <stdexcept>
// std::runtime_error

#include <string>
// std::string

#include <vector>
// std::vector

#include <termios.h>

#include <unistd.h>

#include "cryptic.hpp"
// cryptic

#include "../utils/bitwise.hpp"
// bitwise::

#include "../utils/concepts.hpp"

template<typename Value>
requires
  concepts::add_c::mut<Value, Value, Value> &&
  concepts::xor_c::mut<Value, Value, Value>
Value mix(Value a, Value b) noexcept {
  for (std::uint16_t i = 0; i < 64; i++) {
    a += bitwise::rotate::left<Value, std::uint8_t>(b, 19) * 37;
    a ^= bitwise::rotate::right<Value, std::uint8_t>(b, 23) * 31;
    b ^= a * 29;
    a += bitwise::rotate::right<Value, std::uint8_t>(b, 31) * 23;
    a ^= bitwise::rotate::left<Value, std::uint8_t>(b, 37) * 19;
  }
  return a * 17;
}

struct Keyboard {
  private:
  char original[36] = {
      '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
      'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
      'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
      'u', 'v', 'w', 'x', 'y', 'z'
    };
  char mapping[36];
  public:

  Keyboard() noexcept {
    for (std::uint8_t i = 0; i < 36; i++) {
      this->mapping[i] = this->original[i];
    }
    this->shuffle();
  }

  void shuffle() noexcept {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::shuffle(std::begin(this->mapping), std::end(this->mapping), gen);
  }

  void render() const noexcept {
    for (std::uint8_t i = 0; i < 36; i++) {
      if (((i % 6) == 0) && (i != 0)) {
        std::cout << std::endl;
      }
      for (std::uint8_t j = 0; j < 36; j++) {
        if (this->mapping[j] == this->original[i]) {
          std::cout << "[ " << this->mapping[j] << " -> " << (int)j << ((j < 10) ?  " " : "") << " ]";
          break;
        }
      }
    }
    std::cout << std::endl;
  }

  char operator[](const std::uintmax_t index) const noexcept {
    return this->mapping[index];
  }
};

struct Nonce {
  private:
  std::uint32_t values[16];
  public:

  Nonce() = default;

  Nonce(const std::string directive, std::ifstream&input) {
    if ((directive == "e") || (directive == "encrypt")) {
      std::random_device rd;
      for (std::uint8_t i = 0; i < 16; i++) {
        this->values[i] = rd();
      }
    } else if ((directive == "d") || (directive == "decrypt")) {
      input.read(reinterpret_cast<char*>(this->values), sizeof(this->values));
    } else {
      throw std::runtime_error("Unknown directive: " + directive);
    }
  }

  void dump(std::string directive, std::ofstream&output) const noexcept {
    if ((directive == "e") || (directive == "encrypt")) {
      output.write(reinterpret_cast<const char*>(this->values), sizeof(this->values));
    }
  }

  std::uint32_t operator[](const std::uintmax_t index) const noexcept {
    return this->values[index];
  }
};

struct KeyStream {
  private:
  std::uint64_t pool[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  std::uint64_t roll = 0;
  public:

  KeyStream() = default;

  KeyStream(const Nonce& nonce) noexcept {
    Keyboard keyboard;
    std::intmax_t index = 0;
    volatile std::uintmax_t length = 0;
    termios old_tio;
    termios new_tio;
    tcgetattr(STDIN_FILENO, &old_tio);
    new_tio = old_tio;
    new_tio.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &new_tio);
    while (true) {
      std::system("clear");
      keyboard.render();
      std::cout << "Input password: ";
      for (std::uintmax_t i = 0; i < length; i++) {
        std::cout << "*";
      }
      std::cin >> index;
      if ((index >= 0) && (index < 36)) {
        this->roll = bitwise::rotate::left<std::uint64_t, std::uint8_t>(mix<std::uint64_t>(this->roll, keyboard[index]), 8) * 73;
        keyboard.shuffle();
        length = length + 1;
      } else {
        break;
      }
    }
    std::system("clear");
    length = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &old_tio);
    for (std::uint8_t i = 0; i < 8; i++) {
      this->pool[i] = ((std::uint64_t)nonce[i * 2] << 32) | nonce[(i * 2) + 1];
    }
  }

  std::uint8_t next() noexcept {
    std::uint64_t combined = 0;
    for (std::uint8_t i = 0; i < 8; i++) {
      this->pool[i] = (mix<std::uint64_t>(this->pool[i], this->pool[(i + 1) % 8]) ^ this->roll) * 13;
      combined ^= this->pool[i] * 11;
    }
    this->roll = mix<std::uint64_t>(this->roll, combined) * 7;
    return bitwise::rotate::right<std::uint64_t, std::uint8_t>(this->roll, 59) * 5;
  }
};

struct DataStream {
  private:
  std::uintmax_t size;
  std::vector<std::uint8_t> bytes;
  public:

  DataStream() = default;

  DataStream(std::ifstream& input) noexcept {
    const std::streampos current = input.tellg();
    input.seekg(0, std::ios::end);
    this->size = static_cast<uint64_t>(input.tellg() - current);
    input.seekg(current, std::ios::beg);
    bytes.assign(this->size, 0);
    input.read(reinterpret_cast<char*>(this->bytes.data()), this->size);
  }

  void dump(std::ofstream& output) const noexcept {
    output.write(reinterpret_cast<const char*>(this->bytes.data()), this->size);
  }

  void operator^=(KeyStream& keystream) noexcept {
    for (std::uintmax_t i = 0; i < this->size; i++) {
      this->bytes[i] ^= keystream.next();
    }
  }
};

void cryptic(const std::string directive, const std::string input_name, const std::string output_name) noexcept {
  std::ifstream input(input_name, std::ios::binary);
  const Nonce nonce(directive, input);
  DataStream datastream(input);
  input.close();
  std::ofstream output(output_name, std::ios::binary);
  nonce.dump(directive, output);
  KeyStream keystream(nonce);
  datastream ^= keystream;
  datastream.dump(output);
  output.close();
}

#ifdef MAIN
int main(const int argc, const char* argv[]) {
  if (argc < 4) {
    std::cout << "Usage: " << argv[0] << " <directive> <input> <output>" << std::endl;
    return 1;
  }
  cryptic(argv[1], argv[2], argv[3]);
  return 0;
}
#endif