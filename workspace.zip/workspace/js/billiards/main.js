const BALL_MASS = 0.17;
const BALL_RADIUS = 0.028575;
const POCKET_RADIUS = 0.12;
const SPEED_CAP = 10; // m/s
//
function clamp(value, min, max) {
  if (value < min) {
    return min;
  }
  if (value > max) {
    return max;
  }
  return value;
}
//
//
class Vector {
  //
  constructor(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  //
  get clone() {
    return new Vector(this.x, this.y, this.z);
  }
  //
  copy(vector) {
    this.x = vector.x;
    this.y = vector.y;
    this.z = vector.z;
    return this;
  }
  //
  added(vector) {
    return new Vector(this.x + vector.x, this.y + vector.y, this.z + vector.z);
  }
  //
  add(vector) {
    this.copy(this.added(vector));
    return this;
  }
  //
  subtracted(vector) {
    return new Vector(this.x - vector.x, this.y - vector.y, this.z - vector.z);
  }
  //
  subtract(vector) {
    this.copy(this.subtracted(vector));
    return this;
  }
  //
  multiplied(scalar) {
    return new Vector(this.x * scalar, this.y * scalar, this.z * scalar);
  }
  //
  multiply(scalar) {
    this.copy(this.multiplied(scalar));
    return this;
  }
  //
  divided(scalar) {
    return new Vector(this.x / scalar, this.y / scalar, this.z / scalar);
  }
  //
  divide(scalar) {
    this.copy(this.divided(scalar));
    return this;
  }
  //
  crossed(vector) {
    return new Vector(
      (this.y * vector.z) - (this.z * vector.y),
      (this.z * vector.x) - (this.x * vector.z),
      (this.x * vector.y) - (this.y * vector.x)
    );
  }
  //
  cross(vector) {
    this.copy(this.crossed(vector));
    return this;
  }
  //
  rotated(angle) {
    const sin_angle = Math.sin(angle);
    const cos_angle = Math.cos(angle);
    return new Vector(
      (this.x * cos_angle) - (this.y * sin_angle),
      (this.x * sin_angle) + (this.y * cos_angle),
      this.z
    );
  }
  //
  rotate(angle) {
    this.copy(this.rotated(angle));
    return this;
  }
  //
  get negated() {
    return new Vector(-this.x, -this.y, -this.z);
  }
  //
  negate() {
    this.copy(this.negated);
    return this;
  }
  //
  get magnitude() {
    return Math.sqrt((this.x * this.x) + (this.y * this.y) + (this.z * this.z));
  }
  //
  get angle() {
    return Math.atan2(this.y, this.x);
  }
  //
  toString(precision) {
    return `{ ${this.x.toPrecision(precision)} ${this.y.toPrecision(precision)} ${this.z.toPrecision(precision)} }`;
  }
}
//
//
function dot(a, b) {
  return (a.x * b.x) + (a.y * b.y) + (a.z * b.z);
}
//
//
class Bar {
  //
  constructor(game, color, width, height, left, top, getValue, setValue) {
    //
    this.game = game;
    this.color = color;
    this.width = width;
    this.height = height;
    this.left = left;
    this.top = top;
    this.getValue = getValue;
    this.setValue = setValue;
    //
    this.element = document.createElement("div");
    this.element.className = "Bar";
    this.fill = document.createElement("div");
    this.fill.className = "Fill";
    this.element.appendChild(this.fill);
    this.game.element.appendChild(this.element);
    //
    this.dragging = false;
    this.element.addEventListener("mousedown", (event) => {
      this.dragging = true;
      this.click(event);
    });
    this.element.addEventListener("mousemove", (event) => {
      if (this.dragging) {
        this.click(event);
      }
    });
    window.addEventListener("mouseup", (event) => {
      this.dragging = false;
    });
  }
  //
  click(event) {
    const rect = this.element.getBoundingClientRect();
    const value = 1 - ((event.clientY - rect.top) / rect.height);
    this.setValue(clamp(value, 0, 1));
    this.game.console.clear();
    this.game.console.println(`${(this.getValue() * 100).toPrecision(3)}%`);
  }
  //
  render() {
    this.element.style.width = `${this.width}px`;
    this.element.style.height = `${this.height}px`;
    this.element.style.left = `${this.left}px`;
    this.element.style.top = `${this.top}px`;
    this.fill.style.background = this.color;
    this.fill.style.height = `${clamp(this.getValue(), 0, 1) * 100}%`;
  }
}
//
//
class Slider {
  //
  constructor(game, color, width, height, left, top, getValue, setValue) {
    //
    this.game = game;
    this.color = color;
    this.width = width;
    this.height = height;
    this.left = left;
    this.top = top;
    this.getValue = getValue;
    this.setValue = setValue;
    //
    this.element = document.createElement("div");
    this.element.className = "Slider";
    this.handle = document.createElement("div");
    this.handle.className = "Handle";
    this.element.appendChild(this.handle);
    this.game.element.appendChild(this.element);
    //
    this.dragging = false;
    this.element.addEventListener("mousedown", (event) => {
      this.dragging = true;
      this.click(event);
    });
    this.element.addEventListener("mousemove", (event) => {
      if (this.dragging) {
        this.click(event);
      }
    });
    window.addEventListener("mouseup", (event) => {
      this.dragging = false;
    });
  }
  //
  click(event) {
    const rect = this.element.getBoundingClientRect();
    const value = 1 - ((event.clientY - rect.top) / rect.height);
    this.setValue(clamp(value, 0, 1));
    this.game.console.clear();
    this.game.console.println(`${(this.getValue() * 100).toPrecision(3)}%`);
  }
  //
  render() {
    this.element.style.width = `${this.width}px`;
    this.element.style.height = `${this.height}px`;
    this.element.style.left = `${this.left}px`;
    this.element.style.top = `${this.top}px`;
    this.handle.style.background = this.color;
    this.handle.style.top = `${(1 - clamp(this.getValue(), 0, 1)) * 100}%`;
  }
}
//
//
class Box {
  //
  constructor(game, color, fontSize, fontFamily, width, height, left, top, text = "") {
    //
    this.game = game;
    this.color = color;
    this.fontSize = fontSize;
    this.fontFamily = fontFamily;
    this.width = width;
    this.height = height;
    this.left = left;
    this.top = top;
    //
    this.element = document.createElement("div");
    this.element.className = "Box";
    this.game.element.appendChild(this.element);
    //
    this.print(text);
  }
  //
  render() {
    this.element.style.background = this.color;
    this.element.style.fontSize = `${this.fontSize}px`;
    this.element.style.fontFamily = this.fontFamily;
    this.element.style.width = `${this.width}px`;
    this.element.style.height = `${this.height}px`;
    this.element.style.left = `${this.left}px`;
    this.element.style.top = `${this.top}px`;
  }
  //
  clear() {
    this.element.textContent = "";
  }
  //
  print(text) {
    this.element.textContent += text;
  }
  //
  println(text) {
    this.element.textContent += text + "\n";
  }
}
//
//
class Surface {
  //
  constructor(frictionCoefficient, restitution, point, perpendicular) {
    this.frictionCoefficient = frictionCoefficient;
    this.restitution = restitution;
    this.point = point;
    this.perpendicular = perpendicular;
  }
}
//
//
class Player {
  //
  constructor(name, group) {
    this.name = name;
    this.group = group;
  }
}
//
//
class Ray {
  //
  constructor(table, color, origin, direction, magnitude) {
    this.table = table;
    this.color = color;
    this.origin = origin;
    this.direction = direction;
    this.magnitude = magnitude;
    this.hiding = true;
    this.element = document.createElement("div");
    this.element.className = "Ray";
    this.show();
  }
  //
  show() {
    if (this.hiding) {
      this.table.element.appendChild(this.element);
      this.hiding = false;
    }
  }
  //
  hide() {
    if (!this.hiding) {
      this.element.remove();
      this.hiding = true;
    }
  }
  //
  render() {
    this.element.style.background = this.color;
    this.element.style.width = `${this.magnitude * this.table.scale}px`;
    this.element.style.height = `${0.01 * this.table.scale}px`;
    this.element.style.transform = `translateY(-50%) rotate(${this.direction.angle}rad)`;
    this.element.style.left = `${this.origin.x * this.table.scale}px`;
    this.element.style.top = `${this.origin.y * this.table.scale}px`;
  }
}
//
//
class Ball {
  //
  constructor(table, color, mass, radius, position, velocity) {
    //
    this.table = table;
    this.color = color;
    this.mass = mass;
    this.radius = radius;
    this.position = position;
    this.velocity = velocity;
    this.pocketed = false;
    //
    this.element = document.createElement("div");
    this.element.className = "Ball";
    this.table.element.appendChild(this.element);
    //
    this.element.addEventListener("mousedown", (event) => {
      this.table.game.console.clear();
      this.table.game.console.println(this.color);
      this.table.game.console.println(this.mass);
      this.table.game.console.println(this.radius);
      this.table.game.console.println(this.position.toString(3));
      this.table.game.console.println(this.velocity.toString(3));
    });
  }
  //
  render() {
    this.element.style.background = this.color;
    const size = 2 * this.radius * this.table.scale;
    const shadow = 1 / (1 + this.position.z);
    this.element.style.width = `${size / shadow}px`;
    this.element.style.height = `${size / shadow}px`;
    this.element.style.filter = `drop-shadow(${5 * shadow}px ${5 * shadow}px ${5 * shadow}px rgba(0, 0, 0, ${shadow}))`;
    const left = (this.position.x - this.radius) * this.table.scale;
    const top = (this.position.y - this.position.z) * this.table.scale;
    this.element.style.left = `${left}px`;
    this.element.style.top = `${top}px`;
  }
}
//
//
class Pocket {
  //
  constructor(table, color, radius, position) {
    //
    this.table = table;
    this.color = color;
    this.radius = radius;
    this.position = position;
    //
    this.element = document.createElement("div");
    this.element.className = "Pocket";
    this.table.element.appendChild(this.element);
  }
  //
  render() {
    this.element.style.background = this.color;
    this.element.style.width = `${2 * this.radius * this.table.scale}px`;
    this.element.style.height = `${2 * this.radius * this.table.scale}px`;
    this.element.style.left = `${(this.position.x - this.radius) * this.table.scale}px`;
    this.element.style.top = `${(this.position.y - this.radius) * this.table.scale}px`;
  }
}
//
//
class Table {
  //
  constructor(game, scale, left, top) {
    //
    this.game = game;
    this.scale = scale;
    this.left = left;
    this.top = top;
    //
    this.width = 1.1684;
    this.height = 2.3368;
    this.frictionCoefficient = 0.05;
    this.wallRestitution = 0.9;
    this.floorRestitution = 0.1;
    this.ballRestitution = 0.95;
    this.airDensity = 1.225;
    this.dragCoefficient = 0.47;
    //
    this.moving = null;
    this.evaluated = null;
    this.ballInHand = null;
    this.ply = null;
    this.firstCollision = null;
    this.pocketed = null;
    this.balls = null;
    this.cueBall = null;
    this.eightBall = null;
    this.ray = null;
    //
    this.element = document.createElement("div");
    this.element.className = "Table";
    this.game.element.appendChild(this.element);
    //
    this.playerOne = new Player("Player one", null);
    this.playerTwo = new Player("Player two", null);
    this.currentPlayer = null;
    //
    this.surfaces = [
      new Surface( // left
        0.05,
        0.9,
        new Vector(0, 0, 0),
        new Vector(1, 0, 0)
      ),
      new Surface( // right
        0.05,
        0.9,
        new Vector(this.width, 0, 0),
        new Vector(-1, 0, 0)
      ),
      new Surface( // top
        0.05,
        0.9,
        new Vector(0, 0, 0),
        new Vector(0, 1, 0)
      ),
      new Surface( // bottom
        0.05,
        0.9,
        new Vector(0, this.height, 0),
        new Vector(0, -1, 0)
      ),
      new Surface( // floor
        0.05,
        0.1,
        new Vector(0, 0, 0),
        new Vector(0, 0, 1)
      )
    ];
    //
    this.pockets = [
      new Pocket( // top left
        this,
        "black",
        POCKET_RADIUS,
        new Vector(0, 0, 0)
      ),
      new Pocket( // top right
        this,
        "black",
        POCKET_RADIUS,
        new Vector(this.width, 0, 0)
      ),
      new Pocket( // side left
        this,
        "black",
        POCKET_RADIUS,
        new Vector(-POCKET_RADIUS / 2, this.height / 2, 0)
      ),
      new Pocket( // side right
        this,
        "black",
        POCKET_RADIUS,
        new Vector(this.width + (POCKET_RADIUS / 2), this.height / 2, 0)
      ),
      new Pocket( // bottom left
        this,
        "black",
        POCKET_RADIUS,
        new Vector(0, this.height, 0)
      ),
      new Pocket( // bottom right
        this,
        "black",
        POCKET_RADIUS,
        new Vector(this.width, this.height, 0)
      )
    ];
    //
    this.rack();
    //
    this.dragging = false;
    this.element.addEventListener("mousedown", (event) => {
      this.dragging = true;
      this.click(event);
    });
    this.element.addEventListener("mousemove", (event) => {
      if (this.dragging) {
        this.click(event);
      }
    });
    window.addEventListener("mouseup", (event) => {
      this.dragging = false;
    });
    //
    this.element.addEventListener("dblclick", (event) => {
      if (!this.moving && !this.cueBall.pocketed) {
        this.game.strike();
      }
    });
  }
  //
  click(event) {
    if (!this.cueBall.pocketed) {
      const rect = this.element.getBoundingClientRect();
      const direction = new Vector(
        (event.clientX - rect.left) / this.scale,
        (event.clientY - rect.top) / this.scale,
        0
      );
      direction.subtract(this.cueBall.position);
      direction.divide(direction.magnitude);
      this.game.strikeDir.copy(direction);
    } else if (!this.moving && this.ballInHand) {
      this.setCueBall();
    }
  }
  //
  rack() {
    this.moving = false;
    this.evaluated = true;
    this.ballInHand = true;
    this.ply = 0; // break - 1, becomes break when table.strike is called
    this.firstCollision = null;
    this.pocketed = [];
    this.playerOne.group = null;
    this.playerTwo.group = null;
    this.currentPlayer = this.playerOne;
    if (this.balls != null) {
      for (const ball of this.balls) {
        ball.element.remove();
      }
    }
    this.balls = [];
    const colors = [
      "red", "red", "red", "red", "red", "red",
      "blue", "blue", "blue", "blue", "blue", "blue",
    ];
    for (let i = 0; i < colors.length - 1; i++) { // Fisher-Yates shuffle
      const j = i + Math.floor(Math.random() * (colors.length - i));
      [colors[i], colors[j]] = [colors[j], colors[i]];
    }
    const spacing = (2 * BALL_RADIUS * Math.sqrt(3)) / 2;
    const x0 = this.width / 2;
    const y0 = this.height * 0.25;
    for (let row = 0; row < 5; row++) {
      const count = row + 1;
      const y = y0 - (row * spacing);
      const x = x0 - (((count - 1) * 2 * BALL_RADIUS) / 2);
      for (let i = 0; i < count; i++) {
        const ball = new Ball(
          this,
          "grey",
          BALL_MASS,
          BALL_RADIUS,
          new Vector(x + (i * 2 * BALL_RADIUS), y, BALL_RADIUS),
          new Vector(0, 0, 0)
        );
        if ((row == 2) && (i == 1)) {
          ball.color = "black";
          this.eightBall = ball;
        } else if ((row == 4) && (i == 0)) {
          ball.color = "red";
        } else if ((row == 4) && (i == 4)) {
          ball.color = "blue";
        } else {
          ball.color = colors.pop();
        }
        this.balls.push(ball);
      }
    }
    this.setCueBall();
  }
  //
  setCueBall() {
    if (this.cueBall != null) {
      this.cueBall.element.remove();
    }
    if (this.ray != null) {
      this.ray.element.remove();
    }
    this.cueBall = new Ball(
      this,
      "white",
      BALL_MASS,
      BALL_RADIUS,
      new Vector(this.width / 2, this.height * 0.75, BALL_RADIUS),
      new Vector(0, 0, 0)
    );
    this.balls.push(this.cueBall);
    this.ray = new Ray(
      this,
      this.cueBall.color,
      this.cueBall.position,
      this.game.strikeDir,
      0.5
    );
  }
  //
  get otherPlayer() {
    return (this.currentPlayer === this.playerOne) ? this.playerTwo : this.playerOne;
  }
  //
  strike(velocity) {
    this.game.console.clear();
    this.moving = true;
    this.evaluated = false;
    this.ballInHand = false;
    this.ply++;
    this.firstCollision = null;
    this.pocketed = [];
    this.cueBall.velocity = velocity;
  }
  //
  simulate(timestep) {
    this.moving = false;
    for (let i = 0; i < this.balls.length; i++) {
      // initialization
      const a = this.balls[i];
      const netForce = new Vector(0, 0, 0);
      if (a.velocity.magnitude < 0.01) {
        a.velocity = new Vector(0, 0, 0);
      } else {
        this.moving = true;
      }
      // ball collisions
      for (let j = i + 1; j < this.balls.length; j++) {
        const b = this.balls[j];
        const displacement = b.position.subtracted(a.position);
        const distance = displacement.magnitude;
        if ((distance < (a.radius + b.radius)) && (distance != 0)) {
          const direction = displacement.divided(distance);
          const relativeVelocity = b.velocity.subtracted(a.velocity);
          const normalVelocity = dot(relativeVelocity, direction);
          if (normalVelocity < 0) {
            const impulseMag = (-(1 + this.ballRestitution) * normalVelocity) / ((1 / a.mass) + (1 / b.mass));
            const impulse = direction.multiplied(impulseMag);
            a.velocity.subtract(impulse.divided(a.mass));
            b.velocity.add(impulse.divided(b.mass));
            if (this.firstCollision == null) {
              switch (this.cueBall) {
                case a: this.firstCollision = b; break;
                case b: this.firstCollision = a; break;
              }
            }
          }
        }
      }
      // gravity
      const gravity = new Vector(0, 0, -9.81).multiplied(a.mass);
      netForce.add(gravity);
      // drag
      const speed = a.velocity.magnitude;
      if (speed > 0) {
        const drag = a.velocity.negated.multiplied(
          (this.airDensity * this.dragCoefficient * Math.PI * a.radius * a.radius * speed * speed) / 2
        );
        netForce.add(drag);
      }
      // suface collisions
      for (const surface of this.surfaces) {
        const displacement = a.position.subtracted(surface.point);
        const distance = dot(displacement, surface.perpendicular);
        if (distance < a.radius) {
          // correction
          const penetration = a.radius - distance;
          a.position.add(surface.perpendicular.multiplied(penetration));
          // impulse
          const relativeVelocity = dot(a.velocity, surface.perpendicular);
          const normalVelocity = surface.perpendicular.multiplied(relativeVelocity);
          const tangentialVelocity = a.velocity.subtracted(normalVelocity);
          a.velocity = tangentialVelocity.added(normalVelocity.negated.multiplied(surface.restitution));
          // friction
          const speed = a.velocity.magnitude;
          if (speed > 0) {
            const direction = a.velocity.divided(speed);
            const normalForce = -dot(netForce, surface.perpendicular);
            const friction = direction.negated.multiplied(surface.frictionCoefficient * normalForce);
            netForce.add(friction);
          }
        }
      }
      // integration
      const acceleration = netForce.divided(a.mass);
      a.velocity.add(acceleration.multiplied(timestep));
      a.position.add(a.velocity.multiplied(timestep));
    }
    // pocket collisions
    for (let i = this.balls.length - 1; i >= 0; i--) {
      const ball = this.balls[i];
      for (const pocket of this.pockets) {
        if (pocket.position.subtracted(ball.position).magnitude < pocket.radius) {
          switch (ball) {
            case this.cueBall: this.game.console.println(`${this.currentPlayer.name} pocketed the cue ball`); break;
            case this.eightBall: this.game.console.println(`${this.currentPlayer.name} pocketed the eight ball`); break;
            default: this.game.console.println(`${this.currentPlayer.name} pocketed a ${ball.color} ball`);
          }
          this.pocketed.push(ball);
          this.balls.splice(i, 1);
          ball.pocketed = true;
          ball.element.remove();
        }
      }
    }
  }
  //
  evaluate() {
    if (this.moving || this.evaluated) {
      return;
    }
    let endTurn = false;
    if ((this.ply != 1) && (this.currentPlayer.group == null) && (this.pocketed.length > 0)) {
      const first = this.pocketed[0];
      if ((first !== this.cueBall) && (first !== this.eightBall)) {
        this.currentPlayer.group = first.color;
        this.otherPlayer.group = (first.color == "blue") ? "red" : "blue";
      }
    } else if ((this.pocketed.length == 0) || (this.firstCollision == null)) {
      endTurn = true;
    } else if (this.currentPlayer.group != null) {
      if (this.firstCollision.color != this.currentPlayer.group) {
        endTurn = true;
      }
      let foul = true;
      for (const ball of this.pocketed) {
        if (ball.color == this.currentPlayer.group) {
          foul = false;
          break;
        }
      }
      if (foul) {
        endTurn = true;
      }
    }
    if (this.cueBall.pocketed) {
      this.ballInHand = true;
      endTurn = true;
    }
    if (this.eightBall.pocketed) {
      let win = true;
      if (this.cueBall.pocketed || (this.currentPlayer.group == null)) {
        win = false;        
      } else {
        for (const ball of this.balls) {
          if (ball.color == this.currentPlayer.group) {
            win = false;
            break;
          }
        }
      }
      this.game.console.clear();
      this.game.console.println((win ? this.currentPlayer : this.otherPlayer).name + " wins!");
      this.rack();
      return;
    }
    if (endTurn) {
      this.currentPlayer = this.otherPlayer
    }
    this.evaluated = true;
  }
  //
  render() {
    this.element.style.width = `${this.width * this.scale}px`;
    this.element.style.height = `${this.height * this.scale}px`;
    this.element.style.left = `${this.left}px`;
    this.element.style.top = `${this.top}px`;
    for (const pocket of this.pockets) {
      pocket.render();
    }
    for (const ball of this.balls) {
      ball.render();
    }
    if (!this.cueBall.pocketed) {
      if (this.moving) {
        this.ray.hide();
      } else {
        this.ray.show();
        this.ray.render();
      }
    }
  }
}
//
//
class Game {
  //
  constructor() {
    //
    this.running = false;
    this.last = null;
    this.id = null;
    this.timestep = null;
    this.strikeMag = 0;
    this.strikeDir = new Vector(0, -1, 0); // XY plane
    this.strikeAngle = 0; // Z incline
    //
    this.element = document.createElement("div");
    this.element.id = "Game";
    document.body.appendChild(this.element);
    //
    this.table = new Table(this, 250, 0, 0);
    this.bar = new Bar(
      this,
      "orange",
      (this.table.width * this.table.scale) / 8,
      ((this.table.height * this.table.scale) / 2),
      (this.table.width * this.table.scale) + 10,
      0,
      () => {
        return this.strikeMag;
      },
      (value) => {
        this.strikeMag = value;
      }
    );
    this.slider = new Slider(
      this,
      "orange",
      this.bar.width,
      this.bar.height,
      this.bar.left + this.bar.width + 10,
      0,
      () => {
        return this.strikeAngle;
      },
      (value) => {
        this.strikeAngle = value;
      },
    );
    this.currentPlayerBox = new Box(
      this,
      "white",
      16,
      "monospace",
      this.bar.width + this.slider.width + 10,
      (this.table.height * this.table.scale) / 10,
      this.bar.left,
      this.bar.top + this.bar.height + 10
    );
    this.ballInHandBox = new Box(
      this,
      "green",
      16,
      "monospace",
      this.currentPlayerBox.width,
      this.currentPlayerBox.height,
      this.currentPlayerBox.left,
      this.currentPlayerBox.top + this.currentPlayerBox.height + 10,
      "Ball in hand"
    );
    this.console = new Box(
      this,
      "white",
      11,
      "monospace",
      this.table.width * this.table.scale,
      (this.table.height * this.table.scale) / 5,
      0,
      (this.table.height * this.table.scale) + 10
    );
    //
    window.addEventListener("keydown", (event) => {
      switch (event.key) {
        case "Enter":
          if (!this.table.moving && !this.table.cueBall.pocketed) {
            this.strike();
          } else {
            while (this.table.moving) {
              this.table.simulate(this.timestep);
            }
          }
          break;
        case "ArrowUp":
          this.strikeMag += 0.01;
          if (this.strikeMag > 1) {
            this.strikeMag = 1;
          }
          break;
        case "ArrowDown":
          this.strikeMag -= 0.01;
          if (this.strikeMag < 0) {
            this.strikeMag = 0;
          }
          break;
        case "ArrowLeft":
          this.strikeDir.rotate(-0.01);
          break;
        case "ArrowRight":
          this.strikeDir.rotate(0.01);
          break;
        case "<":
          this.strikeAngle -= 0.01;
          if (this.strikeAngle < 0) {
            this.strikeAngle = 0;
          }
          break;
        case ">":
          this.strikeAngle += 0.01;
          if (this.strikeAngle > 1) {
            this.strikeAngle = 1;
          }
          break;
        case "w":
          if (this.table.ballInHand && ((this.table.cueBall.position.y > (this.table.height * 0.75)) || (this.table.ply != 0))) {
            this.table.cueBall.position.y -= 0.01;
          }
          break;
        case "a":
          if (this.table.ballInHand) {
            this.table.cueBall.position.x -= 0.01;
          }
          break;
        case "s":
          if (this.table.ballInHand) {
            this.table.cueBall.position.y += 0.01;
          }
          break;
        case "d":
          if (this.table.ballInHand) {
            this.table.cueBall.position.x += 0.01;
          }
          break;
        case "r":
          this.table.rack();
          break;
        case "b":
          if (this.table.ballInHand) {
            this.table.setCueBall();
          }
          break;
        case " ":
          this.running ? this.stop() : this.start();
          break;
      }
    });
  }
  //
  strike() {;
    const pitch = (this.strikeAngle * Math.PI) / 2;
    const sin_pitch = Math.sin(pitch);
    const cos_pitch = Math.cos(pitch);
    this.table.strike(new Vector(
      this.strikeDir.x * this.strikeMag * cos_pitch * SPEED_CAP,
      this.strikeDir.y * this.strikeMag * cos_pitch * SPEED_CAP,
      -this.strikeMag * sin_pitch * SPEED_CAP
    ));
  }
  //
  loop(timestamp) {
    if (!this.running) {
      return;
    }
    let timestep = 0;
    if (this.last == null) {
      this.last = timestamp;
    } else {
      timestep = (timestamp - this.last) / 1000;
      this.last = timestamp;
    }
    const SUBSTEPS = 100;
    for (let i = 0; i < SUBSTEPS; i++) {
      this.timestep = timestep / SUBSTEPS;
      this.table.simulate(this.timestep);
    }
    this.table.evaluate();
    if (this.table.currentPlayer.group == null) {
      this.currentPlayerBox.color = "white";
    } else {
      this.currentPlayerBox.color = this.table.currentPlayer.group;
    }
    this.currentPlayerBox.clear();
    this.currentPlayerBox.println(this.table.currentPlayer.name);
    this.ballInHandBox.color = this.table.ballInHand ? "green" : "red";
    this.table.render();
    this.bar.render();
    this.slider.render();
    this.currentPlayerBox.render();
    this.ballInHandBox.render();
    this.console.render();
    this.id = requestAnimationFrame((timestamp) => this.loop(timestamp));
  }
  //
  start() {
    if (this.running) {
      return;
    }
    this.running = true;
    this.last = null;
    this.id = requestAnimationFrame((timestamp) => this.loop(timestamp));
  }
  //
  stop() {
    if (!this.running) {
      return;
    }
    this.running = false;
    if (this.id != null) {
      cancelAnimationFrame(this.id);
      this.id = null;
    }
  }
}
//
//
window.onload = () => {
  for (const id of ["output", "userTextInput", "submitBtn"]) {
    const element = document.getElementById(id);
    if (element != null) {
      element.remove();
    }
  }
  const game = new Game();
  game.start();
}
