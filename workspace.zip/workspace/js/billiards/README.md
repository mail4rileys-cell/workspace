# Objective
  - Make a working physics model of a billiards table and balls
  - Include friction, collisions, spin, etc
  - Expand to 3D if time allows (complete)