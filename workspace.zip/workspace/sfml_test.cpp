#include <SFML/Graphics.hpp>

int main() {
  sf::VideoMode mode({800u, 600u});
  sf::RenderWindow window(mode, "SFML Test");
  sf::CircleShape circle(50.f);
  circle.setFillColor(sf::Color::Blue);
  circle.setPosition({375.f, 275.f});
  while (window.isOpen()) {
    while (auto event = window.pollEvent()) {
      if (event->is<sf::Event::Closed>()) {
        window.close();
      }
    }
    window.clear(sf::Color::Black);
    window.draw(circle);
    window.display();
  }
  return 0;
}
